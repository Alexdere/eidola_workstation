// persist/adapter.js — one interface, three eventual implementations.
//
// v1 is localStorage because it is honest about being v1. SQLite-wasm slots in behind the
// same three methods, and so does the headless runtime's file-backed store. Nothing above
// this file knows which one it is talking to.

export class MemoryAdapter {
  constructor() { this.data = new Map(); }
  async load(key) { return this.data.get(key) ?? null; }
  async save(key, value) { this.data.set(key, value); }
  async clear() { this.data.clear(); }
}

export class LocalStorageAdapter {
  constructor(prefix = 'eidola:') { this.prefix = prefix; }
  async load(key) {
    try { const raw = localStorage.getItem(this.prefix + key); return raw ? JSON.parse(raw) : null; }
    catch { return null; }
  }
  async save(key, value) {
    try { localStorage.setItem(this.prefix + key, JSON.stringify(value)); }
    catch (e) { console.warn('persist failed', e); }
  }
  async clear() {
    for (const k of Object.keys(localStorage)) if (k.startsWith(this.prefix)) localStorage.removeItem(k);
  }
}

/**
 * Cold start budget: paint from cache first, revalidate behind. The last-good value per
 * pane is already in the memo table, so first paint is a read, not a run.
 */
export async function saveWorkspace(adapter, kernel) {
  const snap = kernel.snapshot();
  await adapter.save('store', snap.store);
  await adapter.save('arrangement', snap.arrangement);
  await adapter.save('layout', snap.layout);
  await adapter.save('values', snap.values);
}

export async function loadWorkspace(adapter) {
  return {
    store: await adapter.load('store'),
    arrangement: await adapter.load('arrangement'),
    layout: await adapter.load('layout'),
    values: await adapter.load('values'),
  };
}
