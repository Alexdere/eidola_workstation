// ui/editor.js — editing a pane is editing its node's declared config. Nothing more.
//
// This is deliberately not a "note editor". A note's text, a transform's code, a poll's
// url and interval are all just fields in `config.schema`, so one form covers every node
// that will ever exist — including ones nobody has written yet. A node that declares a
// field gets an editor for free; a node that declares nothing is still summonable and
// still runs. Manifests are hints, not gates.
//
// NOTE on IME and clipboard: the head renders DOM, so real <textarea> elements handle
// composition, selection, dead keys and undo natively. When the cell-grid renderer lands
// that stops being true and the kernel has to own one hidden input it loans to whoever
// holds focus. That is the ~200 lines the transcript was right about — it just isn't due
// yet, and writing it now would be inventing a problem.

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function fieldsOf(def) {
  const schema = def?.config?.schema || {};
  return Object.entries(schema).map(([key, type]) => ({ key, type }));
}

function control(key, type, value) {
  if (type === 'boolean') {
    return `<label class="f row"><input type="checkbox" data-k="${key}" ${value ? 'checked' : ''}><span>${key}</span></label>`;
  }
  if (type === 'number') {
    return `<label class="f"><span>${key}</span><input type="number" data-k="${key}" value="${esc(value)}"></label>`;
  }
  const big = type === 'code' || type === 'text';
  return `<label class="f${big ? ' big' : ''}"><span>${key}</span>
    <textarea data-k="${key}" spellcheck="false" class="${type === 'code' ? 'code' : ''}">${esc(value)}</textarea></label>`;
}

/**
 * Replaces a pane body with a form. Returns a close() that commits and restores.
 * Commit is on close, not per keystroke — otherwise every character would be its own
 * undo step.
 */
export function openEditor(bodyEl, { kernel, pane, def, onClose }) {
  const fields = fieldsOf(def);
  const current = { ...(def.config?.default || {}), ...(pane.config || {}) };

  const exposeUI = pane.parent ? exposeSection(pane, def) : '';
  const hint = fields.length ? '' : `<div class="ehint">this node declares no config. nothing to edit.</div>`;

  bodyEl.innerHTML = `<div class="editor">
    ${fields.map((f) => control(f.key, f.type, current[f.key])).join('')}
    ${hint}${exposeUI}
    <div class="ehint">esc — done · cmd-enter — done</div>
  </div>`;

  const first = bodyEl.querySelector('textarea, input');
  if (first) { first.focus(); if (first.select) first.select(); }

  let closed = false;
  const close = (commit = true) => {
    if (closed) return;
    closed = true;
    if (commit) {
      const next = { ...(pane.config || {}) };
      for (const el of bodyEl.querySelectorAll('[data-k]')) {
        const k = el.dataset.k;
        next[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value;
      }
      kernel.apply({ t: 'set-config', pane: pane.id, config: next });

      const boxes = [...bodyEl.querySelectorAll('[data-expose]')];
      if (boxes.length) {
        const expose = { in: {}, out: {} };
        for (const b of boxes) if (b.checked) expose[b.dataset.dir][b.dataset.expose] = b.dataset.expose;
        const empty = !Object.keys(expose.in).length && !Object.keys(expose.out).length;
        kernel.apply({ t: 'set-expose', pane: pane.id, expose: empty ? null : expose });
      }
    }
    onClose?.();
  };

  // Listen on the form itself, not the pane body — the body outlives the editor, and
  // stacking a listener per edit would leak one every time you opened a pane.
  bodyEl.querySelector('.editor').addEventListener('keydown', (e) => {
    e.stopPropagation();                       // the omnibar must not see these keystrokes
    if (e.key === 'Escape') { e.preventDefault(); close(true); }
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); close(true); }
  });

  return close;
}

/** Public vs private ports on a super pane's boundary. A visibility flag, nothing more. */
function exposeSection(pane, def) {
  const rows = [];
  for (const dir of ['in', 'out']) {
    for (const port of Object.keys(def.ports?.[dir] || {})) {
      const on = !!pane.expose?.[dir]?.[port];
      rows.push(`<label class="f row"><input type="checkbox" data-expose="${port}" data-dir="${dir}" ${on ? 'checked' : ''}>
        <span>${dir} · ${port}</span></label>`);
    }
  }
  if (!rows.length) return '';
  return `<div class="esec">expose through the group boundary</div>${rows.join('')}`;
}
