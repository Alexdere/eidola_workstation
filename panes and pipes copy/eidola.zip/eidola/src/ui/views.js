// ui/views.js — renderers keyed by the node's `view` hint.
// The kernel never reads `view`. Adding a renderer needs no core change; that is the test.

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** Deliberately small. A real markdown node belongs in the store, not in the head. */
function markdown(src) {
  const lines = String(src ?? '').split('\n');
  const out = [];
  let inList = false;
  for (let raw of lines) {
    let line = esc(raw);
    line = line
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|\W)\*([^*]+)\*/g, '$1<em>$2</em>')
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>');
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    const li = line.match(/^\s*[-*]\s+(.*)$/);
    if (li) { if (!inList) { out.push('<ul>'); inList = true; } out.push('<li>' + li[1] + '</li>'); continue; }
    if (inList) { out.push('</ul>'); inList = false; }
    if (h) out.push(`<h${h[1].length}>${h[2]}</h${h[1].length}>`);
    else if (line.trim() === '') out.push('<div class="sp"></div>');
    else out.push('<p>' + line + '</p>');
  }
  if (inList) out.push('</ul>');
  return out.join('');
}

function table(rows) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) return '<div class="empty">no rows</div>';
  const objectRows = typeof list[0] === 'object' && list[0] !== null && !Array.isArray(list[0]);
  const cols = objectRows ? [...new Set(list.flatMap((r) => Object.keys(r || {})))].slice(0, 8) : ['value'];
  const head = '<tr>' + cols.map((c) => `<th>${esc(c)}</th>`).join('') + '</tr>';
  const body = list.slice(0, 200).map((r) => '<tr>' + cols.map((c) => {
    const v = objectRows ? r?.[c] : r;
    return `<td>${esc(typeof v === 'object' ? JSON.stringify(v) : v ?? '')}</td>`;
  }).join('') + '</tr>').join('');
  return `<table>${head}${body}</table>`;
}

function chart(series) {
  const nums = (Array.isArray(series) ? series : []).map(Number).filter((n) => !Number.isNaN(n));
  if (nums.length < 2) return '<div class="empty">needs two points</div>';
  const min = Math.min(...nums), max = Math.max(...nums), span = max - min || 1;
  const pts = nums.map((n, i) => {
    const x = (i / (nums.length - 1)) * 100;
    const y = 100 - ((n - min) / span) * 100;
    return `${x.toFixed(2)},${y.toFixed(2)}`;
  }).join(' ');
  return `<svg class="spark" viewBox="0 0 100 100" preserveAspectRatio="none">
    <polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="1.2" vector-effect="non-scaling-stroke"/>
  </svg><div class="axis"><span>${min}</span><span>${max}</span></div>`;
}

function value(v, cfg = {}) {
  if (v === undefined || v === null) return '<div class="empty">—</div>';
  const text = typeof v === 'object' ? JSON.stringify(v, null, 1) : String(v);
  const big = text.length <= 12;
  return `${cfg.label ? `<div class="vlabel">${esc(cfg.label)}</div>` : ''}
    <div class="${big ? 'vbig' : 'vsmall'}">${esc(text)}${cfg.suffix ? `<span class="vsuf">${esc(cfg.suffix)}</span>` : ''}</div>`;
}

export const VIEWS = {
  markdown: (v) => markdown(v),
  table: (v) => table(v),
  chart: (v) => chart(v),
  value: (v, cfg) => value(v, cfg),
  container: () => '',
};

export function renderView(viewName, v, cfg) {
  return (VIEWS[viewName] || VIEWS.value)(v, cfg || {});
}
