// ui/landscape.js — the ground the whole thing stands on.
//
// Three claims are being made by this file, and they are architectural, not decorative:
//
// 1. GRID RESOLUTION AND PIXEL RESOLUTION ARE SEPARATE. The scene is computed into a small
//    buffer at cell resolution and blitted up with smoothing off. Text stays DOM at device
//    resolution. That is the whole "high resolution TUI" trick: coarse tiles under sharp
//    glyphs. It is also the reason render cost depends on visible cells rather than on how
//    much world exists.
//
// 2. IT IS PROCEDURAL, SO IT SCALES WITH ROOM RATHER THAN STRETCHING. Cell size is fixed in
//    CSS pixels, so a bigger screen gets MORE cells, not larger ones. One monitor and three
//    monitors show the same apparent texture and a wider world. A bitmap could not do this.
//
// 3. DEPTH COMES FROM COLOUR TEMPERATURE, NOT FROM BLUR. Warm advances, cool recedes. That
//    is "infinity focus" taken literally: nothing is ever out of focus, there is no
//    foreground to anchor on, and the eye rests at distance. Attention is signalled by
//    value and saturation — which costs no sharpness, and keeps every pane legible.

export const PALETTE = {
  // cool: distance, air, shadow
  skyHigh: [26, 42, 44],
  skyLow: [44, 66, 62],
  shadow: [18, 34, 42],
  cool: [38, 62, 60],
  // warm: light, nearness, the sun off to one side
  glow: [196, 106, 58],
  ember: [150, 74, 48],
  haze: [214, 146, 84],
  ink: [232, 227, 216],
  accent: [201, 168, 106],
};

const LAYERS = 6;
const DEEP = [10, 20, 26];

// -- deterministic value noise ------------------------------------------------
function hash(x, y, seed) {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 2246822519);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}
const smooth = (t) => t * t * (3 - 2 * t);

function valueNoise(x, seed) {
  const i = Math.floor(x), f = smooth(x - i);
  return hash(i, 0, seed) * (1 - f) + hash(i + 1, 0, seed) * f;
}

function fbm(x, seed, octaves = 4) {
  let sum = 0, amp = 0.5, freq = 1, norm = 0;
  for (let o = 0; o < octaves; o++) {
    sum += valueNoise(x * freq, seed + o * 101) * amp;
    norm += amp;
    amp *= 0.5; freq *= 2.1;
  }
  return sum / norm;
}

const mix = (a, b, t) => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];

export class Landscape {
  constructor({ el, cell = 15, seed = 20260805, palette = PALETTE } = {}) {
    this.cell = cell;
    this.seed = seed;
    this.p = palette;
    this.parallax = { x: 0, y: 0 };

    this.canvas = document.createElement('canvas');
    this.canvas.className = 'landscape';
    el.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d', { alpha: false });

    this.buf = document.createElement('canvas');
    this.bctx = this.buf.getContext('2d', { alpha: false });

    this.grain = this.makeGrain();
    this.resize();
    addEventListener('resize', () => this.resize());
  }

  /** Fine grain at device resolution, tiled. It unifies the coarse tiles so they read as
   *  painterly rather than as compression artefacts. */
  makeGrain() {
    const n = 96;
    const c = document.createElement('canvas');
    c.width = c.height = n;
    const g = c.getContext('2d');
    const img = g.createImageData(n, n);
    for (let i = 0; i < n * n; i++) {
      const v = (hash(i, i * 7, 99) * 255) | 0;
      img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = v;
      img.data[i * 4 + 3] = 16;
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  resize() {
    // Overscan so parallax never exposes an edge.
    const pad = 3;
    this.vw = innerWidth; this.vh = innerHeight;
    this.cw = Math.ceil(innerWidth / this.cell) + pad * 2;
    this.ch = Math.ceil(innerHeight / this.cell) + pad * 2;
    this.pad = pad;
    this.buf.width = this.cw; this.buf.height = this.ch;
    const dpr = Math.min(2, devicePixelRatio || 1);
    this.canvas.width = Math.ceil(innerWidth * dpr);
    this.canvas.height = Math.ceil(innerHeight * dpr);
    this.canvas.style.width = innerWidth + 'px';
    this.canvas.style.height = innerHeight + 'px';
    this.compose();
    this.blit();
  }

  /** Distant things barely move. Feed the canvas pan in and the world gains depth for free. */
  setParallax(x, y) {
    const nx = x * 0.05, ny = y * 0.03;
    if (Math.abs(nx - this.parallax.x) < 0.5 && Math.abs(ny - this.parallax.y) < 0.5) return;
    this.parallax = { x: nx, y: ny };
    this.blit();
  }

  compose() {
    const { cw, ch, p } = this;
    const horizon = Math.round(ch * 0.42);
    const sunX = cw * 0.72;
    const img = this.bctx.createImageData(cw, ch);
    const d = img.data;

    // ridge tops, back to front
    const tops = [];
    for (let l = 0; l < LAYERS; l++) {
      const row = new Float32Array(cw);
      const amp = (ch - horizon) * (0.13 + l * 0.04);
      const base = horizon + (ch - horizon) * (l * 0.185) - amp * 0.5;
      const scale = 0.016 - l * 0.0012;
      // Opposing slopes, so ridgelines cross each other instead of stacking into one ramp.
      // The crossings are what produce the sense of room; a single slope reads as a wall.
      const dir = l % 2 === 0 ? 1 : -1;
      const tilt = dir * (ch - horizon) * (0.44 - l * 0.055);
      for (let x = 0; x < cw; x++) {
        row[x] = base + (fbm(x * scale, this.seed + l * 977, 4) - 0.5) * 2 * amp - (x / cw - 0.5) * tilt;
      }
      tops.push(row);
    }

    for (let y = 0; y < ch; y++) {
      for (let x = 0; x < cw; x++) {
        // which ridge owns this cell? the nearest one whose crest is above it
        let layer = -1;
        for (let l = LAYERS - 1; l >= 0; l--) if (y >= tops[l][x]) { layer = l; break; }

        // warm light falls off with distance from the sun, in both axes
        const dx = Math.abs(x - sunX) / cw;
        const dy = Math.abs(y - horizon) / ch;
        const light = Math.max(0, 1 - dx * 1.25 - dy * 0.85);

        let c;
        if (layer < 0) {
          // sky: cool aloft, warming only as it nears the horizon
          const t = Math.pow(y / horizon, 1.7);
          c = mix(p.skyHigh, p.skyLow, t);
          c = mix(c, p.haze, light * 0.55 * t);
          // cloud banding, quantised like everything else
          const band = fbm(x * 0.04 + y * 0.19, this.seed + 4200, 3);
          const nearH = Math.pow(y / horizon, 3.0);
          c = mix(c, p.glow, Math.max(0, band - 0.52) * light * nearH * 1.6);
        } else {
          const depth = layer / (LAYERS - 1);          // 0 = far, 1 = near
          // A face tilted toward the sun catches it; the next one, tilted away, falls into
          // shadow. Alternating warm and cool bands are what make the depth readable —
          // without the alternation everything blends into a single mass.
          const lit = layer % 2 === 0 ? 1 : 0.16;
          c = mix(p.ember, p.shadow, Math.pow(depth, 0.55));
          c = mix(c, p.glow, light * lit * Math.pow(1 - depth, 1.1) * 0.95);
          c = mix(c, p.cool, (1 - lit * 0.8) * 0.55 + depth * 0.3 * (1 - light * 0.6));
          // a rim of warmth on each crest keeps the staircase readable
          const rim = y - tops[layer][x];
          if (rim < 1.4) c = mix(c, p.haze, 0.18 * light + 0.05);
          c = mix(c, DEEP, Math.pow(y / ch, 2.2) * 0.55);
        }

        // per-cell dither — this is what makes the blocks feel painted rather than posterised
        const j = (hash(x, y, this.seed) - 0.5) * 12;
        const i = (y * cw + x) * 4;
        d[i] = Math.max(0, Math.min(255, c[0] + j));
        d[i + 1] = Math.max(0, Math.min(255, c[1] + j));
        d[i + 2] = Math.max(0, Math.min(255, c[2] + j));
        d[i + 3] = 255;
      }
    }
    this.bctx.putImageData(img, 0, 0);
  }

  blit() {
    const ctx = this.ctx;
    const dpr = Math.min(2, devicePixelRatio || 1);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;              // the whole point
    const ox = -this.pad * this.cell + (this.parallax.x % this.cell);
    const oy = -this.pad * this.cell + (this.parallax.y % this.cell);
    ctx.drawImage(this.buf, 0, 0, this.cw, this.ch, ox, oy, this.cw * this.cell, this.ch * this.cell);
    // grain last, at device resolution, so it never inherits the blockiness
    ctx.imageSmoothingEnabled = true;
    const pat = ctx.createPattern(this.grain, 'repeat');
    ctx.fillStyle = pat;
    ctx.fillRect(0, 0, this.vw, this.vh);
  }

  reseed(seed) { this.seed = seed; this.compose(); this.blit(); }
}
