// ui/menu.js — File · Windows · Network · Session · Help
//
// The mockup's menu bar is making an architectural claim and it is worth honouring rather
// than decorating. "Network" and "Session" in a menu bar means attach/detach — a tmux
// model, not an app model. So Session reports what the runtime is and where it lives, and
// says plainly that no remote runtime exists yet rather than pretending. When the headless
// runtime lands, this menu is where it appears, and nothing else in the head changes.

const fmt = (n) => (n == null ? '—' : String(n));

export class Menu {
  constructor({ kernel, canvas, el }) {
    this.k = kernel;
    this.canvas = canvas;
    this.el = el;
    this.open = null;
    this.render();
    document.addEventListener('pointerdown', (e) => {
      if (!this.el.contains(e.target)) this.close();
    });
  }

  render() {
    this.el.innerHTML = `
      <span class="m" data-menu="file">File</span>
      <span class="m" data-menu="windows">Windows</span>
      <span class="m" data-menu="network">Network</span>
      <span class="m" data-menu="session">Session</span>
      <span class="m help" data-menu="help">Help</span>
      <span class="brand">eidola</span>
      <div class="drop"></div>`;
    this.drop = this.el.querySelector('.drop');
    this.el.addEventListener('pointerdown', (e) => {
      const m = e.target.closest('[data-menu]');
      if (m) { e.preventDefault(); this.toggle(m.dataset.menu, m); return; }
      const item = e.target.closest('[data-do]');
      if (item) { e.preventDefault(); this.run(item.dataset.do, item.dataset.arg); }
    });
  }

  toggle(name, anchor) {
    if (this.open === name) return this.close();
    this.open = name;
    this.drop.innerHTML = this[name]();
    this.drop.style.left = anchor.offsetLeft + 'px';
    this.drop.classList.add('on');
    for (const m of this.el.querySelectorAll('.m')) m.classList.toggle('lit', m.dataset.menu === name);
  }

  close() {
    this.open = null;
    this.drop.classList.remove('on');
    for (const m of this.el.querySelectorAll('.m')) m.classList.remove('lit');
  }

  // ---- panels ------------------------------------------------------------

  file() {
    return this.rows([
      ['new pattern', 'new-pattern'],
      ['export workspace', 'export'],
      ['reseed the landscape', 'reseed'],
      ['—'],
      ['reset everything', 'reset'],
    ]);
  }

  windows() {
    const panes = this.k.arr.panesOf(this.k.arr.activePattern).filter((p) => !p.parent);
    if (!panes.length) return this.note('nothing open. start typing on the landscape.');
    return panes.map((p) => {
      const def = this.k.sched.defOf(p);
      const st = this.k.status(p.id).status;
      return `<div class="row" data-do="focus" data-arg="${p.id}">
        <span class="k">${p.label || def?.name || 'empty'}</span>
        <span class="v s-${st}">${st}${p.residency === 'pinned' ? ' · pinned' : ''}</span>
      </div>`;
    }).join('');
  }

  /** Capabilities are the permission model, so this is the honest place to show them. */
  network() {
    const host = this.k.sched.host;
    const granted = host?.caps || [];
    const netNodes = [...this.k.arr.panes.values()].filter((p) => (this.k.sched.defOf(p)?.caps || []).includes('net'));
    const all = ['net', 'clock', 'vault', 'fs:read', 'fs:write', 'exec', 'browser'];
    const caps = all.map((c) => {
      const on = granted.includes(c);
      const why = on ? '' : c === 'exec' || c.startsWith('fs') ? ' needs a local runtime' : c === 'browser' ? ' needs the browser head' : '';
      return `<div class="row"><span class="k ${on ? 'on' : 'off'}">${on ? '✓' : '·'} ${c}</span><span class="v">${why}</span></div>`;
    }).join('');
    return caps + this.sep() + this.note(`${netNodes.length} pane${netNodes.length === 1 ? '' : 's'} reaching the network`);
  }

  session() {
    const s = this.k.sched;
    const observed = s.observed.size;
    const pinned = [...this.k.arr.panes.values()].filter((p) => p.residency === 'pinned').length;
    return this.rows([
      ['runtime', null, 'local — in this tab'],
      ['store', null, `${this.k.store.defs.size} nodes`],
      ['pattern', null, this.k.arr.patterns.get(this.k.arr.activePattern)?.name || '—'],
      ['observed', null, `${observed} mounted · ${pinned} pinned`],
      ['sources running', null, fmt(s.running.size)],
      ['memo', null, `${s.memoHits} hits / ${s.memoMisses} misses`],
      ['—'],
      ['attach to a runtime…', 'attach', 'no remote runtime yet'],
    ]);
  }

  help() {
    return this.note(`
      <b>there is no bar.</b> start typing on the landscape.<br>
      <k>a word</k> searches your store · <k>a sentence</k> stays a note · <k>&gt;</k> is a command<br>
      <k>enter</k> summons · <k>shift-enter</k> pins that exact version instead of following edits<br>
      <k>arrows</k> move focus by direction, not by tab order<br>
      <k>cmd-p</k> pin so it keeps running when you look away · <k>cmd-b</k> borderless<br>
      <k>backspace</k> remove · <k>cmd-z</k> undo<br>
      <k>drag the header</k> move · <k>drag the ground</k> pan · <k>cmd-scroll</k> zoom`);
  }

  // ---- helpers -----------------------------------------------------------

  rows(list) {
    return list.map(([label, act, hint]) => {
      if (label === '—') return this.sep();
      return `<div class="row${act ? ' act' : ''}"${act ? ` data-do="${act}"` : ''}>
        <span class="k">${label}</span><span class="v">${hint || ''}</span></div>`;
    }).join('');
  }
  sep() { return '<div class="sep"></div>'; }
  note(html) { return `<div class="note">${html}</div>`; }

  run(act, arg) {
    if (act === 'focus') this.canvas.setFocus(arg);
    if (act === 'new-pattern') {
      const p = this.k.apply({ t: 'create-pattern', name: 'pattern ' + (this.k.arr.patterns.size + 1) });
      this.k.apply({ t: 'activate-pattern', id: p.id });
    }
    if (act === 'reseed') this.onReseed?.();
    if (act === 'export') {
      const blob = new Blob([JSON.stringify(this.k.snapshot(), null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'eidola-workspace.json';
      a.click();
    }
    if (act === 'reset') this.onReset?.();
    this.close();
  }
}
