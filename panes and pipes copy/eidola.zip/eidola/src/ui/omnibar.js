// ui/omnibar.js — there is no bar.
//
// You are on the landscape and you type. Characters appear where your cursor is. Results
// arrive around them, nearest first, fading with rank. Keep typing past the point where it
// looks like a search and it becomes a note instead. You were never in a mode.
//
// Against the invariant: this is a pane whose node happens to interpret text. It owns no
// command execution (the kernel does), no index (the store does), no navigation (the canvas
// does). It parses intent and dispatches.

const MAX_RESULTS = 6;

export class Omnibar {
  constructor({ kernel, canvas, root, types }) {
    this.k = kernel;
    this.canvas = canvas;
    this.root = root;
    this.types = types;
    this.open = false;
    this.query = '';
    this.sel = 0;
    this.at = { x: window.innerWidth / 2, y: window.innerHeight / 3 };
    this.el = document.createElement('div');
    this.el.className = 'omni';
    this.el.innerHTML = `<div class="omni-q"><span class="caret">~|</span><span class="omni-text"></span></div><div class="omni-results"></div>`;
    this.root.appendChild(this.el);

    // A resting caret, so the empty landscape invites a keystroke instead of waiting for a
    // shortcut nobody was told about. It is the same prompt, just idle.
    this.rest = document.createElement('div');
    this.rest.className = 'omni-rest';
    this.rest.textContent = '~|';
    this.root.appendChild(this.rest);

    this.bind();
  }

  bind() {
    document.addEventListener('pointermove', (e) => { if (!this.open) this.at = { x: e.clientX, y: e.clientY }; });
    document.addEventListener('keydown', (e) => this.onKey(e));
  }

  onKey(e) {
    const typing = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;
    if (typing) return;

    if (!this.open) {
      if (e.key === 'Escape') {
        // out of the editor, then out of the group, then out of focus. One key, one ladder.
        if (this.canvas.editing) { this.canvas.stopEdit(); return; }
        if (this.canvas.exit()) return;
        this.canvas.setFocus(null);
        return;
      }
      if (e.key === 'Enter' && this.canvas.focus) {
        e.preventDefault();
        this.canvas.activate(this.canvas.focus);
        return;
      }
      if (this.canvas.focus && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.preventDefault();
        this.canvas.moveFocus({ ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[e.key]);
        return;
      }
      if (e.key === 'Backspace' && this.canvas.focus) {
        e.preventDefault();
        this.k.apply({ t: 'delete-pane', pane: this.canvas.focus });
        this.canvas.setFocus(null);
        return;
      }
      if (e.key === 'p' && (e.metaKey || e.ctrlKey) && this.canvas.focus) {
        e.preventDefault();
        const pane = this.k.arr.panes.get(this.canvas.focus);
        this.k.apply({ t: 'set-residency', pane: pane.id, residency: pane.residency === 'pinned' ? 'demand' : 'pinned' });
        return;
      }
      if (e.key === 'b' && (e.metaKey || e.ctrlKey) && this.canvas.focus) {
        e.preventDefault();
        const pane = this.k.arr.panes.get(this.canvas.focus);
        this.k.apply({ t: 'set-borderless', pane: pane.id, value: !pane.borderless });
        return;
      }
      if (e.key === 'z' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); e.shiftKey ? this.k.redo() : this.k.undo(); return; }
      // Any printable character starts the omnibar. No shortcut to remember.
      if (e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
        this.show(e.key);
        e.preventDefault();
      }
      return;
    }

    // open
    if (e.key === 'Escape') { this.hide(); e.preventDefault(); return; }
    if (e.key === 'Backspace') { this.query = this.query.slice(0, -1); if (!this.query) return this.hide(); this.paint(); e.preventDefault(); return; }
    if (e.key === 'ArrowDown') { this.sel = Math.min(this.sel + 1, this.results.length - 1); this.paint(); e.preventDefault(); return; }
    if (e.key === 'ArrowUp') { this.sel = Math.max(0, this.sel - 1); this.paint(); e.preventDefault(); return; }
    if (e.key === 'Enter') { e.preventDefault(); this.commit(e.shiftKey); return; }
    if (e.key.length === 1) { this.query += e.key; this.sel = 0; this.paint(); e.preventDefault(); }
  }

  show(first) {
    this.open = true;
    this.query = first;
    this.sel = 0;
    this.rest.classList.add('gone');
    this.el.classList.add('on');
    this.el.style.left = this.at.x + 'px';
    this.el.style.top = this.at.y + 'px';
    this.paint();
  }

  hide() {
    this.open = false;
    this.query = '';
    this.el.classList.remove('on');
    this.rest.classList.remove('gone');
    this.el.querySelector('.omni-results').innerHTML = '';
  }

  /** The disambiguation is the interaction. Long prose stops being a search. */
  get mode() {
    if (this.query.startsWith('>')) return 'command';
    if (this.query.length > 34 || this.query.includes('\n')) return 'note';
    return 'search';
  }

  paint() {
    this.el.querySelector('.omni-text').textContent = this.query;
    const box = this.el.querySelector('.omni-results');
    if (this.mode === 'note') {
      this.results = [];
      box.innerHTML = `<div class="omni-hint">enter — leave this as a note</div>`;
      return;
    }
    if (this.mode === 'command') {
      this.results = [];
      box.innerHTML = `<div class="omni-hint">${this.commandHint()}</div>`;
      return;
    }
    this.results = this.k.search(this.query, { limit: MAX_RESULTS });
    box.innerHTML = this.results.map((r, i) => `
      <div class="omni-row ${i === this.sel ? 'sel' : ''}" style="--rank:${i}">
        <span class="rname">${r.def.name || r.def.type}</span>
        <span class="rclass ${r.def.class}">${r.def.class}</span>
        <span class="rdesc">${r.def.description || ''}</span>
      </div>`).join('') || `<div class="omni-hint">nothing yet — enter makes it a note</div>`;
  }

  commandHint() {
    const w = this.query.slice(1).trim();
    if (!w) return 'broken · pin · clear · patterns';
    if ('broken'.startsWith(w)) return '> broken — show what is failing';
    if ('clear'.startsWith(w)) return '> clear — remove every pane in this pattern';
    return '> ' + w;
  }

  commit(alt) {
    const at = this.canvas.toWorld(this.at.x, this.at.y);
    if (this.mode === 'command') { this.runCommand(this.query.slice(1).trim()); this.hide(); return; }
    if (this.mode === 'note' || !this.results.length) {
      this.summon(this.types.get('core.note'), { text: this.query }, at, alt);
      this.hide();
      return;
    }
    const def = this.results[this.sel]?.def;
    if (!def) return this.hide();
    const presets = this.k.store.presetsFor(def.hash);
    this.summon(def.hash, presets[0]?.config || {}, at, alt);
    this.hide();
  }

  /** Binding by name follows edits; hold shift to pin the exact version you saw. */
  summon(hash, config, at, pin) {
    const def = this.k.store.get(hash);
    if (!def) return;
    const nodeRef = pin || !def.name ? { kind: 'hash', value: hash } : { kind: 'name', value: def.name };
    // Summon into whatever group you are standing inside. Depth is just a parent id.
    const pane = this.k.apply({ t: 'create-pane', nodeRef, config, parent: this.canvas.container });
    const size = def.view === 'chart' ? { w: 280, h: 140 } : def.view === 'table' ? { w: 340, h: 200 } : { w: 240, h: 130 };
    this.k.apply({ t: 'set-layout', canvas: this.canvas.canvasId, pane: pane.id, box: { x: at.x - 40, y: at.y - 20, ...size } });
    this.canvas.setFocus(pane.id);
  }

  runCommand(word) {
    if (word.startsWith('broken')) {
      const bad = [...this.k.sched.status.entries()].filter(([, s]) => s.status === 'error' || s.status === 'unconfigured');
      if (!bad.length) return;
      this.canvas.setFocus(bad[0][0]);
    } else if (word.startsWith('clear')) {
      for (const p of this.k.arr.panesOf(this.k.arr.activePattern)) this.k.apply({ t: 'delete-pane', pane: p.id });
    }
  }
}
