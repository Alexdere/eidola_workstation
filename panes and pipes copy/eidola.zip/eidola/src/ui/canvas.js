// ui/canvas.js — a lens over the kernel. Owns geometry and nothing else.
//
// The real performance killer in systems like this is re-render fan-out: if every pane
// subscribes to the graph, 1000 panes means 1000 re-renders per change. So every update
// here is surgical — a status event touches one element's class, a dirty event re-pulls
// only the named panes, a layout event moves one box.
//
// The canvas also owns descent into super panes. `path` is a stack of container pane ids;
// what you see is whatever has the current container as its parent. Nesting needed no new
// kernel concept, so it needs no new one here either — just a filter.
import { renderView } from './views.js';
import { openEditor } from './editor.js';

const STATUS_ORDER = ['error', 'unconfigured', 'stale', 'paused', 'active', 'idle'];
const DEFAULT_BOX = { x: 80, y: 80, w: 260, h: 160 };

export class Canvas {
  constructor({ kernel, el, canvasId = 'main' }) {
    this.k = kernel;
    this.el = el;
    this.canvasId = canvasId;
    this.mounted = new Map();          // paneId -> {root, body}
    this.focus = null;
    this.path = [];                    // stack of container pane ids
    this.editing = null;               // {paneId, close}
    this.view = { x: 0, y: 0, z: 1 };

    this.world = document.createElement('div');
    this.world.className = 'world';
    this.wires = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.wires.setAttribute('class', 'wires');
    this.world.appendChild(this.wires);
    this.el.appendChild(this.world);

    this.k.on((ev) => this.onEvent(ev));
    this.bindPointer();
    this.reconcile();
  }

  get container() { return this.path.length ? this.path[this.path.length - 1] : null; }

  // ---- events from the kernel -------------------------------------------

  onEvent(ev) {
    if (ev.type === 'graph') this.reconcile();
    else if (ev.type === 'layout') this.place(ev.pane);
    else if (ev.type === 'status') this.paintStatus(ev.pane);
    else if (ev.type === 'value') this.refresh(ev.pane);
    else if (ev.type === 'dirty') for (const id of ev.panes) this.refresh(id);
  }

  panes() {
    return this.k.arr.panesOf(this.k.arr.activePattern).filter((p) => p.parent === this.container);
  }

  reconcile() {
    const want = new Set(this.panes().map((p) => p.id));
    for (const id of [...this.mounted.keys()]) {
      if (!want.has(id)) { this.mounted.get(id).root.remove(); this.mounted.delete(id); }
    }
    for (const pane of this.panes()) {
      if (!this.mounted.has(pane.id)) this.mount(pane);
      else this.paintChrome(pane.id);
      this.place(pane.id);
      if (this.editing?.paneId !== pane.id) this.refresh(pane.id);
    }
    this.drawWires();
    // Observation includes the containers we are standing inside, so their subgraphs
    // stay live while we are looking at their insides.
    // Reported FROM this canvas. Two canvases over one pattern must not blind each other.
    this.k.apply({ t: 'set-observed', frame: this.canvasId, ids: [...want, ...this.path] });
    this.onPath?.(this.breadcrumb());
  }

  // ---- pane elements -----------------------------------------------------

  mount(pane) {
    const root = document.createElement('div');
    root.className = 'pane';
    root.dataset.pane = pane.id;
    root.tabIndex = 0;
    root.innerHTML = `
      <div class="chrome">
        <span class="dot"></span>
        <span class="title"></span>
        <span class="run" title="trigger">▸</span>
      </div>
      <div class="body"></div>
      <div class="rail in"></div>
      <div class="rail out"></div>
      <div class="grip"></div>`;
    root.addEventListener('pointerdown', (e) => this.onPanePointer(e, pane.id));
    root.addEventListener('dblclick', (e) => { e.preventDefault(); this.activate(pane.id); });
    root.addEventListener('focus', () => this.setFocus(pane.id));
    root.querySelector('.run').addEventListener('pointerdown', (e) => {
      e.stopPropagation(); e.preventDefault();
      this.k.trigger(pane.id);
    });
    this.world.appendChild(root);
    this.mounted.set(pane.id, { root, body: root.querySelector('.body') });
    this.paintChrome(pane.id);
    return root;
  }

  paintChrome(paneId) {
    const m = this.mounted.get(paneId);
    const pane = this.k.arr.panes.get(paneId);
    if (!m || !pane) return;
    const def = this.k.sched.defOf(pane);
    m.root.classList.toggle('borderless', !!pane.borderless);
    m.root.classList.toggle('pinned', pane.residency === 'pinned');
    m.root.classList.toggle('is-container', def?.class === 'container');
    m.root.querySelector('.title').textContent = pane.label || def?.name || 'empty';
    // Only effects and sources can be triggered. Effects show it loudly: the gate is the
    // one policy in the system and it should not be invisible.
    m.root.classList.toggle('triggerable', def?.class === 'effect' || def?.class === 'source');
    m.root.classList.toggle('is-effect', def?.class === 'effect');
    this.paintRails(paneId, def);
    this.paintStatus(paneId);
  }

  paintRails(paneId, def) {
    const m = this.mounted.get(paneId);
    if (!m) return;
    for (const dir of ['in', 'out']) {
      const rail = m.root.querySelector('.rail.' + dir);
      const ports = Object.keys(def?.ports?.[dir] || {});
      rail.innerHTML = ports.map((p) => `<i class="port" data-dir="${dir}" data-port="${p}" title="${p}"></i>`).join('');
    }
  }

  paintStatus(paneId) {
    const m = this.mounted.get(paneId);
    if (!m) return;
    const { status, error } = this.k.status(paneId);
    for (const s of STATUS_ORDER) m.root.classList.remove('s-' + s);
    m.root.classList.add('s-' + status);
    m.root.title = error ? status + ': ' + error : status;
  }

  place(paneId) {
    const m = this.mounted.get(paneId);
    if (!m) return;
    const box = this.k.layout.get(this.canvasId, paneId) || DEFAULT_BOX;
    m.root.style.transform = `translate(${box.x}px, ${box.y}px)`;
    m.root.style.width = (box.w ?? DEFAULT_BOX.w) + 'px';
    m.root.style.height = (box.h ?? DEFAULT_BOX.h) + 'px';
    this.drawWires();
  }

  async refresh(paneId) {
    const m = this.mounted.get(paneId);
    const pane = this.k.arr.panes.get(paneId);
    if (!m || !pane || this.editing?.paneId === paneId) return;
    const def = this.k.sched.defOf(pane);
    if (!def) { m.body.innerHTML = '<div class="prompt">~| unconfigured</div>'; return; }
    if (def.class === 'container') {
      const n = this.k.arr.childrenOf(paneId).length;
      m.body.innerHTML = `<div class="cbody"><span>${n} inside</span><span class="chint">double-click to enter</span></div>`;
      return;
    }
    const port = Object.keys(def.ports?.out || {})[0];
    if (!port) { m.body.innerHTML = ''; return; }
    let v;
    try { v = await this.k.pull(paneId, port); } catch { v = undefined; }
    const html = renderView(def.view, v, { ...(def.config?.default || {}), ...pane.config });
    if (m.lastHtml !== html) { m.body.innerHTML = html; m.lastHtml = html; }
  }

  // ---- descent and editing ------------------------------------------------

  /** Double-click or Enter: a container opens, anything else becomes editable. */
  activate(paneId) {
    const pane = this.k.arr.panes.get(paneId);
    const def = this.k.sched.defOf(pane);
    if (def?.class === 'container') return this.enter(paneId);
    this.edit(paneId);
  }

  enter(paneId) {
    this.stopEdit();
    this.path.push(paneId);
    this.setFocus(null);
    this.reconcile();
  }

  exit() {
    if (!this.path.length) return false;
    this.stopEdit();
    const leaving = this.path.pop();
    this.reconcile();
    this.setFocus(leaving);
    return true;
  }

  breadcrumb() {
    return [{ id: null, label: this.k.arr.patterns.get(this.k.arr.activePattern)?.name || 'home' }]
      .concat(this.path.map((id) => {
        const p = this.k.arr.panes.get(id);
        return { id, label: p?.label || this.k.sched.defOf(p)?.name || 'group' };
      }));
  }

  goToDepth(i) { while (this.path.length > i) this.path.pop(); this.reconcile(); }

  edit(paneId) {
    const m = this.mounted.get(paneId);
    const pane = this.k.arr.panes.get(paneId);
    const def = this.k.sched.defOf(pane);
    if (!m || !def) return;
    this.stopEdit();
    this.setFocus(paneId);
    m.root.classList.add('editing');
    const close = openEditor(m.body, {
      kernel: this.k, pane, def,
      onClose: () => {
        m.root.classList.remove('editing');
        this.editing = null;
        m.lastHtml = null;
        this.refresh(paneId);
        m.root.focus({ preventScroll: true });
      },
    });
    this.editing = { paneId, close };
  }

  stopEdit() { this.editing?.close(true); this.editing = null; }

  // ---- wires ---------------------------------------------------------------

  portPoint(paneId, dir, port) {
    const box = this.k.layout.get(this.canvasId, paneId) || DEFAULT_BOX;
    const pane = this.k.arr.panes.get(paneId);
    const def = this.k.sched.defOf(pane);
    const ports = Object.keys(def?.ports?.[dir] || {});
    const i = Math.max(0, ports.indexOf(port));
    const h = box.h ?? DEFAULT_BOX.h;
    const y = box.y + 26 + (h - 26) * ((i + 0.5) / Math.max(1, ports.length));
    return { x: dir === 'out' ? box.x + (box.w ?? DEFAULT_BOX.w) : box.x, y };
  }

  curve(a, b) {
    const dx = Math.max(38, Math.abs(b.x - a.x) * 0.42);
    return `M${a.x},${a.y} C${a.x + dx},${a.y} ${b.x - dx},${b.y} ${b.x},${b.y}`;
  }

  drawWires() {
    const visible = new Set(this.mounted.keys());
    const parts = [];
    for (const w of this.k.arr.wiresOf(this.k.arr.activePattern)) {
      if (!visible.has(w.from.pane) || !visible.has(w.to.pane)) continue;
      const a = this.portPoint(w.from.pane, 'out', w.from.port);
      const b = this.portPoint(w.to.pane, 'in', w.to.port);
      parts.push(`<path class="w" data-wire="${w.id}" d="${this.curve(a, b)}"/>`);
    }
    if (this.temp) parts.push(`<path class="w temp" d="${this.temp}"/>`);
    this.wires.innerHTML = parts.join('');
  }

  /** Drag out-port to in-port. Clicking a connected in-port disconnects it. */
  startWire(e, paneId, port) {
    e.preventDefault(); e.stopPropagation();
    const a = this.portPoint(paneId, 'out', port);
    const move = (ev) => {
      const p = this.toWorld(ev.clientX, ev.clientY);
      this.temp = this.curve(a, p);
      this.drawWires();
    };
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      this.temp = null;
      const target = document.elementFromPoint(ev.clientX, ev.clientY);
      const port2 = target?.closest?.('.port[data-dir="in"]');
      const pane2 = target?.closest?.('.pane');
      if (port2 && pane2 && pane2.dataset.pane !== paneId) {
        const existing = this.k.arr.wireInto(pane2.dataset.pane, port2.dataset.port);
        if (existing) this.k.apply({ t: 'unwire', id: existing.id });
        this.k.apply({
          t: 'wire',
          from: { pane: paneId, port },
          to: { pane: pane2.dataset.pane, port: port2.dataset.port },
        });
      } else this.drawWires();
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  }

  // ---- interaction ---------------------------------------------------------

  setFocus(paneId) {
    if (this.focus === paneId) return;
    const prev = this.mounted.get(this.focus);
    if (prev) prev.root.classList.remove('focused');
    this.focus = paneId;
    const next = this.mounted.get(paneId);
    if (next) { next.root.classList.add('focused'); next.root.focus({ preventScroll: true }); }
  }

  /**
   * Spatial movement. Tab order is meaningless on a plane, so focus moves by direction:
   * take the nearest pane whose centre lies in that half-plane.
   */
  moveFocus(dir) {
    const boxes = [...this.mounted.keys()].map((id) => {
      const b = this.k.layout.get(this.canvasId, id) || DEFAULT_BOX;
      return { id, cx: b.x + (b.w ?? DEFAULT_BOX.w) / 2, cy: b.y + (b.h ?? DEFAULT_BOX.h) / 2 };
    });
    if (!boxes.length) return;
    const cur = boxes.find((b) => b.id === this.focus) || boxes[0];
    if (!this.focus) return this.setFocus(cur.id);
    const axis = dir === 'left' || dir === 'right' ? 'cx' : 'cy';
    const sign = dir === 'right' || dir === 'down' ? 1 : -1;
    const cands = boxes.filter((b) => b.id !== cur.id && Math.sign(b[axis] - cur[axis]) === sign);
    if (!cands.length) return;
    const cross = axis === 'cx' ? 'cy' : 'cx';
    cands.sort((a, b) =>
      (Math.abs(a[axis] - cur[axis]) + Math.abs(a[cross] - cur[cross]) * 2) -
      (Math.abs(b[axis] - cur[axis]) + Math.abs(b[cross] - cur[cross]) * 2));
    this.setFocus(cands[0].id);
  }

  onPanePointer(e, paneId) {
    const portEl = e.target.closest?.('.port');
    if (portEl) {
      if (portEl.dataset.dir === 'out') return this.startWire(e, paneId, portEl.dataset.port);
      const existing = this.k.arr.wireInto(paneId, portEl.dataset.port);
      if (existing) { e.preventDefault(); e.stopPropagation(); this.k.apply({ t: 'unwire', id: existing.id }); }
      return;
    }
    this.setFocus(paneId);
    if (this.editing?.paneId === paneId) return;          // let the form have its clicks
    const resizing = e.target.classList.contains('grip');
    if (!resizing && !e.target.closest('.chrome')) return; // only the chrome drags
    const start = this.k.layout.get(this.canvasId, paneId) || DEFAULT_BOX;
    const ox = e.clientX, oy = e.clientY;
    e.preventDefault();
    const move = (ev) => {
      const dx = (ev.clientX - ox) / this.view.z, dy = (ev.clientY - oy) / this.view.z;
      const box = resizing
        ? { w: Math.max(120, (start.w ?? DEFAULT_BOX.w) + dx), h: Math.max(70, (start.h ?? DEFAULT_BOX.h) + dy) }
        : { x: start.x + dx, y: start.y + dy };
      // Layout commands never enter the undo stack and never dirty the graph.
      this.k.apply({ t: 'set-layout', canvas: this.canvasId, pane: paneId, box });
    };
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  }

  bindPointer() {
    this.el.addEventListener('pointerdown', (e) => {
      if (e.target !== this.el && e.target !== this.world && !e.target.closest('.wires')) return;
      this.stopEdit();
      this.setFocus(null);
      const ox = e.clientX, oy = e.clientY, sx = this.view.x, sy = this.view.y;
      const move = (ev) => {
        this.view.x = sx + (ev.clientX - ox);
        this.view.y = sy + (ev.clientY - oy);
        this.applyView();
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    });
    this.el.addEventListener('wheel', (e) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      this.view.z = Math.min(2.5, Math.max(0.3, this.view.z * (e.deltaY > 0 ? 0.92 : 1.08)));
      this.applyView();
    }, { passive: false });
  }

  applyView() {
    this.world.style.transform = `translate(${this.view.x}px, ${this.view.y}px) scale(${this.view.z})`;
    // The ground moves a twentieth as far as the panes do. Distance, for free.
    this.onView?.(this.view);
  }

  /** Screen point -> world point, so a summoned pane lands where you were typing. */
  toWorld(clientX, clientY) {
    const r = this.el.getBoundingClientRect();
    return { x: (clientX - r.left - this.view.x) / this.view.z, y: (clientY - r.top - this.view.y) / this.view.z };
  }
}
