// app/main.js — boot. The only file that knows both a kernel and a screen exist.
import { NodeStore } from '../kernel/store.js';
import { Arrangement, LayoutStore } from '../kernel/arrangement.js';
import { Kernel } from '../kernel/kernel.js';
import { WorkerHost } from '../runtime/host.js';
import { installCoreNodes } from '../nodes/core.js';
import { Canvas } from '../ui/canvas.js';
import { Omnibar } from '../ui/omnibar.js';
import { Landscape } from '../ui/landscape.js';
import { Menu } from '../ui/menu.js';
import { LocalStorageAdapter, saveWorkspace, loadWorkspace } from '../persist/adapter.js';

const adapter = new LocalStorageAdapter();
const saved = await loadWorkspace(adapter);

const store = saved.store ? NodeStore.fromJSON(saved.store) : new NodeStore();
const arrangement = saved.arrangement ? Arrangement.fromJSON(saved.arrangement) : new Arrangement();
const layout = saved.layout ? LayoutStore.fromJSON(saved.layout) : new LayoutStore();

// User script never runs on the main thread, so a runaway loop cannot freeze the screen.
const host = new WorkerHost({ caps: ['net', 'clock'], timeoutMs: 4000 });

const kernel = new Kernel({ store, arrangement, layout, host });
const types = installCoreNodes(kernel.store);

// The ground is drawn before anything is computed. Cold start should paint, then think.
const seed = (await adapter.load('seed')) ?? 20260805;
const landscape = new Landscape({ el: document.body, seed });

const canvas = new Canvas({ kernel, el: document.getElementById('stage'), canvasId: 'main' });
canvas.onView = (v) => landscape.setParallax(v.x, v.y);

const omni = new Omnibar({ kernel, canvas, root: document.getElementById('overlay'), types });

// Breadcrumb: only appears once you have descended into something.
const crumb = document.getElementById('crumb');
canvas.onPath = (path) => {
  crumb.classList.toggle('top', path.length < 2);
  crumb.innerHTML = path.map((c, i) => `<span data-depth="${i}">${c.label}</span>`).join('<span>/</span>');
};
crumb.addEventListener('pointerdown', (e) => {
  const d = e.target.dataset?.depth;
  if (d != null) canvas.goToDepth(Number(d));
});

const menu = new Menu({ kernel, canvas, el: document.getElementById('menu') });
menu.onReset = () => adapter.clear().then(() => location.reload());
menu.onReseed = () => {
  const s = Math.floor(Math.random() * 1e9);
  landscape.reseed(s);
  adapter.save('seed', s);
};

// ---- first launch -----------------------------------------------------------
// Quiet in a way that feels ready, not empty in a way that feels broken.
if (!arrangement.panes.size) {
  const place = (pane, box) => kernel.apply({ t: 'set-layout', canvas: 'main', pane: pane.id, box });
  const ref = (type) => ({ kind: 'hash', value: types.get(type) });

  const clock = kernel.apply({ t: 'create-pane', nodeRef: ref('core.clock'), config: { intervalMs: 1000 }, borderless: true, residency: 'pinned' });
  place(clock, { x: 118, y: 470, w: 200, h: 84 });

  const note = kernel.apply({
    t: 'create-pane', nodeRef: ref('core.note'), borderless: true,
    config: { text: '**start typing anywhere.**\n\n- a word finds a node\n- a sentence stays a note\n- `>` is a command\n\narrows move between panes.\n`cmd-p` pins one so it keeps running\nwhen you look away.' },
  });
  place(note, { x: 118, y: 560, w: 330, h: 220 });

  const ticker = kernel.apply({ t: 'create-pane', nodeRef: ref('core.js.transform'), label: 'seconds', config: { code: 'return (input % 60000) / 1000 | 0;' } });
  place(ticker, { x: 560, y: 480, w: 200, h: 110 });
  kernel.apply({ t: 'wire', from: { pane: clock.id, port: 'time' }, to: { pane: ticker.id, port: 'in' } });
}

// ---- persistence ------------------------------------------------------------
let saveTimer = null;
kernel.on(() => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveWorkspace(adapter, kernel), 400);
});

// A second lens over the same pattern, to make the point that the graph is the document.
window.eidola = {
  kernel, canvas, omni, menu, landscape, types,
  secondCanvas(el) { return new Canvas({ kernel, el: el || document.getElementById('stage'), canvasId: 'second' }); },
};
