// runtime/caps.js — one declaration, three jobs: permission prompt, sandbox config, scheduler hint.
// A capability absent from the manifest is simply not a property on ctx. There is nothing to bypass.

export const ALL_CAPS = ['net', 'clock', 'vault', 'fs:read', 'fs:write', 'exec', 'browser', 'agent'];

/** 'secret:github' is a capability like any other, so the install prompt shows it.
 *  A weather node asking for net is reasonable; asking for secret:email is instantly suspect. */
export const isSecretCap = (c) => typeof c === 'string' && c.startsWith('secret:');

/** pure means pure: no ambient state, ever, regardless of what the manifest asks for. */
export function grantedCaps(def, hostCaps) {
  const asked = def.caps || [];
  if (def.class === 'pure') return [];
  return asked.filter((c) => hostCaps.includes(c) || (isSecretCap(c) && hostCaps.includes('secret')));
}

export function buildCtx(def, req, granted, sink) {
  const ctx = {
    config: Object.freeze({ ...(req.config || {}) }),
    log: (...a) => sink.logs.push(a.map(String).join(' ')),
    signal: req.signal,
  };
  if (def.class !== 'pure') ctx.state = req.state ?? {};
  // now() is injected, never Date.now(). That is what makes the source journal replayable.
  if (granted.includes('clock')) ctx.now = () => req.now;
  // Secrets arrive as a lookup, resolved by the runtime, never as a value on config.
  const secretNames = granted.filter(isSecretCap).map((c) => c.slice(7));
  if (secretNames.length && req.resolveSecret) {
    ctx.secret = (name) => (secretNames.includes(name) ? req.resolveSecret(name) : undefined);
  }
  if (granted.includes('net')) {
    ctx.fetch = (url, opts = {}) => fetch(url, { ...opts, signal: req.signal });
  }
  return ctx;
}
