// runtime/worker.js — sandboxed execution. Only what the manifest declared exists here.
import { grantedCaps, buildCtx } from './caps.js';

const compiled = new Map();

self.onmessage = async (e) => {
  const { id, def, req, hostCaps } = e.data;
  const sink = { logs: [] };
  try {
    let fn = compiled.get(def.hash);
    if (!fn) {
      fn = new Function('inputs', 'ctx', `"use strict";\n${def.source}`);
      compiled.set(def.hash, fn);
    }
    const granted = grantedCaps(def, hostCaps);
    const ctx = buildCtx(def, req, granted, sink);
    const outputs = await Promise.resolve(fn(req.inputs || {}, ctx));
    self.postMessage({ id, ok: true, outputs: outputs || {}, state: ctx.state, logs: sink.logs });
  } catch (err) {
    self.postMessage({ id, ok: false, err: String(err?.message || err), logs: sink.logs });
  }
};
