// runtime/host.js — the execution host. Swappable: Local (node + tests), Worker (browser).
// Adding Python later is adding a host, not changing the kernel. That is the whole point.
import { grantedCaps, buildCtx } from './caps.js';

export class LocalHost {
  constructor({ caps = ['net', 'clock'], timeoutMs = 5000 } = {}) {
    this.caps = caps;
    this.timeoutMs = timeoutMs;
    this.compiled = new Map();
    this.executions = 0;
    this.byType = new Map();
  }

  compile(def) {
    let fn = this.compiled.get(def.hash);
    if (!fn) {
      // eslint-disable-next-line no-new-func
      fn = new Function('inputs', 'ctx', `"use strict";\n${def.source}`);
      this.compiled.set(def.hash, fn);
    }
    return fn;
  }

  async execute(def, req) {
    this.executions++;
    this.byType.set(def.type, (this.byType.get(def.type) || 0) + 1);
    const sink = { logs: [] };
    const granted = grantedCaps(def, this.caps);
    const ctx = buildCtx(def, req, granted, sink);
    const fn = this.compile(def);
    const outputs = await Promise.race([
      Promise.resolve(fn(req.inputs || {}, ctx)),
      new Promise((_, rej) => {
        const t = setTimeout(() => rej(new Error('timeout after ' + this.timeoutMs + 'ms')), this.timeoutMs);
        req.signal?.addEventListener?.('abort', () => { clearTimeout(t); rej(new Error('aborted')); });
      }),
    ]);
    return { outputs: outputs || {}, state: ctx.state, logs: sink.logs };
  }

  dispose() {}
}

/**
 * Browser host. User script never touches the main thread, so a runaway loop cannot
 * block the UI — the worker is terminated and replaced.
 */
export class WorkerHost {
  constructor({ caps = ['net', 'clock'], timeoutMs = 5000, url } = {}) {
    this.caps = caps;
    this.timeoutMs = timeoutMs;
    this.url = url || new URL('./worker.js', import.meta.url);
    this.seq = 0;
    this.pending = new Map();
    this.executions = 0;
    this.byType = new Map();
    this.spawn();
  }

  spawn() {
    this.worker = new Worker(this.url, { type: 'module' });
    this.worker.onmessage = (e) => {
      const { id, ok, outputs, state, logs, err } = e.data || {};
      const p = this.pending.get(id);
      if (!p) return;
      this.pending.delete(id);
      clearTimeout(p.timer);
      ok ? p.resolve({ outputs, state, logs }) : p.reject(new Error(err));
    };
    this.worker.onerror = (e) => this.failAll(new Error(e.message || 'worker error'));
  }

  failAll(err) {
    for (const p of this.pending.values()) { clearTimeout(p.timer); p.reject(err); }
    this.pending.clear();
  }

  /** Kill a runaway script mid-compute. The UI never blocks because it was never involved. */
  restart(reason) {
    try { this.worker.terminate(); } catch {}
    this.failAll(new Error(reason));
    this.spawn();
  }

  execute(def, req) {
    this.executions++;
    this.byType.set(def.type, (this.byType.get(def.type) || 0) + 1);
    const id = ++this.seq;
    const payload = {
      id,
      def: { hash: def.hash, class: def.class, caps: def.caps, source: def.source },
      req: { inputs: req.inputs || {}, config: req.config || {}, state: req.state, now: req.now },
      hostCaps: this.caps,
    };
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        this.restart('script exceeded ' + this.timeoutMs + 'ms and was terminated');
        reject(new Error('timeout'));
      }, this.timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      req.signal?.addEventListener?.('abort', () => {
        const p = this.pending.get(id);
        if (p) { clearTimeout(p.timer); this.pending.delete(id); p.reject(new Error('aborted')); }
      });
      this.worker.postMessage(payload);
    });
  }

  dispose() { try { this.worker.terminate(); } catch {} }
}
