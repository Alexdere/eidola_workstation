// nodes/core.js — the starting library. Every one of these is an ordinary store entry.
// If any of them needed special support from the kernel, the node contract would be wrong.

export const CORE_NODES = [
  {
    name: 'clock', type: 'core.clock', class: 'source', caps: ['clock'], view: 'value',
    description: 'ticks. the entry point for time. nothing else may call Date.now()',
    tags: ['time', 'source'],
    ports: { in: {}, out: { time: { schema: 'number' }, text: { schema: 'text' } } },
    config: { schema: { intervalMs: 'number' }, default: { intervalMs: 1000 } },
    source: `
      const t = ctx.now();
      const d = new Date(t);
      const pad = (n) => String(n).padStart(2, '0');
      return { time: t, text: pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) };
    `,
  },
  {
    name: 'http poll', type: 'core.http.poll', class: 'source', caps: ['net', 'clock'], view: 'value',
    description: 'fetch a url on a schedule. the generic connector behind most things',
    tags: ['net', 'api', 'fetch', 'source'],
    ports: { in: {}, out: { body: { schema: 'json' }, status: { schema: 'number' } } },
    config: { schema: { url: 'text', intervalMs: 'number', json: 'boolean' }, default: { url: '', intervalMs: 900000, json: true } },
    source: `
      if (!ctx.config.url) return {};
      const r = await ctx.fetch(ctx.config.url);
      const body = ctx.config.json ? await r.json() : await r.text();
      return { body, status: r.status, at: ctx.now() };
    `,
  },
  {
    name: 'transform', type: 'core.js.transform', class: 'pure', caps: [], view: 'value',
    description: 'your code. takes input, returns output. no clock, no network — those arrive as inputs',
    tags: ['code', 'js', 'pure'],
    ports: { in: { in: { schema: 'any' } }, out: { out: { schema: 'any' } } },
    config: { schema: { code: 'code' }, default: { code: 'return input;' } },
    source: `
      const f = new Function('input', 'config', ctx.config.code || 'return input;');
      return { out: f(inputs.in, ctx.config) };
    `,
  },
  {
    name: 'json path', type: 'core.json.path', class: 'pure', caps: [], view: 'value',
    description: 'pull one value out of a structure. a.b[0].c',
    tags: ['json', 'extract', 'pure'],
    ports: { in: { in: { schema: 'json' } }, out: { out: { schema: 'any' } } },
    config: { schema: { path: 'text' }, default: { path: '' } },
    source: `
      let v = inputs.in;
      const path = String(ctx.config.path || '');
      if (!path) return { out: v };
      for (const seg of path.replace(/\\[(\\d+)\\]/g, '.$1').split('.')) {
        if (!seg) continue;
        if (v == null) return { out: undefined };
        v = v[seg];
      }
      return { out: v };
    `,
  },
  {
    name: 'note', type: 'core.note', class: 'pure', caps: [], view: 'markdown',
    description: 'words on the ground. text lives in config, so it is diffable and content-addressed',
    tags: ['note', 'text', 'write'],
    ports: { in: {}, out: { text: { schema: 'text/markdown' } } },
    config: { schema: { text: 'text' }, default: { text: '' } },
    source: `return { text: ctx.config.text || '' };`,
  },
  {
    name: 'markdown', type: 'core.view.markdown', class: 'pure', caps: [], view: 'markdown',
    description: 'renders text. a view is an identity node carrying a hint — the core has no view system',
    tags: ['view', 'markdown', 'read'],
    ports: { in: { text: { schema: 'text/markdown' } }, out: { text: { schema: 'text/markdown' } } },
    config: { schema: {}, default: {} },
    source: `return { text: inputs.text == null ? '' : String(inputs.text) };`,
  },
  {
    name: 'table', type: 'core.view.table', class: 'pure', caps: [], view: 'table',
    description: 'rows and columns from any array',
    tags: ['view', 'table', 'rows'],
    ports: { in: { rows: { schema: 'table' } }, out: { rows: { schema: 'table' } } },
    config: { schema: { limit: 'number' }, default: { limit: 50 } },
    source: `
      const rows = Array.isArray(inputs.rows) ? inputs.rows : (inputs.rows == null ? [] : [inputs.rows]);
      return { rows: rows.slice(0, ctx.config.limit || 50) };
    `,
  },
  {
    name: 'chart', type: 'core.view.chart', class: 'pure', caps: [], view: 'chart',
    description: 'a line over numbers. accepts numbers, or objects with a value key',
    tags: ['view', 'chart', 'graph', 'sparkline'],
    ports: { in: { series: { schema: 'number[]' } }, out: { series: { schema: 'number[]' } } },
    config: { schema: { key: 'text' }, default: { key: '' } },
    source: `
      const raw = Array.isArray(inputs.series) ? inputs.series : [];
      const key = ctx.config.key;
      return { series: raw.map((v) => Number(key && v && typeof v === 'object' ? v[key] : v)).filter((n) => !Number.isNaN(n)) };
    `,
  },
  {
    name: 'value', type: 'core.view.value', class: 'pure', caps: [], view: 'value',
    description: 'one number or word, large. the gauge',
    tags: ['view', 'value', 'gauge'],
    ports: { in: { value: { schema: 'any' } }, out: { value: { schema: 'any' } } },
    config: { schema: { label: 'text', suffix: 'text' }, default: { label: '', suffix: '' } },
    source: `return { value: inputs.value };`,
  },
  {
    name: 'group', type: 'core.container', class: 'container', caps: [], view: 'container',
    description: 'a pane containing panes. from outside it is one node with ports',
    tags: ['container', 'super', 'group', 'room'],
    ports: { in: {}, out: {} },
    config: { schema: {}, default: {} },
    source: '',
  },
  {
    name: 'append', type: 'core.effect.append', class: 'effect', caps: [], view: 'table',
    description: 'writes. never auto-cooks — requires an explicit trigger. the only policy in the system',
    tags: ['effect', 'write', 'log', 'collect'],
    ports: { in: { item: { schema: 'any' } }, out: { items: { schema: 'table' } } },
    config: { schema: { max: 'number' }, default: { max: 100 } },
    source: `
      const items = Array.isArray(ctx.state.items) ? ctx.state.items : [];
      if (inputs.item !== undefined) items.push(inputs.item);
      ctx.state.items = items.slice(-(ctx.config.max || 100));
      return { items: ctx.state.items };
    `,
  },
];

/** Presets belong to the node, not the pane. A large library is worse than a small one
 *  if every summon costs a setup. */
export const CORE_PRESETS = [
  {
    node: 'core.http.poll', name: 'weather',
    config: { url: 'https://api.open-meteo.com/v1/forecast?latitude=59.91&longitude=10.75&current=temperature_2m', intervalMs: 900000, json: true },
  },
  {
    node: 'core.http.poll', name: 'hacker news top',
    config: { url: 'https://hacker-news.firebaseio.com/v0/topstories.json', intervalMs: 300000, json: true },
  },
];

export function installCoreNodes(store) {
  const byType = new Map();
  for (const def of CORE_NODES) byType.set(def.type, store.put(def));
  for (const p of CORE_PRESETS) {
    const hash = byType.get(p.node);
    if (hash) store.addPreset(hash, p.name, p.config);
  }
  return byType;
}
