// kernel/arrangement.js — patterns, panes, wires.
// A pattern is a latent recipe: which nodes, bound how, wired how. Activating it assembles nothing new.
// A pane is a BINDING SITE. It has no compute, no geometry, no children of its own beyond a parent link.
import { uid, stable } from './ids.js';

/** @typedef {'demand'|'pinned'} Residency */

export function makePane(patternId, opts = {}) {
  return {
    id: opts.id || uid('pane'),
    patternId,
    parent: opts.parent || null,        // super pane containment. Nesting is a self-reference, not a second table.
    nodeRef: opts.nodeRef || null,      // {kind:'hash'|'name', value} — null = unconfigured, the empty prompt
    stateKey: opts.stateKey || uid('st'), // same key in two panes = ref (shared state). Distinct = instance.
    config: opts.config || {},          // overlay on the node's defaults — PUBLIC, enters the cache key
    flavourRef: opts.flavourRef || null, // where and how to connect. Public, shareable, IN the cache key.
    secretRef: opts.secretRef || null,   // as whom. Never in a hash, a log, or a snapshot.
    residency: opts.residency || 'demand',
    surface: opts.surface || 'cells',   // 'cells' | 'raster' | 'dom' — dom cannot render headless or remote
    borderless: opts.borderless ?? false,
    label: opts.label || '',
    expose: opts.expose || null,        // {in:{innerPort:outerPort}, out:{outerPort:innerPort}} on a super pane's child
  };
}

export class Arrangement {
  constructor() {
    this.patterns = new Map();
    this.panes = new Map();
    this.wires = new Map();
    this.activePattern = null;
  }

  createPattern(name, id = uid('pat')) {
    const p = { id, name };
    this.patterns.set(id, p);
    if (!this.activePattern) this.activePattern = id;
    return p;
  }

  addPane(pane) { this.panes.set(pane.id, pane); return pane; }

  removePane(id) {
    for (const child of this.childrenOf(id)) this.removePane(child.id);
    for (const w of [...this.wires.values()]) {
      if (w.from.pane === id || w.to.pane === id) this.wires.delete(w.id);
    }
    const pane = this.panes.get(id);
    this.panes.delete(id);
    return pane;
  }

  // kind: 'value' (latest-wins, safe to drop) | 'event' (each one matters, queued)
  //       | 'trigger' (intent, not data)
  addWire(patternId, from, to, id = uid('w'), kind = 'value') {
    const w = { id, patternId, from, to, kind };
    this.wires.set(id, w);
    return w;
  }

  removeWire(id) { const w = this.wires.get(id); this.wires.delete(id); return w; }

  panesOf(patternId) { return [...this.panes.values()].filter((p) => p.patternId === patternId); }
  childrenOf(paneId) { return [...this.panes.values()].filter((p) => p.parent === paneId); }
  roots(patternId) { return this.panesOf(patternId).filter((p) => !p.parent); }
  wiresOf(patternId) { return [...this.wires.values()].filter((w) => w.patternId === patternId); }
  wireInto(paneId, port) { return [...this.wires.values()].find((w) => w.to.pane === paneId && w.to.port === port) || null; }
  wiresOut(paneId) { return [...this.wires.values()].filter((w) => w.from.pane === paneId); }
  wiresIn(paneId) { return [...this.wires.values()].filter((w) => w.to.pane === paneId); }

  /** Semantics only. No geometry, no status. Moving a pane must not change this string. */
  serializeGraph() {
    const panes = [...this.panes.values()]
      .map((p) => ({
        id: p.id, patternId: p.patternId, parent: p.parent, nodeRef: p.nodeRef,
        stateKey: p.stateKey, config: p.config, residency: p.residency,
        surface: p.surface, expose: p.expose, label: p.label,
        flavourRef: p.flavourRef ?? null,
        // secretRef is deliberately absent: the graph is git-diffable, so it must never
        // carry even the NAME of a credential binding into a shared artefact.
      }))
      .sort((a, b) => a.id.localeCompare(b.id));
    const wires = [...this.wires.values()]
      .map((w) => ({ id: w.id, patternId: w.patternId, from: w.from, to: w.to, kind: w.kind ?? 'value' }))
      .sort((a, b) => a.id.localeCompare(b.id));
    const patterns = [...this.patterns.values()].sort((a, b) => a.id.localeCompare(b.id));
    return stable({ patterns, panes, wires });
  }

  toJSON() {
    return {
      patterns: [...this.patterns.values()],
      panes: [...this.panes.values()],
      wires: [...this.wires.values()],
      activePattern: this.activePattern,
    };
  }

  static fromJSON(j) {
    const a = new Arrangement();
    for (const p of j.patterns || []) a.patterns.set(p.id, p);
    for (const p of j.panes || []) a.panes.set(p.id, p);
    for (const w of j.wires || []) a.wires.set(w.id, w);
    a.activePattern = j.activePattern || (j.patterns?.[0]?.id ?? null);
    return a;
  }
}

/** Layout is a separate tree. Deliberately not reachable from Arrangement. */
export class LayoutStore {
  constructor() { this.canvases = new Map(); } // canvasId -> Map(paneId -> {x,y,w,h,collapsed})
  set(canvasId, paneId, box) {
    let c = this.canvases.get(canvasId);
    if (!c) { c = new Map(); this.canvases.set(canvasId, c); }
    c.set(paneId, { ...(c.get(paneId) || {}), ...box });
  }
  get(canvasId, paneId) { return this.canvases.get(canvasId)?.get(paneId) || null; }
  all(canvasId) { return this.canvases.get(canvasId) || new Map(); }
  drop(paneId) { for (const c of this.canvases.values()) c.delete(paneId); }
  toJSON() { return [...this.canvases.entries()].map(([id, m]) => [id, [...m.entries()]]); }
  static fromJSON(j) {
    const l = new LayoutStore();
    for (const [id, entries] of j || []) l.canvases.set(id, new Map(entries));
    return l;
  }
}
