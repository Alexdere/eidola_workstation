// kernel/kernel.js — the whole public surface: apply(command) in, events out.
// Both are serializable, which is why putting a WebSocket in front of this is mechanical
// and the browser's local mode is the same code with both ends in one process.
import { Arrangement, LayoutStore, makePane } from './arrangement.js';
import { NodeStore } from './store.js';
import { Scheduler } from './scheduler.js';
import { SecretVault } from './secrets.js';
import { uid } from './ids.js';

export class Kernel {
  constructor({ store, arrangement, layout, host, clock, timers, secrets } = {}) {
    this.store = store || new NodeStore();
    this.arr = arrangement || new Arrangement();
    this.layout = layout || new LayoutStore();
    this.secrets = secrets || new SecretVault();
    this.sched = new Scheduler({ store: this.store, arr: this.arr, host, clock, timers, secrets: this.secrets });
    this.listeners = new Set();
    this.history = [];
    this.future = [];
    this.sched.on((ev) => this.#emit(ev));
    if (!this.arr.patterns.size) this.arr.createPattern('home');
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  #emit(ev) { for (const fn of this.listeners) fn(ev); }
  #graphChanged() { this.sched.reconcile(); this.#emit({ type: 'graph' }); }

  // ---- commands ---------------------------------------------------------

  /** @returns {{result:any, inverse:object|null}} */
  #exec(cmd) {
    const a = this.arr;
    switch (cmd.t) {
      case 'create-pattern': {
        const p = a.createPattern(cmd.name || 'pattern', cmd.id || uid('pat'));
        return { result: p, inverse: { t: 'delete-pattern', id: p.id }, canonical: { ...cmd, id: p.id } };
      }
      case 'delete-pattern': {
        const panes = a.panesOf(cmd.id);
        for (const p of panes) a.removePane(p.id);
        const pat = a.patterns.get(cmd.id);
        a.patterns.delete(cmd.id);
        return { result: pat, inverse: { t: 'create-pattern', id: cmd.id, name: pat?.name } };
      }
      case 'activate-pattern': {
        const prev = a.activePattern;
        a.activePattern = cmd.id;
        return { result: cmd.id, inverse: { t: 'activate-pattern', id: prev } };
      }
      case 'create-pane': {
        const pane = makePane(cmd.patternId || a.activePattern, cmd);
        a.addPane(pane);
        // Redo must recreate the same pane, not a look-alike with a fresh id.
        const canonical = { ...cmd, id: pane.id, stateKey: pane.stateKey, patternId: pane.patternId };
        return { result: pane, inverse: { t: 'delete-pane', pane: pane.id }, canonical };
      }
      case 'delete-pane': {
        const pane = a.panes.get(cmd.pane);
        const wires = [...a.wiresIn(cmd.pane), ...a.wiresOut(cmd.pane)];
        const kids = a.childrenOf(cmd.pane).map((k) => ({ ...k }));
        a.removePane(cmd.pane);
        this.layout.drop(cmd.pane);
        return { result: pane, inverse: { t: 'restore-pane', pane, wires, kids } };
      }
      case 'restore-pane': {
        a.addPane(cmd.pane);
        for (const k of cmd.kids || []) a.addPane(k);
        for (const w of cmd.wires || []) a.wires.set(w.id, w);
        return { result: cmd.pane, inverse: { t: 'delete-pane', pane: cmd.pane.id } };
      }
      case 'bind-pane': {
        const pane = a.panes.get(cmd.pane);
        const before = { nodeRef: pane.nodeRef, config: pane.config };
        pane.nodeRef = cmd.nodeRef;
        if (cmd.config) pane.config = cmd.config;
        return { result: pane, inverse: { t: 'bind-pane', pane: pane.id, ...before } };
      }
      case 'set-config': {
        const pane = a.panes.get(cmd.pane);
        const before = pane.config;
        pane.config = { ...cmd.config };
        return { result: pane, inverse: { t: 'set-config', pane: pane.id, config: before } };
      }
      case 'set-residency': {
        const pane = a.panes.get(cmd.pane);
        const before = pane.residency;
        pane.residency = cmd.residency;
        return { result: pane, inverse: { t: 'set-residency', pane: pane.id, residency: before } };
      }
      case 'set-expose': {
        const pane = a.panes.get(cmd.pane);
        const before = pane.expose;
        pane.expose = cmd.expose;
        return { result: pane, inverse: { t: 'set-expose', pane: pane.id, expose: before } };
      }
      case 'set-borderless': {
        const pane = a.panes.get(cmd.pane);
        const before = pane.borderless;
        pane.borderless = !!cmd.value;
        return { result: pane, inverse: { t: 'set-borderless', pane: pane.id, value: before } };
      }
      case 'wire': {
        const w = a.addWire(cmd.patternId || a.activePattern, cmd.from, cmd.to, cmd.id, cmd.kind || 'value');
        return { result: w, inverse: { t: 'unwire', id: w.id }, canonical: { ...cmd, id: w.id, patternId: w.patternId, kind: w.kind } };
      }
      case 'unwire': {
        const w = a.removeWire(cmd.id);
        return { result: w, inverse: w ? { t: 'wire', id: w.id, patternId: w.patternId, from: w.from, to: w.to } : null };
      }
      case 'set-flavour': {
        const pane = a.panes.get(cmd.pane);
        const before = pane.flavourRef;
        pane.flavourRef = cmd.flavourRef;
        return { result: pane, inverse: { t: 'set-flavour', pane: pane.id, flavourRef: before } };
      }
      // Binding a credential is not a graph edit. It is never undoable, never journalled,
      // and never leaves this machine.
      case 'set-secret': {
        const pane = a.panes.get(cmd.pane);
        pane.secretRef = cmd.secretRef;
        return { result: pane, inverse: null, nonSemantic: true };
      }
      case 'put-secret': {
        this.secrets.put(cmd.name, cmd.value);
        return { result: cmd.name, inverse: null, nonSemantic: true };
      }
      case 'put-node': {
        const hash = this.store.put(cmd.def);
        this.#emit({ type: 'store' });
        return { result: hash, inverse: null };
      }
      case 'name-node': {
        const before = this.store.names.get(cmd.name);
        this.store.setName(cmd.name, cmd.hash);
        this.#emit({ type: 'store' });
        return { result: cmd.hash, inverse: before ? { t: 'name-node', name: cmd.name, hash: before } : null };
      }
      // --- non-semantic: never touches the graph, never enters the undo stack ---
      case 'set-layout': {
        this.layout.set(cmd.canvas, cmd.pane, cmd.box);
        this.#emit({ type: 'layout', canvas: cmd.canvas, pane: cmd.pane });
        return { result: null, inverse: null, nonSemantic: true };
      }
      case 'set-observed': {
        this.sched.setObserved(cmd.frame ?? 'default', cmd.ids || []);
        return { result: null, inverse: null, nonSemantic: true };
      }
      default:
        throw new Error('unknown command: ' + cmd.t);
    }
  }

  apply(cmd) {
    const { result, inverse, nonSemantic, canonical } = this.#exec(cmd);
    if (!nonSemantic) {
      if (inverse) { this.history.push({ cmd: canonical || cmd, inverse }); this.future.length = 0; }
      this.#graphChanged();
    }
    return result;
  }

  undo() {
    const entry = this.history.pop();
    if (!entry) return false;
    this.#exec(entry.inverse);
    this.future.push(entry);
    this.#graphChanged();
    return true;
  }

  redo() {
    const entry = this.future.pop();
    if (!entry) return false;
    this.#exec(entry.cmd);
    this.history.push(entry);
    this.#graphChanged();
    return true;
  }

  // ---- reads ------------------------------------------------------------

  pull(pane, port) { return this.sched.pull(pane, port); }
  trigger(pane) { return this.sched.trigger(pane); }
  cook(patternId) { return this.sched.cook(patternId); }
  status(pane) { return this.sched.statusOf(pane); }
  search(q, opts) { return this.store.search(q, opts); }

  /** What a late-joining client receives before it starts taking diffs. */
  snapshot() {
    return {
      store: this.store.toJSON(),
      arrangement: this.arr.toJSON(),
      layout: this.layout.toJSON(),
      status: [...this.sched.status.entries()],
      values: [...this.sched.latest.entries()].map(([k, v]) => [k, { outputs: v.outputs, seq: v.seq, at: v.at }]),
    };
  }

  dispose() { this.sched.dispose(); }
}
