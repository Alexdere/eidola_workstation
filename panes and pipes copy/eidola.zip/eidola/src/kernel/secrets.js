// kernel/secrets.js — the fourth storage tier.
//
// store   small node scripts, searchable, synced
// vault   large blobs, content-addressed
// mounts  pointers to storage you already have
// SECRETS encrypted, referenced by name, resolved only at execution time
//
// The rule that makes this worth its own tier: a secret must never enter a hash, a log, a
// snapshot, or a serialized config. config is in the memo cache key by design and is meant
// to be git-diffable — so a token in config is a token in a thousand cached fingerprints.
// Retrofitting that is miserable, which is why the shape exists before the encryption does.

export class SecretVault {
  constructor({ cipher } = {}) {
    this.cipher = cipher || null;   // null = plaintext in memory. v1 is honest about being v1.
    this.entries = new Map();       // name -> sealed value
    this.reads = [];                // audit: who resolved what, when. Never the value.
  }

  put(name, value) { this.entries.set(name, this.cipher ? this.cipher.seal(value) : value); }
  has(name) { return this.entries.has(name); }
  names() { return [...this.entries.keys()]; }
  forget(name) { this.entries.delete(name); }

  /** Resolved at execution time only, and only for a node that declared the capability. */
  resolve(name, forNode) {
    if (!this.entries.has(name)) return undefined;
    this.reads.push({ name, node: forNode, at: Date.now() });
    const sealed = this.entries.get(name);
    return this.cipher ? this.cipher.open(sealed) : sealed;
  }

  /** Secrets are never serialized with the workspace. Losing them on export is correct. */
  toJSON() { return { names: this.names() }; }
}

/** A node asks for one by capability: caps: ['secret:github']. */
export function secretCaps(def) {
  return (def.caps || []).filter((c) => c.startsWith('secret:')).map((c) => c.slice(7));
}
