// kernel/ids.js — identity and content addressing. No DOM, no I/O.

/** Deterministic 64-bit-ish content hash. Swap for SHA-256 when the store moves to SQLite. */
export function hashString(s) {
  let h1 = 0x811c9dc5 | 0;
  let h2 = 0x9e3779b9 | 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193);
    h2 = Math.imul(h2 ^ c, 0x85ebca6b);
    h2 ^= h2 >>> 13;
  }
  return (h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0');
}

/** Key-sorted JSON so that equal values always hash equal. */
export function stable(v) {
  if (v === undefined) return 'u';
  if (v === null || typeof v !== 'object') return JSON.stringify(v) ?? 'u';
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  const keys = Object.keys(v).sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
}

export function hashOf(v) {
  return hashString(stable(v));
}

let counter = 0;
/** Sortable-ish unique id. */
export function uid(prefix = 'p') {
  counter = (counter + 1) % 0xffff;
  return (
    prefix + '_' + Date.now().toString(36) + counter.toString(36).padStart(3, '0') +
    Math.floor(Math.random() * 0xffffff).toString(36)
  );
}
