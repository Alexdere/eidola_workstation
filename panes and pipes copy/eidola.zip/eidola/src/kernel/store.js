// kernel/store.js — the store: context-free, content-addressed node definitions.
// A node knows nothing about panes, screens, position, or who is using it.
import { hashOf } from './ids.js';

/** Fields that participate in the content hash. Everything else is an index. */
const HASHED = ['name', 'type', 'class', 'version', 'ports', 'config', 'caps', 'view', 'source', 'description', 'tags'];

const DEFAULTS = {
  name: '',
  type: 'anon',
  class: 'pure',           // 'pure' | 'source' | 'effect' | 'container'
  version: '1',
  ports: { in: {}, out: {} },
  config: { schema: {}, default: {} },
  caps: [],                 // 'net' | 'clock' | 'vault' | 'fs:read' | 'fs:write' | 'exec' | 'browser'
  view: 'value',            // hint for the head; the kernel never reads it
  source: '',               // JS body: (inputs, ctx) => outputs
  description: '',
  tags: [],
};

export class NodeStore {
  constructor() {
    /** @type {Map<string, any>} hash -> frozen definition */
    this.defs = new Map();
    /** @type {Map<string, string>} mutable name -> hash. Binding by name = follow; by hash = pin. */
    this.names = new Map();
    /** @type {Map<string, any[]>} hash -> config presets */
    this.presets = new Map();
    this.listeners = new Set();
  }

  put(partial) {
    const def = { ...DEFAULTS, ...partial };
    def.ports = { in: {}, out: {}, ...(partial.ports || {}) };
    const canonical = {};
    for (const k of HASHED) canonical[k] = def[k];
    const hash = hashOf(canonical);
    def.hash = hash;
    if (!this.defs.has(hash)) {
      this.defs.set(hash, Object.freeze(def));
      this.#emit();
    }
    if (def.name) this.setName(def.name, hash);
    return hash;
  }

  setName(name, hash) {
    if (!this.defs.has(hash)) throw new Error('setName: unknown hash ' + hash);
    this.names.set(name, hash);
    this.#emit();
  }

  get(hash) { return this.defs.get(hash) || null; }

  /** ref = {kind:'hash'|'name', value}. Hash pins a version; name follows edits. */
  resolve(ref) {
    if (!ref) return null;
    if (ref.kind === 'hash') return this.get(ref.value);
    const h = this.names.get(ref.value);
    return h ? this.get(h) : null;
  }

  addPreset(hash, name, config) {
    const list = this.presets.get(hash) || [];
    list.push({ name, config, lastUsed: 0 });
    this.presets.set(hash, list);
  }

  presetsFor(hash) { return this.presets.get(hash) || []; }

  /** Summon-by-search. Linear scan; the shape of the result is what SQLite FTS5 must reproduce. */
  search(q, { limit = 12 } = {}) {
    const query = String(q || '').trim().toLowerCase();
    const named = new Set(this.names.values());
    const out = [];
    for (const def of this.defs.values()) {
      if (!query) { out.push({ def, score: named.has(def.hash) ? 1 : 0 }); continue; }
      let score = 0;
      const name = (def.name || '').toLowerCase();
      const type = (def.type || '').toLowerCase();
      const desc = (def.description || '').toLowerCase();
      const tags = (def.tags || []).join(' ').toLowerCase();
      for (const tok of query.split(/\s+/)) {
        if (!tok) continue;
        if (name === tok) score += 100;
        else if (name.startsWith(tok)) score += 60;
        else if (name.includes(tok)) score += 30;
        if (type.includes(tok)) score += 20;
        if (tags.includes(tok)) score += 15;
        if (desc.includes(tok)) score += 8;
        if ((def.source || '').toLowerCase().includes(tok)) score += 2;
      }
      if (score > 0) out.push({ def, score });
    }
    out.sort((a, b) => b.score - a.score || a.def.name.localeCompare(b.def.name));
    return out.slice(0, limit);
  }

  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  #emit() { for (const fn of this.listeners) fn(); }

  toJSON() {
    return {
      defs: [...this.defs.values()].map((d) => ({ ...d })),
      names: [...this.names.entries()],
      presets: [...this.presets.entries()],
    };
  }

  static fromJSON(json) {
    const s = new NodeStore();
    for (const d of json.defs || []) s.put(d);
    for (const [n, h] of json.names || []) if (s.defs.has(h)) s.names.set(n, h);
    for (const [h, p] of json.presets || []) s.presets.set(h, p);
    return s;
  }
}
