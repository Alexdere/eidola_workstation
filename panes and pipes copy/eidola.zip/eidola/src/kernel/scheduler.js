// kernel/scheduler.js — demand-driven, memoized evaluation.
//
//   dirty(n) ← n changed, or an upstream produced a new value
//   live(n)  ← observed(n) ∨ pinned(n) ∨ some live consumer is downstream of n
//   cook(n)  when dirty(n) ∧ live(n) ∧ (class(n) = 'pure' ∨ triggered(n))
//
// No DOM. The only thing this file knows about screens is a set of pane ids.
import { hashOf } from './ids.js';

const MEMO_CAP = 5000;

export class Scheduler {
  constructor({ store, arr, host, clock, timers, journal, secrets } = {}) {
    this.store = store;
    this.secrets = secrets || null;
    this.arr = arr;
    this.host = host;
    this.clock = clock || { now: () => Date.now() };
    this.timers = timers || {
      set: (fn, ms) => setInterval(fn, ms),
      clear: (h) => clearInterval(h),
    };
    this.journal = journal || [];

    // Observation is frame-relative. "Is anything watching this?" has no answer until you
    // say watching FROM WHERE — so observers are keyed by frame and liveness is their union.
    // A single flat set silently assumes one observer, and clobbers the second one.
    this.observers = new Map();            // frameId -> Set<paneId>
    this.live = new Set();
    this.memo = new Map();                 // memoKey -> outputs
    this.latest = new Map();               // paneId -> {outputs, hash, seq, at}  (source & effect)
    this.paneState = new Map();            // stateKey -> state  (never pure)
    this.status = new Map();               // paneId -> {status, error}
    this.running = new Map();              // paneId -> timer handle
    this.inflight = new Map();             // paneId -> AbortController
    this.cookCount = new Map();            // paneId -> executions (milestone 1 instrument)
    this.pendingTicks = new Set();
    this.memoHits = 0;
    this.memoMisses = 0;
    this.listeners = new Set();
  }

  // ---- plumbing ---------------------------------------------------------

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  #emit(ev) { for (const fn of this.listeners) fn(ev); }

  defOf(pane) { return pane && pane.nodeRef ? this.store.resolve(pane.nodeRef) : null; }

  configOf(pane, def) { return { ...(def?.config?.default || {}), ...(pane.config || {}) }; }

  statusOf(id) { return this.status.get(id) || { status: 'idle', error: null }; }

  // "Stale" means four unrelated things — unobserved by design, upstream errored, mount
  // unplugged, paused. One word for all four is the difference between a system you trust
  // and one you double-check, so the cause travels with the state.
  setStatus(id, status, error = null, cause = null) {
    const prev = this.status.get(id);
    if (prev && prev.status === status && prev.error === error && prev.cause === cause) return;
    this.status.set(id, { status, error, cause });
    this.#emit({ type: 'status', pane: id, status, error, cause });
  }

  countCook(id) { this.cookCount.set(id, (this.cookCount.get(id) || 0) + 1); }

  // ---- liveness ---------------------------------------------------------

  /**
   * Liveness propagates UPSTREAM. A source feeding an observed pane stays live even
   * though the source pane itself is off-screen — otherwise panning away quietly kills
   * your weather poll. Containment propagates both ways: a live child needs its
   * container for input fall-through, a live container needs its exposed children.
   */
  computeLive() {
    const next = new Set();
    const queue = [];
    const observed = this.observed;
    for (const p of this.arr.panes.values()) {
      if (observed.has(p.id) || p.residency === 'pinned') { next.add(p.id); queue.push(p.id); }
    }
    while (queue.length) {
      const id = queue.pop();
      const push = (other) => { if (other && !next.has(other)) { next.add(other); queue.push(other); } };
      for (const w of this.arr.wiresIn(id)) push(w.from.pane);
      const pane = this.arr.panes.get(id);
      if (pane?.parent) push(pane.parent);
      for (const child of this.arr.childrenOf(id)) if (child.expose?.out) push(child.id);
    }
    this.live = next;
    return next;
  }

  /** @param frame  which canvas/client/tab is reporting. Never optional. */
  setObserved(frame, ids) {
    if (frame == null) throw new Error('setObserved: observation requires a frame');
    this.observers.set(frame, new Set(ids));
    this.reconcile();
  }

  dropFrame(frame) { this.observers.delete(frame); this.reconcile(); }

  /** The union across every frame. Nothing is unobserved until it is unobserved everywhere. */
  get observed() {
    const all = new Set();
    for (const set of this.observers.values()) for (const id of set) all.add(id);
    return all;
  }

  /** Start sources that became live, stop sources that didn't. The viewport is a GC. */
  reconcile() {
    this.computeLive();
    for (const pane of this.arr.panes.values()) {
      const def = this.defOf(pane);
      if (!def || def.class !== 'source') continue;
      const shouldRun = this.live.has(pane.id);
      const isRunning = this.running.has(pane.id);
      if (shouldRun && !isRunning) this.startSource(pane);
      else if (!shouldRun && isRunning) this.stopSource(pane.id);
    }
  }

  // ---- sources ----------------------------------------------------------

  startSource(pane) {
    const def = this.defOf(pane);
    if (!def) return;
    const cfg = this.configOf(pane, def);
    const ms = Number(cfg.intervalMs) > 0 ? Number(cfg.intervalMs) : 0;
    const handle = ms ? this.timers.set(() => { this.tick(pane.id); }, ms) : null;
    this.running.set(pane.id, handle);
    this.setStatus(pane.id, 'active');
    this.track(this.tick(pane.id));
  }

  stopSource(paneId) {
    const h = this.running.get(paneId);
    if (h != null) this.timers.clear(h);
    this.running.delete(paneId);
    this.inflight.get(paneId)?.abort();
    this.inflight.delete(paneId);
    this.setStatus(paneId, 'paused', null, 'nothing is observing it');
  }

  /** Await every source run currently in flight. Tests and headless cooks need this;
   *  the UI does not, because staleness is a visible state rather than something to wait on. */
  track(p) { this.pendingTicks.add(p); p.finally(() => this.pendingTicks.delete(p)); return p; }
  async settle() {
    let guard = 0;
    while (this.pendingTicks.size && guard++ < 50) await Promise.allSettled([...this.pendingTicks]);
  }

  /** One source run. The kernel owns the clock so runs are journaled and replayable. */
  async tick(paneId) {
    const pane = this.arr.panes.get(paneId);
    const def = this.defOf(pane);
    if (!pane || !def) return;
    const inputs = await this.gatherInputs(pane, def, new Set());
    const out = await this.execute(pane, def, inputs);
    if (!out) return;
    const h = hashOf(out);
    const prev = this.latest.get(paneId);
    if (prev && prev.hash === h) return;             // no new value, nothing downstream is dirty
    const rec = { outputs: out, hash: h, seq: (prev?.seq ?? 0) + 1, at: this.clock.now() };
    this.latest.set(paneId, rec);
    this.journal.push({ pane: paneId, seq: rec.seq, at: rec.at, outputs: out });
    this.setStatus(paneId, 'active');
    this.#emit({ type: 'value', pane: paneId, seq: rec.seq });
    this.markDirty(paneId);
  }

  /** Everything transitively downstream must re-pull. Nothing else is touched. */
  markDirty(paneId) {
    const dirty = new Set();
    const queue = [paneId];
    while (queue.length) {
      const id = queue.pop();
      for (const w of this.arr.wiresOut(id)) {
        if (!dirty.has(w.to.pane)) { dirty.add(w.to.pane); queue.push(w.to.pane); }
      }
      const pane = this.arr.panes.get(id);
      if (pane?.expose?.out && pane.parent && !dirty.has(pane.parent)) {
        dirty.add(pane.parent); queue.push(pane.parent);
      }
      for (const child of this.arr.childrenOf(id)) {
        if (child.expose?.in && !dirty.has(child.id)) { dirty.add(child.id); queue.push(child.id); }
      }
    }
    this.#emit({ type: 'dirty', panes: [...dirty], from: paneId });
  }

  // ---- execution --------------------------------------------------------

  async execute(pane, def, inputs) {
    const ctrl = new AbortController();
    this.inflight.get(pane.id)?.abort();
    this.inflight.set(pane.id, ctrl);
    this.countCook(pane.id);
    try {
      const res = await this.host.execute(def, {
        inputs,
        config: this.configOf(pane, def),
        // pure nodes get no state — state belongs to the binding, and pure means pure
        state: def.class === 'pure' ? undefined : (this.paneState.get(pane.stateKey) ?? {}),
        now: this.clock.now(),
        signal: ctrl.signal,
        // Resolved here, at execution, for this node only. It never touched config,
        // never entered the memo key, and is not in any snapshot.
        resolveSecret: this.secrets && pane.secretRef
          ? (name) => this.secrets.resolve(pane.secretRef[name] ?? name, def.type)
          : null,
      });
      if (def.class !== 'pure' && res.state !== undefined) this.paneState.set(pane.stateKey, res.state);
      if (this.statusOf(pane.id).status === 'error') this.setStatus(pane.id, 'active');
      return res.outputs || {};
    } catch (err) {
      if (ctrl.signal.aborted) return null;
      this.setStatus(pane.id, 'error', String(err?.message || err));
      return null;
    } finally {
      if (this.inflight.get(pane.id) === ctrl) this.inflight.delete(pane.id);
    }
  }

  // ---- input resolution -------------------------------------------------

  async gatherInputs(pane, def, seen) {
    const inputs = {};
    const names = new Set([
      ...Object.keys(def.ports?.in || {}),
      ...this.arr.wiresIn(pane.id).map((w) => w.to.port),
    ]);
    for (const name of names) inputs[name] = await this.resolveInput(pane, name, seen);
    return inputs;
  }

  /** Wire first; then fall through the super-pane boundary; then config. */
  async resolveInput(pane, portName, seen) {
    const wire = this.arr.wireInto(pane.id, portName);
    if (wire) return this.pull(wire.from.pane, wire.from.port, seen);
    const outer = pane.expose?.in?.[portName];
    if (outer && pane.parent) {
      const parent = this.arr.panes.get(pane.parent);
      if (parent) return this.resolveInput(parent, outer, seen);
    }
    const cfg = pane.config || {};
    return Object.prototype.hasOwnProperty.call(cfg, portName) ? cfg[portName] : undefined;
  }

  // ---- the pull ---------------------------------------------------------

  /** Demand. Nothing computes unless something asks. */
  async pull(paneId, port, seen = new Set()) {
    const mark = paneId + ':' + port;
    if (seen.has(mark)) throw new Error('cycle through ' + mark);
    seen = new Set(seen); seen.add(mark);

    const pane = this.arr.panes.get(paneId);
    if (!pane) return undefined;
    const def = this.defOf(pane);
    if (!def) { this.setStatus(paneId, 'unconfigured'); return undefined; }

    if (def.class === 'source') {
      if (!this.running.has(paneId)) this.startSource(pane);   // demand can wake a source
      return this.latest.get(paneId)?.outputs?.[port];
    }

    if (def.class === 'effect') {
      // never auto-cooks. The only policy baked into the system.
      if (!this.latest.has(paneId)) this.setStatus(paneId, 'stale', null, 'never triggered');
      return this.latest.get(paneId)?.outputs?.[port];
    }

    if (def.class === 'container') {
      const child = this.arr.childrenOf(paneId).find((c) => c.expose?.out && c.expose.out[port]);
      if (!child) return undefined;
      return this.pull(child.id, child.expose.out[port], seen);
    }

    // pure
    const inputs = await this.gatherInputs(pane, def, seen);
    // flavour is public and SHOULD share cache across identical public configuration;
    // secretRef is absent on purpose — two panes differing only by credential are the
    // same computation, and a token must never reach a fingerprint.
    const key = hashOf([def.hash, this.configOf(pane, def), pane.flavourRef ?? null, inputs]);
    if (this.memo.has(key)) {
      this.memoHits++;
      this.setStatus(paneId, 'idle');
      return this.memo.get(key)[port];
    }
    this.memoMisses++;
    const outputs = await this.execute(pane, def, inputs);
    if (!outputs) return undefined;
    this.memo.set(key, outputs);
    if (this.memo.size > MEMO_CAP) this.memo.delete(this.memo.keys().next().value);
    this.setStatus(paneId, 'idle');
    return outputs[port];
  }

  /** Effects require an explicit trigger. A homepage must not fire webhooks because you opened a tab. */
  async trigger(paneId) {
    const pane = this.arr.panes.get(paneId);
    const def = this.defOf(pane);
    if (!pane || !def) return undefined;
    if (def.class !== 'effect' && def.class !== 'source') throw new Error('trigger: not an effect or source');
    const inputs = await this.gatherInputs(pane, def, new Set());
    const outputs = await this.execute(pane, def, inputs);
    if (!outputs) return undefined;
    const prev = this.latest.get(paneId);
    this.latest.set(paneId, { outputs, hash: hashOf(outputs), seq: (prev?.seq ?? 0) + 1, at: this.clock.now() });
    this.setStatus(paneId, 'active');
    this.markDirty(paneId);
    return outputs;
  }

  /** Headless: cook every output that nothing else consumes, then stop. */
  async cook(patternId) {
    const panes = this.arr.panesOf(patternId ?? this.arr.activePattern);
    const consumed = new Set(this.arr.wiresOf(patternId ?? this.arr.activePattern).map((w) => w.from.pane + ':' + w.from.port));
    const results = {};
    for (const pane of panes) {
      const def = this.defOf(pane);
      if (!def) continue;
      for (const port of Object.keys(def.ports?.out || {})) {
        if (consumed.has(pane.id + ':' + port)) continue;
        results[pane.id + ':' + port] = await this.pull(pane.id, port);
      }
    }
    return results;
  }

  dispose() {
    for (const id of [...this.running.keys()]) this.stopSource(id);
    for (const c of this.inflight.values()) c.abort();
    this.inflight.clear();
  }
}
