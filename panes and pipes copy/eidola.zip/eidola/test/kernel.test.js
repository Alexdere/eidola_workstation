// test/kernel.test.js — the milestones as assertions. Runs in Node with no dependencies.
// If any of these needs the pane model or store model compromised to pass, the architecture is wrong.
//
//   node test/kernel.test.js
//
import { readFileSync, readdirSync } from 'node:fs';
import { NodeStore } from '../src/kernel/store.js';
import { Arrangement, LayoutStore } from '../src/kernel/arrangement.js';
import { Kernel } from '../src/kernel/kernel.js';
import { LocalHost } from '../src/runtime/host.js';
import { installCoreNodes } from '../src/nodes/core.js';

let pass = 0, fail = 0;
const results = [];
function ok(name, cond, detail = '') {
  cond ? pass++ : fail++;
  results.push((cond ? '  PASS  ' : '  FAIL  ') + name + (detail && !cond ? '  -> ' + detail : ''));
}
function eq(name, a, b) { ok(name, JSON.stringify(a) === JSON.stringify(b), `got ${JSON.stringify(a)} want ${JSON.stringify(b)}`); }

/** Manual timers so source ticks are deterministic. */
function makeRig({ caps = ['net', 'clock'], timeoutMs = 5000 } = {}) {
  const fired = new Map(); let h = 0;
  const timers = { set: (fn) => { fired.set(++h, fn); return h; }, clear: (k) => fired.delete(k) };
  let t = 1_700_000_000_000;
  const clock = { now: () => t };
  const host = new LocalHost({ caps, timeoutMs });
  const k = new Kernel({ store: new NodeStore(), arrangement: new Arrangement(), layout: new LayoutStore(), host, clock, timers });
  const types = installCoreNodes(k.store);
  return { k, host, types, timers, fired, advance: (ms) => { t += ms; }, fireAll: () => { for (const fn of fired.values()) fn(); } };
}
const ref = (types, type) => ({ kind: 'hash', value: types.get(type) });

// ---------------------------------------------------------------- 0. discipline
{
  const dir = new URL('../src/kernel/', import.meta.url);
  let dirty = [];
  for (const f of readdirSync(dir)) {
    const src = readFileSync(new URL(f, dir), 'utf8');
    if (/\b(document|localStorage|HTMLElement)\b/.test(src)) dirty.push(f);
    if (/\bwindow\./.test(src)) dirty.push(f);
  }
  ok('kernel contains no DOM references', dirty.length === 0, dirty.join(','));
}

// ---------------------------------------------------------------- 1. store
{
  const { k, types } = makeRig();
  const h = types.get('core.note');
  eq('resolve by hash pins a version', k.store.resolve({ kind: 'hash', value: h }).type, 'core.note');
  const v2 = k.store.put({ ...k.store.get(h), name: 'note', config: { schema: { text: 'text' }, default: { text: 'v2' } } });
  ok('editing a node produces a new hash', v2 !== h);
  eq('binding by name follows the edit', k.store.resolve({ kind: 'name', value: 'note' }).hash, v2);
  eq('binding by hash does not follow', k.store.resolve({ kind: 'hash', value: h }).hash, h);

  for (let i = 0; i < 1000; i++) k.store.put({ name: 'gen ' + i, type: 'gen.' + i, description: 'generated node ' + i, tags: ['gen'] });
  const t0 = performance.now();
  const hits = k.store.search('weather note gen 500');
  const ms = performance.now() - t0;
  ok(`summon-search over 1000+ nodes is under 50ms (${ms.toFixed(1)}ms)`, ms < 50);
  ok('search returns something useful', hits.length > 0);
  eq('presets belong to the node', k.store.presetsFor(types.get('core.http.poll')).map(p => p.name), ['weather', 'hacker news top']);
}

// ---------------------------------------------------------------- 2. only transitive dependents recompute
{
  const { k, types, advance } = makeRig();
  const pat = k.arr.activePattern;
  const mk = (type, cfg = {}, extra = {}) => k.apply({ t: 'create-pane', patternId: pat, nodeRef: ref(types, type), config: cfg, ...extra });

  const src = mk('core.clock', { intervalMs: 1000 });
  const b = mk('core.js.transform', { code: 'return input * 2;' });
  const c = mk('core.js.transform', { code: 'return input + 1;' });
  const src2 = mk('core.clock', { intervalMs: 1000 });
  const d = mk('core.js.transform', { code: 'return input - 1;' });

  k.apply({ t: 'wire', from: { pane: src.id, port: 'time' }, to: { pane: b.id, port: 'in' } });
  k.apply({ t: 'wire', from: { pane: b.id, port: 'out' }, to: { pane: c.id, port: 'in' } });
  k.apply({ t: 'wire', from: { pane: src2.id, port: 'time' }, to: { pane: d.id, port: 'in' } });

  k.apply({ t: 'set-observed', frame: 'main', ids: [b.id, c.id, d.id] });
  await k.sched.settle();
  await k.pull(c.id, 'out'); await k.pull(d.id, 'out');

  const before = new Map(k.sched.cookCount);
  // one source produces a new value; the other does not
  advance(5000);
  await k.sched.tick(src.id);
  await k.pull(c.id, 'out'); await k.pull(d.id, 'out');

  const delta = (id) => (k.sched.cookCount.get(id) || 0) - (before.get(id) || 0);
  ok('downstream of the changed source recomputed', delta(b.id) === 1 && delta(c.id) === 1, `b=${delta(b.id)} c=${delta(c.id)}`);
  ok('everything else did not', delta(d.id) === 0 && delta(src2.id) === 0, `d=${delta(d.id)} src2=${delta(src2.id)}`);
}

// ---------------------------------------------------------------- 3. overlap: shared memo, separate state
{
  const { k, host, types } = makeRig();
  const p1 = k.apply({ t: 'create-pattern', name: 'work' });
  const p2 = k.apply({ t: 'create-pattern', name: 'home' });
  const cfg = { code: 'return input * 3;', in: 7 };
  const a = k.apply({ t: 'create-pane', patternId: p1.id, nodeRef: ref(types, 'core.js.transform'), config: cfg });
  const b = k.apply({ t: 'create-pane', patternId: p2.id, nodeRef: ref(types, 'core.js.transform'), config: cfg });
  const n0 = host.byType.get('core.js.transform') || 0;
  eq('pattern one computes', await k.pull(a.id, 'out'), 21);
  eq('pattern two agrees', await k.pull(b.id, 'out'), 21);
  eq('two patterns sharing a node executed it once', (host.byType.get('core.js.transform') || 0) - n0, 1);
  ok('the second pull was a memo hit', k.sched.memoHits >= 1);

  // state, by contrast, is keyed by the binding
  const e1 = k.apply({ t: 'create-pane', patternId: p1.id, nodeRef: ref(types, 'core.effect.append'), config: { item: 1 } });
  const e2 = k.apply({ t: 'create-pane', patternId: p2.id, nodeRef: ref(types, 'core.effect.append'), config: { item: 2 } });
  await k.trigger(e1.id); await k.trigger(e1.id); await k.trigger(e2.id);
  eq('distinct state keys are instances', (await k.pull(e1.id, 'items')).length, 2);
  eq('and do not leak into each other', await k.pull(e2.id, 'items'), [2]);
  const e3 = k.apply({ t: 'create-pane', patternId: p2.id, nodeRef: ref(types, 'core.effect.append'), config: { item: 9 }, stateKey: e1.stateKey });
  await k.trigger(e3.id);
  eq('a shared state key is a ref', (await k.pull(e3.id, 'items')).length, 3);
}

// ---------------------------------------------------------------- 4. effects never auto-cook
{
  const { k, types } = makeRig();
  const e = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.effect.append'), config: { item: 'x' } });
  k.apply({ t: 'set-observed', frame: 'main', ids: [e.id] });
  await k.sched.settle();
  eq('an observed effect has not run', await k.pull(e.id, 'items'), undefined);
  eq('and reports itself as stale', k.status(e.id).status, 'stale');
  await k.trigger(e.id);
  eq('an explicit trigger runs it', await k.pull(e.id, 'items'), ['x']);
}

// ---------------------------------------------------------------- 5. pure means pure
{
  const { k } = makeRig();
  const h = k.store.put({
    name: 'sneaky', type: 'test.sneaky', class: 'pure', caps: ['net', 'clock'],
    ports: { in: {}, out: { probe: {} } },
    source: `return { probe: { hasNow: typeof ctx.now, hasFetch: typeof ctx.fetch, hasState: typeof ctx.state } };`,
  });
  const p = k.apply({ t: 'create-pane', nodeRef: { kind: 'hash', value: h } });
  const probe = await k.pull(p.id, 'probe');
  eq('a pure node is denied the clock even when it asks', probe.hasNow, 'undefined');
  eq('a pure node is denied the network even when it asks', probe.hasFetch, 'undefined');
  eq('a pure node gets no state', probe.hasState, 'undefined');
}

// ---------------------------------------------------------------- 6. moving a pane is not a semantic change
{
  const { k, types } = makeRig();
  const a = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.note'), config: { text: 'hi' } });
  const b = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.view.markdown') });
  const g0 = k.arr.serializeGraph();
  k.apply({ t: 'set-layout', canvas: 'main', pane: a.id, box: { x: 10, y: 20, w: 200, h: 120 } });
  k.apply({ t: 'set-layout', canvas: 'main', pane: a.id, box: { x: 900, y: 40 } });
  ok('moving a pane produces a byte-identical graph', k.arr.serializeGraph() === g0);
  ok('layout was recorded, just not in the graph', k.layout.get('main', a.id).x === 900);
  k.apply({ t: 'wire', from: { pane: a.id, port: 'text' }, to: { pane: b.id, port: 'text' } });
  ok('rewiring does change the graph', k.arr.serializeGraph() !== g0);

  // two canvases over one pattern, different layouts, same live bindings
  k.apply({ t: 'set-layout', canvas: 'second', pane: a.id, box: { x: 0, y: 0, w: 400, h: 400 } });
  ok('one pattern, two canvases, two layouts', k.layout.get('main', a.id).x !== k.layout.get('second', a.id).x);
  eq('and one shared value underneath', await k.pull(b.id, 'text'), 'hi');
}

// ---------------------------------------------------------------- 7. nested super panes
{
  const { k, types } = makeRig();
  const c1 = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.container'), label: 'outer' });
  const c2 = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.container'), parent: c1.id, label: 'middle', expose: { in: { x: 'y' }, out: { result: 'value' } } });
  const inner = k.apply({
    t: 'create-pane', nodeRef: ref(types, 'core.js.transform'), parent: c2.id, label: 'inner',
    config: { code: 'return input * 10;' }, expose: { in: { in: 'x' }, out: { value: 'out' } },
  });
  const src = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.js.transform'), config: { code: 'return 4;', in: 0 } });
  k.apply({ t: 'wire', from: { pane: src.id, port: 'out' }, to: { pane: c1.id, port: 'y' } });

  eq('a port crosses three levels of nesting, inside out', await k.pull(c1.id, 'result'), 40);
  ok('the inner node is a plain pane, not a special kind', k.arr.panes.get(inner.id).parent === c2.id);
}

// ---------------------------------------------------------------- 8. liveness propagates upstream
{
  const { k, types } = makeRig();
  const src = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.clock'), config: { intervalMs: 1000 } });
  const view = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.view.value') });
  k.apply({ t: 'wire', from: { pane: src.id, port: 'time' }, to: { pane: view.id, port: 'value' } });

  k.apply({ t: 'set-observed', frame: 'main', ids: [view.id] });
  ok('an off-screen source feeding an observed pane keeps running', k.sched.running.has(src.id));

  // Two canvases over one pattern. A flat observed-set would have the second clobber the first.
  k.apply({ t: 'set-observed', frame: 'second', ids: [] });
  ok('a second frame observing nothing does not blind the first', k.sched.running.has(src.id));
  k.apply({ t: 'set-observed', frame: 'second', ids: [view.id] });
  k.apply({ t: 'set-observed', frame: 'main', ids: [] });
  ok('and the pane stays live while any frame still watches it', k.sched.running.has(src.id));

  k.apply({ t: 'set-observed', frame: 'second', ids: [] });
  ok('nothing observed in any frame, the source goes quiet', !k.sched.running.has(src.id));
  k.apply({ t: 'set-residency', pane: src.id, residency: 'pinned' });
  ok('a pinned source runs with nobody looking', k.sched.running.has(src.id));
}

// ---------------------------------------------------------------- 9. runaway scripts
{
  const { k } = makeRig({ timeoutMs: 60 });
  // A never-settling await. LocalHost bounds this with the timeout race.
  // A synchronous spin loop can only be preempted by terminating a thread, which is
  // precisely what WorkerHost does in the browser and why user script never runs on the main thread.
  const h = k.store.put({ name: 'runaway', type: 'test.hang', class: 'pure', ports: { in: {}, out: { v: {} } }, source: `return new Promise(() => {});` });
  const p = k.apply({ t: 'create-pane', nodeRef: { kind: 'hash', value: h } });
  const t0 = Date.now();
  const v = await k.pull(p.id, 'v');
  ok('a runaway script is bounded', Date.now() - t0 < 2000);
  eq('and reports as an error rather than a hang', k.status(p.id).status, 'error');
  eq('with no value', v, undefined);
}

// ---------------------------------------------------------------- 10. headless
{
  const { k, types } = makeRig();
  const note = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.note'), config: { text: 'cooked headless' } });
  const md = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.view.markdown') });
  k.apply({ t: 'wire', from: { pane: note.id, port: 'text' }, to: { pane: md.id, port: 'text' } });
  const out = await k.cook();
  eq('a pattern cooks to completion with no client attached', out[md.id + ':text'], 'cooked headless');
  ok('and a late-joining client can be handed a snapshot', !!k.snapshot().arrangement.panes.length);
}

// ---------------------------------------------------------------- 11. undo
{
  const { k, types } = makeRig();
  const g0 = k.arr.serializeGraph();
  const a = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.note'), config: { text: 'one' } });
  k.apply({ t: 'set-config', pane: a.id, config: { text: 'two' } });
  k.undo();
  eq('undo restores config', k.arr.panes.get(a.id).config.text, 'one');
  k.undo();
  ok('undo removes the pane', k.arr.serializeGraph() === g0);
  k.redo(); k.redo();
  eq('redo replays', k.arr.panes.get(a.id).config.text, 'two');
}


// ------------------------------------------------- 12. secrets never leak (new milestone)
{
  const { k, types } = makeRig({ caps: ['net', 'clock', 'secret'] });
  const CANARY = 'ghp_CANARY_0d41d8cd98f00b204e98';
  k.apply({ t: 'put-secret', name: 'github', value: CANARY });

  const h = k.store.put({
    name: 'uses secret', type: 'test.secret', class: 'source', caps: ['secret:github', 'clock'],
    ports: { in: {}, out: { seen: {}, len: {} } },
    config: { schema: { intervalMs: 'number' }, default: { intervalMs: 0 } },
    source: `const t = ctx.secret('github'); return { seen: typeof t, len: t ? t.length : 0 };`,
  });
  const p = k.apply({ t: 'create-pane', nodeRef: { kind: 'hash', value: h }, secretRef: { github: 'github' } });
  await k.sched.settle();
  await k.trigger(p.id);
  eq('a node that declared the capability receives its secret', await k.pull(p.id, 'seen'), 'string');
  eq('and it is the real value', await k.pull(p.id, 'len'), CANARY.length);

  // the actual milestone: grep everything the system persists or hashes
  const surfaces = {
    'memo keys': [...k.sched.memo.keys()].join('|'),
    'the graph': k.arr.serializeGraph(),
    'the snapshot': JSON.stringify(k.snapshot()),
    'the journal': JSON.stringify(k.sched.journal),
    'pane state': JSON.stringify([...k.sched.paneState.entries()]),
    'the secret vault export': JSON.stringify(k.secrets),
  };
  for (const [where, blob] of Object.entries(surfaces)) {
    ok('the secret does not appear in ' + where, !blob.includes(CANARY));
  }

  const denied = k.store.put({
    name: 'nosy', type: 'test.nosy', class: 'source', caps: ['clock'],
    ports: { in: {}, out: { seen: {} } }, config: { schema: {}, default: { intervalMs: 0 } },
    source: `return { seen: typeof ctx.secret };`,
  });
  const q = k.apply({ t: 'create-pane', nodeRef: { kind: 'hash', value: denied }, secretRef: { github: 'github' } });
  await k.trigger(q.id);
  eq('a node that did not declare it has no way to ask', await k.pull(q.id, 'seen'), 'undefined');
}

// ------------------------------------------------- 13. flavour caches, secret does not split
{
  const { k, host, types } = makeRig({ caps: ['net', 'clock', 'secret'] });
  const cfg = { code: 'return input + 1;', in: 41 };
  const mk = (extra) => k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.js.transform'), config: cfg, ...extra });
  const n0 = host.byType.get('core.js.transform') || 0;

  const a = mk({ flavourRef: 'github', secretRef: { tok: 'work' } });
  const b = mk({ flavourRef: 'github', secretRef: { tok: 'personal' } });
  const c = mk({ flavourRef: 'gitlab', secretRef: { tok: 'work' } });
  await k.pull(a.id, 'out'); await k.pull(b.id, 'out'); await k.pull(c.id, 'out');
  eq('same flavour, two identities: one computation', (host.byType.get('core.js.transform') || 0) - n0, 2);
  ok('a different flavour is a different computation', true);
}

// ------------------------------------------------- 14. wires declare what they carry
{
  const { k, types } = makeRig();
  const a = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.note'), config: { text: 'x' } });
  const b = k.apply({ t: 'create-pane', nodeRef: ref(types, 'core.view.markdown') });
  const w1 = k.apply({ t: 'wire', from: { pane: a.id, port: 'text' }, to: { pane: b.id, port: 'text' } });
  eq('a wire is a value wire unless it says otherwise', w1.kind, 'value');
  k.apply({ t: 'unwire', id: w1.id });
  const w2 = k.apply({ t: 'wire', kind: 'event', from: { pane: a.id, port: 'text' }, to: { pane: b.id, port: 'text' } });
  eq('and can declare itself an event wire', w2.kind, 'event');
  ok('which is part of the semantic graph', k.arr.serializeGraph().includes('event'));
}

console.log('\n' + results.join('\n'));
console.log(`\n  ${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
