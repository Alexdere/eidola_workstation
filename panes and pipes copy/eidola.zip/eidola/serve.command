#!/bin/bash
# Double-click this file to run eidola.
# ES modules and module workers need a real origin, so file:// will not work.
cd "$(dirname "$0")"
PORT=${PORT:-8777}
echo "eidola -> http://localhost:$PORT"
( sleep 1; open "http://localhost:$PORT" 2>/dev/null || true ) &
python3 -m http.server "$PORT"
