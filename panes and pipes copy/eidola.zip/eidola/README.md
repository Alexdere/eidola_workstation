# eidola — MVP

A visual operating environment. Panes are binding sites onto a store of small scripts;
patterns are latent arrangements; a demand-driven scheduler decides when anything runs.

**Run it:** double-click `serve.command` (or `python3 -m http.server` in this folder, then
open `localhost:8777`). ES modules and module workers need a real origin, so `file://` will
not work.

**Test it:** `node test/kernel.test.js` — 41 assertions, no dependencies, no browser.
That the kernel runs headless in Node is not a convenience, it is the proof that the
separation is real.

---

## The invariant

> A pane is a binding site. It relays a node from the store into a context.
> It owns nothing except status and presence.
> The store holds logic. The pattern holds arrangement. The runtime holds execution.

Every feature proposal gets one question: *does this require the pane to own something it
currently doesn't?* If yes, it belongs in the store, the pattern, or the runtime.

These are enforced, not asserted:

| Rule | Enforcement |
|---|---|
| Kernel never touches a screen | test greps `src/kernel/` for DOM globals |
| Pane has no compute | there is no `compute` field on a pane; only `NodeDef` has `source` |
| Nodes have no position | geometry lives only in `LayoutStore`, unreachable from `Arrangement` |
| Pure means pure | `grantedCaps` returns `[]` for pure nodes regardless of what the manifest asks; a denied capability is simply not a property on `ctx` |
| Moving a pane is not a semantic change | `serializeGraph()` excludes layout and status; a test asserts byte-identity after a move |

---

## Layout

```
src/kernel/       zero DOM, runs in node
  ids.js          content hashing, key-sorted stable stringify
  store.js        content-addressed NodeDefs, mutable name index, search, presets
  arrangement.js  patterns / panes / wires + a deliberately separate LayoutStore
  scheduler.js    demand-driven, memoized, observed-gated evaluation
  kernel.js       apply(command) in, events out — the protocol surface
src/runtime/      swappable execution
  caps.js         one declaration, three jobs: prompt, sandbox config, scheduler hint
  host.js         LocalHost (node, tests) + WorkerHost (browser)
  worker.js       the sandbox
src/nodes/core.js the starting library
src/persist/      storage adapter: memory + localStorage today, SQLite behind the same 3 methods
src/ui/           a lens. views.js, canvas.js, omnibar.js
src/app/main.js   the only file that knows both a kernel and a screen exist
test/             the milestones as assertions
```

---

## How it runs

Four node classes, distinguished only by their relationship to the outside world:

- **pure** — `f(inputs, config) → outputs`. Memoized by input hash. Auto-cooks freely. Gets no clock, no network, no state.
- **source** — produces values from outside on its own schedule. The only entry point for nondeterminism. The kernel owns the interval and injects `ctx.now()`, so every run is journaled and replayable.
- **effect** — writes outside. **Never auto-cooks.** Requires an explicit trigger. This is the only policy baked into the system and it is why a homepage does not fire webhooks because you opened a tab.
- **container** — a pane containing panes. Ports cross the boundary via `expose`.

```
dirty(n) ← n changed, or an upstream produced a new value
live(n)  ← observed(n) ∨ pinned(n) ∨ some live consumer is downstream of n
cook(n)  when dirty(n) ∧ live(n) ∧ (class(n) = 'pure' ∨ triggered(n))
```

Two consequences worth knowing. The viewport is a garbage collector for computation — pan
away from a subgraph and it goes quiet. And liveness propagates **upstream**, so a source
feeding an on-screen pane keeps running even though the source itself is off-screen.
Without that second rule, panning away quietly kills your weather poll.

`residency: 'pinned'` opts a pane out of viewport GC entirely. That distinction is the
difference between a dashboard and a thing that silently loses your data.

---

## Two mechanisms people usually conflate

**Pin vs follow.** `nodeRef: {kind:'hash'}` pins an exact version. `{kind:'name'}` follows
edits. Shift-enter when summoning pins instead of follows.

**Instance vs ref.** Two panes with distinct `stateKey`s are instances with separate state.
Two panes sharing a `stateKey` are refs onto one live thing. Same column, no second
mechanism.

And because the memo key is `hash(defHash, config, inputHashes)`, two patterns containing
the same node with the same inputs **share cached computation without sharing state**,
automatically. Overlap is free rather than a conflict to resolve.

---

## What this MVP deliberately is not

No Python or wasm toolchains, no portals, no community registry, no multiplayer, no cloud
sync, no LLM omnibar, no local agent. JS-in-a-worker only — one language proves the
contract, and proving *the runtime is a plugin* is why Python can arrive later without
regret.

Known gaps, stated plainly:

- **Cycles are detected, not prevented.** Wiring A→B→A is accepted and only throws when
  something pulls it. It should be rejected at wire time.
- **The memo key serialises every input value on every pull.** A large table gets re-hashed
  constantly. Values should carry a hash computed once when produced. Related: a diamond
  dependency re-walks shared upstream nodes several times per frame — memo saves the
  compute but not the traversal. Both are contained fixes in the scheduler and both get
  expensive to retrofit.
- **`hashString` is FNV-flavoured, not SHA-256.** Fine for a local store, wrong the moment
  nodes are exchanged with anyone.
- **localStorage caps out around 5MB.** IndexedDB is the next step and already sits behind
  the adapter interface.
- **A pinned source in a background browser tab gets throttled to about once a minute.**
  Real background residency wants the headless runtime; the browser will not give it to you.
- **The head renders DOM, not a cell buffer.** Comfortable to a few hundred mounted panes,
  which is well past what a homepage needs. The cell-grid renderer is the upgrade that makes
  render cost depend on visible cells rather than pane count — and it is what makes remote
  and headless rendering possible. It is also the point at which text editing stops being
  free and the kernel has to own one hidden input it loans to whoever holds focus.

---

## Working in it

There is no bar. Start typing on the landscape.

| | |
|---|---|
| a word | searches the store |
| a sentence | stays a note |
| `>` | a command |
| enter | summon · **shift-enter** pins that exact version instead of following edits |
| arrows | move focus by direction, not tab order |
| enter *(on a pane)* | edit it — or descend into it, if it is a group |
| esc | out of the editor, then out of the group, then out of focus |
| drag a right-edge port to a left-edge port | wire them · click a connected input to disconnect |
| ▸ in the header | trigger. Effects only ever run this way |
| cmd-p | pin, so it keeps running when you look away |
| cmd-b | borderless · **backspace** remove · **cmd-z** undo |

Editing a pane means editing its node's declared `config` schema — so a note's text, a
transform's code and a poll's url are the same form. Any node that declares a field gets an
editor for free, including ones nobody has written yet.

To build a group: summon `group`, double-click to enter it, summon nodes inside, wire them,
then edit any inner pane and tick the ports you want visible from outside. From the outside
it is one box with those ports.

---

## The expansion path, and why none of it is a rewrite

| Next thing | What it costs |
|---|---|
| **SQLite / FTS5 store** | implement three methods behind `persist/adapter.js`. Search already returns the shape FTS5 must reproduce. |
| **Headless runtime** | the kernel already runs in node and `apply/on` are already serializable. Put a WebSocket in front of `Kernel`; the browser's local mode becomes the same code with both ends in one process. |
| **Multi-screen / multi-client** | falls out of the above. The kernel's only knowledge of screens is a set of observed pane ids, so three screens and a terminal client are just three clients calling `set-observed` with different sets. There is no multi-window feature to build. |
| **Python / Rust nodes** | add a host implementing `execute(def, req)`. The kernel does not change. |
| **Portals** | a node with `caps: ['browser']`, a capability the premium head provides and the plain one does not. The pane still just relays. |
| **Registry** | node defs are already content-addressed and serializable; install = `put-node`. |
| **Cell-grid renderer** | replace `src/ui/`. Nothing above it moves. |

---

## The one strategic risk

The graveyard is large and full of well-built things: Yahoo Pipes, Luna, Sourcetrail,
NoFlo. The survivors — ComfyUI, Houdini, TouchDesigner, Grasshopper, Node-RED — share one
property: **the graph is authoritative for something.** It isn't a view of a program
written elsewhere; it is the program.

So the sequencing matters. Make the graph authoritative first — homepage, personal
automation, data flow, where the graph genuinely *is* the program. Let the
code-architecture lens be the proof that lenses work rather than the wedge. A derived,
read-only architecture map is a tool people open twice and admire. Sourcetrail was good and
died on exactly that.
