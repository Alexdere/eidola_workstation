# hosts/worker — PLACEHOLDER

**Why it matters.** Every execution theorem in `docs/5-foundations/formal-foundations.md` is
conditional on the Floor: a leaf reads only its declared inputs, powers and journal. Today that is
convention. This host makes it construction, and it is the one build that unlocks sharing other
people's units (ADR-0008).

**What it must do**
1. Implement `ExecutionPort` (`core/src/ports.ts`) by running each `host/1` body in a dedicated
   Web Worker (browser) or worker thread (node) whose global scope has no `fetch`, timers,
   `Date`, `Math.random`, `crypto`, storage or DOM. Hardened JavaScript (SES `lockdown()` +
   `Compartment`) is the most direct way to get a frozen, capability-free realm; a sandboxed iframe
   with a strict CSP is the fallback.
2. Pass in exactly the `Ctx` the boundary declares (`core/src/caps.ts`): `memFold`, `memAppend`,
   `journal`, `world` — and nothing else.
3. Keep the tick synchronous for the engine: either run bodies through `Atomics.wait` on a
   `SharedArrayBuffer` (needs cross-origin isolation), or make the engine's pass B async. The
   second is a core change and needs an ADR.
4. Prove it with the replay test: record, clear derived state, replay, compare sigma — plus a test
   that a body calling `Date.now()` throws instead of returning.

**Open questions:** per-tick cost of crossing into the worker (batch a whole pass B per message);
how secrets reach an AI body without entering its realm (they stay host-side today).
