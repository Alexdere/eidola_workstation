# hosts — what fills the execution hole

A host turns an opaque body into something callable (`ExecutionPort.resolve(body, unit) → LeafDef`,
`core/src/ports.ts`). The kernel ships two: `PrimHost` (the primitive table) and `JsHost` (runs
`host/1` JavaScript with `new Function`, in the page). Both live in `core/src/`.

| host | status | what it guarantees |
|---|---|---|
| `PrimHost` | running | everything: primitives are part of the spec |
| `JsHost` | running, **soft** | nothing structural — a body *could* read the clock or the network; the replay test catches it after the fact |
| `worker/` | **placeholder** — see `worker/README.md` | Law 4 and Law 5 by construction: the body's world contains only what its boundary declares |
| node host | not started | a host for the CLI / daemon tier (T2) |

Until the worker host exists the alpha policy is ADR-0008: run code you wrote or reviewed.
