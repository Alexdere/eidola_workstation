# The Wrap

*How the head gets executed: the TS port, the oracle, the browser scaffolding, and first
light. Companion to `claude/one-core.md` (the shape), `claude/core-spec.md` (the kernel),
`claude/the-head.md` (the presentation laws) and `claude/implementation-v0.1.md` (what the
Python build found). Written 2026-08-22.*

The Python core runs — eight laws, 27 tests, ~1400 lines. It has never been *seen*.
Merge-order #1 ("point a browser at Eidola") is still open. This is the plan to close it.

---

## 0. Three questions, one seam

"What do we make to see it," "why Python not the browser," and "the head is really eidola"
are one question: **where does the core↔head seam sit, and in which process does the kernel
live.** Everything else is downstream.

**Why it was Python.** Python was correct for *discovering* the laws — a medium you refactor
at the speed of thought, which the removal test (eight axioms → two constitutive) required.
It earned its place as the medium the laws were found in. It is the wrong medium for the head,
because the head's process is the browser tab.

**Head Law 4 already decided this.** No optimistic mutation → render from state → the
round-trip must be cheap → "kernel-in-the-same-process makes the shortcut unnecessary." A
browser head talking to a Python core over a socket breaks the premise Law 4 leans on: every
render eats a hop, or you cheat with optimistic updates, which the head laws proved diverge the
instant a second view exists. So the kernel comes into the tab. Decision (2026-08-22):
**port the core to TypeScript.** Native T0, ships as "genuinely complete," no WASM weight.

**Python is not discarded — it is promoted to the oracle.** Identity is content (Law 3); σ is
a map of hashes; serialization is byte-identical. Two independent cores must tick to
*bit-identical σ* or one is wrong. The deterministic Python grades the TS core forever, free
labelled data, shadow mode free because truth is append-only. This is the Hermione race
(`merged-architecture.md` §6) applied to the kernel itself — the same move as running FTS5 to
grade NTDB.

---

## 1. The spec the oracle forces

Bit-identical σ across two languages is only possible if the hash is defined over a **canonical
byte encoding**, not over language-native objects. So the first artifact is a versioned,
language-neutral serialization spec — and that is exactly requirement #1 from
`merged-architecture.md` §10, arriving early instead of being retrofitted. The grader and the
interchange format are one object.

What the spec must pin, drawn from what the Python build already learned:

- **Merkle by construction.** A form references its children *by hash*. Hashing is bottom-up;
  a cycle would need a form's hash before computing it, so the store is a DAG permanently
  (Law 3, free consequence).
- **Wires sorted, ports not** (impl D3). Authoring order cannot enter identity; a boundary is
  an ordered interface. A small Law 8 boundary case, and the one that was silently wrong until
  a byte-identical test existed — so it must be in the spec, not in the code by accident.
- **`@in` / `@out` reserved endpoints** (impl D1). A composite's boundary appears *in* its
  graph as two ordinary endpoints; there is no separate expose table.
- **Blobs content-addressed; code is a blob inside identity** (impl §5). Shipping the form
  closure ships the program.
- **σ is PortAddr → BlobId, an address is a path not an Id** (impl §6). Forty occurrences of
  one unit share one memo entry because the key is content and the address is not.

Canonical encoding candidate: deterministic CBOR or JCS (RFC 8785) over sha256, no
dependencies. The choice is settled by whichever both cores can implement to the byte with the
least ceremony.

> The oracle test is one sentence: feed both cores the same workspace and the same
> source-emission log; replay; assert σ bytes equal at every tick. Any divergence is a TS bug
> — or an under-specified spot in the spec, which is itself worth finding.

---

## 2. The shape, made concrete

Following `one-core.md`'s diagram, with the browser tier filled in:

```
suites/    eidola (homepage, first) · graphmap (the wedge, later)
           nodes + lenses + presets + default arrangement
heads/     browser (first) · cli (later)
──────────────────────────── protocol boundary ─
core/      (TS)  ids · store · graph · scheduler · caps · mem · ports
           the seven rules, ported from Python 1:1
──────────────────────────── port boundary ─────
drivers/   persist: idb (Dexie) · opfs (corpus) · yjs+y-indexeddb (graph tier)
           host:    worker (ExecutionPort) · local
oracle/    the Python core + the bit-identical-σ harness
spec/      canonical serialization + hash (language-neutral, versioned)
```

### Core modules (TS, port of the Python 1:1)

`ids` (canonical encode + content hash) · `store` (immutable G + B, DAG by construction) ·
`graph` (panes, wires, patterns; `serializeGraph()` byte-identical; @in/@out) · `scheduler`
(the five-pass tick F8: sources → delay-reads → body[topo, memoised] → delay-writes → commit;
liveness fold `observed ∨ pinned ∨ upstream`) · `caps` (Authority floor: ports vs powers, no
composite binds a power; Ctx carries only declared powers) · `mem` (role/address binding, the
one addition — leaf names a role, boundary names the address, runtime binds at cook) · `ports`
(persistence + execution interfaces).

The 27 Python tests port to TS and must pass identically. Passing them is necessary but not
sufficient — the oracle is what proves *bit* fidelity, not just behavioural.

### Head (browser) — two stores, one vertex set

The head holds **two** stores, which is `the-head.md` §1 made mechanical:

- **Graph projection** — subscribed from the core via `apply(command)` in / events out. Never
  mutated directly.
- **Presentation store** — gauge: geometry, z-order, collapse, which-rect-is-viewport. Local,
  persisted, and *inert* — it participates in nothing (Law 8). Saved and inert at the same
  time, so the composer's thinking is kept without becoming content.

The loop is render-from-state, always (Head Law 4): command → core → events → projection →
re-render. A pane renders its value up through a lens (renderer registry); a click goes around,
becoming a command — never back down the wire the pixels came up (Head Law 5). Navigation
(zoom, collapse, tab, drill) is gauge ops on the presentation store only, and is therefore
free of the graph (§7). To renest you **descend** into the target and place — no cross-boundary
drag exists (Head Law 2).

### Liminal — a runtime mode, not a table

Cook an undeclared graph with **memo off**, results not persisted, against a *tentative*
boundary. **Melt** takes a declared unit into liminal space (the original untouched because it
cannot be touched); **Declare** freezes the boundary, the hash exists, and `parent_hash`
lineage is set at exactly that event. Without this, every keystroke is a new hash and authoring
is impossible — Closure is unusable if you cannot hear it while writing it (`the-head.md` §4,
impl §8). This is load-bearing, not polish.

---

## 3. First light is the invariant, not a feature

The smallest honest first screen is the memo-sharing test (impl §6) turned into pixels:
**two panes over one node.** The node computes *once* (two views, one memo entry). Drag a pane
— and the on-screen hash readout does not move. That is `serializeGraph()` byte-identical under
a gauge transformation — the group-membership test of Head Law 1 — *seen* instead of asserted.

> The first thing on the screen is not "look what it does." It is "look what stays still."

Then each next step is a core-spec §5 falsification test with a face on it: add a wire
(one-line graph diff, visible); melt → play unmemoised → declare → watch the hash appear; add a
second suite item.

Why eidola-homepage and not graphmap for first light: graphmap is the **wedge** (authoritative
for a real thing) but geography is heavy — MapLibre, PMTiles, tiles. eidola-homepage is the
**daily driver**, and "make useful things and pipe them" is Closure as an everyday gesture.
The homepage keeps the core load-bearing; graphmap proves the core is worth something. Both are
suites riding one head — the head stays domain-free.

---

## 4. Build order

1. **`spec/`** — canonical serialization + hash, versioned. The interchange format and the
   oracle's shared ground.
2. **`core/` (TS)** — ids/store/graph/scheduler/caps/mem/ports. Port the 27 tests; they pass.
3. **`oracle/`** — Python grades TS on bit-identical σ, fuzzed over workspaces + source logs.
   Green = the port is faithful to the byte.
4. **`heads/browser`** — two stores, render-from-state, one pane over one node. **First light:
   two-panes-one-node, drag → hash unchanged.**
5. **`drivers/host/worker`** — Novelty becomes construction, not convention (impl §7).
6. **`drivers/persist`** — yjs graph tier, idb cache, opfs corpus (three lifetimes, one port).
7. **Liminal** — melt/declare, so the homepage is authorable rather than read-only.
8. **`suites/eidola`** — nodes + lenses + presets + default arrangement. The homepage you open.

Falsification checks that bite along the way (core-spec §5, merge-order): plugin #2 written
without touching a kernel file · lens #2 on an existing address without knowing what it shows ·
a format reader added with no new primitive · the highest-priority open item, coercion
composition (finding #5), before many format readers exist rather than after.

---

## In one breath

The kernel comes into the tab as TypeScript because Head Law 4 needs the round-trip cheap; the
Python core is kept as the oracle that grades the port to the byte; grading two cores against
each other forces the versioned serialization spec the project needed anyway; the head is two
stores over one vertex set — a graph projected from the core and an inert presentation gauge —
rendered always from state; authoring needs liminal space or every keystroke is a new hash; and
the first thing to put on a screen is not a feature but the invariant itself — two panes over
one node, and a hash that does not move when you drag.
