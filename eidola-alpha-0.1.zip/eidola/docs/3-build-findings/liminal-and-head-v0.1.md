# Liminal + head v0.1 — what the build found

*The draft state, the closure gesture, and the first head. Companion to
`claude/core-ts-v0.1.md` (the kernel) and `claude/the-wrap.md` (the plan). Written
2026-08-22.*

Steps 4, 7 and 8 of the wrap's build order, done together — they turned out to be one thing.
~5700 lines total, 41 core tests, 10 oracle tests, 22 checks driven in a real browser, and the
differential grader still bit-identical after all of it.

---

## 1. Lineage cannot be inside identity

`merged-architecture.md` §6 wanted `parent_hash` and could not find a trigger for it.
Declaration is the trigger — the one event where a boundary freezes and a hash comes into
existence. But putting the field where it was imagined to go breaks the keystone:

> A unit's identity is its content. Two structurally identical units must remain **the same
> thing** however each of them came to be. A `parent_hash` field inside the unit would make
> identical things distinct — Law 3 backwards.

So lineage lives in a **ledger beside the store**, `unitId → parentUnitId`. The test that pins
it: melt a composite, change nothing, declare — and you get *the same id back*, with no
lineage recorded, because nothing happened. History is a fact about the world, not a fact
about the thing.

This generalises past lineage: **anything that is true of an object's provenance rather than
its content belongs beside the store, not on the seam.** Provenance, license, fetch time —
graphmap's requirement #3 — is the same shape and now has a home.

---

## 2. The boundary is not invented; it is read off the crossings

The closure gesture is `select → group`, and the interesting part is where the interface comes
from. It is not designed and not prompted for:

- a wire that **entered** the selection becomes an `in` port, shaped by its consumer
- a wire that **left** it becomes an `out` port, shaped by its producer
- several external consumers of one internal port share **one** boundary port — fan-out, not
  fan-in, which the core already forbids

"A graph you are building is a workspace until you declare its exposure, and the `expose` map
is the act of crystallisation" — the map turns out to be *already drawn*, by whatever you
happened to wire before you drew the line. The author's only real decision is where the line
goes.

Which retroactively justifies deletion D1 (`expose` dissolved into `@in`/`@out`): a separate
expose table would have had to be authored; wires do not.

---

## 3. Liminal is a scratch store, not a flag

The implementation that fits the law is not a mode bit. It is a **store that reads through to
the real one and writes only locally**, plus the memo off. A draft can then be evaluated as
many times as you like — twenty edits, twenty plays — and the addressed world learns nothing.
The test counts stored units before and after and they are equal.

Stubs matter more than expected. A draft is played against the *tentative* boundary, so its
`@in` ports have no producers; the head supplies the parent's actual values at that pane's
inputs as stubs. The effect is that **descending into a composite lets you hear it in the
context it actually runs in**, not in a vacuum. That was not in the design and it is the
difference between a scratch buffer and a useful one.

---

## 4. Two findings the head produced that the kernel could not

### Pinning a composite was a no-op — and the oracle could never have caught it

`pinned` is a declaration on a *seam* that what is behind it has a reason to be alive. The
liveness fold only ever looked at leaf panes, so pinning a container did nothing. Law 6 had a
hole exactly where composites are.

The instructive part is why the grader was silent: **both implementations had the same gap.**
Two implementations written from one spec by one author share that author's blind spots — the
spec said what `pinned` means without saying what it means for a composite, and both cores
read it the same wrong way. So a differential oracle proves *agreement*, never *correctness*,
and its silence is only as strong as the spec is complete. What found it was a browser test
asking a question in the user's terms: *I pinned this box, why is nothing running?*

### Naming is gauge

Labels — for panes and for units — are not content, because identity is content and a name is
not. So renaming lives in the presentation store and **changes no hash**. This falls out of
Law 8 rather than being decided, but it is not obvious until a UI needs a name field, and it
is the kind of thing that would have been quietly wrong if the head had shipped first.

---

## 5. What the head made watchable

The presentation store is a real second structure over the same vertex set, and putting it on
a screen turns three laws into things you can do rather than things you are told:

| gesture | what it shows |
|---|---|
| drag a pane | the graph hash does not move; a counter says how many gauge ops since it last did |
| **fold** a pane | still no hash change — **but the value behind it disappears** |
| drag port to port | the hash *does* move, because a wire is content |
| wire `bool` into `num` | refused at wire time, with the reason, before anything runs |
| group a selection | several panes become one unit, in the palette, usable anywhere |
| descend | the hash readout says *liminal*: you are editing something with no identity yet |

The second row is the one worth watching. Folding is pure gauge — the graph is byte-identical
— and yet the computation behind it stops, because folded means unobserved and unobserved
means not alive. **A purely presentational act changing what runs without changing what the
thing is.** That is `the-head.md` §5's observer effect, and on a screen it reads as a feature
rather than as the concession it was written up as.

---

## 6. Two bugs the browser found that no unit test would have

Both are about the head being a *head*, and both were invisible to every other kind of test:

1. **A refusal that repaints nothing is not a refusal.** The rejection path set the message and
   returned without re-rendering, so the law was enforced and the user saw the previous
   message. Enforcement you cannot see is indistinguishable from silence.
2. **Rebuilding the pane DOM on selection destroyed double-click.** Selection is presentation,
   so it must repaint classes, not replace nodes — replacing them between the two halves of a
   double-click means the browser never synthesises the event, and descending is precisely the
   gesture that needs it. *Gauge changes must be applied as gauge, in the DOM too.*

---

## 7. Scoreboard

| Push | Outcome |
|---|---|
| liminal | **core grows** — a read-through scratch store; the law needed a mechanism, not a flag |
| lineage | **core grows, identity doesn't move** — a ledger beside the store |
| the closure gesture | **core doesn't move** — the boundary was already drawn by the wires |
| pinning a composite | **core fixes a hole** — a pin is on a seam, so it must reach the interior |
| naming | **core confirms** — a name is not identity, so renaming is gauge |
| the head | **kernel unchanged** — no new construct was needed to put it on a screen |

## 8. Still open

- **A real ExecutionPort.** Still the local host calling a function; Novelty is convention, not
  construction. A worker host is the next thing that makes a law impossible rather than
  detectable.
- **Persistence drivers.** Everything is in memory; the browser tier (yjs / idb / opfs) is
  unbuilt, and the persistence port is synchronous while IndexedDB is not — that mismatch is a
  real design question, not a chore.
- **Nested descent beyond one level** works, but a draft inside a draft has never been
  exercised hard.
- **Composite-level memoisation**, **higher-order units**, **incremental folds**,
  **frame-relative time** — unchanged from `core-ts-v0.1.md` §8.
- **The primitive table's boundary.** Twenty-six ops now. Every one added is shared ground two
  languages must agree on; every one refused is something a suite must build from closure. That
  trade is the live design pressure and it has no formula.
