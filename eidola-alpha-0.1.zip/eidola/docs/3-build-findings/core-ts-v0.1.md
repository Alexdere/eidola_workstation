# Core TS v0.1 + oracle — what the build found

*The spec, the TypeScript kernel, and the Python oracle that grades it. Companion to
`claude/the-wrap.md` (the plan) and `claude/implementation-v0.1.md` (the Python build that
found the laws). Written 2026-08-22.*

Steps 1–3 of the wrap's build order, done. ~1590 lines of TS core, ~1490 lines of Python
oracle, ~470 lines of spec, 29 falsification tests, 10 oracle tests, and a differential fuzzer
that has graded several thousand ticks across two independently written implementations
without a divergence.

The rule that produced this document is the same one as last time: *structure points, detail
refutes.* Below is only what changed by being built.

---

## 0. The oracle is not a testing nicety — it is what forces the spec

Identity is content and σ is a map of hashes, so two independent implementations must tick to
**bit-identical σ** or one is wrong. But bit-identical σ across two languages is only possible
if the hash is defined over a **canonical byte encoding**, not over either language's native
objects.

So the grader cannot exist without a versioned, language-neutral serialization format — and
that format is requirement #1 from `merged-architecture.md` §10, the one that is cheap now and
near-impossible to retrofit. **The grader and the workspace file are the same artifact.**
Wanting the first paid for the second before there was anything to migrate.

This is the Hermione race applied to the kernel itself, and it generalises: the deterministic
implementation grades the speculative one, shadow mode is free because truth is append-only,
and the loser becomes a driver rather than a deletion.

---

## 1. Code is a blob, so the same computation in two languages is two units

The first thing the build found, and it arrived within an hour.

Law 3 says identity is content. `implementation-v0.1.md` §5 says code is a blob and the blob
is inside the unit's identity — which is what makes migration free. Both are right, and
together they say something the design had not noticed:

> A leaf written in JavaScript and the same leaf written in Python are **different contents,
> therefore different units, therefore different hashes.** Cross-language identity is not
> merely hard; it is forbidden, and correctly so.

Which means an oracle cannot grade arbitrary leaves at all. The resolution is not a weakening
but a new object: a **primitive table** whose identity is the **op name**, not any source
text. Seventeen ops (`core.add`, `core.delay`, `core.source`, …), implemented identically by
every conformant core, and a unit built from them hashes the same everywhere.

```
{ "@": "prim/1", "op": "core.add" }              portable — identity is the name
{ "@": "host/1", "lang": "js", "src": "…" }      not portable — identity is the text
```

So the body of a leaf is one of exactly two things, and the split is not a convenience: it is
the line between **the shared ground** and **a host extension**. It is also the strongest
version of "a leaf's source runs in a namespace with no `import`, `open` or `eval`" — a
primitive has no source to constrain.

**Consequence for suites:** a suite made of primitives is portable across every head and every
host. A suite that reaches for host code is portable across heads *in one language*. That is a
real design pressure on where the primitive table's boundary sits, and it did not exist before
today.

---

## 2. The five classes are the five passes

`core-spec.md` listed four classes (`pure | source | effect | container`). Running the tick
forced a fifth, `delay`, and the count rising is supposed to be an alarm (guard #1). It
survives the alarm because of what it turned out to be:

| pass | | class |
|---|---|---|
| 0 | sources emit, journalled on the way in | `source` |
| A | delay reads: fold over the log as at tick start | `delay` |
| B | the body, topological over the live set, memoised | `pure`, `effect` |
| C | delay writes: inputs settled, appends buffered | `delay` |
| D | commit | — |

`container` is structural and belongs to no pass. So the taxonomy is not a taxonomy — **the
classes are the passes**, and `delay` earns its place by being the one class the tick's shape
exists for. Passes A and C are there for nothing else. A class that named no pass would be
the convenience the guard is aimed at.

The "handed no inputs" rule survived contact with code in its strong form: `read(ctx)` has no
parameter for inputs. Impossible, not detectable.

---

## 3. Route selection had to become part of the spec

Law 7 says transitions must agree around a loop, and `core-spec.md` finding #5 — route
agreement — is the highest-priority open item. Implementing it produced two findings the
design had not reached.

**First: agreement is only ever within a tolerance.** `temp.c → temp.k` directly and
`temp.c → temp.f → temp.k` compose different roundings. Requiring bit-identical agreement
makes the check either vacuous or permanently red, and a permanently red check gets switched
off. So **the tolerance is part of the frame's declaration**, and for non-numeric frames it is
zero, i.e. canonical equality. The check is now real and it passes.

**Second, and sharper: if routes agree only within tolerance, then *which route was taken* is
visible in the last bits of σ.** Selecting a route by registration order would let two
conformant cores produce different σ while both being right. So route selection is now
specified:

> The canonical route is the **shortest**, ties broken by the lexicographically smallest
> sequence of frame ids — a property of the registry's **content**, never of the order it was
> built in.

Which is Law 8 turning up in an unexpected place: *the order transitions were registered in is
gauge, and a value's path must not depend on gauge.* The doc's own line — "the canonical route
is the semantics; a direct route is an optimisation carrying an obligation to agree" — was
already the answer, written before there was a mechanism that needed it.

---

## 4. The fuzzer found what neither test suite could

Both implementations passed their own suites and the golden vectors. The differential fuzzer —
random workspaces, random source journals, σ compared per tick — found two divergences where
**neither core was wrong on its own terms and the spec was underdetermined.** That is the
find the grader exists to produce.

### The integer rule was wrong

CVE/1 said: *integers beyond ±(2⁵³−1) are not values; reject them at encode time.* It reads
sensibly. Implemented literally in TypeScript it made the core **refuse `1e10 × 1e10`** — a
product of two of its own values, and an exactly representable double.

The error: the rule describes a property of *integer types*, and the whole point of the
one-numeric-type universe is that there are none. Every binary64 is a value. What actually
needs checking is an implementation's **input**, and only in a language that has an exact
integer type:

- JavaScript: nothing to check. Every number *is* a binary64.
- Python: an `int` must round-trip through a double or be **refused**, never silently rounded.

The asymmetry is honest and belongs in the spec rather than being smoothed over. It is also a
small instance of the general shape: *a rule stated about the world when it belongs to the
seam.*

### Gathering inputs must be all-or-nothing

Writing each input into σ as it was resolved meant a site with one missing input contributed a
partial fragment — and *which* fragment depended on the order its ports happened to be
declared in. Absence is a member of the set (`core-spec.md` §3e); a partial absence is not.
Gather now collects first and writes only if every input is present.

---

## 5. State scope is a property of the unit, not the occurrence

Memory binds by role: the leaf names `mem:r`, the pane names the address, the runtime binds
them at cook time (`implementation-v0.1.md` §2). Held literally, one consequence follows that
nobody chose:

> Two occurrences of the same stateful container **share state**, because the address lives
> inside the container's graph, and the graph is inside the unit's identity. To get
> independent state you must make them different units.

That is not a bug to fix. It is Law 3 saying two things with the same content are the same
thing, **including the same state binding**. It is `instance-vs-reference is not a column, it
is A1 and A8 together`, cashed out into something you can trip over. Both tests are in the
suite: different addresses hold independent state, the same address shares one log.

The practical shape: a suite author who wants two independent counters writes two units, and
"writing two units" is one field different in a JSON declaration. Content addressing makes the
cost of distinctness exactly the size of the distinction.

---

## 6. Flattening trades composite memoisation for path addressing

Evaluation flattens nested graphs into leaf **sites addressed by path**, with container
boundary ports surviving as relay endpoints (so a value crossing into a composite still
crosses a real seam rather than being inlined away).

The cost, stated rather than hidden: **memoisation happens at leaf granularity.** A wholly
pure subgraph is not memoised as one unit — its leaves are memoised individually. The property
that matters is unaffected — two panes over one node still compute once, because the memo key
is content and the address is not — but composite-level memoisation is now a known,
unimplemented optimisation rather than an assumed behaviour.

---

## 7. Scoreboard

| Push | Outcome |
|---|---|
| cross-language identity | **core grows** — a primitive table, because code-in-identity forbids the alternative |
| the class taxonomy | **core confirms** — five classes because five passes; the count rose and earned it |
| route agreement (finding #5) | **core grows** — tolerance in the frame, canonical route in the spec. Closed structurally. |
| the integer rule | **spec shrinks** — the constraint was on the wrong object |
| gather semantics | **core confirms** — absence was already a member; partial absence never was |
| state scope | **core doesn't move** — Law 3 already decided it; the build only made it visible |
| the workspace format | **arrived early** — the grader could not exist without it |

## 8. Still open

Unchanged from `implementation-v0.1.md` §8 except where noted:

- **Liminal space** — still the next thing worth building, and now blocking: everything is
  declared, so authoring in a head has full hash churn. Closure is unusable if you cannot hear
  it while writing it.
- **A real ExecutionPort** — the local host calls the function, so Novelty is enforced by
  convention. A worker host makes it construction. The replay test is what currently catches
  violations.
- **Incremental folds** — `mem_fold` still recomputes over the whole log.
- **F9 · higher-order units** — a port carrying a unit id, still not implemented.
- **F1 · frame-relative time** — untouched, still the one place the core is genuinely open.
- **New:** composite-level memoisation (§6), and the primitive table's boundary (§1) — how
  much of a suite must be primitives for it to stay portable across languages.
