# Core v0.1 / Runtime v0.1 — what the build found

The eight laws, running. Python 3.11, no dependencies, ~1400 lines of core +
runtime + head, 27 falsifiable tests, all passing. Companion to
`claude/the-generator.md` (the laws), `claude/axioms.md` (the types) and
`claude/core-findings.md` (the ledger). Written 2026-08-21.

The rule that produced this document: *structure points, detail refutes.* Below
is only what changed by being built.

---

## 1. Three deletions

Each is a field that turned out to be a second, weaker copy of something that
was already there. The count came down; nothing came out of the laws.

### D1 — `expose` dissolves into two reserved names

`Graph.expose: {in: Record<string,[string,string]>, out: ...}` is gone. A
composite's own boundary ports are addressable inside its graph as the reserved
occurrences `@in` and `@out`:

```python
graph({"inner": pin(add)},
      [wire(("@in", "x"),      ("inner", "a")),
       wire(("inner", "out"),  ("@out", "y"))])
```

The expose map was a parallel wire table that could not express fan-out (one
outer input feeding two inner units). Wires already can. One table, not two,
and Law 2 reads more cleanly: a composite is a graph plus a boundary, and the
boundary appears *in the graph* as two ordinary endpoints.

### D2 — the wire `kind` field is gone

`core-spec.md` gave a wire three kinds (`value | event | trigger`). What a wire
carries is a property of the **ports it joins**, not of the relation. A port of
shape `"trigger"` carries intent; everything else carries a value. Relations
stay content with no fields of their own — which is what the axioms already
said and the spec had not caught up to.

### D3 — wire order is gauge, port order is not

Wires are sorted before hashing, so authoring order cannot enter identity.
Ports are *not* sorted: a boundary is an ordered interface. This is a small
Law 8 boundary case, and it was silently wrong until the byte-identical test
was written.

---

## 2. One addition: memory binds by role, not by address

The axioms say `stateKey` disappears into the `mem` power on the boundary. Held
literally in code, that means the leaf's source contains the memory address —
so every delay in the system is a different nine-line program.

The fix is the ocap move applied to `mem`: **the leaf names a role, the boundary
names the address, the runtime binds one to the other at cook time.**

```python
def cook(inp, ctx):   return {"prev": ctx.mem_fold(fold="last", init=0)}
def store(inp, ctx):  ctx.mem_append(inp.get("x", 0))
```

One `delay` recipe, one blob, serves every delay. Changing a unit's state scope
changes its identity without touching a character of its code — which is what
"instance-vs-reference is not a column, it is A1 and A8 together" means once it
has to run. Naming an address that is not on the boundary raises `PowerDenied`,
so the role binding does not weaken the floor.

---

## 3. F8 is a five-pass tick, and that is its whole content

"A cycle is legal iff it contains a delay" is not a checker rule with a runtime
somewhere else. It is the shape of the tick:

```
0  sources       novelty enters, journalled on the way in
A  delay reads   every mem:r unit emits its fold over the log as it stood
                 at the start of the tick
B  the body      topological order over the live set, memoised on content
C  delay writes  inputs have settled; appends are buffered
D  commit        the log grows by one tick's worth
```

Passes A and C are the cut. Inside one tick the graph is always a DAG, so there
is no fixpoint to iterate and no paradox to discover at runtime — the undelayed
cycle is refused at wire time instead. Cyclic behaviour is not eliminated; it is
lifted into the tick index. *The universe of forms is a DAG; the universe of
events is a DCG indexed by time.*

**One detail worth keeping:** a delay's read phase is handed **no inputs at
all**. Not "should not use them" — cannot see them. Impossible beats
detectable, and this was the one place where the temptation to write the weaker
version was strongest.

---

## 4. An effect is `pinned` or it is dead

An effect unit has no output port, so nothing can ever observe it, so
`live ← observed ∨ pinned ∨ upstream` leaves it dead forever. Not a bug — Law 6
telling you that **a world-facing act needs a declared reason to be alive.** The
printer in the demo suite carries `[effect, pinned]` and that pair is the honest
statement of what a side effect is in a demand-driven world.

Corollary already implied by the gate taxonomy, now mechanical: rendering needs
no such pairing, because rendering is a fold and not a door.

---

## 5. Motion needed no new law

The chat's open question — *how does the same seam survive when the world
beneath it changes?* — turned out to be two lines:

```python
dest = Store(MemoryPersistence())     # a different machine, empty
engine2 = engine.migrate(dest)
```

Because code is a blob and the blob is inside the unit's identity, shipping the
form closure ships the program. Because σ is a map of hashes, shipping the blobs
σ points at ships the state. Preserve Boundary + Identity, replace Substrate;
both engines then tick to bit-identical σ.

**The memo table is deliberately not shipped.** It is cache tier and rebuilds
deterministically. That is what "the memo is not state" means operationally, and
it is the cheapest possible proof that the (G, B, σ) split is real: if anything
lived outside those three, migration would lose it, and the test would say so.

---

## 6. The four lifetimes

```
  Core   G    immutable topology + code, content-addressed     forever
  Blobs  B    immutable values, content-addressed              forever
  State  σ    PortAddr → BlobId                                one tick
  Memory      append-only logs of BlobIds                      the run
```

Nothing is ever mutated. The only thing that changes is which immutable objects
are currently referenced. Replay, snapshot, undo, migration and deterministic
simulation are then not features — they are the same three-line operation on σ,
which is why they all landed together rather than one at a time.

Note the *address*: a port address is a **path** (an occurrence), not an Id. One
unit appearing in forty places is one unit and forty paths. That distinction is
exactly what lets forty occurrences share a single memo entry — the test that
two panes over one node execute once passes because the memo key is content and
the address is not.

---

## 7. What the honest asymmetry looks like in code

`Ctx` carries exactly the declared powers as attributes; everything else raises
at the point of the reach. There is no `now` in it for anybody — time is not a
power; a clock is a source or it does not exist.

Where it stops being impossible and becomes conventional: a leaf's source runs
in a namespace with no `import`, `open` or `eval`, which makes the easy routes
to ambient authority unwritable, but is not a sandbox. The real isolation
boundary is the `ExecutionPort`, and `LocalHost` just calls the function. So
**Novelty is enforced by convention in v0.1 and by construction only once a
worker/process host exists.** The replay test (T2) is what currently catches
violations, and it catches all of them at once, which is why it was worth
building first.

---

## 8. Still open after building

- **F1 · frame-relative time** — untouched, and still the one place the core is
  genuinely open. No per-object local oscillator against a master tick.
- **Liminal space** (`claude/the-head.md` §4) — everything here is declared,
  so composing has full hash churn. This is the next thing worth building:
  Closure is unusable if you cannot hear it while writing it.
- **Incremental folds** — `_fold` recomputes over the whole log. Correct and
  wrong at scale. The monoid-homomorphism requirement exists precisely so this
  can become an incremental update; the test pins the requirement, the
  optimisation is not done.
- **F9 · higher-order units** — a port carrying a unit's Id is not implemented.
- **A real ExecutionPort** — see §7.

## 9. Scoreboard

| Push | Outcome |
|---|---|
| `expose` | **core shrinks** — dissolved into two reserved wire endpoints |
| wire kinds | **core shrinks** — the property belongs to the port |
| memory addressing | **core reuses** — role/address binding, the ocap move |
| F8 | **core confirms** — it *is* the tick, not a rule about the tick |
| effects under Demand | **core confirms** — `pinned` was already the answer |
| migration | **core doesn't move** — content addressing already paid for it |
