# Generated from the core, always

*The correction. Written 2026-08-25. Supersedes README finding #1's "fix" and reframes
`prims.ts`.*

---

## The principle

The core limits what a node **is**. It never says what a node **does**.

- What a node *is*: a boundary — ports (data it takes and gives) and powers (what it's
  allowed to do). Plus an interior: opaque leaf, or a graph of other nodes.
- What a node *does*: its behaviour. `add` returns a+b. That is not the core's business.
  It's four lines someone wrote, in an authored leaf, openable and changeable.

`library.ts` already says this out loud: *"NOTHING here is core. Every entry below is an
ordinary authored leaf... `add` is not a primitive of anything — it is four lines someone
wrote, and you can open it, change it, and declare your own. The core limits what a node IS,
never what a node DOES."*

Every tier obeys it. Nothing — base, workstation, or suite — introduces a behaviour the
core defines. Every node's *doing* is an authored leaf you can descend into and rewrite.
This is the suite rule ("no underivable primitives") generalised to the whole system,
including the workstation.

---

## The misstep

`prims.ts` — the `PRIMS` table: `core.add`, `core.sub`, `core.mul`, `core.gt`, `core.if`,
`core.concat`, … — baked behaviour into the kernel. Once that table exists, the core knows
what addition is, and the claim that "a node is a boundary, content-free by construction"
leaks. A head then draws its palette straight from the core (`app.ts`: `PALETTE =
[["number", ["core.add", "core.sub", …]]]`), and `add` is no longer something you can open —
it's frozen in the kernel.

### Where it came from

The oracle. To grade two independent implementations (TypeScript + Python) to bit-identical
sigma, both had to share a ground. README finding #1: *"Code is a blob, so the same
computation in two languages is two units... The fix is a primitive table whose identity is
the op name: a shared ground both cores implement."*

That was locally reasonable and globally wrong. The pressure to make two languages agree
pulled behaviour *into* the core, against the core's own axiom (A2: a boundary is
content-free; you cannot reach inside except through ports). It then cascaded — the primitive
table forced route-selection into the spec, forced a shared tolerance, forced a fixed
numeric universe — a chain of corrections all downstream of one misplacement. The oracle is
a good tool that asked for the wrong thing in one place.

---

## The correction

Behaviour lives in the library, not the kernel. Authored host bodies, keyed by their own
hash like any unit, openable, meltable, declarable.

**The core keeps only the machinery:**

- identity — `hash(form)` (canon.ts, sha256.ts)
- boundary — ports + powers (model.ts, caps.ts)
- the tick — the five-pass engine (engine.ts, flatten.ts)
- liminal — melt / play / declare (liminal.ts)
- frames — the atlas and route agreement (frames.ts)
- store + persistence port (store.ts, ports.ts)

**The core keeps no vocabulary.** No `add`, no `if`, no `concat`. Those are library entries.
`core.source`, `core.delay`, `core.print`, `core.ai` look structural — they're the class
exemplars (source = where novelty enters, delay = memory, effect = the world, ai = a source
facing a model). But `library.ts` already re-authors even these as ordinary leaves
(`number`, `text`, `clock` are authored sources with the `emit` power; the class is defined
by *where change enters*, not by a kernel op). So the class exemplars are demonstrations, not
requirements. The library carries them too.

### What happens to the oracle

The differential oracle graded *behaviour* across languages through the shared prim table.
Drop the table and host bodies are graded within a language only — which finding #1 already
conceded for host bodies anyway. The oracle still does its real job: it grades the
**machinery** — canon, the tick, flatten, frames, liminal — over authored graphs, and it
still forces the serialisation spec to exist. Bit-identical sigma still holds for the
machinery and for any authored leaf both sides choose to implement identically. What goes
away is the *core mandating a behaviour set*. The core was never supposed to have one.

`prims.ts` isn't deleted — old files can be important. It's reframed: a bundled starter
library, the same content `library.ts` now carries as authored leaves. Heads stop importing
`PRIMS` for their palette.

---

## Status by head

| head | behaviour source | generated from core? |
|---|---|---|
| **base** (`eidola.ts`) | `library.ts` — authored leaves | yes, already |
| **workstation** (`app.ts`) | `PRIMS` — the core table | **no — the remaining locus of the misstep** |

The base is already right. The workstation is the one head still to convert: its palette and
spawns must come from the authored library, exactly as the base's do. That conversion is the
concrete next code task, and it's what makes "eidola-workstation" honest rather than a
prim-based head wearing a new name.

The deepest form of the correction — making `prims.ts` vestigial in the core itself and
having the oracle grade only the machinery — is a core-level change with oracle implications,
a separate arc from the head naming. This doc is the decision; that's the migration.

---

## One line

The core is a grammar, not a dictionary. It says how nodes combine; it never says what any
word means. Every meaning is authored, openable, and yours.
