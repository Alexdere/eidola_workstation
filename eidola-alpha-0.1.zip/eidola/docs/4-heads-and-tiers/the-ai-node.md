# The AI Node

*Why asking for an AI node in the omnibar froze eidola, what the node actually is inside
the architecture, and how it reads and writes nodes and levels. Companion to `the-head.md`
(channels, liminal, authority) and `the-generator.md` (the seam, the eight laws). Written
2026-08-25; implemented the same day (see §Status).*

The freeze reasons from the tick model, not from any one `ai` verb: the cause is structural.

---

## 1. Why it freezes

A tick is **synchronous and closed**. Sources read a value already sitting in the journal;
pure nodes compute from inputs; effects fire; delays commit — one straight blocking pass,
then σ is returned. Nothing in the pass awaits anything.

The AI node is the first buildable thing that wants to be four incompatible things at once,
and each one lands on a different law:

| wants to be | collides with |
|---|---|
| **nondeterministic** — same prompt, different answer | Law 3 · Identity — `pure` promises same inputs → same output; it is what makes the memo sound |
| **effectful** — it reaches a model | Law 4 · Authority — it needs the `world` power |
| **latency-bound** — the answer arrives in seconds | Law 5 · Novelty — a source emits *at a tick*, not across one |
| **self-referential** — its output can feed its input | Law 6 · Demand — a live, stale node re-runs |

Put such a node live (observed or pinned) with the run loop on. Every 120 ms the engine runs
every live, **stale** node synchronously. The AI node is stale on *every* tick, because its
output never equals a memo key. So it either blocks the main thread on a model call each
frame, or — in liminal (`memoOn` off), or wherever its output feeds back — fires an unbounded
stream of calls. The freeze is Demand kept perfectly, aimed at the one node that should never
have been synchronous.

---

## 2. The seat already exists

No new construct. Split the node into the two shapes the core already ships — `core.print`
(effect, `world`) and `core.source` (source, `emit`, journalled) — and let the head carry the
message between them across ticks.

- **Ask** — an effect. When the prompt input's *signature* changes, it dispatches a request.
  A dedup on the prompt is the guard: a stable prompt never re-fires, so the runaway loop
  cannot form.
- **Receive** — a source. The model's answer lands back in the head asynchronously and is
  journalled onto the output port on a *later* tick, exactly like `srcValues → journal[occ#out]`.
  Until it arrives the output is `void 0`; downstream does not compute; the pane shows `—`,
  then flips. No blocking, ever.

Wrap the two into one prior — `prompt` in, `answer` out. The **boundary** tells you everything
(prompt in, text out); the **interior** tells you nothing you need (a round-trip through a
model). The model is substrate-face.

**Free payoff — replay.** Because the answer enters as a journalled source, the session is
deterministically replayable even though the model is not. The nondeterminism was captured at
the boundary, the one legal way new information enters (Law 5). Same reason `fetch` is a source.

---

## 3. Two senses of "interact with eidola"

**As a transformer.** Reads *one value* off its input wire, writes *one value* to its output.
`ai "summarize this"` in a pipeline. Boundary (Law 1) sandboxes it totally. The ninety-percent
case.

**As an author.** Emits *commands* — `add-pane`, `add-wire`, `wrap`, `descend`, `declare` —
not values. This is "read and write nodes and their levels," and needs no new mechanism: the
engine's whole authoring surface is already `apply(command)`. An AI author is just another
speaker of the head's language, standing where the omnibar stands.

---

## 4. Read/write is level-scoped

Authority is scoped to the level you stand on, and levels move only by **descending**.

> You cannot act on a unit through the view of it. (the-head §5)

To change the *inside* of a declared node an author must descend into it (from *above* to
*beside*), melt to liminal, edit, re-declare. It cannot reach through a boundary. Hence
**liminal is the home for AI authorship** — playable-not-citable, no hash churn; the AI
sketches on glass and `declare` (where lineage is recorded) is the human's keystroke.

---

## 5. What it cannot do through this

- **Cannot bind powers** (Law 4). It wires and instantiates palette nodes but cannot grant
  `world`/`mem`/`emit`; those come only from the runtime.
- **Cannot fake purity** (Law 3/5). Anything needing the world must declare it, visibly.
- **Cannot build a cycle without a delay.** `topoOrder` throws; `edit` catches, reverts, and
  *says* the error — loud, reverted, legible: the opposite failure mode from the freeze.
- **Cannot act by looking.** Reading a pane's value never confers the power to change it.
- **Cannot finish inside a tick.** Every AI action is async, mediated by the head across ticks.

---

## Status — implemented 2026-08-25 (in `eidola.html`)

Built on the real workstation head, not a mock, and driven headlessly to confirm the guarantees.

**The node — `core.ai`.** A leaf of class `source` with ports `prompt` (in, str) and `out`
(out, any), powers `["emit","world"]` — `emit` to read its journalled answer, `world` declared
so its authority to reach a model is visible on the boundary though the call lives in the head.
Its `cook` only re-emits whatever answer the head has already placed in the journal, so the
tick can never block. Added to the palette under **ai**, and to the omnibar as `ai <prompt>` —
the gesture that used to freeze now drops a non-blocking source on the canvas.

**The head service — `serviceAI()`.** Runs after every tick. For each AI node it reads the
effective prompt (the value on a wired `prompt` port, read from the producer's σ, else the
node's own config string) and dispatches `generate()` *only* when that prompt changed and no
request is in flight. The answer is stored and folded back on the next tick; `retickAI()` is
re-entrant-safe because the dedup skips a resolved node. Proven: a changed prompt dispatches
once, and twenty further ticks with the same prompt add **zero** calls — the run loop ticks and
pauses promptly, no hang. Cyclic AI prompts are refused at wire time by `topoOrder` ("cycle
without a delay"), so no runaway is even constructible without a delay in between.

**`generate()` + provider.** Offline by default — a canned stand-in so the async path is
visible with no setup. With a provider configured it POSTs the OpenAI-compatible chat shape
(OpenAI, Ollama, LM Studio all speak it). Always async; errors thrown, surfaced via `say`,
never swallowed into a tick.

**The "ai and tools" view.** Multiple named views now ride one shared store (so a unit declared
in one is usable in every other — the palette's "yours" is global). `ai and tools` is the
default landing view: a provider setup panel (mock / openai / ollama / custom, with test and
`+ ai node`) plus a seeded `prompt → assistant` example that answers on arrival. Tab strip in
the bar switches views; `＋` or omnibar `new <name>` makes one. Sessions persist as `session/2`
(all views + tools), with `session/1` still loadable. The view is where tools get set up and
tested; nothing stops you building the same anywhere.

---

## In one breath

> The AI node froze because it is the only node that tries to be pure, effectful, async, and
> self-feeding at once, and a synchronous tick has no chair for that. But the core already owns
> the chair: a source that **asks** through an effect and **hears back** through the journal,
> authoring only where it stands and only by descending — sandboxed as a transformer, level-
> scoped as an author, replayable because the world got in at a boundary. Now built, in the
> `ai and tools` view, where a prompt pane already feeds an assistant that answers on its own.
