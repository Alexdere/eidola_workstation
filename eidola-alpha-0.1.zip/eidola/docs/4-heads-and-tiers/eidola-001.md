# Eidola 001 — Design & Build Outline

*Decisions from the 2026-08-23 session. Companion to `the-wrap.md` (the core build plan)
and `one-core.md` (the shape). This is the application, not the infrastructure.*

---

## 0. What eidola is

Eidola is the product. The core, oracle, spec, and eight laws are infrastructure that
exists so eidola can make promises other apps can't keep. Users never open "the core."
They open eidola.

Suites (graphmap, Closure, etc.) are not siblings of eidola — they are **eidola with
different furniture**. You open eidola. You install a lens pack and domain sources — now
it's graphmap. You haven't left eidola. The suite is a configuration, not a separate app.

Eidola must be good at being **empty**. The unfurnished state — no domain lenses, just
the liminal surface and the omnibar — must feel like a place worth being.

---

## 1. Decisions made

### Liminal by default

The screen is liminal space. You are always inside an undeclared node. Nothing has
identity until you say so. No save anxiety — you're sketching on glass.

- **Declare** when something earns a name (conscious, like a git commit)
- **Wrap** is always available — select panes, wrap, compose without leaving the surface
- Interiors don't need to work fully yet — liminal is playable, not citable (Head Law 3)

### Pane lifecycle

Panes that aren't producing a live value are **absent**, not hidden. The screen shows
what's live. When you bring something into existence (paste a URL, type text, drop a
file), a pane appears. When done or unfocused, it recedes.

Minimized state: a **name tag** — the identity, maybe a tiny preview. Clickable to
expand. Default: if it's not contributing to what you're looking at, it's not on screen.

### No visible wires

Wires are not a primitive. A wire is the rendering of the fact that two addresses are
connected — a liminal node, gauge, presentation-only. Show-wires is a toggle or hold
gesture, like showing guides in a design tool. The connection exists in the structure;
you see the *effect* of wiring, not the wire.

- `A1 → B3` in the omnibar creates a connection; no persistent visual line
- Any wire that does something (transforms) is a real node (F3), descendable
- "Show wires" creates transient liminal renderings; turn it off and they cease to exist

### Coordinates

Each pane at a level gets a local coordinate: A1, B3, F2, etc. Strategy-game grid.

- **Gauge** — renaming or rearranging doesn't touch the hash
- **Scoped by boundary** — A1 inside node X ≠ A1 inside node Y
- **Human shorthand** — jump to, route between, reference in commands
- Not the address (content-derived path); a pet name, local, reassignable
- Can be turned off or customized

### Omnibar

The command surface for the head. Scoped to your current position.

Verb categories:
- **Navigation:** `go A1`, `descend A1`, `up`, `top`
- **Routing:** `A1 → B3`, `A1.out → B3.in`, `break A1 → B3`
- **Composition:** `wrap A1 B3 C2`, `unwrap D1`, `melt A1`, `declare`
- **Lensing:** `lens A1 chart`, `lens A1 raw`
- **Query:** `what A1`, `feeds A1`, `A1 feeds`
- **Source:** `fetch url`, `paste`, `text "hello"`, `file report.pdf`

The omnibar language is **the head's language**, not the core's. It compiles down to
`apply(command)` calls. Other heads (CLI, terminal, game engine) have their own syntax
for the same commands. External languages (Python, etc.) can use the resolution library
or talk to the core directly.

### Three visibility levels

Same object, three zoom levels of mechanism:

1. **Surface view** — panes showing their output, no wires, no graph. The homepage.
2. **Structure view** — panes with connections highlighted on demand. Understanding flow.
3. **Node view** — full graph, wires drawn. Building and debugging. The workstation.

Surface and node views are two panes over one graph — the memo-sharing test, literally.

### The head is a graph (bedrock)

The head itself is a graph running on the core. Lenses, the omnibar parser, the
coordinate resolver — all nodes. The renderer, event dispatcher, presentation store
persistence — **bedrock**: frozen, chromed, visually distinct, can't be melted from the
session they're running.

Users can fork bedrock nodes: melt a copy, rewire, declare, swap in. Never editing the
floor while standing on it.

Bootstrap: a few hundred lines of browser code stands up the core, loads the bedrock
graph, starts ticking. After that, self-hosted.

### Priors, not widgets

A widget is a black box from a catalogue. A prior is a node with ports — takes input,
produces output, interior is a graph you can descend into. At the simple level, you see
"weather." Descend, and you see: source node → transform → lens. Rewire the internals.
The boundary between simple and advanced is **depth**, not role.

Composition means every homepage piece is inspectable, forkable, user-modifiable, and
re-closable into something someone else can use.

---

## 2. What eidola gives that other apps can't

All consequences of the laws, not engineered features:

| Capability | Why | Law |
|---|---|---|
| Two views of one thing, one computation | Memo-sharing is structural | A1 |
| Rearrange without breaking | Layout is gauge | A8 |
| Wrap anything into a reusable piece | Composition is the primitive | A3 |
| See how anything works by descending | Every piece has a boundary + interior | A2 |
| Unused things don't compute | Viewport = garbage collector | A7 |
| Offline by default | No server in the core | Ports |
| Per-node capability safety | Powers declared, enforced by ctx | A4 |
| The file is the app | Content-addressed, closed | A1 + A3 |

---

## 3. Build outline for 001

### What exists (done)

- TS core: 41 tests, typechecks, oracle-graded to the byte (300 fuzzed workspaces)
- Python oracle: conformance + differential grading
- Canonical serialization spec: language-neutral, versioned, test vectors
- Head scaffolding: app.ts (35KB), lens.ts, present.ts, build/smoke scripts
- Architecture docs: core-spec, the-head, the-wrap, axiom-status, one-core, findings

### Layer 1 — Liminal surface (first milestone)

The empty screen. You open eidola and see nothing. The omnibar is present.

- [ ] Liminal runtime mode as the default — no graph is declared on boot
- [ ] Omnibar: basic command parsing (source verbs only at first)
- [ ] `fetch <url>` → source pane appears, fetches, shows result
- [ ] `text "..."` → text pane appears
- [ ] Paste handler → appropriate source pane created
- [ ] Pane rendering through lens registry (raw/text/image for starters)
- [ ] Pane recede: unfocused panes minimize to name tags

### Layer 2 — Routing & coordinates

Panes can talk to each other.

- [ ] Coordinate assignment: each pane gets a grid coordinate at creation
- [ ] Omnibar: `go <coord>`, `<coord> → <coord>` routing
- [ ] Shape matching on route: infer which ports connect
- [ ] Effect visible: output of source pane feeds into display of another
- [ ] Structure view toggle: show connections as highlights

### Layer 3 — Composition

The core's closure claim, made interactive.

- [ ] Omnibar: `wrap <coords>`, `unwrap <coord>`
- [ ] Wrap: selected panes become interior of new node, pop up one level
- [ ] Descend: enter a wrapped node, see its interior as a new coordinate space
- [ ] `up`: return to parent level
- [ ] Melt: copy a declared node into liminal space for editing
- [ ] Declare: freeze the current liminal workspace, assign hash

### Layer 4 — Persistence & polish

Survives a browser reload.

- [ ] IndexedDB persistence driver for graph store
- [ ] Presentation store persistence (coordinates, layout, collapse state)
- [ ] Save/load cycle: close tab, reopen, same state
- [ ] Visual polish: pane chrome, transitions, name tag design
- [ ] Node view: the full graph rendering (the workstation mode)

### Layer 5 — First priors

Domain-free but useful.

- [ ] Clock/date source
- [ ] Fetch/RSS source
- [ ] Text/markdown lens
- [ ] Image lens
- [ ] Link/bookmark prior (source + lens composed)
- [ ] Simple "homepage" default arrangement using these

### Not in 001

- Bedrock (head-as-graph, self-hosting) — important but not first
- External language bindings
- Multiple suites / suite installation
- Network sync / sharing
- Extension or daemon tiers
- Audio / Closure domain

---

## 4. Effort estimate

Layer 1 is the hard part — it's where every design decision about how panes feel, how
the omnibar responds, how the liminal surface looks gets made for the first time.
Architecturally simple (the core supports all of it), experientially difficult (it has
to feel right or nothing else matters).

Layers 2–3 are where the core's properties start showing. Routing and composition are
mostly wiring the existing core operations to the omnibar and the coordinate system.
The core already does all of this; the work is the head translation.

Layer 4 is plumbing — necessary, boring, bounded.

Layer 5 is where it starts being a homepage someone would actually open every day.

The whole thing is buildable by one person. The core is done. The spec is done. The
oracle is done. The remaining work is the head — and the head, honestly, is the product.

---

## 5. Build status — first instance (2026-08-23)

A working eidola-001 exists, riding the real core (not a mockup). It lives beside the
workstation (`app.ts`) as a *second head* on the same kernel:

- `head/src/eidola.ts` — the calm homepage head (~600 lines, one file)
- `head/index-eidola.html` — the ADLON-inspired shell (stone + amber, horizon, stars)
- `head/build-eidola.mjs` — bundles core + head to one self-contained page
- `head/dist/eidola001.html` — the runnable artifact (~91 kB, no dependencies)

Build: `node build-eidola.mjs` from `head/`. Typechecks clean; driven and screenshotted
in headless Chromium with zero console errors.

### What works now

- **Empty-but-alive surface** — opens with a horizon, a live clock, an ambient status
  bar, and a focused omnibar. Not a blank canvas.
- **Omnibar as the interface** — `text`, `num`, `clock`, `fetch <url>` create source
  panes; `add/mul/gt/concat/sum/if/…` create ops and auto-wire from coordinate args
  (`add A1 B1`); `A1 > B2` routes; `A1 x B2` breaks.
- **Coordinates** — each pane gets a local A1/B3 slot, used for routing and reference.
- **Real computation** — `num 20`, `num 22`, `add B1 C1` → a pane showing **42**,
  computed through the core, ticking live.
- **Gauge, visible** — `move A1 C2` rearranges and the status-bar hash *does not change*;
  `name` and `lens` likewise. Wiring *does* change it. Confirmed live in-browser.
- **Wires invisible by default** — drawn only around the focused pane.
- **Composition + depth** — `wrap A1 B1` makes a prior; **Tab** descends into it (a
  liminal draft, "no hash yet"); **Esc** declares & ascends (hash appears).
- **Spatial keyboard nav** — arrows move focus by proximity, `1–9` jump, Tab/Esc for
  depth. `help` / `?` overlay.
- **Lenses** — auto · big · num · text · json · bool · bar.

### Known gaps (next passes)

- **True liminal root** — the top surface is a declared workspace, not yet liminal-by-
  default; wrap/descend gives the liminal experience but the root isn't a draft yet.
- **Full persistence** — only presentation is saved; the graph reseeds (Layer 4 wires the
  IndexedDB/workspace driver the workstation already has).
- **Pane recede** — `fold` exists (name-tag + stops compute) but auto-recede on idle isn't
  wired.
- **The two-panes-one-node moment** — memo-sharing works in the core but has no dedicated
  visual yet (the signature first-light demo still to design at pixel level).
- **Priors library / install path** — sources and ops exist; a browsable/forkable prior
  catalogue (the growth path) is still blank.
- **Time (F1)** — clock uses tickIndex; real frame-relative time is still the open core
  finding.
