# Eidola — Three Tiers

*The split between base, workstation, and suites. Written 2026-08-25.
Companion: `claude/generated-from-core.md` (the invariant every tier obeys).*

---

## Naming (locked 2026-08-25)

"eidola" was pointing at four things — the project, a source file, the workstation build,
and the base build. That collision is why switching contexts felt like losing your place.
Fixed:

| name | is | source | build output |
|---|---|---|---|
| **eidola** | the umbrella + the base itself | — | — |
| **eidola-base** | the maximally open compose surface | `head/src/eidola.ts` | `dist/eidola-base.html` |
| **eidola-workstation** | the inspect / debug surface | `head/src/app.ts` (legacy, see below) | `dist/eidola-workstation.html` |
| **eidola-home** | the low-entrance homepage suite (a.k.a. green) | later | later |
| **graphmap**, **closure** | domain suites | later | later |

Old files stay (they can be important): `eidola.html`, `eidola-home.html`, `eidola001.html`
remain untouched as reference. The new names are additive.

---

## The invariant: generated from the core, always

Every tier obeys one rule (full statement in `generated-from-core.md`): the core says what a
node **is** (a boundary — ports + powers), never what a node **does**. All behaviour is an
authored leaf you can open, change, and re-declare. No tier introduces a primitive the core
defines.

Status against the invariant:

- **base** (`eidola.ts`) — already sources behaviour from `library.ts`. Correct.
- **workstation** (`app.ts`) — still sources behaviour from the core `PRIMS` table. This is
  the last locus of the oracle-era misstep. It works as a debug surface today, but making
  "eidola-workstation" honest means converting its palette to the authored library, exactly
  as the base does. Tagged **legacy / prim-based** until then.

---

## The split

Eidola is three things, and conflating them is how the product stays confused about what
it's for. They share a core, a store, and a serialisation format. They do not share a
head, a purpose, or an audience.

| tier | what it is | who it's for |
|---|---|---|
| **Base** | the runtime substrate rendered as a maximally open surface | builders — us, and anyone making a suite |
| **Workstation** | the full graph editor: visible wires, inspector, node view | the person inspecting or debugging a graph |
| **Suites** | eidola wearing furniture for a domain | end users of a specific thing |

---

## The triangle

Three tiers, three verbs, three positions relative to the graph:

| | verb | position | what you see | what you sacrifice |
|---|---|---|---|---|
| **Base** | compose | beside | raw authored leaves, every port, every boundary op | comfort — nothing is pre-packaged |
| **Home** (suite) | use | above | results, priors, furnished surfaces | mechanism — you don't see the graph |
| **Workstation** | inspect | beneath | the graph itself, every wire, every value | intuition — mechanism crowds out flow |

These are the three positions from the-head.md (§5), made concrete as products:

- **Beside** (base): you're in the graph, a participant. You place units, wire ports, melt
  and declare. You work with the material.
- **Above** (home/suites): you're looking at output. The graph is running but you see the
  weather, the feed, the clock — not the source→transform→lens pipeline that produces them.
- **Beneath** (workstation): you see the substrate. Every wire drawn, every port value
  displayed, the hash in the status bar, the inspector showing lineage and powers.

The sacrifice column is what makes them distinct products rather than zoom levels. Base
sacrifices comfort: nothing is pre-packaged, you build from raw units. Home sacrifices
mechanism: you can't see the wires, which is the point — the wires are noise when you're
checking the weather. Workstation sacrifices intuition: showing every wire and every hash
makes the graph legible but not *feelable*. You can run analysis but you can't be inside
the experience the way you can at the base or in a suite.

---

## Base

The base is not a product. It's the thing products are made of. Its job is to expose every
authored leaf — every port, every wire, every boundary operation — in a space where nothing
is hidden behind convenience and nothing is locked behind a suite's opinion.

What "maximally open" means concretely:

- Every unit the store knows is placeable.
- Every port is visible and connectable.
- Liminal is the default state — you're always in a draft.
- The omnibar compiles to `apply(command)` with no domain filtering.
- No chrome that assumes what you're building.
- Coordinates, spatial nav, pane recede, invisible-wires-by-default — base ergonomics.

The base is **beneath** home and workstation, not between them on a complexity axis. Both
are heads on the base. A suite builder starts here the same way we do.

What the base is NOT:

- Not the low-entrance one. It's the most capable one, which means the most exposed one.
- Not a homepage. It's a workbench for making homepages.
- Not empty in the "nothing here" sense — empty in the "this space is ready for anything"
  sense. "Good at being empty" is a base property, not a suite property.

### Current state

`head/src/eidola.ts` (~138KB now, grown well past the original 600 lines) is the base. It has:

- The calm surface, the omnibar, coordinates, spatial keyboard nav
- Real computation through the core (not a mockup)
- Behaviour from `library.ts` — authored leaves, every one openable (generated-from-core)
- Wrap/descend/declare (composition is the primitive)
- Gauge visible and confirmed (move doesn't change hash, wire does)
- Views (free / media / systems), horizon sky/ground, lenses, background themes

Note: some of what `eidola.ts` carries now — the room-with-a-horizon framing, the
free/media/systems views — is really **home-suite furniture** living in the base. That's
fine for now (don't remove functionality). When home is split out as a proper suite, that
furniture moves with it and the bare base gets lighter. "Then later we'll work on suites."

What it still needs to be a proper base (vs. a rich demo):

- True liminal root (top surface is currently declared, not draft)
- Full persistence (currently presentation only, graph reseeds)
- The rendering contract documented: what a head must implement to ride the core
- A clean API surface for suite authors: "here's what you wire into"

---

## Workstation

The workstation is a head for inspection and analysis. It shows everything the base hides by
default — not because it disagrees with hiding, but because showing is its job.

- Visible wires always: the graph is the point
- Inspector sidebar: occurrence, unit hash, class, powers, config, pin, lineage
- Palette rail, views over one shared store, dump/load, full CRUD
- AI tools panel: provider config, test, AI node spawning

### What the workstation is for

The workstation is where you go when something isn't working and you need to see why. Or
when you want to understand a prior someone else declared — descend into it, see its graph,
trace the values flowing port to port.

It is less intuitive than the base, by design. The base lets you compose by feel — place a
unit, wire it, see the result, adjust. The workstation shows you the mechanism instead of the
result. That's the trade: you get analysis (every value at every port, the hash confirming or
moving, the topo order visible) but you lose flow (too much information, the graph competing
with the experience).

The workstation is NOT primarily a creation tool. You can create in it, but the creative act
is better served by the base, where the result is foregrounded and the mechanism recedes.
The workstation is where you go *after* creating, to verify, debug, optimise, or understand.

Think: a DAW's arrange view vs. its mixer/routing view. You compose in arrange. You debug in
the mixer. Same session, different verb.

### Current state and the legacy tag

The workstation is `head/src/app.ts` → `dist/eidola-workstation.html`. It works as a debug
surface. But it draws its node behaviour from the core `PRIMS` table (`PALETTE = core.add,
core.sub, …`), which violates the generated-from-core invariant. So it's tagged **legacy /
prim-based**. The real workstation is either (a) `app.ts` with its palette re-sourced from
`library.ts`, or (b) the base head with an inspect mode turned on (wires-always, inspector,
hash-always). (b) is the cleaner end state — one generated-from-core head, two modes — but
(a) is the smaller step. Either way the conversion is the next concrete code task.

### Relationship to base

The workstation is NOT the base plus more UI. It's a different verb. The base shows you what
a graph does. The workstation shows you what a graph is.

They share: the core, the store, the `workspace/1` + `session/2` format, the presentation
store shape, the tick mechanic.

They differ: default visibility (base hides wires; workstation shows them), chrome, intent
(compose vs inspect), audience.

---

## Suites — and the underivability constraint

A suite is eidola with furniture. It's a configuration of the base, not a fork of it.

### The rule: no underivable, changeable primitives

Everything a suite shows the user must be **derivable from authored leaves**. A "weather
widget" is a declared composite — a source fetching a URL, a transform, a lens. You can take
it into the workstation, descend, see the graph, melt it, rewire, declare a variant. This is
the same rule as generated-from-core, applied to the suite surface: nothing opaque, nothing
the workstation can't open, nothing the base can't compose with.

What it permits: new host-body leaves (a MapLibre renderer, an audio engine, an RSS parser)
registered through the existing host path — inspectable, hashable, shared via the store;
domain lenses (presentation, A8); priors (pre-declared composites); opinions (which priors to
show, the default arrangement — pure gauge).

The constraint closes the loop between tiers:

```
base (compose) → declare → suite installs the prior → user uses it
                              ↓
                    workstation (inspect) → find a problem → back to base
```

If a suite could introduce underivable primitives, the loop breaks: the workstation can't
inspect what it can't decompose, the base can't compose with what it can't place, and the
suite becomes an island.

### Planned suites (not yet built)

**Eidola Home** (green) — the low-entrance suite. A homepage you'd open every day. Clock,
weather, bookmarks, RSS, notes — all priors you can descend into. Not "simple eidola" — eidola
with every mechanism behind a prior boundary, and every prior one double-click deep.

**Graphmap** — space, time, relation. The geo suite. Everything in `merged-architecture.md`.

**Closure** — the audio suite, where "you must hear it while writing it" (Head Law 3) is the
whole product.

### Build order

Base and workstation first. The workstation is how you *build* suites — construct the prior
graph, declare it, install it. The base is where you *compose*. Home is where the user *uses*.

---

## The coherence contract

What makes the tiers one system rather than three apps:

1. **One store.** Every unit, blob, mem address in one `Store`.
2. **One format.** `workspace/1` is content; `session/2` wraps it with presentation. Any head
   loads any workspace; head-specific fields are ignored, not rejected.
3. **One hash.** `graphHash()` is the same everywhere. A1 + A8.
4. **Interchangeable inspection.** Anything composed in the base opens in the workstation;
   anything a suite installs descends from the base. No tier is opaque to another.
5. **Gauge flows freely.** Strip all presentation and the workspace still computes identically.

---

## The sentence version

The base is where you compose. The workstation is where you inspect. Suites are where users
live. Every node's behaviour is an authored leaf, in every tier. They share a core, a store, a
format, and a hash. They share nothing else.
