# The Head

*Laws for the presentation and authoring layer. Everything here is a consequence of Law 8
(Gauge) and Law 1 (Boundary) — see `claude/the-generator.md`.*

The core documents describe the kernel. This describes the head, which is where most
violations will actually happen. Written 2026-08-21.

---

## 1. Two graphs, one vertex set

Layout is not coordinates. It is a **second relational structure** over the same units:
proximity, nesting, stacking, z-order, what-is-beside-what. It carries real meaning *to a
person*, and it is not content.

> **Two graphs share the vertex set. Only one of them is content.**

Three tiers, and the middle is wrong in both directions by default:

| | identity & computation | persisted | meaningful to a person |
|---|---|---|---|
| **content** | yes | yes | yes |
| **presentation** | **no** | **yes** | **yes** |
| **ephemeral** (scroll, hover, drag-in-progress) | no | no | no |

Presentation as content → multi-view dies. Presentation as ephemeral → the composer's thinking
is lost, because it was never written down anywhere else. It must be **saved and inert at the
same time.**

---

## 2. Gauge is gauge in the technical sense

A gauge transformation is a change of description with no content; gauge-invariant quantities
are the observables. Moving a pane is a gauge transformation; `serializeGraph()` is the
observable. Transformations leaving content fixed form a **group**; content is the invariant;
the infinitely many appearances are the **orbit**.

The byte-identical test is therefore a **test for group membership**.

### Head Law 1 — the intake test

> **Ask every new operation: are you a gauge transformation? Hash before, hash after.**
> Equal → free, no kernel involvement, have as many of yourself as you like.
> Different → you are a command; route through the kernel.

---

## 3. You cannot reach in from outside

*(Supersedes the earlier "make level crossings visible" rule — that made the hazard
detectable; this makes it unrepresentable, which is always the better fix.)*

Dragging a declared unit "into" a container is not a value crossing a boundary. It is
**editing that container's interior**, an act available only to someone already inside.

> **Values enter through ports. Authors enter by descending.**

### Head Law 2 — no cross-boundary placement

> A drag at level N stays at level N, and is therefore **always gauge**. To change nesting you
> **descend** into the target first — an explicit, visible context change — and then place.

The trapdoor needs no warning light: the gesture that could fall through it does not exist.
This also converges with §5 — **descending is moving from *above* to *beside***, which is the
only way to acquire authority over a level. The authorship model and the causal model are the
same model.

---

## 4. Liminal and declared

*A corollary of Law 1, not a ninth law.* No declared boundary → not a unit.

> A thing without a frozen boundary has **no identity, cannot be wired, cannot be referenced,
> and cannot be violated.** There is nothing there to preserve, so everything is free.

### What this solves

Content addressing has a real cost: **immutability makes editing awkward** — every keystroke
is a new hash. Unison and Nix both spend effort here; it is the tax paid for Law 3.

Liminal space is the answer: **mutation is quarantined outside the addressed world.** No hash
churn while composing, because nothing is addressed yet. Precedent people already hold: **the
working tree is liminal, the commit is the declaration, the hash exists only afterward.**

### The two transitions

- **Melt** — take a declared unit into liminal space. Produces something with no identity; the
  original is untouched because it cannot be touched.
- **Declare** — freeze the boundary. Hash exists. Citable, wireable, immutable.

**Lineage gets its natural home.** Hermione's `parent_hash` had no obvious trigger; the
declaration is exactly the one event where it belongs, and it is an event the user consciously
performs.

For composites: **a graph you are building is a workspace until you declare its exposure. The
`expose` map is the act of crystallisation.**

### Head Law 3 — liminal is playable, not citable

> Evaluate against the tentative boundary — sound, preview, feedback all work. But **no memo
> entry** (the key would move underneath) and **nothing may reference it** (there is no name to
> reference). A scratch buffer.

Required, or Closure is unusable: you must hear it while writing it.

| stage | mutable | addressed | citable | evaluable |
|---|---|---|---|---|
| **liminal** | yes | no | no | yes, unmemoised |
| **declared** | no | yes | yes | yes, memoised |

---

## 5. Seeing and acting are different channels

Pixels come *up* from a value; a click goes *around*, becoming a command to the kernel, which
changes the graph, which re-renders. The click never travels back down the wire the pixels came
up.

> **You cannot act on a unit through the view of it.**

Three positions, two of which can touch:

| position | can act? |
|---|---|
| **beside** — a unit in the same graph, wired in | yes — and you are now part of what you affect |
| **beneath** — the runtime, its substrate | yes — by constituting it |
| **above** — looking | no |

*The instructive exception:* `live ← observed ∨ pinned ∨ …` means **looking at something causes
it to run.** An observer effect, built for garbage-collection reasons. So the honest claim is
weaker and sharper:

> Seeing is a channel with one direction and almost no authority. Acting requires the other
> direction and declared authority. **They are never the same channel.**

*And the medium of seeing is invisible to the seeing:* the presentation layer is not in the
graph, so the seam you look *through* is absent from the world you look *at*. Law 8 read from
the other side — which is why you cannot inspect a pane through the pane.

### Head Law 4 — no optimistic mutation

> **Optimistic UI updates are a Gauge violation.** Mutating the view directly and reconciling
> later is acting through the view. It works until a second view exists, then they diverge and
> nothing can say which is right.

Render from state, always. Kernel-in-the-same-process makes the round-trip cheap enough that
the shortcut is unnecessary.

### Head Law 5 — no privileged reads

> A debug or status panel reaching into runtime internals is **acting through the view with
> extra authority.** The fix is not "stop doing that" — it is **reflection as a source**:
> expose runtime state as a value in the graph, and the panel becomes an ordinary pattern.

(Open finding 6, `menu.js`. Now backed by a principle rather than a rule.)

*The limit on reflection:* you may act on the encoding; the encoding is not the thing encoded.
The map may be in the territory; moving the map does not move the territory. Which is why
enforcement cannot be self-hosted — if the law were such an object, pushing on it would change
the law.

---

## 6. Three invariances

| | operation | law |
|---|---|---|
| **under redescription** | move, stack, recolour, collapse | Gauge |
| **under embedding** | use it in forty patterns — one motif, not forty copies | Identity + reference |
| **under wrapping** | put a boundary around it — interior untouched, exterior is new | Closure |

Three groups acting on the same object, none reaching in. This is why a system made entirely of
immaterial seams nevertheless feels solid: **nothing available from outside changes anything.**

> **Permanence is not being stored. It is being invariant under everything that can be done
> from outside.**

A motif persists not because it is saved but because no operation available to you changes it.
Saving is how you get it back; invariance is why it is still it.

---

## 7. What this permits, which no timeline tool can offer

- **Twelve motifs in one screen rectangle** — identical rects, z-order, a selector. Flip
  between them to edit; all stay wired and sounding.
- **Visibility and participation are independent** — hiding does not silence, because `pinned`
  decouples liveness from observation.
- **The entire navigation UI is free of the graph** — drill to fullscreen, zoom to
  architecture, collapse, tab between layers: all "which rect is the viewport."
- **One arrangement, many layouts, all live** — two windows, three monitors, a phone; the same
  content under different gauge.

In a timeline, position *is* time, so every navigational act is entangled with meaning. Here
they are orthogonal, and that orthogonality is the product feature, not a technicality.
