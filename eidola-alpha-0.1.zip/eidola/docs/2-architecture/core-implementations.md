# Core implementations — which language fills which slot

*Python vs Rust vs browser, and whether either of the first two ever needs a head of its own.
Companion to `claude/the-wrap.md` (why the browser core is TS), `claude/core-ts-v0.1.md` (the
oracle), `claude/merged-architecture.md` §5 (the tier table) and `claude/suite-closure.md`
(the growth rule). Written 2026-08-28.*

The browser slot doesn't move: TS, in-tab, because Head Law 4 needs the render round-trip to
be a function call, not a hop (`the-wrap.md` §0). Python and Rust were never candidates for
that slot. The real question is which of the tier table's *headless* rows each fills, and
whether either needs a head of its own.

---

## 1. Two headless slots already exist

`merged-architecture.md` §5 names them: **T4 headless CLI** (`graphmap fold` in CI) and
**T2 daemon** (unbounded compute, unlimited storage, true cron, filesystem, OS keychain,
local hardware). Both are `apply(command)` in / events out, no DOM, no tab — no seeing
channel at all.

**Python already fills T4.** It was kept on as the oracle (`the-wrap.md` §0) precisely
because it's deterministic and cheap to refactor — the same property that made it right for
*discovering* the laws makes it right for reference execution. It didn't need promoting into
T4; it was already there the moment it became the grader. Correctness over throughput is the
whole job.

**Rust's candidate slot is T2, and only if the daemon needs to tick graphs itself.** The
daemon row is an MCP server with, per §5, *zero application logic* — if it's purely a
capability provider (fetch, store, filesystem, secrets) it doesn't need a kernel in it at
all. A third core only earns its place if the daemon has to run graphs at a volume Python's
tick loop can't sustain — heavy folds over large parquet, continuous real-time ingestion
through the graph (an SDR feed, say). That's `suite-closure.md`'s rule applied to the kernel
a second time: *growth isn't failure, growth only one workload needs is failure.* Build Rust
when a concrete daemon job saturates Python, not speculatively — the same way TS got built
when the tab, a concrete need, forced it.

Because the core carries no vocabulary — `generated-from-core.md`'s point: ~1500 lines of
pure machinery (identity, boundary, tick, liminal, frames, store), primitives living outside
it in the library — a Rust port is a bounded, spec-driven target, oracle-gradable to the byte
exactly as TS was. Cheap to justify precisely because it'd only be reached for once justified.

---

## 2. What "doesn't need browser capabilities" means

It's the tier table's own right-hand columns, not a separate question:

| capability | browser (T0) | daemon (T2) |
|---|---|---|
| fetch | CORS-limited | anything |
| store | OPFS, quota'd | unlimited |
| compute | WASM | native, GDAL, local models |
| schedule | tab open only | true cron |
| filesystem | one handle | watch/walk/write |
| secrets | localStorage | OS keychain |

Work that needs the right column — unbounded compute, real cron, hardware access, unlimited
storage — is daemon work by definition, independent of which language runs it.

---

## 3. Neither Python nor Rust needs its own head

A head is specifically the render-from-state / pane / gauge apparatus Head Laws 4 and 5
govern (`the-head.md`), and those laws exist *because there's a seeing channel to keep
honest*. A daemon has no seeing channel — command in, events out, full stop. A native GUI
over a Python or Rust core would mean re-deriving all of `the-head.md`'s machinery a second
time, for a capability the architecture already has for free: the daemon talks MCP to the
*same* browser tab (§5: "one protocol for all of it"). One head, capability tiers underneath
it — that's the content of "tiers as capability providers, not versions."

A standalone desktop head (zero-browser, fully offline) would be a distinct product bet, not
a technical requirement — worth naming explicitly if it's ever wanted, but nothing in the
current build order (`the-wrap.md` §4) calls for it, and building one now pays the head cost
twice for a capability tiering already delivers once.

---

## In one breath

The browser stays TS because Head Law 4 needs the round-trip in-process; Python already fills
the T4 headless slot because it's the oracle and reference execution wants determinism over
speed; Rust is a candidate for T2 only, and only once a concrete daemon workload outruns
Python's tick loop, following the same growth-discipline that governs everything else in the
core; and neither headless core needs a head of its own, because Head Laws police a seeing
channel that a daemon, by construction, doesn't have — the daemon feeds capabilities to the
one browser head via MCP instead of growing a second one.
