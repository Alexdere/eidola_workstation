# graphmap — merged architecture

Status: brainstorm consolidated 2026-08-21. Merges the globe/map thread with three prior
projects (Eidola, Hermione/Vault, NTDB). Nothing committed; this is the shape.

---

## 0. The headline

**Eidola is graphmap's kernel.** The map thread re-derived, from the geography side, an
architecture that already exists with ~57 passing tests. Graphmap is Eidola's first
application where the graph is genuinely authoritative for something.

---

## 1. The reduction

Node / edge / field / event collapses to two things:

| | representation | GPU |
|---|---|---|
| Discrete | timed GeoJSON feature (`geometry + [t0,t1] + attrs`) | vertex buffers |
| Continuous | raster tile | texture |

Rendering: point, line, polygon, texture. Four draw types. If a feed needs a fifth
primitive, the kernel is wrong.

The invariant is **the camera, not the data**. One world, N cameras. Existing globe
projects have one camera, which is why they're movies.

---

## 2. Panes are first-class

```
Pane = (source, lens, viewport)
```

Decoupled, lenses become a cross-product not a checklist: same source, lens=map /
timeline / table / graph / text. Every pane is addressable:

```
geo://bbox/32.1,12.4,44.0,20.9?lens=map&plugins=ais,gdelt&at=now
plugin://usgs/quakes?mag=gte:4.5&window=P7D&lens=timeline
note://local/a91f3c
graph://fold/report?panes=*&at=now
```

The address buys: deep links, real OS windows (`window.open` + sync), and **time as an
axis** (`?at=` → two panes, same bbox, different time, side by side).

Panes emit as well as consume. A note is a graph node with no geometry until a link
gives it one.

---

## 3. Three tiers of state

| Tier | What | Size | Store | Lost on clear? |
|---|---|---|---|---|
| Graph | panes, addresses, links, notes, layout, clock | KB | CRDT doc (Yjs) | never — this is the file |
| Cache | tiles, fetched features, feed contents | GB | IndexedDB / Cache API | fine, regenerable |
| Corpus | captures, dead sources, your writing | MB | OPFS, content-hashed | unrecoverable |

**The graph is only small while every address stays resolvable.** Hence `presence` (see §6).

---

## 4. Parasitism: eat formats, not projects

Attachment depths: embed (iframe) < feed < artifact < graft < **protocol**.

Rank every adapter by fan-out. Nine readers cover most of the open world:

STAC · COG · PMTiles/MBTiles · GeoParquet (+ DuckDB-WASM) · GeoJSON ·
OGC API Features/WFS · Overpass · RSS/Atom · MCP

Adapters are **data, not code** — a JSON manifest (url template, format, field mapping,
license, refresh). In Eidola terms: a **preset** on a generic source node, with
**flavours** for each endpoint.

Symbiotic half: provenance non-strippable (license compliance becomes structural), and
be the renderer projects with good pipelines and bad frontends don't have.

---

## 5. Tiers as capability providers, not versions

One core. Providers register at runtime; features declare what they need.

| Capability | Browser | + Extension | + Daemon |
|---|---|---|---|
| fetch cross-origin | CORS-limited | anything | anything |
| store | OPFS, quota'd | same | unlimited |
| compute | WASM | WASM | native, GDAL, local models |
| schedule | tab open only | background worker | true cron |
| observe browsing | no | **yes** | no |
| filesystem | one handle | same | watch/walk/write |
| sync | needs relay | same | is the relay |
| secrets | localStorage | ext storage | OS keychain |

Tier identities (one sentence each, or the tier shouldn't exist):

- **T0 browser** — no install, no server. Must be genuinely complete, not a teaser.
- **T1 extension** — *turns browsing into ingestion.* CORS transcendence + pipe-the-current-tab.
- **T2 daemon** — *turns you from consumer into source.* Unlimited storage, GDAL, cron,
  local models, and local hardware (RTL-SDR → your own ADS-B/AIS feed).
- **T3 shared instance** — *turns a workspace into a situation room.*
- **T4 headless CLI** — *turns a workspace into a build artifact.* `graphmap fold` in CI.
- **T5 embeddable** — *inverts the parasitism.* Other projects host you.

Build order: 0 → 1 → 4 → 2 → 5 → 3.

**One protocol for all of it: MCP.** External tools, capability providers, plugins, and
agent access are the same client. The extension and the daemon are MCP servers containing
zero application logic. If the daemon knows what a pane is, the architecture leaked.

---

## 6. What merges from the prior projects

### Eidola (WHERE_WE_ARE, MVP_SPEC) — this is the kernel

Already built and directly reusable: pane-as-binding-site invariant · `view` hint +
renderer registry (= lenses) · typed wires (`value|event|trigger`) · Pattern +
`serializeGraph()` byte-identical under layout moves (= graph tier) · memo keyed by
`hash(def, config, inputs)` (= cache tier) · frame-keyed `set-observed` (= many cameras) ·
`borderless` + `residency:'pinned'` **already fields on Pane** (= pin a region) · caps +
swappable host (= capability tiers) · secrets vault (= API keys) · **flavour** (= adapters
as data) · headless kernel, `apply(command)` in / events out (= T4, T5) · reflection as a
source (= folds).

Graphmap adds four things Eidola lacks:
1. **Address** — a URI per pane. Buys deep links, OS windows, time-in-the-binding.
2. **Geography as a frame** — bbox + CRS + time cursor, slotting into existing frame machinery.
3. **Provenance** alongside content-addressing — origin + license + fetch time, not just integrity.
4. A domain where `source` carries the product.

### Hermione / Vault

- **`presence: here|vaulted|pending|missing` + `vault_id`** (~60 lines). "Search a drive
  that isn't plugged in" → "query a region whose live source you no longer have." A tool
  that can't distinguish *no data* from *data I once had* is lying when it matters most.
- **`parent_hash` lineage** — the same source versioned and diffable against itself. How
  did this page/NOTAM/record change. Headline OSINT feature, mechanism already designed.
- **The race** — deterministic query (bbox ∩ time ∩ attrs) vs fuzzy/semantic over captures
  and link structure; the deterministic side grades the fuzzy one forever, free labeled data.
- **The metabolism** — T2's emotional payload: come back and the region has been watched.
  `corpus.jsonl` → workspace history, negative space ("reached for Red Sea AIS 11×, never had it").
- **Anti-librarian, transposed** — never ask the user to pick layers. Same principle as the
  original "humans think in events, not layer stacks."
- **`pack` + FORMAT.md** — a workspace exports carrying its own reader.

### NTDB

Mechanism (sha256-as-embedding, 1KB introns) isn't needed. Two things are:
- **Constant-size metadata over unbounded data** — same invariant as relations-not-data,
  arrived at from the storage side.
- **Lighthouses** — learned routing over towers. This is the mechanism for the layer-free
  query: "everything around the Red Sea" surfaces the right sources without toggles.

---

## 7. The two open Eidola bugs are graphmap's central risks

**Finding #5 — coercion composition.** The registry checks a coercion *exists*, not that
two routes *agree*. Format adapters are coercions: `parquet→features` vs
`parquet→geojson→features`; `stac→cog→field` vs `stac→field`. A format-parasite generates
multi-route conversions by design, so "subtly wrong in one branch at month three" is the
default here, not an edge case. **Highest-priority open item in either project.**

**Port schemas without units** (Mars Climate Orbiter). In geospatial this has a canonical
answer: a CRS *is* a frame declaration, with EPSG/proj machinery behind it. A port typed
`features` must carry its CRS. Worked example that generalizes back to every other port type.

---

## 8. Stack

- **MapLibre GL JS** (BSD-3) — 2D map *and* the corner globe (`projection: globe`, same
  style, same tiles, camera slaved). Flat and round are one substrate.
- **PMTiles / Protomaps** (BSD) — single file, static hosting, range requests, no tile
  server. Planet z0–15 ≈ 120 GB; `pmtiles extract --maxzoom` for a z0–6 world in tens of MB.
- **Natural Earth** (public domain) — geometry + Gray Earth / shaded-relief rasters. The
  2.5D feel is: flat fill + NE relief raster at 6–10% multiply + noise PNG at ~3% screen +
  1px `#D57A32` border with a blurred halo. All declarative, no custom WebGL.
- **deck.gl** (MIT) — overlay layers; `views[]` array = many cameras, one canvas, one
  context, one data upload. `DataFilterExtension` = GPU-side birth/decay from a clock uniform.
- **xyflow** (MIT) — pane canvas: nodes = panes, edges = links. Self-similar with the
  geographic graph inside map panes.
- **Yjs** (MIT) + y-indexeddb → y-websocket later. **Dexie** (Apache-2) for cache. OPFS for corpus.
- **DuckDB-WASM** — SQL over remote parquet, no backend.
- Palette: ocean `#44515B` · land `#6F8492` · borders `#D57A32` · selection `#E8EDF2`.

Feeds by cheapness: USGS quakes (PD, no key, node+event+field in one endpoint) · GDELT ·
OpenSky · WorldPop/GHSL · NOAA GFS · AISStream · RIPE Atlas/RIS.

---

## 9. Why this is different

Each neighbour owns two of *space, time, relation* and delegates or ignores the third:

| | space | time | relation | data delegated |
|---|---|---|---|---|
| QGIS, kepler.gl | ✓ | partial | ✗ | ✗ |
| Grafana | ✗ | ✓ | ✗ | ✓ |
| Obsidian, tldraw | ✗ | ✗ | ✓ | ✗ |
| Palantir Gotham | ✓ | ✓ | ✓ | **theirs** |
| graphmap | ✓ | ✓ | ✓ | ✓ |

Grafana's real invention was the data-source abstraction, not the charts. Same trick, with
space and relation added, and the abstraction pushed a level deeper — sources are JSON files,
not Go plugins.

**Claim:** an open, local-first workspace where space, time, and relation are peers, and
where the data is deliberately not yours.

**Wedge:** the graph must be authoritative for something. Not a homepage — *your
situational picture of a region over time*. That's the artifact, and there's no export path
to it from anywhere else.

---

## 10. Requirements for it to actually be that

Cheap now, near-impossible to retrofit:

1. The workspace file is a versioned, documented spec readable by things that aren't your app.
2. Links typed from the first commit. An untyped edge is a drawing.
3. Provenance non-strippable.
4. Adapters are data.
5. Capability negotiation before there's anything to negotiate.
6. The core runs headless.
7. Time lives in the address.
8. One protocol, defended against the constant locally-reasonable pressure to split into three.

None are features. All are shape.

---

## 11. Merge order

1. **Point a browser at Eidola.** Unchanged priority #1; the head has never been executed.
2. **Address as a first-class pane field.** Cheapest graft, unlocks the most.
3. **Coercion composition check** (finding #5) — before twelve format readers, not after.
4. **`presence` + `vault_id` on values** (~60 lines).
5. **The map as a `view` node** — MapLibre + PMTiles + style JSON via the renderer registry.
   *If this needs the kernel to grow, the decomposition is wrong.* This step is the whole bet.
6. **Two source nodes with flavours:** `geo.features` (GeoJSON/OGC) and `geo.stac`.
7. **`parent_hash` lineage** — captures become a diffable history.
8. **Reflection as a source** (finding #6) → folds and reports become patterns, not features.

Falsification tests, in order of when they bite:
- Plugin #2 (flights) written without touching a kernel file.
- Lens #2 (timeline) on an existing address, without knowing it's showing earthquakes.
- A format reader added without a new primitive.
