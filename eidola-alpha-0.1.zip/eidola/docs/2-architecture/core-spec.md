# The core, precisely

Companion to `claude/one-core.md` (the framing) and `claude/merged-architecture.md` (the merge).
This is what the kernel *is*, why each part is shaped that way, what the alternative was, and
what would kill it. Written 2026-08-21.

---

## 1. Three tables, one rule, one loop, two holes

### NodeDef — what *can* be done
A script + a declaration: what it takes in, what it puts out, what powers it needs, which of
four classes it is (`pure | source | effect | container`). No idea whether it will run or appear.

- **Why:** separating recipe from instance lets one script appear in forty places, once.
- **Alternative:** the thing on screen owns its logic (Excel). Copy = fork. Fix a bug in one of
  two hundred places.

### Pane — a binding site
Which node, with what settings, whose state. **Not** position. **Not** cached values.

- **Why:** the invariant below.
- **Alternative:** pane holds position + values + status. Then one arrangement can't be open
  twice with two layouts, and it can never run without a screen.

### Wire — a relation between ports
Declares what it carries: `value` (latest wins) · `event` (each one matters) · `trigger` (intent).

- **Why:** relations are what the system is about, so they get a row instead of being implied.
- **Alternative:** nodes name their own inputs. Then rewiring means editing nodes, and the
  arrangement isn't an object you can save, diff, or share.

*A **pattern** is not a fourth table — it's a shared id over panes and wires. This matters for closure.*

### The one rule
> A pane owns nothing except status and presence.

Presence = is it here. Status = is the thing behind it working. Both are **indexicals**
(properties whose value depends on who's asking, like "here" and "now"). They're the only two
indexicals a pane has, so they're the only two it may own.

- **Why a rule at all:** a rule that *forbids* gives a test with a real answer — *does this
  proposal force the pane to own something new?* If yes, it belongs in the node, the pattern,
  or the runtime.
- **Alternative:** a rule that permits everything is a mirror, not a compass.

### The one loop
```
dirty(n)  ← n changed, or an upstream produced a new value
live(n)   ← observed(n) ∨ pinned(n) ∨ a live consumer is downstream
cook(n)   when dirty ∧ live ∧ (class = pure ∨ triggered)
```
Demand-driven: nothing runs because it exists, only because someone wants its answer.
Consequence nobody designs and everyone wants: **the viewport is a garbage collector for
computation.** Liveness propagates *upstream* (a source feeding a watched pane stays live).

- **Alternative:** run on a timer (melts the battery) or run on change (unpredictable cascade).

### The two holes
A **port** = a socket the core defines but doesn't fill.

- **Persistence port** — "store/fetch bytes by key." Filled by SQLite · IndexedDB · OPFS ·
  ledger+vault · NTDB.
- **Execution port (host)** — "run this node with exactly these powers." Filled by local
  process · browser worker · extension · daemon.

- **Why holes not choices:** the browser/extension/daemon tiers become three plugs, not three products.
- **Alternative:** the core knows about IndexedDB → the daemon version is a fork.

---

## 2. The clarifying comparison: Excel

The most successful system of this shape ever built. Demand-driven, memoised, dataflow,
visual, hundreds of millions of users. The shape is proven; its limits are what the core fixes.

| | Excel | the core |
|---|---|---|
| logic vs instance | cell owns its formula | node in a store, pane binds it |
| sharing a computation | copy-paste (forks it) | two panes, one node, shared memo |
| powers | macros: all or nothing | declared capabilities per node |
| where change enters | a few built-ins | the `source` class, anything |
| **composition** | **a range of cells is not a cell** | **a pattern is a node** |

The last row is why spreadsheets never became programs — and it is the closure question in a
familiar object. Excel's ranges, named ranges, tables, and Power Query are four incompatible
attempts at what closure gives free.

---

## 3. Is the core closed?

Four senses; deliberately yes to three, no to one. Plus a fifth that's a live checklist.

### (a) Closed under composition — YES, and this is the essential one
*Plain version:* an operation is closed over a set if applying it to members lands you back
inside. Integers are closed under addition; not under division (3÷2), and that hole is why
fractions had to be invented.

Here the operation is **wrapping**: box a subgraph, expose ports — is the result usable
anywhere a node is usable? Eidola: yes, via `container` + `expose` + `parent` self-reference.
No room table, no group feature, no macro system. Three levels tested.

**Closure IS "unbounded generativity from a minimal core", stated in algebra.** Not a nice
property alongside that goal — the same thing.

- **Alternative (not closed):** a fresh abstraction mechanism per level — functions, then
  macros, then templates, then modules, each a special case.
- **The alarm:** any time grouping something requires adding a *feature*.

### (b) Closed as a system — NO, deliberately
A closed system has nothing crossing its boundary. That's a screensaver.

The core is **open with enumerable openings**: change enters only at `source` nodes. Not
sealed — the boundary is a finite printable list. That's what makes **replay** possible:
record what sources emitted and the whole system re-runs. Undeclared openings → never
replayable. No openings → nothing to replay.

### (c) Complete, logically — NO, correctly
Gödel constrains *proof* from inside a fixed axiomatization; it says nothing about
*generation*. The core doesn't prove things about itself, it produces them. It cannot tell you
whether an arrangement terminates or is correct — it runs it and you look. That is the only
epistemics available to a generative system.

- **Trap:** a static analyser that certifies arrangements before running. Works on the cases
  you already understood, silent elsewhere, grows forever.

### (d) Self-referential — PARTIALLY, and the partition is the design
- **Reflection is the ring.** Health, staleness, convergence — built from ordinary units:
  expose system state as a `source`, so a monitor is a *pattern*, not a feature. This is
  **arithmetization** (encoding statements about a system as objects inside it). A triumph
  rather than a paradox *because the encoding is explicit*; the Liar paradox is the same
  crossing left implicit.
- **Enforcement is the floor.** Capabilities, the effect gate, secrets-never-hashed —
  unreachable from inside. If capabilities were nodes, a node could be wired to influence
  them. **Security cannot be self-hosted.**

→ **Reflexive in what it reports, non-reflexive in what it forbids.** The asymmetry is what
makes reflexivity safe.

### (e) Topologically closed — a live checklist
*Contains its own boundary points.* Plain version: are degenerate cases ordinary members, or
do they crash?

- cycle → currently *detected* when a value is asked for. Should be **refused at wire time**,
  making "cyclic" a state, not an exception.
- pane bound to a vanished node → is `missing` a value or an error?
- data once held, no longer fetchable → `presence: vaulted`, a member.
- stale → already split four ways, because one word meant three cases were outside the set.

Every fix is the same move: **pull the degenerate case inside as an ordinary value.** Cheap
early, brutal late.

### One line
> Closed under composition. Open at declared points. Incomplete by construction. Reflexive in
> report, not in law. Closed at its boundaries only insofar as you keep pulling the degenerate
> cases inside.

---

## 4. Dead ends, ranked by body count

1. **Universal substrate with no application.** Expresses anything; nobody wants any of it.
   Yahoo Pipes, NoFlo, Luna. → *Core = whatever two suites both need, extracted after both exist.*
2. **The escape hatch.** One node running arbitrary code with full powers "just for now."
   Purity unenforceable, replay broken, memoisation silently lying. → *A pure node receives a
   context with no clock and no network even if its manifest asks.* (already built)
3. **The privileged supervisor.** One channel that sees everything; every awkward feature
   lands there; within a year it *is* the system. → *Reflection as a source; delete privileged
   reads.* (`menu.js`, open)
4. **Non-composing conversions.** Two routes between shapes that silently disagree. In a
   format-eating system this is the weather, not an edge case. → *Registry checks routes
   agree, not just that a route exists.* (finding #5, open — highest priority)
5. **Hashing that scales wrong.** Re-fingerprinting every input per request: fine for a
   number, fatal for a 10k-row table. → *Values carry a hash computed once when produced.*
6. **The graph unreadable at 50 nodes.** The perennial death of visual programming. → *The
   graph must be authoritative for something where the **arrangement itself** is the value —
   a situational picture, a workspace — not for general computation.* Survivors (ComfyUI,
   Houdini, Grasshopper) all obey this; the graveyard is projects trying to be a better way
   to write programs.

---

## 5. Tests that prove the properties (not coverage — claims that could be false)

- **Composition closure:** nest three levels, wire innermost port to outermost, data flows.
- **Gauge:** move a pane → `serializeGraph()` byte-identical. Rewire → one-line diff.
- **Openness enumerable:** record source emissions, replay the graph, identical outputs.
- **Enforcement floor:** a pure node asking for clock and net receives neither; a planted
  canary secret appears in none of six persisted/hashed places.
- **Reflection ordinary:** the health panel is a pattern, and grepping the head for scheduler
  internals fails.
- **Boundary membership:** drawing a cycle is refused at wire time; a pane bound to a missing
  node renders a state, not an error.
- **Route agreement:** for every pair of shapes with two conversion routes, both routes agree
  on a fixture.
