# One core, many suites

Framing layer above `claude/merged-architecture.md`. Written 2026-08-21.
Supersedes how that doc's §0 reads: it isn't "Eidola is graphmap's kernel" — it's that all
three prior projects are one object seen from three sides.

---

## The three are three faces, not three layers

- **NTDB** — relations at the *storage* level: how a relation persists and gets found.
- **Eidola** — relations at the *computation* level: how a relation evaluates and when.
- **graphmap** — relations at the *perception* level: how a relation gets looked at.

Persist · evaluate · perceive.

The evidence is convergence, not elegance. Three separate attempts, three domains, same
skeleton, none designed against the others:

| | NTDB | Eidola | graphmap |
|---|---|---|---|
| the unit | intron + block | node | source / feature |
| grouping, free | tower (0 bytes) | pattern (recipe, not copy) | workspace (relations, KB) |
| the router | lighthouse | scheduler + wires | address / query |
| the surface | — | pane | pane + lens |
| precious | data blocks | store + pattern | graph tier |
| disposable | weights | memo cache | tile / feature cache |
| optimisation | learned from use | memoised from use | cached from use |

---

## The core: seven rules

Domain-free. True of a store, a runtime, and a viewport alike.

1. **Identity is content.** Same content, same thing.
2. **Relation is cheaper than the things it relates.** Towers cost zero. Patterns are
   recipes. The graph tier is kilobytes.
3. **Truth is append-only; everything else is derived and disposable.**
4. **Change enters only at declared points.** The `source` class — therefore replayable.
5. **Power must be declared to be held.** Capabilities; secrets are one more declared power.
6. **Vantage is not content.** Layout is gauge; the graph is invariant. Presence and status
   are the only indexicals a pane owns.
7. **Every derived thing rebuilds from truth.** Delete any index; lose time, not information.

Mostly a contract, not a codebase — ~800 lines enforcing it (ids, store, graph, scheduler,
host interface, persistence port). Eidola's `src/kernel/` is already this, minus a storage
tier. The "fundamental relations set" is not a document; it's that directory. Generation is
the proof.

---

## The refinement: the core is not a flagship

A name that is both platform and application loses the platform every time — the app's
needs win. That is most of the graveyard (Yahoo Pipes, NoFlo, Luna). The survivors
(ComfyUI, Houdini, Grasshopper) keep the runtime unambiguous.

- **Core** — unbranded. No UI, no domain, no opinions. Library + CLI. Authoritative for
  *nothing*, which is the job.
- **Suites** — branded, opinionated, each authoritative for something: graphmap
  (geography), eidola (homepage/automation), dump (personal archive), codemap. A suite is
  **nodes + lenses + presets + a default arrangement** — itself a bundle of declarations,
  so shareable/forkable/user-writable. The registry falls out; same shape as adapters-as-data.
- **Heads** — browser, CLI, extension, terminal, third-party. Already free via
  `apply(command)` in / events out, no DOM.

"Eidola" is a good name for a *suite*. The kernel underneath doesn't want one.

---

## NTDB is a driver

`src/persist/` — "storage behind one small interface" — is the port, already built.

```
persistence port
  ├── FTS5 / SQLite driver    deterministic, boring, works today
  ├── IndexedDB / OPFS        browser tiers
  ├── ledger + vault          presence-aware (Hermione)
  └── NTDB driver             learned, fuzzy, speculative
```

Run FTS5 and NTDB behind the same port; the deterministic one grades the learned one
(Hermione's race); ship NTDB when it wins. Shadow mode is free because rule 3 holds. The
learned index becomes a research program *inside* a shipping product rather than a
prerequisite for one.

---

## The shape

```
suites     graphmap · eidola · dump · codemap
           nodes + lenses + presets + arrangement
────────────────────────────────────────────────
heads      browser · CLI · extension · terminal · yours
──────────────────────────── protocol boundary ─
CORE       identity · relation · evaluation · vantage
           panes · wires · patterns · scheduler · caps
           (seven rules, ~800 lines)
──────────────────────────── port boundary ─────
drivers    persist:  sqlite | ntdb | idb | opfs | ledger+vault
           host:     local | worker | extension | daemon | mcp
```

Panes and wires are **core** (a pane is the vantage primitive; the invariant is about it).
Lenses are **suite**. That cut is the one to expect argument about later.

---

## What the structure demands

**Extract the kernel, don't design it.** A platform with no application is the graveyard.
The core is *discovered by writing the second suite*. Rule: the core is whatever graphmap
and the homepage both need, and nothing else. One suite = generalising from one example;
three = over-built before shipping.

**One suite must be the daily driver.** Otherwise the core drifts toward interesting rather
than load-bearing. Argument for the homepage suite existing early even though graphmap is
the stronger wedge.

**Keep the metaphysics cashed out as prohibitions.** The frames/atlas/Gödel work produced
six findings because every abstraction was immediately run as "this forbids X, go look."
The "fundamental relations" framing pulls toward writing instead of building; the antidote
is already the stated protocol — structural pointers one way, exhaustive checking the
other, and the build as the only place a violation breaks something rather than being
merely thought.

---

## In one breath

A small kernel whose only claims are that identity is content, relation is cheaper than
what it relates, truth is append-only, change enters only where declared, power must be
asked for, and vantage carries no content. It has no screen, no domain, and nothing it is
authoritative for. Storage is a driver. Execution is a driver. Heads are clients.
Everything anyone actually uses is a suite of nodes, lenses and presets riding on top — a
homepage, a personal dump, a situational map of the world — and each of those is
authoritative for something real, which is the only reason any of them survive.
