# Closure — suite design + kernel stress test

A music composition suite (from the "Album name suggestions" thread, 19 Aug 2026), taken
seriously on its own terms and then run against the core in `claude/core-spec.md` to see
what breaks. Written 2026-08-21.

**Headline result:** three pushes on the core — one *unification*, one *justified growth*,
one *clean refusal*. That distribution is roughly what a healthy kernel looks like under a
suite it wasn't designed for.

---

## 1. What Closure is

Not a graph DAW. **A notation system for music whose identity is relational rather than
temporal.**

> DAW: time is absolute, objects are temporary.
> **Closure: objects are absolute, time is emergent.**

The music it serves is the music the timeline fights: free-tempo piano, folk lament, ring
composition, process music, Feldman, Reich phasing, gamelan, plainchant. The source MIDI
(`eizo paizo.mid`) is the archetype — 159 notes, 14 pitches, no meter, four motifs
recurring "like remembered thoughts rather than chorus returns."

### Six primitives

Closure (node) · Flow (edge) · Oscillator · Memory · Traversal · Renderer.

**Memory is the load-bearing one.** It converts a closed geometry from a loop into a
generator: a triangle whose vertices remember each visit and alter what leaves is a
dynamical system with fixed topology — unbounded output from a finite closed shape. Same
move as closure-under-composition in the kernel: fixed rules, unbounded product.

### The on-ramp (the conversation didn't solve this)

Empty canvas kills creative tools. **First action is analysis, not composition.** Drop a
MIDI; extract motifs by interval-sequence n-gram matching under transposition, inversion,
and octave equivalence; hand back a graph of the user's own music. Tractable, and the first
experience is seeing your own piece as a shape. Composition is session two.

### Signature feature: coherence, computed

The stated design problem was *"it isn't how to play them, it's how to make them cohere."*
Five metrics a relational format can compute and a timeline structurally cannot:

| Metric | Computes | Tells you |
|---|---|---|
| Reachability | principal node reachable from every node | orphaned material |
| Return | every node in the SCC containing the principal | branches that never come home |
| Phase | LCM of local periods | 3·4·11 → 132 ticks; 7·11·13 → 1001, i.e. never audibly |
| Kinship | interval-vector similarity between motifs | do these objects share a world |
| **Closure index** | similarity of final state to initial, by interval topology not pitch | does the piece re-enter itself |

The last is the author's own compositional fingerprint as a live number.

### What it must refuse to build

A synth, effects, a mixer. **Audible output quality is not the differentiator.** Render to
MIDI, let Logic orchestrate; ship one plain sampled piano so the workspace isn't mute.
Stay 2.5D (X free, Y pitch, Z motif layers) — no camera to fight.

---

## 2. What the core hands it free

| Closure needs | Core has | Status |
|---|---|---|
| Recursive closures (node contains graph, descend, return, still one object) | `container` + `expose:{in,out}` + `parent` | built, tested 3 deep |
| Instances not copies; parent edit → inherit or diverge | `stateKey` (ref vs instance) + `nodeRef {hash=pin, name=follow}` | built, two fields |
| `.closure` native format | `serializeGraph()` | built |
| Motif library, searchable | content-addressed store + name index | built |
| MIDI export as projection | a fold | free once reflection lands |
| Coherence heatmap | reflection-as-source → the heatmap is a *pattern* | one open finding away |
| Undo | command log with inverses | built |
| "No accounts, nothing uploaded" | capability declaration — structural, not a promise | built |
| Same motif in two views | frame-keyed `set-observed` | built |

Two that matter more than convenience:

**Gauge = the musical thesis.** *Moving a pane produces a byte-identical serialized graph.*
In graphmap that was tidiness. Here it is "the geometry is invariant; only its embedding
changes," mechanically enforced. Where you dragged a node cannot alter the composition's
identity.

**Content-addressing = a global motif namespace.** Two composers who independently wrote
the same motif have the same motif. For a shared library that is the whole feature.

---

## 3. The three breaks

### Break 1 — the edge computes → the core UNIFIES

Core wires are inert; Closure edges carry duration, curve, dynamics, articulation,
probability, and open an inspector on click.

But a **coercion** (finding #5) is already an edge that transforms — it lives in a side
registry precisely because wires weren't allowed to compute. Closure forces the question
the registry was dodging.

**Resolution:** *A wire may **name** a transform; the transform is an ordinary node; the
scheduler inserts it.* Wire stays inert (naming ≠ computing), the transform gets a real
editor free, clicking a line opens that node's config, and the coercion registry becomes
"wires with implied transform nodes" — which is where route-composition checking wants to
live anyway. One change fixes an open bug and hosts the suite.

### Break 2 — nodes have memory → the core GROWS (justifiably)

The four classes are defined by relationship to the *outside world*. A node with
accumulating internal state touches nothing outside but isn't pure. Hole in the taxonomy.

**Resolution, better than a fifth class:** a stateful node is still deterministic if state
counts as an input — `f(inputs, stateₙ) → (output, stateₙ₊₁)`. Memoisation survives (memo
key includes the state hash). Replay survives (initial state + journaled visits). Rule 4
holds: change still enters only at sources; state *evolution* is deterministic.

**The finding:** `stateKey` is already an input to the computation and is not in the
fingerprint. Consistent today only because `pure` nodes are denied state entirely.

**Extraction test passes:** the homepage suite needs it too — accumulating counters, unread
badges, running averages, downloads that survive scrolling away. `residency:'pinned'` was
built for exactly these; a pinned accumulator *is* an automaton. Two suites, independently.

### Break 3 — no global time → the core GROWS (same hole, already flagged)

Every closure owns a local oscillator; the master tick is a simulation update rhythm, not
musical time. Two performances can both last 30s and be Generation 1 and Generation 8.

The core injects a single `ctx.now()`, and the August session already flagged: *"whose now,
once the runtime is its own process?"*

**Resolution:** time is frame-relative — master tick is a source; each pane's phase is
local, derived from it. Same fix shape as frame-keyed `set-observed`, one axis over.

> **graphmap gives the core's spatial frame problem a worked example (CRS/EPSG).
> Closure gives its temporal frame problem one (local period vs master tick).**

---

## 4. Where the core must REFUSE: the audio clock

Web Audio needs sample-accurate scheduling ~100ms ahead of wall clock. A demand-driven,
memoised, liveness-gated reactive scheduler cannot do that and must not try.

> **The core has no DOM. The core also has no audio clock.**

The graph computes a *schedule* (next N seconds of events); Tone.js owns the fast clock.
Therefore audio is a **renderer**, exactly like MIDI export — both folds over one object,
one writing a file, one writing a buffer. **Playback is a projection, not an evaluation.**

A good kernel test must be able to fail. This one did, and the correct response was refusal.

---

## 5. Hosted vs standalone

**For hosted:** five of six "novel" features already exist and are tested · the gauge rule
*is* the musical invariance claim, not an analogy · content-addressed motif store is free
and is the best version of that feature · three pushes, two producing changes another suite
needs anyway · `.closure` = `serializeGraph()`, so core-spec requirement #1 (the file is a
readable, versioned spec) is satisfied by default.

**For standalone:** Closure's graphs are tiny (dozens of nodes) — memoisation, liveness
gating, capability sandboxing and persistence ports are dead weight at that scale · token
traversal is genuinely a different evaluation strategy from pull-based demand · real-time
audio is a hard domain that wants its own architecture.

**Position:** hosted, with sequencing honesty. Closure's value *now* is as a paper stress
test, and it has already paid for itself with three core findings. Build it after graphmap
proves the head runs — betting a second suite on unexercised UI infrastructure produces two
stalled projects instead of one shipped.

**On the name:** the suite is named for the property the kernel has. Closure-under-
composition makes a pattern a node; closure makes the last phrase re-enter the first. Same
word, two scales — the author's design language appearing in the architecture and in the
music. Which is also the evidence that this is the **daily-driver suite** required by
`one-core.md`: the album is being made regardless, so the tool has a real first user with a
deliverable that survives if the software doesn't.

---

## 6. What the test proved about the core

| Push | Outcome | Reading |
|---|---|---|
| Transforming edges | **unify** — one change fixes an open bug and hosts the suite | decomposition right, implementation incomplete |
| Node memory | **grow** — but the other suite needs it too | correct growth; extraction rule satisfied |
| Audio clock | **refuse** — and the refusal clarifies | the boundary is real |

All three "grow" → decomposition wrong. All three free → test proved nothing. One unify,
one justified growth, one clean refusal is a healthy result.

**Refinement to the standing rule** (*did this need the core to grow?*):

> **Growth isn't failure. Growth only one suite needs is failure.**

---

## 7. Core changes this test produced

1. **Wires may name a transform; transforms are ordinary nodes.** Subsumes the coercion
   registry; makes route-composition checking (finding #5) natural rather than bolted on.
2. **State is an input.** Memo key includes the state hash; `stateKey` enters the
   fingerprint; deterministic-stateful nodes become expressible without breaking replay.
3. **Time is frame-relative.** Master tick as a source; local phase per pane; `ctx.now()`
   becomes frame-keyed like `set-observed`.
4. **The core has no audio clock** — added to the enforcement floor alongside "no DOM."
