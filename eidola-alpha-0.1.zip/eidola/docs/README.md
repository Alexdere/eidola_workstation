# The design record

New here? Start with `guide/quickstart.md`. Decisions since alpha-0.1 are in `adr/`; the
mathematics is in `5-foundations/`.

Sections 1–4 are the 19 design docs from the claude.ai project "graphmap", copied verbatim and grouped
by what they are about. When a doc refers to `claude/<name>.md`, it means the file of that name
in one of the folders below.

## Coming back cold: read these five, in order

1. `1-laws/eight-laws-introduction.md` — the whole framework in plain language.
2. `4-heads-and-tiers/eidola-tiers.md` — base, workstation and suites, with the naming that
   is locked.
3. `4-heads-and-tiers/generated-from-core.md` — the correction that shapes everything since
   Aug 25: the core says what a node *is*, never what it *does*.
4. `3-build-findings/core-ts-v0.1.md` — what building the kernel and the oracle forced.
5. `../STATUS.md` — what is running today, and what is soft, unbuilt or open.

## 1 · Laws — what the core is

| doc | written | what it is | still current? |
|---|---|---|---|
| `eight-laws-introduction.md` | Aug 22 | the eight laws for an outside reader: what each forbids and what each buys | yes |
| `the-generator.md` | Aug 21 | substrate as a relation, a unit as a seam, the laws ordered by depth, the test for a ninth law; holds the A1–A8 → Law 1–8 rename map | yes; the canonical numbering |
| `axioms.md` | Aug 21 | the formal statement: A1–A8, what is derived, the nine-type manifestation | content yes; numbering superseded by the-generator |
| `axiom-status.md` | Aug 21 | which axioms are constitutive and which regulative, and where each is enforced (container, floor or ring) | yes |
| `core-findings.md` | Aug 21 | the findings ledger: F1–F9, the gate taxonomy, prior art | ledger yes; some "open" items have closed since (see STATUS) |

## 2 · Architecture — where it sits

| doc | written | what it is | still current? |
|---|---|---|---|
| `merged-architecture.md` | Aug 21 | graphmap: the map thread merged with Eidola, Hermione and NTDB; tiers T0–T5 | the plan for the graphmap suite |
| `one-core.md` | Aug 21 | one core, many suites: persist · evaluate · perceive; the seven rules | framing yes |
| `core-spec.md` | Aug 21 | the kernel precisely: tables, rule, loop, holes; "is the core closed?"; dead ends | mostly; the wire `kind` field and the `expose` map were later dissolved (implementation-v0.1 §1) |
| `suite-closure.md` | Aug 21 | Closure (the music suite) as a stress test of the kernel: unify, grow, refuse | yes |
| `core-implementations.md` | Aug 28 | which language fills which slot: TS in the tab, Python for T4, Rust for T2 only if needed | yes; the newest doc |

## 3 · Build findings — what building it forced

| doc | written | what it is |
|---|---|---|
| `implementation-v0.1.md` | Aug 21 | the Python core: three deletions, role/address memory, the five-pass tick |
| `the-wrap.md` | Aug 22 | the plan: port to TS, promote Python to oracle, first light |
| `core-ts-v0.1.md` | Aug 22 | the TS kernel and oracle: code is a blob, the classes are the passes, route selection, what the fuzzer found |
| `liminal-and-head-v0.1.md` | Aug 22 | lineage beside the store, a boundary read off the crossings, the scratch store, the first head |

## 4 · Heads and tiers — what you open

| doc | written | what it is | still current? |
|---|---|---|---|
| `the-head.md` | Aug 21 | Head Laws 1–5: gauge as a group, no reaching in, liminal vs declared, seeing ≠ acting | yes |
| `eidola-001.md` | Aug 23 | eidola as the product; the 001 outline (layers 1–5) and its first build | outline yes; its "known gaps" are partly closed |
| `the-ai-node.md` | Aug 25 | why the AI node froze, and the ask/receive split | the design yes; the build it describes lives only in the project's `eidola.html`, not in source |
| `generated-from-core.md` | Aug 25 | behaviour lives in the library, never the kernel | yes |
| `eidola-tiers.md` | Aug 25 | base / workstation / suites; naming locked; the coherence contract | yes, except that persistence is no longer "presentation only" |

## The base, and the core read as a universe

- *The Eidola core as a little universe* — the laws, the theorems that follow from them, the
  audit of whether the build obeys them, the physics reading, and what is still open. A doc in
  the claude.ai project "graphmap" (14 Oct).
- `inside-eidola-base.html` — what the base is, where it touches the core, what the
  review fixed and what comes next (also published as an artifact).

## Next to the code

- `../spec/CANON.md` and `../spec/CORE-FORMAT.md` — the normative specs that both cores
  implement.
- `../STATUS.md` — status today.
- `../CHANGELOG.md` — what changed on 2026-10-13 and 2026-10-14.

## Not copied here

- `eidola.html` from the project: the AI-node build of the workstation. It is a
  hand-patched bundle with no source, and it stays in the project as a record.
- `liminal and head v0.1` (no extension): a duplicate of `claude/liminal-and-head-v0.1.md`.

## 5 · Foundations — the mathematics (2026-11-09 … 11-12)

See `5-foundations/README.md`: formal foundations with proofs, the chip-calculus experiments, the
build-layer findings, and the alpha plan.

## Decision records

`adr/README.md` — one file per decision that changes a hash, a sigma, or what a workspace may contain.

## Guide

`guide/quickstart.md` — open it, check and run a workspace, replay, export, develop.
