# Foundations — the mathematics, and what it found in the build

| doc | what it is |
|---|---|
| `formal-foundations.md` | the core as a space (free algebra of a wiring operad; frames as a flat bundle; time as a covering); theorems with proofs, status-tagged [P]/[K]/[V]/[O]; open problems; spec findings |
| `chip-calculus-findings.md` | the experiments behind it: summary algebra, coherence as a semiring, card decks |
| `build-layer-findings.md` | Eidola as a build-time layer: export, measured runtime cost, the determinism hole, research directions |
| `alpha-plan.md` | what blocked an open alpha and the order it was cut in |

The scripts that produced every number are in `research/`.
