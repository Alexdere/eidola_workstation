# Open alpha — plan and where it stands (2026-11-12)

**Verdict:** nothing theoretical blocks an alpha. Theorems are guarantees; an alpha promises graded
behaviour (two cores agree, bit for bit) and honest labels (STATUS). What blocked it was a handful of
hard-to-reverse decisions, one safety item and packaging.

| step | status |
|---|---|
| 1. Record the one-way doors; fix pass order and rule 6 | done — ADR-0001, 0003, 0004 · **0002 open** |
| 2. Freeze vectors; metamorphic grading | done — ADR-0007 |
| 3. Public API, package names, license | API + names done (ADR-0006) · **license open (ADR-0009)** |
| 4. Run-your-own-code policy, or a worker host | policy done (ADR-0008) · host is a placeholder |
| 5. CLI over existing functions; exporter | Python CLI + Python exporter done · JS exporter and TS CLI placeholders |
| 6. Quickstart; STATUS as the contract | done |
| 7. Cheap performance: liveness cached per form and observed set; incremental folds | not started |

**To tag `0.1.0-alpha.0`:** decide ADR-0002 and ADR-0009, run `./check.sh`, tag.
