# Eidola as build layer + runtime — findings (2026-11-12)

Source: external chat "Explain and Present Key Concepts" (Eidola as build-time correctness layer; two-layer wrapper; harness units; export to plain code; runtime vs build tradeoff). Checked against the 2026-10-14 oracle.

## Built and measured
- Export = residualising the tick for one fixed form (first Futamura projection). Prototype `research/probes/residualize.py`; the standalone exporter is `export/py/eidola_export.py` emits plain Python step(journal): no store, hashing, memo, liveness pass or Ctx; delays as incremental accumulators; journal of sources only.
- Exact: 904/904 random grader workspaces (96 refused), 3591 ticks — every sigma value and effect reproduced (containers, frames, shared memory, delays, effects, liveness).
- Speed (Python oracle vs exported): 500 / 2000 / 8000 leaves → 72 / 126 / 415 µs per leaf vs ~0.8 µs; ratio 89× / 164× / 554×. Oracle cost per leaf grows with size: liveness is a fixpoint recomputed every tick (TS core same structure). Memo hits gave no speedup at prim granularity (hashing ≥ compute).
- History: 40 running sums, oracle tick 0.64 ms at tick 10 → 27.7 ms at tick 3000 (full-log fold, F5 unbuilt); exported stays ~20–40 µs.
- Determinism hole: two delays sharing a memory address, panes inserted in different order → identical graph hash, different sigma (shared log's last = 2.0 vs 1.0). Pass C iterates sites in insertion order (TS core same loop). Grader can't see it (both cores read the same JSON order).

## Key points worth research
1. Honesty = trust surface. Two-layer wrapper = ascription: derived seam ⊑ ascribed seam (ring check, not a ninth law; containers can't declare powers under rule 7). May-properties (powers, reach, dependency) have a safe direction (over-declare); equality properties (frames, memo purity) don't. Anchors: abstract interpretation; Rust unsafe; gradual typing + blame (Wadler–Findler); Hardened JS/SES Compartments; WASM component model (WIT).
2. What survives erasure: build-time facts (well-formedness, frame checks, derived seams) and replay (journal sources only, Law 5); lost: enforcement, memo, hot swap. Law 6 must survive export (unpinned effects never fire). Multi-target export only for prim units (host code is language-locked). Anchor: Lustre/SCADE modular code generation (Biernacki–Colaço–Hamon–Pouzet 2008), qualified code generators.
3. Substitution certificates per property: swap safe for P iff Σ_P equal (Myhill–Nerode); same ports ≠ substitutable. Reverse index + Thm 6 → refactor diff.
4. Harness units = contexts (one-hole diagrams, authoring-time, outside core) vs F9 runtime higher-order. Power-rebinding harnesses (transaction) = effect handlers; Law 4 puts them at the floor: powers(H[u]) = (powers(u) − handled) ∪ powers(H). Anchors: algebraic effects (Plotkin–Pretnar), Koka/OCaml 5, ocap attenuation.
5. Runtime cost is mostly algorithmic: liveness/topo are form properties (cache per form + observed set), folds incremental (F5), memo only where hit-rate × leaf cost > key cost. Granularity knob: coarse leaves (two-layer pattern) make native practical. Anchors: Adapton, Salsa, Build systems à la carte (Mokhov–Mitchell–Peyton Jones).
6. Metamorphic grading: every transformation the laws call invisible (wire order, pane insertion order, layout, renaming under canonical naming) must leave sigma unchanged — derive test oracles from invariances. Fix for the hole: canonical pass order, or forbid non-commutative multi-writer reads (Thm 13c).
7. Hot swap = state migration: memory is scoped by occurrence path, so the log survives a swap; entry schemas are frames, migrations are lossy transitions; Thm 8/11 check migration coherence. Anchors: bidirectional lenses (lens laws = round-trip obligations), Cambria (Ink & Switch).
8. Native domains: coarse leaves + frequent edits/reuse + replay value (Closure, graphmap, notebooks, build tools); request/response with tiny leaves → export.

## Small corrections to the external thread
- Recursion inside a leaf body is fine; F8 only concerns wiring loops.
- Theorem 6 counts ancestor recomputation; optimality not claimed.
- Overhead is not a fixed 100–1000×; measured above and mostly removable.
