# Eidola — formal foundations, v0.1

*2026-11-09 · built from the CORE/1 spec, the 2026-10-14 tree (Python oracle), and the chip-calculus experiments.*

Status tags: **[P]** proved here · **[K]** known theorem, applied here · **[V]** verified by computation only · **[O]** open.

Standing assumption, used by every theorem that talks about *executions* rather than *forms*:

> **Floor (leaf honesty).** A leaf's outputs in a tick are a function of its declared inputs, its declared powers and the journal; it reads nothing else and writes nothing else.

Today this is convention (`JsHost`), so every execution theorem below is conditional on it. Theorems about forms (identity, well-formedness, frames, summaries) are unconditional.

---

## 1. What kind of space the core defines

### 1.1 Boundaries and wiring diagrams (Laws 1 and 2)

A **boundary** is a pair of ordered port lists $\beta = (\mathrm{in}, \mathrm{out})$, each port carrying a shape and a frame.

A **wiring diagram** $W : (\beta_1, \dots, \beta_m) \to \beta$ is a finite set of wires whose sources are out-ports of the inner boxes $\beta_i$ or in-ports of the outer box $\beta$ (the endpoint `@in`), and whose targets are in-ports of inner boxes or out-ports of $\beta$ (`@out`), such that **every target receives at most one wire** (no fan-in; fan-out is free).

Substituting a diagram into an inner box of another diagram is again a diagram. With this substitution, wiring diagrams form a coloured operad $\mathcal W$ (objects: boundaries; operations: diagrams). This is Laws 1 and 2 stated as one object: Law 1 says boxes interact only through their port lists, and Law 2 says the operation that makes a box from boxes is closed.

### 1.2 Units are the free algebra (Law 3, F7)

Let $\mathcal L$ be the set of leaves (opaque bodies with boundaries and powers). The set of all units is the **free $\mathcal W$-algebra** on $\mathcal L$: every unit is a finite term, either a leaf or a diagram whose boxes are filled with units. In storage this is the Merkle DAG, and `unit_id` hashes the canonical serialisation of the term.

- **F7 is well-foundedness of terms.** A term cannot contain itself, so the store is a DAG. This holds by construction and needs no check.
- **Hash identity is labelled.** The spec hashes occurrence names: two graphs that differ only in pane names get different ids (checked on the oracle). The prose of Law 3 ("if two people independently build the same structure… they have built the same unit") describes a coarser identity, the orbit under renaming occurrences. The two coincide only if the hash is taken over a **canonical labelling** (graph canonisation). The gap between the two identities is exactly where the reconstruction questions of §6 live.

### 1.3 Meaning is a map out of the free algebra

Any assignment of meaning to leaves that respects wiring extends uniquely to all units. That is the universal property of a free algebra, and it is the formal content of *"the boundary tells you everything you need"*: a property $P$ is decidable from seams exactly when $P$ factors through a $\mathcal W$-algebra homomorphism. It has a **finite** seam summary exactly when that algebra can be taken finite on each boundary (recognisability, §2.4).

### 1.4 Geometry on the wires

Three labellings live on the edges of every flattened graph:

| layer | values | law | geometric reading |
|---|---|---|---|
| **frames** | invertible conversions (a groupoid of bijections) | Law 7: agreement around loops | a **local system / discrete bundle** over the wiring graph; Law 7 = flat; on a graph, flat ⇔ globally trivial |
| **time** | delay counts in $\mathbb N$ | F8: cycles must contain a delay | the event space is the **$\mathbb Z$-covering** of the form graph; F8 = every loop winds forward in time |
| **authority** | sets of powers (a lattice) | Law 4 | a monotone flow; only leaves introduce powers |

Frames and time are the same kind of object, a group-valued 1-cochain on edges. Law 7 asks its holonomy to be trivial. F8 asks the holonomy of every directed cycle to be positive.

### 1.5 Seams are coboundaries

For a set $S$ of occurrences in a graph, let $\delta S$ be the set of wires with exactly one end in $S$. The CORE/1 rule *"the boundary is read off the crossings"* says that melting $S$ creates a unit whose ports are $\delta S$. Law 1 then says all interaction with $S$ passes through $\delta S$. The same $\delta S$ reappears in §4: an internal re-framing of a region is invisible except on $\delta S$. Seams, Law 1 and undetectable defects are one object.

### 1.6 Presentation is a fibre (Law 8)

A workspace is a pair (content, layout). Law 8 says the hash, the semantics and every summary factor through the projection to content. The layouts over one content form the fibre, which is literally a gauge fibre.

### 1.7 So is it a space, a manifold, an interaction?

All three, at different layers:

- **Composition** is an *interaction algebra*: the free algebra of a wiring operad, equivalently a free traced monoidal category. This is the same structure as Geometry of Interaction and interaction nets.
- **Frames** are a *manifold-style atlas*: charts are frames, transition maps are conversions, Law 7 is the cocycle condition. Because the base is a graph, Law 7 forces the atlas to be globally a single chart up to relabelling. Allowing **declared curvature** would make it a genuine bundle. The musical case is the Pythagorean comma, the holonomy of twelve pure fifths against seven octaves:
  $$\left(\tfrac32\right)^{12}\Big/\,2^{7} \;=\; \frac{3^{12}}{2^{19}} \;=\; \frac{531441}{524288}\;\approx\;1.0136$$
  Under Law 7 as written this is a bug; in tuning it is the geometry. Closure may want declared curvature.
- **Events** form a *covering space* of the form graph, indexed by ticks.

---

## 2. Composition

### 2.1 The seam theorem [P]

**Setting.** $(S,\oplus,\otimes,0,1)$ is a complete semiring: countable sums exist, are associative under arbitrary partitions, and $\otimes$ distributes over them. Examples: Boolean; tropical with $\infty$; $[0,\infty]$; the frame-coherence semiring of §3.

Each leaf $\ell$ carries a weight matrix $w_\ell \in S^{\mathrm{in}(\ell)\times \mathrm{out}(\ell)}$, and each wire a weight (default $1$; a conversion for frames). $\mathrm{Flat}(u)$ is the flattened graph: vertices are port endpoints at every depth (container ports are relay vertices, as in the oracle), and edges are wires plus leaf-internal edges. Define

$$\Sigma(u)[p,q] \;=\; \bigoplus_{\pi:\ \mathtt{@in}.p \,\leadsto\, \mathtt{@out}.q \text{ in } \mathrm{Flat}(u)} \ \bigotimes_{e\in\pi} w(e).$$

For a container $u$, the **seam graph** $\mathrm{Sg}(u)$ has as vertices the endpoints at level $u$ (its own ports and its children's ports). Its edges are the level-$u$ wires plus, for each child $c$ and port pair $(i,o)$, an edge $c.i \to c.o$ of weight $\Sigma(c)[i,o]$.

**Theorem 1.** $\Sigma(u)$ equals the path-sum from $\mathtt{@in}.p$ to $\mathtt{@out}.q$ in $\mathrm{Sg}(u)$.

*Proof.* A child's in-port vertex $c.i$ has incoming edges only from level $u$ (inside $c$ it is the source-only `@in`). Its out-port vertex $c.o$ has incoming edges only from inside $c$. So every path in $\mathrm{Flat}(u)$ splits uniquely into level-$u$ wires and maximal segments inside children, and each segment runs from some $c.i$ to some $c.o$ as a path of $\mathrm{Flat}(c)$. This gives a bijection between Flat-paths and pairs (seam path, one interior path per child edge). Weights multiply along the split. Summing in two stages, first over interior choices and then over seam paths, is allowed by partition-associativity and distributivity:

$$\bigoplus_{\pi} w(\pi) \;=\; \bigoplus_{\sigma}\ \bigotimes_{e\in\sigma}\Big(\bigoplus_{\text{choices for } e} w\Big) \;=\; \bigoplus_{\sigma}\ \bigotimes_{e\in\sigma}\Sigma(\text{child})[i,o].\qquad\blacksquare$$

**Corollary 1.1.** By induction on depth, $\Sigma(\text{root})$ is computed from leaf matrices and per-level wiring only. $\Sigma(u)$ depends only on $\mathrm{id}(u)$, so it is computed once per distinct unit. The serial, parallel and feedback formulas of the experiments are the special cases (product, block-diagonal, and the star formula $\Sigma_{xy}\oplus\Sigma_{xu}\Sigma_{uu}^*\Sigma_{uy}$).

**Instances** (each a choice of semiring and leaf weights):

| law / question | semiring | leaf weights |
|---|---|---|
| Law 6 liveness reach | Boolean | all-ones (delays included) |
| F8 dependency (instantaneous) | Boolean | pure/effect all-ones, delay zero |
| Law 4 powers touched along a route | antichains of power-sets | the leaf's powers |
| Law 7 route coherence | frame-coherence semiring (§3) | conversions |
| latency, probability | tropical, $[0,\infty]$ | costs, probabilities |

**Proposition 1.2 [P].** Purity and the set of powers inside a unit are homomorphisms from the finite multiset of leaves (logical AND, set union). So they are seam summaries too. *Proof:* AND and union are associative and commutative, and a container's leaf multiset is the sum of its children's. ∎

### 2.2 F8 at the seam [P]

Let $\mathrm{Flat}_0(u)$ be $\mathrm{Flat}(u)$ with delay-leaf internal edges removed. Define:

- $D(u) \in \{0,1\}^{\mathrm{in}\times\mathrm{out}}$, the Boolean $\Sigma$ on $\mathrm{Flat}_0$;
- $C(u)$, true iff $\mathrm{Flat}_0(u)$ has a directed cycle;
- $\mathrm{Sg}_0(u)$, the seam graph that keeps a child edge $c.i\to c.o$ exactly when $D(c)[i,o]=1$.

**Theorem 2.** (a) $D(u)$ is reachability from $\mathtt{@in}$ to $\mathtt{@out}$ in $\mathrm{Sg}_0(u)$.
(b) $C(u) \iff \bigvee_c C(c)\ \lor\ \mathrm{Sg}_0(u)$ has a directed cycle.

*Proof.* (a) is Theorem 1 in the Boolean semiring.

(b), right to left: expand each child edge of a seam cycle into an instantaneous interior path. This exists by (a). The result is a nonempty closed walk in $\mathrm{Flat}_0(u)$, which contains a cycle.

(b), left to right: let $\gamma$ be an instantaneous cycle. If $\gamma$ never touches a level-$u$ vertex, it lies inside one child, so $C(c)$ holds. Otherwise decompose it as in Theorem 1. Each segment $c.i \leadsto c.o$ is instantaneous, so $D(c)[i,o]=1$, and the decomposition is a closed walk in $\mathrm{Sg}_0(u)$, which contains a cycle. ∎

**Corollary 2.1.** CORE/1 well-formedness rule 6 ("the graph with delays removed is acyclic") is decided by the cached pairs $(D, C)$ per unit id plus the root wiring, without flattening.

**[V]** Against the oracle's flatten on 3000 random nested workspaces: same verdict in 2979. The 21 disagreements are cycles made only of relay vertices. Rule 6 refuses them; the oracle accepts them unless a leaf reads them, in which case the 4096-hop guard refuses them. A check limited to today's stored seam (ports, powers, class) would refuse 165 of the 211 legal workspaces.

### 2.3 Time is a covering; replay [P, replay conditional on the Floor]

Give each edge of $\mathrm{Flat}$ a delay weight $\tau(e)\in\{0,1\}$: 1 on delay-leaf internal edges, 0 elsewhere. The **event graph** is

$$\widehat{G} \;=\; \mathrm{Flat}\times\mathbb Z,\qquad (x,t)\to(y,\,t+\tau(e)) \text{ for each edge } e:x\to y.$$

**Theorem 3.** These are equivalent: (i) $\widehat G$ is acyclic; (ii) every directed cycle of $\mathrm{Flat}$ has positive delay weight; (iii) $\mathrm{Flat}_0$ is acyclic (F8).

*Proof.* A cycle in $\widehat G$ returns to the same $t$, so it projects to a closed walk of total weight 0. Weights are non-negative, so every edge on it has weight 0, which is a cycle of $\mathrm{Flat}_0$. Conversely, a cycle of $\mathrm{Flat}_0$ lifts to $\widehat G$ at any fixed $t$. ∎

**Corollary 3.1 (Replay, axioms.md T2).** Under F8 and the Floor, given the form, initial memory and the journal, every $\sigma_t$ is uniquely determined.

*Proof.* Induct well-foundedly on $\widehat G$ restricted to $t\ge 0$, ordered by (tick, topological rank in $\mathrm{Flat}_0$). Each value is a function of its predecessors, and delay reads see only earlier ticks. ∎

F8 makes each tick finite. It does not bound a run: a loop $x\mapsto 2x$ through a delay is legal and still diverges over time. That is the ordinary small-gain question, asked per tick.

### 2.4 Finite summaries: recognisability and width [K + P]

**Definition.** For a property $P$ and two units $u, v$ with the same boundary, set $u \sim_P v$ iff $P(C[u]) = P(C[v])$ for every context $C$. This is the **seam congruence** of $P$.

**Theorem 4 [K, Myhill–Nerode for algebras].** $P$ has a seam summary that composes (Theorem 1 style) iff $P$ is a union of $\sim_P$-classes. That is automatic, and the summary map $u \mapsto [u]_{\sim_P}$ is the minimal one. The summary is finite iff $\sim_P$ has finite index on each boundary. The "price list" of a property is this index.

Examples:

$$|\text{reach}| \le 2^{k_{in}k_{out}},\qquad |\text{F8}| \le 2^{k_{in}k_{out}+1},\qquad |\text{frame coherence}| \le (|\Gamma|+2)^{k_{in}k_{out}},$$

while exact path counting has infinite index.

**Theorem 5 [P].** Suppose every seam has at most $k$ ports and every composite interior has at most $m$ occurrences. Then $\mathrm{Flat}(\text{root})$ has treewidth at most $(m+1)k-1$.

*Proof.* Use the unit tree as the decomposition. The bag of a composite occurrence holds its own port endpoints and those of its children, so at most $k + mk$ vertices. Every wire at level $u$ and every leaf-internal edge lies in bag($u$). A child's port endpoints occur exactly in bag(parent) and bag(child), which are adjacent. ∎

**Corollary 5.1 [K + P] (Courcelle over a Merkle DAG).** Every property definable in monadic second-order logic over $\mathrm{Flat}$ is decidable by a finite bottom-up automaton over the unit tree. The automaton state at a unit depends only on its id, so the total cost is linear in the number of **distinct** units in the store, not in the flattened size, which can be exponentially larger through sharing.

*Missing:* the automaton size is non-elementary in general (finite is not the same as small). It also assumes bounded $m$; large flat workspaces need $m$ replaced by the treewidth of each interior's seam graph.

### 2.5 Incremental recomputation [P]

**Theorem 6.** Let $\Sigma$ be any summary defined by structural recursion, $\Sigma(u) = F(\text{form of } u,\ (\Sigma(\text{children})))$. Replacing the unit at one occurrence path $p$ creates new ids exactly on the ancestor chain of $p$. Recomputation is $\mathrm{depth}(p)$ evaluations of $F$, and every other $\Sigma$ value is a cache hit.

*Proof.* Forms are Merkle, so a form changes iff it contains the edited occurrence. Unchanged forms keep their ids and hence their cached $\Sigma$ (assuming hash injectivity). ∎

This settles "composite-level memoisation" for every structural summary. For values, memoisation of pure composites keyed by (id, input blob ids) is already licensed by the purity rule.

---

## 3. Frames (Law 7)

**Setting.** $V$ is a set of frames, each with a value set $X_v$. $T$ is a set of declared transitions $t: a\to b$, each a bijection $f_t: X_a\to X_b$. A *route* is a directed path. A *closed walk* is undirected; traversing $t$ backwards uses $f_t^{-1}$.

- **(F) Flatness:** every closed walk has holonomy $\mathrm{id}$.
- **(R) Route agreement:** any two routes with the same endpoints have equal composites, where the empty route counts when the endpoints coincide.

**Theorem 7 [P].** (F) implies (R). If the atlas is symmetric (every $t: a\to b$ has a declared $\bar t: b\to a$), then (R) implies (F).

*Proof.* Two parallel routes form a closed walk. For the converse, (R) applied to $\bar t\circ t$ versus the empty route gives $f_{\bar t}=f_t^{-1}$. Every closed walk is then realised by a directed closed route, and (R) makes it the identity. ∎

The shipped check compares only routes with distinct endpoints, so it never sees round trips. That is the gap the probes found.

**Theorem 8 [P] (tree obligations are complete and minimal).** Take a spanning forest $\Phi$ of the underlying undirected graph and a root $r$ in each component. Let $\varphi_v : X_r \to X_v$ be the composite along the forest path. Then

$$(F)\iff \forall\, t: a\to b,\ t\notin\Phi:\quad f_t\circ\varphi_a=\varphi_b .$$

There are $|T|-|V|+c$ obligations ($c$ = number of components), and no obligation is implied by the others.

*Proof.* (⇒) The closed walk $r\leadsto a \xrightarrow{t} b\leadsto r$ has holonomy $\varphi_b^{-1}f_t\varphi_a$. (⇐) Every edge, forest edges included, satisfies $f_t=\varphi_b\varphi_a^{-1}$, so the holonomy of any closed walk telescopes to $\mathrm{id}$. Minimality: replace one non-forest $f_{t_0}$ by $f_{t_0}\circ g$ with $g\ne\mathrm{id}$ (possible when $|X|\ge 2$). This breaks exactly that one obligation. ∎

For a symmetric atlas with $E$ undirected pairs, the count splits as $E$ round-trip obligations plus $2(E-V+1)$ loop obligations. Making canonical routes the **forest routes** (instead of the per-pair shortest route) is what makes axiom-status §4's sentence true: *"the canonical route is the semantics; a direct route carries an obligation."*

**Theorem 9 [P] (fixtures are proofs for finite-dimensional classes).** Suppose all transitions lie in a class $\mathcal F$, closed under composition and inverse, in which any two members that agree on a fixed set $X_0$ of $k$ points are equal. Then checking each obligation of Theorem 8 on $X_0$ in exact arithmetic decides (F) exactly. Examples:

- $\mathrm{Aff}(d)$ with $k = d+1$ affinely independent points; temperature is $\mathrm{Aff}(1)$, so **2 fixtures and exact rationals are a proof**;
- projective maps $\mathrm{PGL}(d+1)$ with $d+2$ points in general position.

*Proof.* Each obligation compares two elements of $\mathcal F$, and equality on $X_0$ forces equality. ∎

For opaque code no finite fixture set decides anything, so fixtures there are samples.

**Proposition 10 [P] (tolerance drift).** Suppose the forest maps are isometries in a metric $d$, and each obligation holds within $\varepsilon$ in the sup-distance. Then a closed walk that crosses $j$ non-forest edges has holonomy within $j\varepsilon$ of $\mathrm{id}$, and the bound is tight.

*Proof.* For isometric $g$, $\|g\circ f-\mathrm{id}\|\le\|f-\mathrm{id}\|+\|g-\mathrm{id}\|$; induct on $j$. ∎

With non-isometric maps the per-step error is multiplied by Lipschitz condition numbers. So a per-obligation tolerance has to be the total budget divided by the longest loop, or the transitions should be stored in an exact class (Theorem 9).

**Theorem 11 [P] (lossy conversions are coherent on reachable values).** Now let transitions be arbitrary maps, not necessarily invertible. Fix an entry frame $r$ from which every frame is reachable, a directed spanning arborescence $\Phi$ from $r$, and forest composites $\varphi_v$. If $f_t\circ\varphi_a=\varphi_b$ for every non-forest $t$, then any two routes $P, Q: a\to b$ agree on $\mathrm{im}(\varphi_a)$. Moreover every value that can reach $a$ from $r$ along any route lies in $\mathrm{im}(\varphi_a)$. With several entry frames, use one arborescence per entry. The obligations are also necessary.

*Proof.* Telescoping gives $R\circ\varphi_x=\varphi_y$ for every route $R: x\to y$. Hence $P\circ\varphi_a=\varphi_b=Q\circ\varphi_a$, and every route from $r$ to $a$ equals $\varphi_a$. Necessity: if an obligation fails, the route through $t$ and the forest route disagree on a reachable value. ∎

By Law 5, values enter only at sources and constants. So *coherence on reachable values* is the right notion, and Theorem 11 covers lossy formats and resampling (the value side of F1).

---

## 4. Detection and localisation

**Setting.** A connected frame graph carries a correct flat assignment $g$. A perturbed assignment $g'$ differs from $g$ on a nonempty edge set $D$. "Invisible" means every loop check passes for $g'$, i.e. $g'$ is flat. $\lambda(G)$ is the edge connectivity.

**Theorem 12 [P].** (a) $D$ is invisible iff $g'$ is a **re-framing** of $g$: there are self-maps $\psi_v$ of each $X_v$ with

$$g'_e = \psi_b\, g_e\, \psi_a^{-1}\qquad\text{for every edge } e:a\to b.$$

(b) If $D\neq\varnothing$ is invisible, then $D\supseteq\delta S$ for some nonempty proper $S\subset V$. Hence $|D|\ge\lambda(G)$, and **any fewer than $\lambda$ simultaneous wrong conversions are caught**. The bound is tight: re-framing one side of a minimum cut changes exactly that cut and stays invisible.

(c) If a set $A$ of frames is **anchored** (their mutual conversions are known from outside), the bound becomes

$$\lambda_A=\min\{|\delta S| : A\subseteq S\subsetneq V\}.$$

(d) A single wrong wire is invisible iff it is a bridge. Two wires give identical failure patterns iff they lie on exactly the same cycles, i.e. they are in series [K].

*Proof.* (a) Both $g$ and $g'$ are flat, so both have potentials $\varphi, \varphi'$ from a common root with $\varphi_r=\varphi'_r=\mathrm{id}$. Put $\psi_v=\varphi'_v\varphi_v^{-1}$; then $g'_e=\varphi'_b\varphi'^{-1}_a=\psi_b g_e\psi_a^{-1}$. The converse is immediate.

(b) Pull each $\psi_v$ back to the root frame, $\chi_v=\varphi_v^{-1}\psi_v\varphi_v$. Edge $e$ is unchanged iff $\psi_b g_e\psi_a^{-1}=g_e$ iff $\chi_a=\chi_b$. Since $\chi_r=\mathrm{id}$ and $D\neq\varnothing$, the function $\chi$ is not constant. Let $S=\{v:\chi_v=\mathrm{id}\}$. Every edge of $\delta S$ has $\chi=\mathrm{id}$ at one end only, so it lies in $D$.

(c) Root at an anchor. The anchor checks force $\chi=\mathrm{id}$ on $A$, so $S\supseteq A$.

(d) For $D=\{e\}$, (b) needs $\delta S\subseteq\{e\}$, i.e. $e$ is a bridge. The series characterisation is standard matroid theory. ∎

The proof never uses commutativity, so the result holds for any group or groupoid of conversions.

**[V]** 48-element non-commutative group:

- fewer than $\lambda$ defects: caught 10080/10080;
- min-cut re-framings: invisible 291/291;
- trees with two anchors, one wrong wire between them: loops see nothing, anchors catch it 400/400;
- single-defect series classes: 16868/16868 pairs.

**Reading.** A bug that no test can ever see is indistinguishable from someone consistently re-framing a whole region. Only an absolute anchor can tell the two apart. In Eidola's own vocabulary, invisible integration bugs are *gauge*.

---

## 5. Memory (F5, F6)

Let a read be $r: E^*\to V$ over logs of entries.

**Theorem 13 [P] (three levels).**

(a) **Append-incremental with bounded state** iff the right congruence $x\equiv y \iff \forall z\, r(xz)=r(yz)$ has finite index. Any left fold is append-incremental with *some* state; the median needs unbounded state.

(b) **Segment caching** (summarise chunks of a log, combine the summaries) iff $r$ factors through a monoid homomorphism. The minimal one is the syntactic monoid, which is finite iff $r$ is recognisable.

(c) **Interleaving invariance.** When each entry may come from a different writer, the value is independent of how writers interleave iff $r$ depends only on the multiset of entries, i.e. factors through the free commutative monoid $\mathbb N^{E}$.

*Proof.* (a) and (b) are Myhill–Nerode for words. (c): interleavings of single-entry writers realise every permutation; the converse is immediate. ∎

So F5's "must be a monoid homomorphism" is exactly what segment-level caching and merging need; append-only incrementality needs only (a). Under F6 (several writers to one address), count, sum and max are order-free. **last** and **hist** are not. They are exactly the reads where scheduler order enters values, and if writes in one tick are appended in path order, renaming an occurrence can change a value (follows from the spec; not run). The single-writer lint is needed exactly for non-commutative reads.

---

## 6. Identity and reconstruction

**Proposition 14 [V].** Hash identity includes occurrence names (oracle: same wiring with different pane names gives different unit ids). Names are also semantic, because memory scope paths use them, so renaming acts on content and memory together.

**Proposition 15 [P].** For $n\ge3$ occurrences, a graph is reconstructible from its one-occurrence-deleted cards if (i) occurrences are labelled (hash identity), or (ii) all occurrences hold distinct unit ids.

*Proof.* (i) Every wire $x\to y$ survives in any card deleting a third occurrence, so the union of the cards recovers the graph. (ii) Any isomorphism preserves unit ids; with all ids distinct, the ids act as labels, and (i) applies. ∎

**Proposition 16 [P] (unlabelled chips are not reconstructible in general).** In the plain digraph model of the chip experiments (fan-in allowed), take Stockmeyer's infinite family of non-isomorphic tournament pairs $G, H$ with equal decks. Add one input port wired to every unit and every unit wired to one output port. The resulting chips $G', H'$ are live, have equal decks, and are non-isomorphic.

*Proof.* Isomorphisms fix the ports. So card isomorphisms correspond to isomorphisms of the vertex-deleted tournaments, and $G'\cong H'$ would restrict to $G\cong H$. ∎

**[V] Repeated identical units with named ports** (one unit type, each in-port fed by at most one wire, one card per deleted occurrence):

| in-ports per unit | occurrences | classes | non-reconstructible |
|---|---|---|---|
| 1 | 4 / 5 / 6 | 45 / 121 / 338 | **0 / 0 / 0** |
| 2 | 3 / 4 | 720 / 16 900 | 159 / **39** |
| 3 | 3 | 43 968 | 8116 |

Twins were verified independently.

**[O] Conjectures.**

- **R1:** one-in-port structures (each unit has one input) are reconstructible for $n\ge4$.
- **R2:** for every $p\ge2$ there are twins for infinitely many $n$.
- **R3:** the twin fraction tends to 0 as $n$ grows.

None of these affects hash identity (labelled). They matter for structural identity, latent-unit discovery and fingerprints.

---

## 7. Open, with what is missing

| # | statement | status | what is missing |
|---|---|---|---|
| O1 | **Floor.** Leaf honesty holds structurally | convention | a worker/process host. Every execution theorem (replay, seam sums over real runs) is conditional on it |
| O2 | **Price list.** Explicit minimal seam summaries for deadlock, capability escape, coherence, and selected logic properties | bounds only (Thm 4) | construct the congruences; find the summaries that are polynomial in $k$ |
| O3 | **F1 clocks.** Units at different rates | value side solved by Thm 11 | cooking semantics: when a slow unit runs inside a master tick (Lustre when/current); clock frames as non-invertible transitions; Closure's LCM phase as the period of a composite clock map |
| O4 | **F9 higher-order ports.** Ports that carry a unit id | open | seam summaries stay static iff the reference is pinned (pin puts it in the form). For followed references, summaries become functions of the environment; needs a dependent-summary theory |
| O5 | **Tolerance beyond isometries** | bound (Prop 10) | either exact transition classes everywhere (Thm 9) or an error calculus with condition numbers along forest paths |
| O6 | **Reconstruction** for port graphs | data + R1–R3 | proofs, or a Stockmeyer-style family with named ports |
| O7 | **Integration thesis.** Bugs per-unit tests miss are loop phenomena | theorem for frame-type defects (Thm 12) | other defect types (timing, resources, races) need their own semirings; real-project data |
| O8 | **Declared curvature** | design question | if Closure wants tuning holonomy, Law 7 becomes "holonomy equals declared value", still checked by Thm 8's obligations |
| — | **Full behavioural equivalence** | impossible (Rice) | out of scope by design; the laws make no claim about behaviour |

---

## 8. Spec findings (concrete, small)

1. **Rule 6 versus the implementation.** Relay-only cycles are accepted unless read, and are then caught by a hop guard. Decide which is intended; Theorem 2 implements rule 6 as written.
2. **Law 7 check.** Add round trips, and use forest-canonical routes with one obligation per non-forest transition (Thm 8). Store affine transitions as exact forms (Thm 9).
3. **Authority at the seam.** A container's stored powers are always empty, so Law 4's "read the boundary, know its authority" holds for leaves and for the derived seam (Prop 1.2), not for the stored one.
4. **Law 3 prose versus hash.** Either canonicalise occurrence names, or say "built the same way, with the same names".
5. **Shared memory with last/hist.** Values depend on writer order; lint (Thm 13c).
6. **Derived seam = (D, C, purity, powers, …).** Computed bottom-up and cached by id. This is not a ninth law: it is in the closure (axiom-status §1, case 1).
