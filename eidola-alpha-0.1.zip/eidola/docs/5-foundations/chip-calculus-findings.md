# Chip calculus — findings (2026-11-09)

Source: the ChatGPT thread that went Signal Harbor → Eidola meta-harness → macro-graph → chip
matrices → cards/coherence, then checked against the 2026-10-14 tree. Scripts:
`research/chip-calculus/` and `research/probes/`.

## Core invariant
A seam summary is a small matrix that respects composition, so a huge system can be checked by
reading seams instead of opening interiors. Serial and parallel wiring are free; every hard
question lives on loops (feedback convergence, frame curvature, bug visibility, reconstruction
ambiguity).

## Results
**A · summary algebra.** Serial, parallel and feedback composition exact 400/400 each for Boolean
reach, min-plus latency and capability antichains; 500/500 on live-feedback-only cases;
independent graph-library check 400/400. Path counting and worst latency exact without loops,
∞ in about half the cells under feedback. Probability flow exact when loop gain < 1 (linear-solve
cross-check 400/400). Loop-freedom after feedback: reach matrix + one bit predicts it 2000/2000;
reach alone cannot.

**B · coherence as a semiring** (48-element non-commutative group of axis swaps and sign flips).
Composes 300/300 for serial, parallel and feedback. One bad wire: coherence alone catches 12%;
exact criterion "on some but not all routes" 1500/1500; with a spec route 767/767. Depth-6
hierarchy with 1×1 summaries: the lowest flagged composite is the predicted one 300/300, every
live bug flagged, median region to inspect 3.2%. Indistinguishable wires ⇔ series class,
16868/16868 pairs.

**C · cards** (Ulam deck, content hash = up to isomorphism). Undirected n = 3…6 all
reconstructible. Plain digraphs non-reconstructible: n=3 10/16, n=4 16/218, n=5 18/9608 (9 twin
pairs). Chips 1-in/1-out: n=3 184/752, n=4 136/45960 (0.30% vs 7.3% for plain digraphs).
2-in/2-out n=3: 3040/44736. Structural decks fixed port reachability for n ≥ 3; summary-only
cards don't (91/340 decks). Specimen: two 4-unit chips that differ only in the direction of one
wire on a loop through all four units.

## Checked against the tree
- Law 7 already *is* the coherence semiring. Tree obligations (T − V + 1) are complete for
  invertible exact conversions. The shipped route check (simple routes ≤ 4, distinct endpoints)
  misses round trips, hub atlases and rings of ≥ 10 frames; a complete 10-frame atlas needs
  36,090 routes against 81 obligations. → `checkLoops()` in alpha-0.1 (ADR-0005).
- Affine transitions composed exactly make holonomy an exact map (tolerance 0, no fixtures).
- Seam leak 1 (F8): identical seams, different loop legality. The derived same-tick dependency
  matrix matches the oracle's flatten 2979/3000; the 21 were relay-only loops, refused since
  alpha-0.1 (ADR-0004). A seam-only check would wrongly refuse 165/211 legal workspaces.
- Seam leak 2 (Authority, from the spec): container powers are always empty (rule 7), so a
  container's stored seam says nothing about the powers inside. `eidola check` reports the
  derived set.
- F8 = the zero-delay layer of every loop is acyclic → each tick is a convergent series in z.
  Each tick is finite; boundedness over time is a separate question.
- F5 and composite memoisation are one law: a cache survives iff the summary respects composition.

## Conjecture ladder
- **C1 Seam sufficiency:** every law that is a predicate over forms is checkable from derived
  child seams plus local wiring. Holds for route-type laws. Open: lossy frames, tolerance, F1,
  F9, memory folds.
- **C2 Exactness from closure (Courcelle):** MSO questions linear-time from cached seams; needs a
  width bound and real summary sizes.
- **C3 Frame completeness:** tree obligations complete + minimal for invertible exact transitions;
  open for tolerance and lossy conversions.
- **C4 Loops are the detection budget:** invisible defects = consistent re-framings of a region;
  any < λ defects caught; resolution = series classes. Needs the floor.
- **C5 Reconstruction:** false for plain-digraph chips (Stockmeyer embedding); open for port graphs
  with repeated identical units.
- **C6 Cache law:** true given Law 3 + homomorphic summaries; needs F5 + composite memo built.
- **C7 Time as frame (F1):** same open problem as lossy frames.

## Formal anchors
Kleene algebra matrices (Conway, Kozen); algebraic path problem (Lehmann); traced monoidal
categories (Joyal–Street–Verity); small-gain theorem; Courcelle + Myhill–Nerode; Penrose,
cohomology of impossible figures; Beeri–Fagin–Maier–Yannakakis; Kelly's lemma; Stockmeyer;
causality interfaces (Zhou & Lee); Rice.
