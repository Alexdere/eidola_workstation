# Eight Laws for a Substrate

*An introduction to the core — what it is, why each law exists, what each one forbids, and how they hold together.*

---

## What is this thing?

The core is a small set of rules for building systems out of connected parts. Not a programming language, not a database, not a visual tool — it sits underneath all of those. It defines what a "part" is, how parts connect, what they're allowed to do, and what counts as the same part appearing twice.

The whole thing runs on about 1,400 lines of code. It has been tested against three very different applications — a situational map of the world, a music composition tool, and a personal homepage — and the same rules held in all three without growing. That is the claim: eight laws, no more, and they do not need to change when the domain changes.

The laws fall into four layers. Two make the system possible at all. One makes things nameable. Three are guarantees the runtime enforces. Two are properties the system can check about itself. Here they are.

---

## The two that make levels

### Law 1 — Boundary

*A unit is a boundary plus an interior. Nothing reaches across except through the boundary.*

Think of a unit as a wall with labeled sockets on it. You can plug things into the sockets, and you can see what the sockets are called, but you cannot reach through the wall. Whatever is behind it — a single calculation, a thousand interconnected parts, a connection to a live data feed — you interact with only through those sockets.

This is the most basic commitment. It says levels exist. There is an inside and an outside, and you cannot skip the interface between them. Every other law is a statement about what that interface must or must not carry.

**What it forbids:** Reaching into a unit's guts from outside. Knowing how something works in order to use it. Any kind of privileged back-channel.

**What it buys:** You can replace the interior without anything outside noticing, as long as the sockets stay the same. You can test a unit in isolation. You can describe what a unit does without describing how.

### Law 2 — Closure

*Interiors are either opaque (a single piece of code) or are graphs of units. Any graph of units, given a boundary, is itself a unit.*

This is the law that makes the system scale. Take three units, wire them together, draw a boundary around the assembly, and the result is a unit — usable anywhere a single unit is usable. No special "grouping" feature, no "macro" system, no "module" concept. The operation that makes things is the same operation at every level.

The name is from algebra. An operation is "closed" over a set when applying it to members lands you back inside the set. Addition is closed over integers: add two integers, get an integer. Division is not: divide 3 by 2 and you've left the integers, which is why fractions had to be invented. Here the operation is wrapping — bundle units into a boundary — and it is closed. You never leave the set. You never need a new kind of thing.

**What it forbids:** A third kind of interior. Any feature that exists because "grouping things required adding something." Templates, macros, rooms, modules, subgraphs-that-aren't-quite-units — all of these are symptoms of a system that isn't closed, and each one ages badly because it doesn't compose with the next one.

**What it buys:** Unlimited nesting from a finite vocabulary. A pattern containing patterns containing patterns, all the way down, and every level works the same way. The system can express things the designer never imagined, without the designer adding anything.

---

## The one that makes things nameable

### Law 3 — Identity

*Two things are the same thing exactly when they are built the same way.*

A unit's name is its content. If two people independently build the same structure — same boundary, same interior, same wiring, same occurrence names — they have built the same unit. (Names count because memory scope paths use them; see `docs/adr/0001`.) Not a copy, not a clone: the same thing. The system represents this by hashing the structure (a fingerprint computed from the content), but the hash is a representation, not the definition. The definition is structural equality.

**What it forbids:** Mutable identity — a name that points to something today and something else tomorrow. Handles that can be reused for different content. Two things with the same name but different insides, or two names for the same content.

**What it buys for free:** You cannot build a structure that contains itself (you'd need the hash before you could compute it), so the store is automatically a directed graph with no cycles — permanently, by construction, no cycle-detection needed. Memoization works because the key is always stable. Migration works because shipping the content ships the identity. A shared library of reusable parts gets deduplication for free — if two composers independently wrote the same four-note motif, the system has one motif, not two copies.

---

## The three the runtime enforces

These are rules that are made *impossible to violate* rather than merely checked. A unit running under these rules literally cannot perform the forbidden action, because the capability to do so does not exist in its environment.

### Law 4 — Authority

*The boundary carries ports and powers. Ports are satisfiable by a wire from a neighbor. Powers are satisfiable only by the runtime. No composite may bind a power.*

Ports are where data flows in and out — any neighbor can connect to them. Powers are what a unit is *allowed to do*: read the network, write to the filesystem, hold a secret, act as a data source, fire an effect. The critical line is the last one: no assembly of units can grant a power. Only the runtime — the thing underneath everything — can do that.

This is the security model, and its key property is that it is not self-hosting. If capabilities were just another kind of data flowing through wires, then a clever arrangement of units could wire itself to have whatever authority it wanted. The floor has to be beneath the furniture, not made of it.

**What it forbids:** A unit granting itself or its neighbors capabilities they weren't given. Self-hosted security. "Just for now" escape hatches that bypass the permission system.

**What it buys:** You can read a unit's boundary and know its complete authority — what it can do, and what it cannot — without running it, without dynamic analysis, without trusting it. The complete surface area of any program is computable by reading its structure.

### Law 5 — Novelty

*Every value is a constant baked into a form, a function of other values, or emitted by a source at a tick. Nothing else.*

This is where the outside world gets in. New information — a sensor reading, a network response, the current time, a user action — enters only through units that have declared themselves as sources. Everything else is either constant or computed from other values. There are no side doors.

**What it forbids:** Ambient state. A pure calculation that secretly reads the clock. A function that gives different answers when called twice with the same inputs because it reached out to the network when you weren't looking.

**What it buys:** Replay. Record what the sources emitted, and you can re-run the entire system and get bit-identical results. This is the single most powerful property a system can have for debugging, testing, and understanding what happened. It is impossible without this law.

### Law 6 — Demand

*A unit runs when it is stale and alive. Alive means someone is looking at it, or it has been explicitly pinned to stay alive, or it feeds something that is alive.*

Nothing runs because it exists. Nothing runs on a timer. Nothing runs "just in case." A unit computes only when something downstream wants the answer. Liveness propagates upstream: if you're watching a chart, the chart is alive, so the data source feeding the chart is alive, so the parser feeding the data source is alive. Close the chart and everything upstream goes quiet.

**What it forbids:** Background computation nobody asked for. Effects that fire on their own. Battery drain from invisible work. The system doing things you didn't know about.

**What it buys:** The viewport is a garbage collector for computation. The act of looking at something is what keeps it running. Stop looking, and it stops. This is why the same system can run as a full graphical application or as a headless command-line tool — the only difference is what is observed.

---

## The two the system checks about itself

These properties are not made impossible to violate; they are *tested* — the system can express them as predicates over its own structure and verify them at any time.

### Law 7 — Frame

*Ports carry a frame as well as a shape. Two ports connect if frames match or a declared transition exists, and transitions must agree around any loop.*

A number means nothing until you say from where. Meters are not feet. Celsius is not Fahrenheit. Geographic coordinates need a coordinate reference system. Musical time in beats-per-minute is not the same as wall-clock seconds. Every port declares not just *what kind* of data it accepts (its shape) but *what reference frame* that data is stated in (its frame).

When two frames are different, a declared conversion must exist. And here is the sharp part: if there are two different paths for converting between the same two frames, both paths must agree. If you convert Celsius to Fahrenheit directly, or if you convert Celsius to Kelvin and then Kelvin to Fahrenheit, you must get the same number. If you don't, the system has a bug — and that bug is detectable by running both paths on the same input and comparing.

**What it forbids:** Silent conversion errors. Two different adapters that both claim to handle the same format but produce subtly different results. The class of bug where you get the wrong number and nobody knows which conversion introduced it.

**What it buys:** Confidence that data means what it says it means. The ability to plug in new format converters without worrying about contradicting existing ones, because the system will catch the contradiction.

### Law 8 — Gauge

*Presentation is not content. Where you put something on screen, what color it is, whether it is collapsed or expanded — none of these participate in identity or computation.*

The name comes from physics. A gauge transformation is a change of description that does not change the thing described — like measuring a length in inches versus centimeters. The length hasn't changed; only the numbers have. Here, moving a unit on screen, recoloring it, stacking it behind another unit — all of these are gauge transformations. The content is invariant.

The test is byte-identical serialization: save the graph, move something on screen, save again. The two files must be identical. If they aren't, something presentational has leaked into the content, and the whole multi-view story breaks.

**What it forbids:** Position as meaning. Layout embedded in identity. The common trap where rearranging a visual workspace silently changes the underlying computation.

**What it buys:** One arrangement, many views. Open the same workspace on two monitors with different layouts — both are correct, because neither layout is the content. Run the same workspace headlessly from a command line with no screen at all — still correct, because nothing about the computation depended on there being a screen. In a music tool: the same piece viewed as a graph, a score, or a timeline — three presentations, one identity.

---

## How they hold together

The eight laws are not a checklist. Every one of them is a statement about what belongs at the boundary between inside and outside.

Two make the boundary. Five say what must be declared on it. One says what must be kept off it.

Read that way, the whole framework is one sentence: **a good boundary is one where the outside tells you everything you need and the inside tells you nothing you need.** The eight laws are the enumeration of what that requires — what "everything" consists of (identity, authority, sources of novelty, when it runs, what its values mean) and what must be excluded (presentation).

The sharpest version of this is a test for any proposed ninth law: it must name something that needs to be declared at the boundary, or excluded from it, that none of the eight already covers. If it can't be stated that way, it isn't a law. It's a feature, a convention, or a wish.

---

## What it is not

It is not a foundation for reality. It is not a theory of everything. It is not a claim about the bottom of the stack.

Below it: a browser, an operating system, a machine, physics. Above it: applications, workspaces, people, practices. It is a clean joint at one place in a stack that extends in both directions farther than anyone can see, and its virtue is precisely that it does not claim to be the floor. It claims to be one joint, made well.

The laws are axioms for a machine. Their entire virtue is that each one can be violated by a program, and the violation can be made to fail a test. That is not true of a metaphysics. This does not prove the system works. It defines "works" precisely enough that running it can show you.
