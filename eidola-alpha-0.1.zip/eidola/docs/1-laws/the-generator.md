# The Generator

*What the substrate is, why it will not hold still, and the eight laws restated as one thing.*

Supersedes the naming in `claude/axioms.md` and `claude/axiom-status.md` — those remain
correct in content; the rename map is in §10. Written 2026-08-21.

---

## 1. Why it will not hold still

The difficulty of pointing at this thing is not vagueness on our part. It is a property of
what we are pointing at.

Ask what the substrate *is* and the answer keeps sliding, because **substrate is not a kind of
thing. It is a relation.** X is substrate *for* Y. The same object is substrate seen from
above and object seen from below, and nothing is substrate simpliciter.

The kernel is substrate for a suite and an object to the browser. A suite is substrate for a
workspace and an object to the kernel. A workspace is substrate for a session and an object to
the suite. Below the browser: the OS, the machine, physics. Above the session: a person, a
practice, a culture. The stack does not terminate in either direction and we do not own either
end of it.

So asking "what is the substrate, really?" is asking for the **absolute value of a relative
quantity** — the same error as asking what velocity a body has, full stop. We already know
what to do with that question: it has no answer, not because we lack information, but because
the question helps itself to a frame that does not exist.

That dissolves the discomfort without cheapening it. The thing is hard to touch firmly because
firmness was never one of its properties.

---

## 2. A unit is a seam

If substrate is a relation, then the interesting object is not either side. It is **the
join**.

> **A unit's boundary is its object-face. Its interior is its substrate-face.**

The boundary faces up, toward whatever uses it. The interior faces down, toward whatever it is
made of. A unit is therefore not a thing sitting at a level — it is **the membrane between two
levels**, and that is exactly why it feels immaterial. A membrane has no volume. There is
nothing inside a node because a node is not a container; it is a surface with two sides.

This is the answer to "what is a node really," arrived at from the other direction than
before. Earlier: *a node is a boundary; what is behind it is not the node's business.* Now:
*a node is the seam where one level becomes another,* and the reason it has a boundary at all
is that a seam needs a face.

Everything else in the system follows from taking the seam seriously.

---

## 3. The two laws that make levels

There are exactly two constitutive laws, and they are not laws *about* things in the world.
They are the laws of nesting itself. That is why they cannot be stated inside the system —
any statement inside is made of units, and these say what a unit is.

**Law 1 — Boundary.** *There is a seam, and it has two faces.* A unit is a boundary and an
interior. Nothing reaches across except through the boundary.

**Law 2 — Closure.** *Seams stack without limit.* Any graph of units, given a boundary,
is a unit — usable anywhere any unit is usable, with no new construct.

Law 1 says levels exist. Law 2 says they can be made indefinitely. Together they are not two
facts about the world; they are **the generator of levels**, and everything the system can
ever contain is downstream of them.

Which explains a result we reached from the removal test and did not fully understand: only
two axioms turned out constitutive. Now it is obvious why. Exactly two facts are needed to
have nesting at all — *there is a seam*, and *seams compose*.

---

## 4. The world is the closure, and it can only be run

The generator is finite, statable, and fits on an index card. The world is everything the
generator produces, and it is unbounded.

The gap between them is not a gap in our knowledge. A closed generative system's product is
not compressible into a description of the system — if it were, you would not need to run it.
So there is no shortcut through a theory, and **generation remains the only proof**: the way
to establish that a structure obtains is to produce it.

This also fixes what "unbounded from minimal" means precisely. It is not a slogan. It is Law 2:
closure under composition *is* unbounded generativity, stated in algebra. Anything closed
under an operation has an infinite product from finite generators, and anything not closed
needs a fresh abstraction mechanism at every level — functions, then macros, then templates,
then modules, each a special case, each aging badly.

---

## 5. The eight laws, ordered by depth

Ordered from container outward: what makes levels, what makes them nameable, what the runtime
must guarantee, what the system can check about itself.

### The container — these make the levels

**1 · Boundary** — a unit is a boundary plus an interior; nothing reaches across except
through ports.
*Forbids:* privileged access.

**2 · Closure** — interiors are opaque or are graphs of units; any graph plus a boundary is a
unit.
*Forbids:* a third interior kind. Every macro, template, module, group, room feature.

### The keystone — this makes them nameable

**3 · Identity** — two things are the same thing exactly when they are built the same way.
Hashing represents the class; structural equality defines it.
*Forbids:* mutable identity; a handle whose insides change.
*Free consequence:* structural cycles become unbuildable — you would need a form's hash before
computing it. The store is a directed acyclic graph by construction, permanently.

### The floor — the runtime guarantees these; they are unreachable from inside

**4 · Authority** — the boundary carries ports (satisfiable by a wire) and powers (satisfiable
only by the runtime). No composite may bind a power.
*Forbids:* self-hosted security. A unit wired to a capability by another unit.

**5 · Novelty** — every value is a constant in a form, a function of other values, or emitted
by a source at a tick. Nothing else.
*Forbids:* ambient state — a clock read that is not a source, a fetch that is not declared.
*Buys:* exact replay.

**6 · Demand** — a unit runs when it is stale, alive, and either pure or explicitly triggered;
alive means observed, pinned, or upstream of something alive.
*Forbids:* uninvited computation; effects firing on their own.
*Split:* the liveness predicate is an ordinary computation over the graph. The act of running
is the runtime's.

### The ring — the system checks these about itself, as ordinary units

**7 · Frame** — ports carry a frame as well as a shape. Two ports connect if frames match or a
declared transition exists, and transitions must agree around any loop.
*Forbids:* untyped conversion; two routes silently disagreeing.
*Note:* disagreement around a loop is **curvature**, not incoherence — the same object that
shows up as force in physics. The canonical route is the semantics; a direct route is an
optimisation carrying an obligation to agree, falling back when it cannot.

**8 · Gauge** — presentation is not content. Geometry, z-order, colour, label, collapse state
are maps from identity to appearance and participate in nothing.
*Forbids:* position on a unit; layout in the graph.
*Buys:* one arrangement open in many views at once, and headless execution, from the same fact.

---

## 6. What unifies them

The eight are not a list. Read them again and every one is a statement about **what belongs at
the seam.**

| | says |
|---|---|
| Boundary | the seam exists and has two faces |
| Closure | seams repeat |
| Identity | the seam is named by its own content |
| Authority | the seam declares which powers cross it |
| Novelty | the seam declares where the world gets in |
| Demand | the seam declares when it runs |
| Frame | the seam declares what its values mean |
| Gauge | the seam excludes what does not matter |

Two make the seam. Five say what must be **on** it. One says what must be **off** it.

That is the whole framework in one sentence:

> **A good seam is one where the boundary tells you everything you need and the interior tells
> you nothing you need. The eight laws are the enumeration of what that requires.**

And it gives a much sharper test for a ninth law than any counting rule:

> **A candidate law must name something that must be declared at the seam, or excluded from
> it, and that none of the eight already covers.** If it cannot be stated that way, it is not
> a law — it is a feature, a convention, or a wish.

---

## 7. The framework inside its own world

The framework is itself an object, and it lives — partly — in the world it describes. That
nesting is real and it has a precise limit.

**What can be inside.** Any law that is a predicate over forms can be an ordinary unit. Frame
and Gauge are literally tests. Demand's liveness rule is a reachability fold. Authority's
"no composite binds a power" is a walk over a form. So the system can hold a working
description of most of its own law, and a health monitor is therefore a *pattern*, not a
feature.

This is arithmetization — statements about a system encoded as objects inside it. It is a
triumph rather than a paradox exactly because the encoding is declared. The Liar is the same
crossing left implicit.

**What cannot be inside.** Enforcement. If the law that constrains units were made of units, a
unit could be wired to influence it. So:

> The map of the territory may be in the territory. The map may not be the territory's law.

**What is not even expressible.** Boundary and Closure. Not because they are sacred, but
because any sentence in the system is made of units and these say what a unit is. They are not
above the system or below it; they are its condition.

**And one honest asymmetry.** Novelty is only half-checkable. You can verify that a leaf
*declares* no source power. You cannot verify its opaque code never calls the clock. Which
exposes the distinction the whole design has been using without naming it:

> **There are two ways to hold a rule: make violations detectable, or make them impossible.**

Novelty is not checked; it is made impossible — a pure unit's context has no clock, so the
call cannot be written. Identity and Authority are impossible in the same way. Frame and Gauge
are merely detectable. Prefer impossible. It is stronger and it is cheaper.

---

## 8. Two kinds of justification

The levels determine what kind of argument each law takes, which settles a great many disputes
before they start.

**Constitutive laws are justified by retorsion.** Denying them requires using them — any
argument against Boundary is itself a bounded thing with an interior. This is the shape of
Aristotle's defence of non-contradiction, and of the Church–Turing thesis: unfalsifiable,
never proved, universally relied on, warranted entirely by every attempt to get outside
landing back inside.

**Regulative laws are justified by consequence.** *Here is what breaks without it.* Empirical,
arguable, revisable, and stronger for being defended that way — Authority because ambient
authority is a security disaster, Novelty because replay is worth more than convenience, Gauge
because vantage is not content.

So Boundary and Closure are not more sacred than the rest. They take a **different kind of
argument**, and someone attacking them with consequences has proposed a sibling system rather
than raised an objection.

---

## 9. What this does not claim

It is not a foundation for reality, a theory of everything, or a bottom.

It is **a well-made seam at one place in a stack we do not own**, and its virtue is precisely
that it does not claim to be the floor. Below it: a browser, an operating system, a machine,
physics. Above it: suites, workspaces, people, practices. The laws describe what it takes for
*this* join to be clean. They say nothing about the joins above and below, and they should
not.

The axioms here are axioms for a machine, and their entire virtue is that each can be violated
by a program and the violation made to fail a test — which is not true of a metaphysics.
This does not prove the system works. It defines "works" precisely enough that running it can
show us.

A sibling system with Boundary and Closure and different regulative choices is a different
chart on the same space, and whether the two charts translate is the Frame question one level
up. That the structure recurs at the meta level is weak evidence it is real. Weak, not strong
— recursion is also what a good metaphor does.

---

## 10. Guards, and the rename map

**Three guards, in order of how easily they are lost.**

1. **The count never rises without something coming out.** Axiom systems invite completeness,
   and completeness is the failure mode. A system whose law count grows with its suite count
   has the wrong laws.
2. **For every law, name what the system becomes without it.** If you can name the resulting
   system, the law is negotiable. If you cannot finish the sentence, it is constitutive. Held
   loosely, "you cannot remove one without the rest collapsing" becomes armour against all
   revision.
3. **Structure points, detail refutes.** Every finding so far came from taking a prohibition
   seriously and going to look — not from any formalism. The build is the only place a
   violation shows up as something breaking rather than as something merely thought.

**Rename map** — old identifiers in the other documents resolve as:

| was | is |
|---|---|
| A1 | Law 3 · Identity |
| A2 | Law 1 · Boundary |
| A3 | Law 2 · Closure |
| A4 | Law 4 · Authority |
| A5 | Law 7 · Frame |
| A6 | Law 5 · Novelty |
| A7 | Law 6 · Demand |
| A8 | Law 8 · Gauge |

Findings keep their numbers. The ledger is `claude/core-findings.md`; the type signatures are
in `claude/axioms.md` §5; the removal analysis is `claude/axiom-status.md`.

---

## In one breath

> Substrate is a relation, not a kind, so the thing we are building has no absolute position —
> only a place in a stack that ends nowhere in either direction. What sits at that place is a
> seam: a boundary facing up toward whatever uses it, an interior facing down toward whatever
> it is made of. Two laws make seams and make them stack, and that is the whole generator;
> everything the world can contain is what those two produce. Five more laws say what must be
> declared at a seam — its name, its authority, its openings, its schedule, its meaning — and
> one says what must be kept off it. The framework can hold a description of itself but never
> its own enforcement, and it does not claim to be the bottom of anything. It claims to be one
> join, made cleanly, in a stack it did not build.
