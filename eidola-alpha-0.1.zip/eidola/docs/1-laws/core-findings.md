# Core findings ledger

Running record of core changes, in the format of SESSION_05aug Part IV. **Authoritative** —
supersedes the "core changes" sections in `claude/suite-closure.md` and `claude/core-spec.md`
where they disagree. Companion to `claude/axioms.md` (the formal statement). Each finding
arrives as *this is forbidden* → go look.

Last updated 2026-08-21.

---

## Open

| # | Principle applied | What it found | Status |
|---|---|---|---|
| 5 | Transitions must compose | Coercion registry doesn't check that two routes between shapes agree | **superseded by F3** — dissolved, not fixed |
| 6 | Reflection must be ordinary units | `menu.js` reads scheduler internals through a privileged channel | **open** |
| F1 | Acting requires a frame | `ctx.now()` is frameless. Closure needs per-object local oscillators against a master tick; runtime-as-process is the same hole | **open — real growth** |
| F5 | Memoisation requires stable keys | Memory reads must be **monoid homomorphisms** (`#count`, `#last`, `#sum`, `#max`); "median" is not, and forces full replay on every append | **open — characterised, design before F4** |
| F6 | Single truth per address | Multiple writers to one memory address interleave; ordering is scheduler-determined. Append-only makes it lossless, but a single-writer lint is wanted | **open — lint, not law** |
| F9 | First-order boundary is what makes effects static | map/fold over user-supplied units will be wanted (graphmap: "for each pinned region, apply this fold"). A port carrying a unit's **Id** gives it without closures; the cost is exactly pin-vs-follow — pinned keeps the boundary static, followed doesn't | **open — policy, not a new concept** |

## Resolved by composition (core did not grow)

### F2 — Layout stacking is free
Twelve motifs in one screen rectangle = twelve panes with identical rects in `LayoutStore`
plus z-order and a selector. `serializeGraph()` unchanged. Drill-to-fullscreen,
zoom-out-to-architecture, collapse, tab-between-layers — all "which rect is the viewport."

> **The entire navigation UI is free of the graph.**

*The one leak, already plugged:* visibility gates liveness (`live ← observed ∨ pinned ∨ …`),
so hiding a motif would silence it. `pinned` resolves it.

> **Visibility is gauge. Participation is semantic. They are independent — which no timeline
> tool can offer.**

*Precision to hold:* **stacking is gauge, collapsing is semantic.** Visually similar,
structurally opposite — collapse introduces a container, so the graph changes. The
byte-identical test distinguishes them instantly. Keep them visually distinct.

### F3 — Transforming edges are pipelines, and they delete the coercion registry
Not `A → B` with params on the wire. **`A → ab1 → ab2 → ab3 → B`**, each `ab` an ordinary
node, the chain collapsible into one macro via existing container + expose.

- No wire gains a field. No scheduler magic. No implicit insertion.
- **An "edge inspector" is a collapsed container rendered as a line.** Click → expand → inside
  a subgraph. Same affordance as descending into a recursive closure: one interaction, not two.
- Unix precedent exact: `a | b | c` saved as a shell function, usable anywhere a command is.

**The deletion.** A coercion is a node with declared input/output shapes. Therefore
"does a conversion X→Y exist?" = **a path search over port frames in the store** — the
registry becomes an index, not a mechanism. Finding #5 becomes an ordinary assertion between
two ordinary computations: `pathA(fixture) === pathB(fixture)`.

*Cost to watch:* an extra node per transformed edge. Irrelevant at music scale; graphmap wants
value-identity hashing (already listed), and most edges carry no transform.

### F7 — Structural cycles are impossible for free
**Content addressing (A1) means you cannot build a form containing itself** — you would need
its hash before computing it. The store is a DAG *by construction*. No cycle detection is ever
needed at that level.

### F8 — A cycle is legal iff it contains a delay *(supersedes "reject cycles at wire time")*
The naive rule would have made Closure impossible — a closed traversal is the point.
The correct rule is the synchronous-dataflow one (Lustre `pre`, Esterel, Signal):

> **A dataflow cycle is legal iff at least one edge in it is a delay.**

Checkable at wire time. Permits Closure's loops. Forbids the ill-founded ones. And a delay is
already in the vocabulary — it is `mem:r` reading last tick's value. Nothing new.

**This is the decision about computational power, not a detail:**
- cycles forbidden → DAG evaluation → every graph provably terminates → Closure impossible
- cycles with delay → **Turing-complete** → non-termination possible, no static halting guarantee

Choose the second *knowingly*. Mitigation already on the list: kill a runaway script
mid-compute, UI never blocks.

**Three self-references, three rules — do not conflate:**
| Kind | Rule |
|---|---|
| structural (composite in composite) | free and safe — F7 |
| dataflow (A→B→A) | legal iff delayed — F8 |
| reflection (system observes itself) | enforcement is the floor, reflection is the ring |

## Resolved by reuse (core grows by reusing an existing mechanism)

### F4 — Memory is a declared capability, not a node class
**Not** a fifth class, **not** state-in-the-fingerprint. Memory joins capabilities and secrets:
declared by name on the boundary, resolved by the runtime *only at cook time*, never ambient.

```
powers: [ {k:'mem', name:'motif.M3', mode:'r', fold:'count'}
        , {k:'mem', name:'motif.M3', mode:'rw'} ]
```

A node declaring `mem:r` **is still pure** — a pure function of (inputs, memory-at-X). The
purity rule forbids *ambient* clock and network; a value arriving through a declared port was
never what was forbidden.

**Append-only; current state is a fold over the log.** Replay works by construction; multiple
writers interleave rather than clobber; "Generation 8" is the eighth entry; the graph tier
stores *initial* state + tick count while running state is cache-tier and rebuilds
deterministically (an hour-old evolving piece still saves as a few KB); inspection is a query.

> **Node memory is Hermione's Ledger scoped to a computation.** Same primitive, two scopes.

**The payoff:** memory has an address, so anything can read it. Closure — the coherence panel
folds every motif's generation log. Homepage — the unread count has a *history*, a week-long
sparkline, free. graphmap — a watch's observations are a timeline pane.

> **Every stateful thing automatically has a history you can plot** — because memory is a log,
> not a variable.

## Enforcement floor (additions)

- **The core has no audio clock**, alongside "the core has no DOM." Web Audio needs
  sample-accurate scheduling ~100ms ahead of wall clock; a demand-driven memoised scheduler
  cannot and must not. The graph emits a *schedule*; Tone.js owns the fast clock.
- **No composite may bind a power** (A4). This is what makes security non-self-hosting.

---

## The gate taxonomy

The "world with gated flow" framing, made mechanical. A4 + A6 together *are* the gates.

| | Gate | Power |
|---|---|---|
| **in** | world → system | `source` |
| | environment → system | `names` |
| | store → system | `mem:r` |
| **out** | system → world (triggered, irreversible) | `effect` |
| | system → store (journaled, replayable) | `mem:w` |
| **not a gate** | system → a viewer | *render* — a fold, A8 territory |

**Rendering is not an exit, it is a view.** Which is why MIDI export, the audio schedule, the
coherence heatmap and graphmap's report are all the same operation, while *saving the MIDI to
disk* is a separate `fs:write` effect. The projection and the writing are different acts;
only the second is a door.

**What this buys:**

> The complete boundary of a program is computable by **reading its forms** — no execution, no
> dynamic analysis. Most languages cannot say what a program will touch without running it.

---

## Scoreboard

| Push | Outcome |
|---|---|
| Transforming edges | **core doesn't move** — composition + a lens; registry deleted |
| Node memory | **core reuses** — a capability, like secrets |
| Frame-relative time | **core grows** — genuinely open (F1) |
| Audio clock | **core refuses** — the boundary is real |
| Cycles | **core narrows** — legal iff delayed; Turing-completeness chosen knowingly |

---

## Rules refined by these passes

**On growth** (was: *did this need the core to grow?*):
> Growth isn't failure. **Growth only one suite needs is failure.**

**On method** — the companion to the invariant test:
> *Does this force the pane to own something?* → then: **"Which existing mechanism is this already?"**
>
> Both wins came from finding an existing mechanism with the right shape rather than adding
> one. Pipes were already containers. Memory was already secrets.

**On axiomatisation** — the guard this framing needs:
> **Track the axiom count. It must never go up without something else coming out.**
>
> Eight is good; nine is worse *unless it deletes a mechanism*. Axioms are cheap to add and
> expensive to remove, and axiom systems invite completeness — which is the failure mode. A
> system whose axiom count grows with its suite count has the wrong axioms.

---

## Prior art to read before building (ranked by time saved)

- **Unison** — content-addressed code as primary storage, hashes as names, codebase-as-database.
  A1 built for real, with years of answers on naming, versioning and refactoring under content
  addressing. **Read first; you will hit every problem they hit.**
- **Algebraic effects & handlers** (Plotkin & Pretnar) — the theory of gated flow in and out of
  a pure core. The power system is this.
- **Object-capability model** (Mark Miller) — authority as unforgeable reference, no ambient
  authority. A4, with the security arguments already made.
- **Lustre / Esterel / Signal** — synchronous dataflow: delay-in-every-cycle (F8), clocks as
  first-class (F1), provably schedulable graphs.
- **Self-adjusting computation** (Acar) / **Adapton** — demand-driven memoised recomputation
  with change propagation. A7, with the performance work done.
- **Interaction nets** (Lafont) — agents with ports and local rewriting; closest structural
  cousin to boundary-plus-wires.
- **Nix** — content-addressed derivations; a working answer to what a form means when it
  references other forms.

---

## What the thing is, in one paragraph

> A capability-gated dataflow substrate whose forms are their own names. Externally: a closed
> universe with every door declared, so the complete boundary of any program is computable by
> reading it. Internally: two interior kinds, one composition law, and cycles permitted only
> through a delay — enough to be unbounded, little enough to be replayed exactly. Presentation
> is separated from content by construction, so the same world can be looked at from any number
> of vantages without any of them changing what it is. It is not a language you write and not a
> database you query; it is an algebra of processes with a declared boundary, and the novel part
> is not any single commitment but that identity-is-content, boundary-declares-everything, and
> presentation-is-not-content hold at the same time.
