# The core, axiomatised

Formal statement of the kernel before implementation. Companion to `claude/core-spec.md`
(prose) and `claude/core-findings.md` (ledger). Written 2026-08-21.

---

## 0. What a node is

A node is **not** a computation.

> **A node is a boundary. What is behind it is not the node's business.**

("What we perceive isn't objects but object *interfaces*" — SESSION_05aug. The answer was
already there, filed under perception.)

So "a node is everything and nothing" is a **theorem, not a worry**: a boundary is
content-free by construction, and anything that presents ports can be one. It is not vacuous
because it forbids three things:

- you cannot reach inside a unit except through its ports
- you cannot satisfy a *power* from inside a composite
- you cannot make presentation into content

*Method note:* this structure has categorical shape (composition, identity, partiality). It
is deliberately **not** grounded in category theory — per the August correction on
smuggling, handing over a downstream formalism as the neutral tool for reaching upstream is
the error itself. The structure is prior to any notation for it.

---

## 1. Signature

Three undefined terms:

- **Form** — a finite structure; anything serializable.
- **Shape** — what a port accepts.
- **Frame** — the vantage a shape's values are stated from (CRS, tick-rate, unit, encoding).

Everything else is defined.

---

## 2. Axioms

Each as *formal · plain · forbids · manifestation*.

### A1 — Identity is content
`x ≡ y ⟺ form(x) = form(y)` structurally. `Id = H(form)` **represents** the class; it does
not define it.
*Plain:* two things are the same thing exactly when they are built the same way.
*Forbids:* "same object, different content." Mutable identity. Persistent handles whose
insides change.
*Manifestation:* content addressing. Hash collisions are an implementation risk, never a
semantic one.

### A2 — Everything is a unit; a unit is a boundary plus an interior
`Unit = (Boundary, Interior)`, `Boundary = (in:[Port], out:[Port], powers:[Power])`
*Plain:* a thing is what it exposes plus what is behind it.
*Forbids:* privileged access — no path to an interior except through `in`/`out`.
*Manifestation:* one envelope, one serializer, one validator, one generated editor.

### A3 — Interiors are exactly two kinds; composites are closed
`Interior = Leaf(opaque) | Composite(Graph)`, `Graph = (units, wires, expose)`
**Closure law:** for any Graph G and exposure e, `(β, Composite(G))` is a Unit.
*Plain:* a thing is either given from outside or made of things; wrapping things gives a thing.
*Forbids:* a third kind. Every macro / template / module / group / room feature is refused here.
*Manifestation:* one container implementation; no group feature, ever.
**This is the strong axiom — push every future request at it.**

### A4 — Boundary splits into ports and powers; only the runtime satisfies powers
`ports` are satisfiable from inside a composite (by a wire). `powers` are satisfiable **only**
by the runtime. **No composite may bind a power.**
*Plain:* what a thing takes as data can come from neighbours; what it is *allowed to do* can
only come from above.
*Forbids:* self-hosted security — a node cannot be wired to a capability by another node.
*Manifestation:* the enforcement floor, formalised. `net`, `fs:write`, `secret:X`, `mem:rw:Y`,
`source`, `effect`, `pinned`, `names` are powers. A power absent from the boundary is simply
not a property on `ctx`.

### A5 — Ports carry frames; frames form an atlas
Two ports connect iff `shape` matches **and** (`frame` equal **or** a declared transition
`τ: F₁→F₂` exists). Transitions satisfy the **cocycle condition**: any two routes between the
same frames agree, `τ₂∘τ₁ = τ₃`.
*Plain:* a number means nothing until you say from where; conversions must agree whichever
way round you go.
*Forbids:* untyped conversion; two routes silently disagreeing.
*Manifestation:* finding #5 is not a registry check — it is the cocycle condition on an atlas.
Charts = frames, transition maps = coercions, and **disagreement is curvature, not
incoherence** (August sharpening, arriving as a type-system law). EPSG is a worked atlas;
tick-rate is another.

### A6 — Novelty enters only at sources
Every value is exactly one of: a constant in some form · `f(v₁…vₙ)` for a world-power-free
Leaf · emitted by a `source`-holding unit at tick `t`.
*Plain:* nothing appears from nowhere except at declared doors.
*Forbids:* ambient state — a clock read that isn't a source, a fetch that isn't declared.
*Manifestation:* **replay.** Record source emissions, re-run, get a bit-identical valuation.

### A7 — Evaluation is demand-driven over the live set
`live = closure↑(observed ∪ pinned)`; `cook(u) ⟺ dirty(u) ∧ u∈live ∧ (pure(u) ∨ triggered(u))`
*Plain:* things run because someone wants the answer, not because they exist.
*Forbids:* uninvited background work; effects firing on their own.
*Manifestation:* the viewport is a garbage collector for computation. `pinned` is the declared
exception, hence a power (A4) rather than a flag.

### A8 — Gauge: presentation is not content
There exist maps `L: Id → Presentation` (geometry, z-order, colour, label, collapse state)
such that `form(u)` is invariant under any change to `L`.
*Plain:* where you put it cannot change what it is.
*Forbids:* position on the unit; layout in the graph; any presentation state in identity.
*Manifestation:* `serializeGraph()` byte-identical after a move. Enables multi-view, headless,
and twelve-motifs-in-one-rectangle simultaneously.

---

## 3. Everything else is derived

| Thing | Is | Note |
|---|---|---|
| Constant | Leaf, `in=[]`, no powers | |
| Config | constants wired to inputs | not a special field |
| **Pane** | Composite: one child + constants + identity exposure | |
| Pattern | Composite | same thing, bigger |
| Wire | an entry in `Graph.wires` — **content, not a unit** | relations are content; not all content is a unit |
| Pipeline edge | a wire replaced by a chain of units, optionally wrapped | wrapping is A3 |
| Coercion | a Leaf implementing a transition τ | registry → **path search over port frames** |
| Memory | a `mem:rw:X` power; the store behind it is a log | |
| Secret | a `secret:X` power | already exactly this |
| Container / super-pane | Composite | already exactly this |
| Layout, collapse, stacking | `L` | A8 |
| Audio clock | outside; the graph emits a *schedule* | enforcement, like the DOM |

### Two fields that become consequences

**`stateKey` disappears.** It is a parameter of the `mem` power → on the boundary → in the
content. Therefore two panes with the same node, config and state scope **hash to the same Id
— they are one unit appearing twice in `L`.** Different scope → different boundary →
different unit.

> Instance-vs-reference is not a column. It is A1 and A8 together.

**Pin-vs-follow, stated sharply.** A hash reference puts the target *in the form*. A name
reference resolves against the index at cook time — hence a power (`names`) — and the
*resolved* Id enters the memo key while the form stays stable.

> **Pin puts the reference in the form. Follow puts it in the environment.**

---

## 4. Theorems to prove (as tests)

**T1 — Closure.** For any Graph G and exposure e, the wrapped unit is usable anywhere a Leaf
is usable, and `expose` composes.
*Test:* three levels deep, innermost port wired to outermost, value flows. **Have it.**

**T2 — Replay.** Given (form, initial memory, recorded source emissions), evaluation is a
function; bit-identical valuation.
*Test:* run, journal, clear all derived state, replay, compare. **Don't have it — highest
value test in the system**, because it catches every accidental ambient dependency at once.

**Corollary (settles the open memory question).** Memory is an append-only log — a free
monoid over entries. For memoisation to survive, a memory *read* must be a **monoid
homomorphism** into the value: `#count`, `#last`, `#sum`, `#max` qualify; "median" does not.

> A memory read must be a fold updatable incrementally. Formally: a monoid homomorphism.
> Anything else forces full replay on every append and silently kills the cache.

---

## 5. The manifestation

```ts
type Id      = string                    // H(form) — representation of A1
type Frame   = string                    // "EPSG:4326" | "tick:master" | "utc" | ...
type Port    = { name: string; shape: string; frame: Frame }
type Power   =
  | { k:'net' } | { k:'fs', mode:'r'|'rw' }
  | { k:'secret', name:string }
  | { k:'mem', name:string, mode:'r'|'rw', fold?:string }   // fold must be a monoid hom
  | { k:'source', period?:number } | { k:'effect' }
  | { k:'pinned' } | { k:'names' }

type Boundary = { in: Port[]; out: Port[]; powers: Power[] }

type Ref      = { pin: Id } | { follow: string }            // A1 vs environment
type Graph    = {
  units:  Record<string, Ref>
  wires:  Array<[[string,string],[string,string]]>
  expose: { in: Record<string,[string,string]>
          , out: Record<string,[string,string]> }
}

type Interior = { leaf: string } | { composite: Graph }
type Unit     = { boundary: Boundary; interior: Interior }

// A8 — deliberately not part of Unit, deliberately not hashed
type Layout   = Record<Id, {x:number;y:number;w:number;h:number;z:number;collapsed:boolean}>
```

Nine types. Scheduler = A7. Host = A4. Persistence port holds forms and logs.

**Not present:** no Pane type, no Pattern type, no Wire type, no class enum, no `stateKey`,
no `parent`, no `residency`, no `view` hint. All derived or gauge.

---

## 6. Honest scope

These are axioms for a machine, not for reality. Their virtue is that they are **checkable** —
each can be violated by a program and the violation made to fail a test, which is not true of
a metaphysics. This does not prove the system works; it defines "works" precisely enough that
running it can show you.

**Generation is still the proof.**

The limit to watch: **A3's claim that two interior kinds suffice is the strong one.** Push
every future feature request at it. Closure pushed and it held.
