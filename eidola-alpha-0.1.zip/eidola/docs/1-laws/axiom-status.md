# Which axioms can be removed, and where each one lives

Companion to `claude/axioms.md`. Two questions: which of the eight are constitutive (remove →
nothing) vs regulative (remove → weaker but coherent), and at which level each is enforced.
Written 2026-08-21.

---

## 1. The conjecture, sharpened

Two kinds of axiom system:

> **Descriptive** systems chase a domain that exists independently of them, so they need
> schemas and never finish.
> **Generative** systems create their domain, so they finish exactly when they close.

ZFC is descriptive and *literally* infinite: Separation and Replacement are **schemas** — one
axiom per formula; ZFC is not finitely axiomatisable. (NBG is, and is conservative over it, so
the infinitude is partly formulation.) Tarski goes further: true arithmetic is not
axiomatisable by *any* recursive set. The domain outruns every finite description.

Generative systems have a dichotomy that proves "cannot grow without ceasing to be itself"
exactly. If generators `G` produce closure `C(G)`, adding `g'`:

- `g' ∈ C(G)` → nothing changes; it was a theorem wearing an axiom's clothes
- `g' ∉ C(G)` → `C(G ∪ {g'}) ⊋ C(G)`; a strictly different universe

> **There is no small extension of a closed generative system.** Every real addition is a
> total replacement.

Same argument as SESSION_05aug on uniqueness. *Type two:* lambda calculus, SK combinators.
*Type one:* group axioms (drop associativity → quasigroups, a healthy field).

**Refinement that makes it usable:** most real systems are mixed (Peano — zero and successor
load-bearing, induction droppable → Robinson arithmetic). The split is Searle's
**constitutive vs regulative**: constitutive rules *create* the activity (chess's rules make
chess exist); regulative rules govern something that would exist anyway.

> The question is not which kind of system you have, but **which of your axioms are which**.

---

## 2. The removal test

*Remove it. Can you name what the system becomes? If yes → regulative. If you cannot form a
coherent sentence → constitutive.*

| | Remove it and you get | Kind |
|---|---|---|
| **A2** unit = boundary + interior | *nothing* — every other axiom refers to units | **constitutive** |
| **A3** two interiors, closure | no composition; "unbounded from minimal" dies; or a third kind, then a fourth | **constitutive** |
| **A1** identity is content | a working system with UUIDs — but F7 dies (cycles buildable), memoisation needs a new key, instance-vs-ref returns as a field | **load-bearing, not constitutive** |
| **A4** ports vs powers | a system that computes fine and is unsafe | regulative |
| **A5** frames + cocycle | shape-only matching; routes silently disagree | regulative |
| **A6** novelty only at sources | ambient effects; replay dies | regulative |
| **A7** demand-driven over live | eager evaluation; correct, wasteful | regulative |
| **A8** gauge | position becomes content; multi-view and headless die | regulative |

**Two constitutive · one load-bearing · five regulative.**

> **A2 + A3 is the mathematics. A1 is the engineering keystone. A4–A8 are the house style.**

A system with A2+A3 and different regulative choices is not a competitor to refute — it is a
**sibling**, a different chart on the same space. (The August atlas, one level up: constitutive
core = the space, regulative choices = charts, graph-translation = transition maps, and whether
those compose is A5's cocycle condition again.)

---

## 3. Three levels, not two

**Container** (constitutive: A2, A3). Not stated *in* the system — the system is made of them.
You cannot express "a unit is a boundary plus an interior" using units. Not viciously circular;
constitutively circular, like a definition of "rule" that must itself be a rule.

**Floor** (enforcement). Regulative axioms whose violation is made **impossible** by the
runtime. Unreachable from inside by design.

**Ring** (reflection). Regulative axioms stated as **ordinary units** — predicates over forms,
running as patterns.

> Every regulative axiom is **expressible** from within. Not every one is **enforceable** from
> within. (Arithmetization: statements about the system encoded inside it are fine; deciding
> their truth from inside is not.)

### The test this implies

> **A regulative axiom you cannot state in the system's own terms is not an axiom. It's a wish.**

Running it: A5 ✓ (`pathA(fix) === pathB(fix)`) · A8 ✓ (`serialize(g) === serialize(move(g))`) ·
A7 ✓ (liveness is a reachability fold; the *act* of cooking isn't) · A4 ✓ (walk the form,
assert no composite binds a power) · **A6 ✗ only half** — you can check that a leaf *declares*
no source power; you cannot check its opaque code doesn't call `Date.now()`.

That half-failure exposes the distinction the whole design has been using unnamed:

> **Two ways to enforce a rule: make violations detectable, or make them impossible.**

A6 isn't checked — it's made impossible: a `pure` node's `ctx` has no clock, so the call cannot
be written. Stronger and cheaper than any predicate.

### Where each axiom lives

| | Enforcement mode | Level |
|---|---|---|
| A2, A3 | *is* the container | container |
| A1 | impossible — cannot hash a form containing its own hash | floor |
| A4 | impossible — powers aren't wireable | floor |
| A6 | impossible — the property isn't on `ctx` | floor |
| A7 | policy is a unit; cooking is the runtime | **both** |
| A5 | detectable by test | ring |
| A8 | detectable by test | ring |

**Design rule:** when adding a rule, first ask whether violations can be made
*unrepresentable*. Fall back to testing only when they can't. Three of five regulative axioms
already clear that bar.

---

## 4. Consequence: a better resolution for A5 / finding #5

A5 currently sits in the *detectable* column. It can be moved to *impossible*:

> **Pick a spanning tree over the frame graph. All conversions go through it. Two routes cannot
> disagree because there is only one route.**

(How unit systems work — everything converts through SI.) Cost: a spanning tree can force a
lossy intermediate (JSON→CSV→table where JSON→table was direct and better).

The version that keeps both:

> **The canonical route is the semantics. Every direct route is an optimisation that must be
> proven equal to it, and falls back to canonical if it isn't.**

Exactly the shape of memoisation — the fast path carries an obligation to agree with the slow
path. Finding #5 stops being "a bug you might discover at month three" and becomes "a shortcut
that failed its obligation," with a defined fallback. **Supersedes the plain route-agreement
test in `core-findings.md` F3.**

---

## 5. Two axioms, two kinds of argument

> **Constitutive axioms are justified by retorsion** — denying them requires using them. Any
> argument against A2 is itself a boundary with an interior.
>
> **Regulative axioms are justified by consequence** — *here is what breaks without it.*
> Empirical, arguable, revisable.

A2 and A3 aren't more sacred than A4–A8; they take a **different kind of argument**. Someone
attacking them with consequence-reasoning ("what if we allowed a third interior kind?") has
made a category error — that's a proposal for a sibling system, not an objection to this one.
Someone attacking A5 with consequences is doing exactly the right thing.

---

## 6. The failure mode to guard against

Held loosely, *"you can't remove one without the others becoming incoherent"* is unfalsifiable
and becomes **armour**: every change is refused as "that would make it a different thing," and
the system stops being revisable while feeling principled.

**The discipline:** for every axiom, write down what the system becomes without it, **and name
that system.** If you can name it, it's negotiable. If you cannot finish the sentence, it's
constitutive. Run this whenever tempted to add a ninth; with the count rule (*the number never
goes up without something coming out*), that is a real guard rather than a feeling.

---

## 7. Corollary: permanence through flow

An object sustained by flow rather than storage is a **dissipative structure** — flame,
whirlpool, standing wave; it persists by continuous regeneration. Here: a `pinned` unit with
memory, oscillating, its current form stored nowhere as a static thing.

Dissipative structures are normally lossy — stop the water and the whirlpool is gone. A6
journals every input that produced it, so:

> **Exactly reconstructible dissipative structures.** Stop the flow, restart, replay the
> journal — the same whirlpool returns, not a similar one.

Two kinds of persistence, **static** (store, memo) and **dynamic** (a pinned oscillating unit),
with A6 as the bridge that makes the second as trustworthy as the first. This is why Closure
saves a piece at Generation 8 as a few kilobytes rather than a dump of accumulated state.
