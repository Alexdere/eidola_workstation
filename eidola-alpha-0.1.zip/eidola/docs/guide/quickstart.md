# Quickstart

## 1 · Open it (nothing to install)

Open `head/dist/eidola-base.html` in a browser. Type `tour` for a walk through, `view inspect` to
see every pane and wire with its hash, and `dump` to get the workspace as a `workspace/1` file.

## 2 · Check and run a workspace from the command line (Python 3.9+, nothing to install)

    python3 cli/eidola.py check examples/running-total/workspace.json
    python3 cli/eidola.py run   examples/running-total/workspace.json --log examples/running-total/log.json --values

`check` tells you whether the workspace is well-formed and, for every composite, what its boundary
does not show: the powers inside it, whether it is pure, and which inputs reach which outputs within
one tick (which decides whether it can sit inside a loop).

A log is a list of ticks: `{"observed": [occurrences you are watching], "journal": {"occ#out": value}}`.
Nothing runs unless something downstream is observed or pinned (Law 6).

## 3 · Replay

    python3 cli/eidola.py run    WS.json --log LOG.json --save run.json
    python3 cli/eidola.py replay WS.json --log LOG.json --expect run.json

Same form, same journal → the same sigma at every tick (Law 5). Only the sources' emissions are
recorded.

## 4 · Export to plain code

    python3 cli/eidola.py export WS.json --observe total -o step.py
    python3 -c "import runpy; m = runpy.run_path('step.py'); step, log = m['make'](); print(step({'reading#out': 3.0}))"

The output has no Eidola runtime: no store, no hashing, no memo table. It is fixed to the observed
set you chose. `prim/1` bodies and the conformance frame atlas only, for now (`export/README.md`).

## 5 · Develop the kernel

    ./setup.sh            # npm ci in core/ and head/, plus a Chromium for the browser checks
    ./check.sh            # everything: types, 72 core claims, frozen vectors, oracle, base in a browser,
                          # differential + metamorphic grading, export, CLI

Set `PW_CHROME=/path/to/chrome` if a Chromium is already installed. Use `SPEC_REGEN=1 ./check.sh`
only for a deliberate spec change.

## Rules for the alpha

- Run code you wrote or reviewed: `host/1` bodies are not sandboxed yet (ADR-0008).
- Import `@eidola/core`, not `@eidola/core/internal`, if you want to survive the next release.
- Formats are versioned; ids do not move silently.
