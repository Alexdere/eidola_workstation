# ADR-0001 · Identity includes occurrence names

**Status:** Decided (alpha-0.1)

## Context
Unit ids hash occurrence names (pane keys). Law 3's prose ("two people who build the same structure
build the same unit") describes a coarser identity: the orbit under renaming occurrences. The two
differ exactly by the renaming group, and names are semantic anyway — memory scope paths use them.

## Decision
Keep labelled identity for `unit/1`. Change the prose to "built the same way, with the same
names". Canonical naming (hash a canonical labelling) is a possible `unit/2`, shipped with a
migration.

## Consequences
Ids stay stable for everyone who already has units. Structural comparison across authors is a
tool (fingerprints, docs/5-foundations §6), not identity.
