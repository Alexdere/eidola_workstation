# ADR-0009 · License

**Status:** OPEN — owner's decision

## Context
The tree carries no license. Without one, nobody else may legally use, copy or modify it, which
makes an *open* alpha impossible.

## Decision
Not decided here. Common choices for an open core + spec: Apache-2.0 (patent grant) or MIT for
code; CC-BY-4.0 for spec text. The company/foundation split (docs/5-foundations) may want the
spec and core permissive and suites free to differ.

## Consequences
Pick one, add LICENSE at the root, and add a `license` field to every package.json.
