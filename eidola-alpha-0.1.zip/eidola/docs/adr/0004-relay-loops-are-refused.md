# ADR-0004 · Relay-only loops are cycles without a delay

**Status:** Done (alpha-0.1)

## Context
Rule 6 says the graph with delays removed is acyclic. A loop made only of container
pass-through wires (no leaf on it) was accepted unless a leaf read it, and then refused only by a
4096-hop guard.

## Decision
Both flattens walk feeder wires back from every endpoint and refuse a closed walk with
"cycle without a delay: relay loop through …".

## Consequences
Rule 6 holds as written. The seam-matrix check (cli `check`) and the cores now agree on every
workspace.
