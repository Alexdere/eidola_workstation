# Decision records

One file per decision that is hard to reverse. Content ids are permanent, so anything that
changes a hash, a sigma, or what a workspace may contain gets a record here first.

| # | decision | status |
|---|---|---|
| [0001](0001-identity-includes-occurrence-names.md) | Identity includes occurrence names | Decided (alpha-0.1) |
| [0002](0002-pinned-flag-or-power.md) | `pinned`: content or runtime request | OPEN — decide before 0.1 is tagged |
| [0003](0003-canonical-pass-order.md) | Passes walk sites in canonical path order | Done (alpha-0.1) |
| [0004](0004-relay-loops-are-refused.md) | Relay-only loops are cycles without a delay | Done (alpha-0.1) |
| [0005](0005-law7-by-loop-obligations.md) | Law 7 checked by loop obligations | Done, additive (alpha-0.1) |
| [0006](0006-public-name-and-api.md) | Public name and API surface | Done (alpha-0.1) |
| [0007](0007-frozen-vectors-and-metamorphic-grading.md) | Frozen vectors, metamorphic grading | Done (alpha-0.1) |
| [0008](0008-alpha-code-policy.md) | Alpha code policy: run your own code | Decided (alpha-0.1) |
| [0009](0009-license.md) | License | OPEN — owner's decision |
