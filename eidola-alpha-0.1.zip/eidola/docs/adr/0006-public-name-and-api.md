# ADR-0006 · Public name and API surface

**Status:** Done (alpha-0.1)

## Context
Packages were `@graphmap/*` and `core/src/index.ts` re-exported every module.

## Decision
Packages are `@eidola/core` and `@eidola/base`. `core/src/public.ts` is the alpha API (42
exports, package entry "."); everything else is "@eidola/core/internal", which the base uses
today and may change between alpha releases.

## Consequences
Suites written against the public entry are insulated from internal churn. The SDK is still
extracted when the second suite lands.
