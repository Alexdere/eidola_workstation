# ADR-0008 · Alpha code policy: run your own code

**Status:** Decided (alpha-0.1)

## Context
`JsHost` runs `host/1` bodies with `new Function` in the page. Novelty (Law 5) and Authority
(Law 4) for those bodies are convention, not construction.

## Decision
Alpha users run code they wrote or reviewed. No shared-library execution of others' host bodies
until a worker/iframe host exists (hosts/worker/README.md). `prim/1` bodies are safe everywhere.

## Consequences
Every execution theorem in formal-foundations is conditional on this policy until the worker
host lands.
