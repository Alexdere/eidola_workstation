# ADR-0003 · Passes walk sites in canonical path order

**Status:** Done (alpha-0.1)

## Context
Passes 0, A and C iterated sites in insertion order. With two delays sharing one memory
address, append order is observable, so two workspaces with the same graph hash ticked to
different sigma (research/probes/order_probe.py; grade/metamorphic.py found 10 violations in 300
scenarios on both cores).

## Decision
Both cores walk sites sorted by path in every pass. Paths are ASCII, so JavaScript and Python
sort identically.

## Consequences
One hash, one sigma. Golden vectors unchanged. Renaming an occurrence can still change append
order — consistent with ADR-0001. A lint for non-commutative reads on shared addresses (F6,
formal-foundations Thm 13c) remains a good idea.
