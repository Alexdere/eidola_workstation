# ADR-0005 · Law 7 checked by loop obligations

**Status:** Done, additive (alpha-0.1)

## Context
`checkRouteAgreement` compares simple routes of length ≤ 4 between distinct frames. It misses
round trips, hub-shaped atlases and long rings, and its cost explodes on large atlases.

## Decision
Add `checkLoops()` / `check_loops()`: from each frame as an entry, one obligation per
transition outside a breadth-first tree. Complete for invertible transitions, exact on reachable
values for lossy ones (formal-foundations Thm 8, 11). The old check stays.

## Consequences
Neither check runs automatically yet: the kernel holds no atlas. `eidola check` runs both on
the conformance atlas; suites should call `checkLoops` when they build theirs.
