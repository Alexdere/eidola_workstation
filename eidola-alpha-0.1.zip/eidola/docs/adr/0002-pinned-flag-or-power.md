# ADR-0002 · `pinned`: content or runtime request

**Status:** OPEN — decide before 0.1 is tagged

## Context
`pinned` is stored on the pane, so pinning moves the hash. The laws call it a power (Law 4);
the build stores it as a flag (STATUS, "built but soft").

## Decision
Recommendation: keep it as content for `pane/1` (a pin is a declaration that this binding has a
reason to live, CORE-FORMAT §1), and say so in Law 6's text. A runtime-only pin can be a separate,
unhashed request later.

## Consequences
If this changes after 0.1, every pinned pane changes id: decide before tagging.
