# ADR-0007 · Frozen vectors, metamorphic grading

**Status:** Done (alpha-0.1)

## Context
`check.sh` regenerated `spec/vectors` from the TS core on every run, so the vectors tracked the
core instead of constraining it.

## Decision
`check.sh` regenerates into a scratch copy and fails if anything differs, unless
`SPEC_REGEN=1` (a deliberate spec change that needs review). `grade/metamorphic.py` applies every
transformation the laws call invisible (pane order, wire order, unit order) and requires identical
hashes, sigma and effects from both cores.

## Consequences
A third-party core is conformant if it reproduces the frozen vectors and passes both graders.
