#!/usr/bin/env bash
# Everything, in the order that makes a failure legible: types, the core's own claims,
# the oracle's own claims, static conformance, the heads in a real browser, then
# differential grading. Needs: node ≥ 18 (+ `npm ci` in core/ and head/, and
# `npx playwright install chromium` once, in head/), python3 ≥ 3.9. No Python packages.
set -euo pipefail
cd "$(dirname "$0")"

echo "=== core: typecheck ==="
(cd core && npx tsc --noEmit -p tsconfig.json)

echo "=== core: falsification suite ==="
(cd core && npx vitest run 2>&1 | tail -5)

echo "=== spec: the frozen vectors still hold (ADR-0007) ==="
frozen="$(mktemp -d)"; cp -r spec/vectors "$frozen/"
(cd core && npx tsx tools/gen-vectors.ts)
if ! diff -rq "$frozen/vectors" spec/vectors >/dev/null; then
  if [ "${SPEC_REGEN:-}" = "1" ]; then
    echo "vectors regenerated (SPEC_REGEN=1): review the diff and bump the spec version"
  else
    cp -r "$frozen/vectors/." spec/vectors/
    echo "FAIL: the core no longer reproduces spec/vectors (set SPEC_REGEN=1 for a deliberate change)"
    exit 1
  fi
fi

echo "=== oracle: its own claims ==="
(cd oracle && python3 test_oracle.py)

echo "=== oracle: static conformance against the golden vectors ==="
(cd oracle && python3 conform.py)

echo "=== head: typecheck ==="
(cd head && npx tsc --noEmit -p tsconfig.json)

echo "=== head: bundle the base ==="
(cd head && node build-eidola-base.mjs)

echo "=== head: base driven in a real browser (verify 1–8) ==="
(cd head && node verify-all.mjs)

echo "=== head: regressions (2026-10-13 and 2026-10-14) ==="
(cd head && node regress.mjs 2>&1 | tail -1)

echo "=== head: the tour view ==="
(cd head && node tour.mjs 2>&1 | tail -1)

echo "=== head: the 2026-10-14 audit (smuggling, bugs, inspect, dump) ==="
(cd head && node audit.mjs 2>&1 | tail -1)

echo "=== grading: two cores, same workspaces, sigma compared per tick ==="
(cd oracle && python3 grade.py -n "${N:-300}" --seed "${SEED:-7}")

echo "=== grading: invisible transformations change nothing, in either core (ADR-0007) ==="
python3 grade/metamorphic.py -n "${N:-300}" --seed "${SEED:-7}" --core

echo "=== export: plain code reproduces every sigma and effect ==="
python3 export/py/verify.py -n "${N:-300}" --seed "${SEED:-7}"

echo "=== cli: smoke test on the examples ==="
python3 cli/eidola.py check examples/running-total/workspace.json >/dev/null
python3 cli/eidola.py run examples/running-total/workspace.json --log examples/running-total/log.json >/dev/null
echo "cli: ok"
