# Changelog

## 2026-11-12 — alpha-0.1: the first open-alpha cut

The repository becomes **eidola**: everything from the 2026-10-14 working tree, plus the formal
pass of 2026-11-09…12 and the tools it produced. Decisions are recorded in `docs/adr/`.

**Fixed in both cores** (vectors unchanged; new claims in `core/test/alpha.test.ts` and
`oracle/test_oracle.py`, which fail on the 2026-10-14 cores):

- **One hash, one sigma** (ADR-0003). Passes 0, A and C walked sites in insertion order, so two
  delays sharing a memory address could tick differently in two workspaces with the same graph
  hash. Every pass now walks sites in canonical path order.
- **Relay-only loops are refused** (ADR-0004). Rule 6 now holds for loops made only of container
  pass-through wires.
- **Law 7 by loop obligations** (ADR-0005). New `checkLoops()` / `check_loops()`: one obligation
  per transition outside a breadth-first tree, from each frame as entry. Sees round trips and
  loops of any length; complete for invertible transitions.

**Packaging** (ADR-0006): `@eidola/core` and `@eidola/base`, version `0.1.0-alpha.0`; a curated
public API in `core/src/public.ts`, everything else under `@eidola/core/internal`.

**Grading** (ADR-0007): `check.sh` now fails if the core stops reproducing the frozen vectors
(`SPEC_REGEN=1` for a deliberate change), and runs `grade/metamorphic.py` (invisible
transformations must change nothing, in either core).

**New:** `cli/eidola.py` (check · run · replay · export · grade, with derived seams);
`export/py/` (plain Python step functions, verified against the oracle); `examples/`;
`research/` (the chip-calculus and probe scripts); `docs/5-foundations/` (formal foundations,
findings, alpha plan); `docs/adr/`; placeholders with requirements for the worker host, the JS
exporter, the TS CLI, the library and three suites.

**Prose:** Law 3 in `eight-laws-introduction.md` now says "with the same occurrence names"
(ADR-0001). `spec/CORE-FORMAT.md` states canonical pass order and the relay-loop case of rule 6.

**Still open before tagging:** ADR-0002 (`pinned`) and ADR-0009 (license).

## 2026-10-14 — one name per thing, a kernel with no vocabulary, two audit passes

**Naming, fixed.** There are three layers. **core** is the kernel. **base** is the minimal
surface (`head/src/eidola.ts`, published as "Eidola · base"). **home** is the first suite,
not built yet. "Horizon" now names only the sky/ground layout the base borrows from Home.
The **workstation** is retired into `head/legacy/`: it did nothing the base could not, and
its palette came from the kernel's primitive table. Its replacements in the base are
`view inspect` (every pane, every wire, the inspector open, the hash showing) and `dump`
(a WORKSPACE/1 box to copy out, or to paste a file into and load). The old dist names
`eidola-home.html` and `eidola.html` are gone, and every check uses `dist/eidola-base.html`.

**The kernel no longer knows any vocabulary** (`core/src`, mirrored in the oracle):

- **`memFold` takes a step function.** The core used to name the folds "last", "sum" and
  "all", so it knew what adding is. It now walks the log with the body's own step, which is
  also the shape an incremental fold (F5) needs. Bodies saved with the old names still run:
  the base's host (`head/src/host.ts`) reads the three names for them, and their text, which
  is their identity, is unchanged. The old bodies also ship precompiled.
- **The default frame registry is empty.** The temperature atlas is now
  `conformanceFrames()`, a spec fixture that the vectors and the grader pass explicitly.
- **Memory is scoped by the enclosing occurrence.** Two copies of one declared counter used to
  write to a single log and count each other's ticks. The new vector
  `memory-is-scoped-by-occurrence` makes the old oracle fail and the new one pass.
- **A source may name its door**, as `emit:clock` or `emit:typed`. The core accepts the family
  and knows no door by name.
- **`collapse(…, { draft: true })`** wraps straight into a draft, so a draft can now be wrapped
  again.
- **A draft keeps one scratch store across ticks**, so a counter inside a draft keeps counting.
- **`dropMem`** lets a log end with its binding.
- 67 core claims, 9 vector scenarios, and grading is still bit-identical.

**The base, after two audit passes** (`head/audit.mjs` has 43 checks; regress has 39, the tour 35):

- Sources declare their door (`emit:typed`, `emit:clock`, `emit:reply`, `emit:context`,
  `emit:fetch`), so what a source receives is content. Before, a path-keyed presentation
  record decided it, and a copy of a chip with a clock inside it never ticked.
- The AI context describes content only: occurrence names, classes, ports, wires and values.
  Renaming a pane or switching views could change the prompt, and so send a paid request.
  An unscoped context describes its own graph. A target that has gone says so instead of
  widening to everything. The loop exclusion now works at every depth, so wrapping the
  assembly no longer makes it describe itself until the tab freezes.
- Memory addresses are the occurrence name, so the same structure hashes the same however it
  was built. Logs of panes that are gone are ended (kept aside for undo and redo), so a new
  pane never inherits a ghost's count. Wrapping carries a counter's history to its new
  scope.
- Memory and the clock are saved with the session. The first tick after a reload asks the
  model nothing.
- A reload while inside a draft keeps the draft's edits.
- Fixed: `redo` inside a draft corrupting the root; undo after a load or reset reaching into
  the old room; undo after `up` losing values; notes left behind on old paths; `zoom abc`;
  rename collisions; wrapping in one view stranding panes in another; `fetch` missing from the
  library; the clock stopping inside drafts.
- One gesture is one undo step: `const`, an op with its wires, and `ai`. Going in and out of an
  unchanged draft adds no step.
- Editing a declared unit through a window says which other panes still hold the old version.

**Known edge:** if a deleted pane's name is reused and both steps are then undone, the undo
restores the more recent history.

## 2026-10-13, last — the tour (`head/src/eidola.ts`)

A fourth view that shows what the head can do, built when you ask for it. Type `tour`, or
click **tour** in the empty room's hint. It is made of the same gestures a person would use,
so it can be taken apart, and one `undo` takes all of it away. The free view still opens
empty (verify4 still says so).

The five stations:

1. **Values flow.** `a + b` from two numbers you can click and change.
2. **Watching is computing.** Two running totals of the same 1, one of them pinned. Switch
   away and only the pinned one keeps counting. This is the viewport acting as a garbage
   collector, made visible.
3. **A body written here.** `fizzbuzz`, an authored leaf that is not a preset, reading a clock
   in the sky.
4. **Wrap · expose · declare.** A Celsius-to-Fahrenheit converter is wrapped into a draft,
   given two named ports, declared into one unit, and looked through live. A second pane
   holds the same unit (same colour) with its own input: 100 → 212.
5. **Something to talk to.** The AI assembly, scoped to the converter. It asks nothing until
   you type.

New along the way:

- **`const`, a library leaf for constants.** Building station 4 found a real gap. A number
  you type is novelty, journalled at a source and kept with *that pane*. So a declared chip
  whose interior held typed numbers came out blank when placed a second time (`0` instead of
  `212`): its constants were never part of its identity. `const` holds its value in the pane's
  config, which is content. It is in the hash, and it travels with the unit. From the omnibar,
  type `const 1.8`; change the value in inspect.
- **Notes.** `note some words` puts a caption in the current view, and `note clear` removes
  them. Notes are presentation, so the hash never moves.
- **The `big` lens shows text without quotes.**
- **Undo is batchable.** `pushUndo` now reports whether it pushed, and `edit`, `wrap` and `del`
  take back only what they pushed. A build like the tour records one step for the whole of
  itself.
- **`makeAI` takes a position** and leaves an outer assembly's quiet flag alone.
- **`head/tour.mjs` has 35 checks**, wired into `check.sh` and `npm test`. One of them runs the
  whole tour under a strict CSP.

## 2026-10-13, later — Horizon review (eidola-base, `head/src/eidola.ts`)

This was a full read of the base head, with every suspicion driven in a real browser first.
All of these were reproduced before they were fixed. `head/regress.mjs` now has 48 checks and
`core` has 58 tests.

**It froze or misbehaved**

- **`ai` in a room with no container to scope it froze the tab.** The `context` source
  described the whole view, including its own prompt, the reply and the display. Every answer
  changed the context, which changed the prompt, which asked again. With no key this recursed
  through microtasks until the page hung; with a key it would have asked forever, and paid for
  each one. This is the AI-node freeze arriving by reflection instead of by wire. Context now
  leaves out its own loop: what it feeds, what feeds that, and every reply.
- **The assembly asked the model while it was still being wired.** Building it cost up to
  three calls before you had typed anything. It is now quiet until the first real edit.
- **A question typed while an answer was in flight was dropped silently.** It now waits and
  goes next.
- **A guard against self-feeding asks:** more than three asks with no human action in between
  stops the run and says why.
- **Clicking a value did not open an editor.** The browser's own mousedown focus landed after
  the re-render and blurred the new field at once, so nothing was editable by click. Number
  fields now also refuse words instead of storing `NaN`.

**It lost things**

- **Undo of a wrap left the panes invisible and their values gone.** The presentation was moved
  before the undo snapshot was taken, and snapshots did not hold source values. Both are fixed.
- **Wrapping dropped the names you had given the panes.**
- **A deleted pane's name, placement and value haunted the next pane to reuse its name**
  (`text1` came back called "notes"). Deleting now ends everything kept at that path, in every
  view, and undo brings it back.
- **A refused edit inside a draft ate a step of root undo.**
- **Draft names drifted after a reload.** Draft tickets are renumbered on load, so names now
  follow them.

**It didn't do what it said**

- **Pasting a number failed** ("no “num” in the library").
- **Seven verbs the omnibar suggested were unknown:** `concat`, `sum`, `delay`, `hist`, `if`,
  `print` and `lt`. They were prim-era names. The suggestions are now generated from the library
  itself, so they cannot drift again, and the old names still work as aliases. `lt` has no
  library entry and is no longer offered.
- **Enter completed a whole word into a different one** (`sum` became `sum5`).
- **`x` broke a route even inside a word** (`max2`). It now has to be a word of its own.
- **Coming up out of a draft sealed it, and recorded lineage to a ticket that would vanish.**
  Up now keeps a draft a draft, the same rule editing through a window already followed.
  `declare` (or the draft bar's button) seals it on the way out.

**It now runs where eval is forbidden**

- **The starter library is precompiled at build time** (`head/tools/compile-library.mjs` writes
  `src/library.compiled.ts`). Units are still identified by their source text. A page under a
  strict CSP, such as an artifact frame or a browser extension (the T1 tier, where eval is
  never allowed), now runs everything it shipped with. New bodies are refused there with the
  reason.
- **`Hosts` in the core now reports the host that actually tried.** A JS body that failed to
  compile used to surface as "PrimHost cannot run host/1".
- **`reset yes` works without a dialog.** Some hosts refuse `confirm()`.
- **The shell sets `color-scheme: dark`,** so native selects and scrollbars match the stone
  palette.

## 2026-10-13 — reorganised, bundled, everything green again

Starting point: `graphmap 2 copy 2` on the Desktop, last touched 2026-08-25. As found, `./check.sh`
stopped at the first step.

### Missing parts, restored

- **`core/src/defaulthost.ts` was missing.** `engine.ts` imports it, so the core did not
  typecheck and nothing downstream could run. Recovered from your own Aug 25 build
  (`head/dist/eidola-home.html`, which still contained it).
- **`PrimHost` was missing from `core/src/prims.ts`.** That file was the Aug 22 version; the
  Aug 25 one had gained the host that runs `prim/1` bodies through the execution port.
  Recovered from the same build. After both, every core module rebuilds identically to what
  that Aug 25 page contains, module for module.

### Bugs fixed

**Core and oracle**

- **The Python oracle had drifted from the TS core: the grader reported 1064 divergences.** On Aug 25 the engine
  switched to *absence is a member of the set* (a missing input is a missing key; the body
  decides what it means). `oracle/graphmap_oracle/engine.py` still skipped any site with a
  missing input. Updated to match, so the differential grader is bit-identical again (300
  workspaces at seed 7, 1000 at seed 42, and on Python 3.9 as well as 3.13).
- **A new golden scenario, `absence-is-a-member`, now pins this semantics in the static
  vectors.** Before, only the fuzzer would have noticed. The existing vectors are unchanged.
- **A stale core test.** `liminal.test.ts` still expected the old all-or-nothing gather.
  Rewritten to assert the current semantics.
- **The scratch store's read-through hid the parent's log** (`core/src/liminal.ts`). After a
  draft appended one entry, reading returned only that entry. A sum or history ticked twice in
  a draft gave `100, 1, 2` instead of `100, 101, 102`. It now returns the parent's entries
  followed by the draft's.
- **A framed interior could not be declared without passing a registry.** `Liminal.declare`
  fell back to an empty frame registry, while the engine falls back to the default one, so
  wrapping `temp.c → temp.f` failed with "no frame route". It now falls back to the engine's
  default.

**eidola-base (`head/src/eidola.ts`)**

- **Descending showed an empty room in the free and media views.** Wrap drops the children's
  surface membership, so the interior had no panes in view, and unobserved meant nothing
  computed. A descended level now shows its interior in every view.
- **Inside a descended container, values never showed and sources never emitted.** A draft is
  played in paths relative to itself, while the head keys everything by full path. The paths
  are now translated at that seam, both ways.
- **Descending into a container with in-ports gave the draft no inputs.** Its stubs were read
  at `chip#x`, where nothing is ever stored, because a boundary is an alias. They are now read
  where `@in.x` lands, via `inValue`, the in-side twin of `epOf`.
- **Typing into an author-panel field was hijacked.** Letters went to the omnibar,
  Backspace deleted the focused pane, and the arrows moved focus. Any focused field now owns
  its keys, and Escape still closes the panel.
- **A foreign session under `eidola/session` was silently overwritten.** The base now keeps it
  aside as `eidola/session.other` and opens its content.

**eidola-workstation (`head/src/app.ts`, legacy and parked; fixed, not extended)**

- **It shared the base's storage key.** Saving here replaced the base's room, and `reset` here
  wiped it. It now uses `eidola-workstation/session`. With nothing of its own it still opens
  the base's content, read-only.
- **The workspace-file textarea lost keys.** Space stepped the graph and vanished, and
  Backspace deleted the selected panes.
- **Grouping under one name produced `box`, `box2`, `box23`, `box234`.** It now counts from the
  stem.
- **A composite's outputs showed `—`** (the boundary-alias problem again), **sources lost their
  value the moment they were grouped**, and **values inside a descended composite never
  showed.** All three are fixed the same way as in the base.

### Tests and tooling

- `core/test/fixes.test.ts`: 6 claims, one per core defect above (56 core tests in all).
- `head/regress.mjs`: 20 browser checks, one per head defect above. Run against the
  pre-fix sources, it fails on each of them.
- `head/verify-all.mjs` runs the eight base walkthroughs and fails on any `XX`, page error or
  crash. Before, they only printed. Four of them had gone stale against renames since Aug 25
  (`num1` → `number1`, prior/group → container, chip → container, and the inspector's
  "boundary is its op" → "declared by whoever wrote it"). They were updated, and none of them
  hid a real failure.
- `head/chrome.mjs`: browser scripts no longer hardcode the sandbox's Chromium path, so they
  run on a Mac after `npx playwright install chromium`.
- `check.sh` now covers everything: head typecheck, all four builds, smoke, verify 1–8,
  regress, and grading. `setup.sh` is the one-time install.
