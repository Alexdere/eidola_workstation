# examples

| folder | shows |
|---|---|
| `running-total/` | a container with memory (`core.sum`), a comparison, a pinned effect that fires only when its input changes |
| `frames/` | one constant in Celsius feeding ports declared in Kelvin and Fahrenheit; conversions applied on the wire |

    python3 cli/eidola.py check examples/running-total/workspace.json
    python3 cli/eidola.py run   examples/running-total/workspace.json --log examples/running-total/log.json --values
    python3 cli/eidola.py export examples/running-total/workspace.json --observe total -o /tmp/step.py
