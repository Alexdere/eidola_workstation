"""Ulam reconstruction for Eidola-style port graphs.
n occurrences of ONE unit type (worst case for symmetry), P named in-ports, one out-port.
Fan-out allowed, fan-in forbidden: each in-port has at most one source occurrence.
Card = delete one occurrence (its wires go with it), recorded up to isomorphism (content hash).
Isomorphism = relabel occurrences; port names are part of the unit, so they are preserved."""
import itertools, collections, sys
import numpy as np

def canon_table(n, P):
    B = n + 1; L = n * P
    codes = np.arange(B ** L, dtype=np.int64)
    D = np.zeros((codes.size, n, P), dtype=np.int64)
    c = codes.copy()
    for k in range(L):
        D[:, k // P, k % P] = c % B; c //= B
    weights = (B ** np.arange(L, dtype=np.int64)).reshape(n, P)
    best = None
    for sig in itertools.permutations(range(n)):
        m = np.array([0] + [s + 1 for s in sig], dtype=np.int64)
        newD = np.empty_like(D)
        for v in range(n): newD[:, sig[v], :] = m[D[:, v, :]]
        code = (newD * weights).sum(axis=(1, 2))
        best = code if best is None else np.minimum(best, code)
    return best, D

def analyse(n, P):
    can, D = canon_table(n, P)
    canm, _ = canon_table(n - 1, P)
    Bm = n; Lm = (n - 1) * P
    wm = (Bm ** np.arange(Lm, dtype=np.int64)).reshape(n - 1, P)
    reps, idx = np.unique(can, return_index=True)
    Dr = D[idx]
    cards = []
    for v in range(n):
        keep = [u for u in range(n) if u != v]
        sub = Dr[:, keep, :].copy()
        sub[sub == v + 1] = 0                      # wires from the deleted occurrence vanish
        sub[sub > v + 1] -= 1                      # relabel the rest
        cards.append(canm[(sub * wm).sum(axis=(1, 2))])
    cards = np.sort(np.stack(cards, axis=1), axis=1)
    groups = collections.defaultdict(list)
    for i, row in enumerate(map(tuple, cards.tolist())): groups[row].append(i)
    amb = [g for g in groups.values() if len(g) > 1]
    return len(reps), sum(len(g) for g in amb), amb, Dr

if __name__ == "__main__":
    for P, ns in ((1, range(2, 7)), (2, range(2, 5)), (3, range(2, 4))):
        for n in ns:
            nc, nonrec, amb, Dr = analyse(n, P)
            ex = ""
            if amb and n >= 3:
                a, b = amb[0][:2]
                fmt = lambda d: " ".join(f"{'xyz'[p]}{v}<-{('·' if d[v][p] == 0 else d[v][p]-1)}" for v in range(n) for p in range(P))
                ex = f"   e.g. [{fmt(Dr[a])}] vs [{fmt(Dr[b])}]"
            print(f"P={P} in-port(s), n={n} occurrences: {nc:7d} classes, non-reconstructible {nonrec}{ex}")
