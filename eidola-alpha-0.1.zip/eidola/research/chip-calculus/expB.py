"""
Coherence as one more semiring.
Group: signed 3x3 permutation matrices (coordinate-frame conventions: axis swaps + sign flips,
order 48, non-commutative).  Each node has a frame f(v); a correct wire u->v carries the
conversion f(u)^-1 f(v), so every path telescopes and all routes agree.  A bug = one wire
whose conversion is off.
"""
import random, itertools
import numpy as np
from chipalg import *

PERMS = list(itertools.permutations(range(3)))
def gel(perm, signs):
    M = [[0] * 3 for _ in range(3)]
    for i, j in enumerate(perm): M[i][j] = signs[i]
    return tuple(tuple(row) for row in M)
GROUP = [gel(p, s) for p in PERMS for s in itertools.product((1, -1), repeat=3)]
GID = gel((0, 1, 2), (1, 1, 1))
def gmul(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)) for i in range(3))
def ginv(a):  # orthogonal -> transpose
    return tuple(tuple(a[j][i] for j in range(3)) for i in range(3))
assert len(set(GROUP)) == 48 and any(gmul(a, b) != gmul(b, a) for a in GROUP for b in GROUP)
GAUGE = make_gauge(gmul, GID, lambda r: r.choice(GROUP), "frame coherence")

def coherent_chip(r, n, p, q, dens=0.35, dag=True, frames=None):
    """random chip whose wire conversions are induced by node/port frames -> coherent by construction"""
    c = random_chip(BOOL, r, n, p, q, dens, dag)   # topology only
    fr = frames or {}
    f = lambda key: fr.setdefault(key, r.choice(GROUP))
    c.inE = [(i, v, gmul(ginv(f(("in", i))), f(v))) for i, v, _ in c.inE]
    c.E = [(u, v, gmul(ginv(f(u)), f(v))) for u, v, _ in c.E]
    c.outE = [(v, o, gmul(ginv(f(v)), f(("out", o)))) for v, o, _ in c.outE]
    c.frames = fr
    return c

def plant_bug(r, c):
    """perturb one wire's conversion (in any of the three edge lists)"""
    lists = [("inE", c.inE), ("E", c.E), ("outE", c.outE)]
    name, L = r.choice([x for x in lists if x[1]])
    j = r.randrange(len(L)); e = L[j]
    bad = gmul(e[2], r.choice([g for g in GROUP if g != GID]))
    L[j] = e[:2] + (bad,)
    return name, j

def is_top(S): return any(x == TOP for row in S for x in row)

if __name__ == "__main__":
    r = random.Random(3)
    # --- 1. compositional exactness of the coherence summary, non-commutative group
    from expA import trial  # reuse random gluing harness
    import expA
    expA.r = r
    for op in ("seq", "par", "fb"):
        ok = 0
        for _ in range(300):
            g, flat, comp = trial(GAUGE, op, False, 0.3)
            ok += meq(GAUGE, flat, comp)
        print(f"[1] gauge semiring, random chips, {op:3s}: flat==composed {ok}/300")

    # --- 2. pairwise/local checks vs. global: chips with one planted bug
    stats = dict(local_pass=0, detected=0, undetectable=0, n=0)
    for _ in range(2000):
        c = coherent_chip(r, r.randint(3, 8), 1, 1, 0.4)
        S0 = summary(GAUGE, c)
        assert not is_top(S0)
        plant_bug(r, c)
        S = summary(GAUGE, c)
        stats["n"] += 1
        stats["local_pass"] += 1          # every individual wire is still a valid group element
        if is_top(S): stats["detected"] += 1
        else: stats["undetectable"] += 1
    print(f"[2] single chip, one bad wire: every local check passes {stats['local_pass']}/{stats['n']}; "
          f"summary flags conflict {stats['detected']}/{stats['n']}; silent {stats['undetectable']}/{stats['n']}")

    # --- 3. exact criterion: detectable  <=>  bad wire lies on SOME but not ALL routes of some (in,out) pair
    import networkx as nx
    def routes_info(c, which, j):
        G = nx.DiGraph()
        ins = [("i", i) for i in range(c.p)]; outs = [("o", o) for o in range(c.q)]
        el = [(("i", i), v) for i, v, _ in c.inE] + [(u, v) for u, v, _ in c.E] + [(v, ("o", o)) for v, o, _ in c.outE]
        G.add_edges_from(el)
        idx = {"inE": 0, "E": len(c.inE), "outE": len(c.inE) + len(c.E)}[which] + j
        bad = el[idx]
        some_not_all = False; on_any = False
        for s in ins:
            for t in outs:
                if s not in G or t not in G: continue
                paths = list(nx.all_simple_paths(G, s, t))
                thru = [P for P in paths if any((P[k], P[k+1]) == bad for k in range(len(P) - 1))]
                if thru: on_any = True
                if thru and len(thru) < len(paths): some_not_all = True
        return some_not_all, on_any
    agree = n = 0; with_spec = relevant = 0
    for _ in range(1500):
        c = coherent_chip(r, r.randint(3, 8), r.randint(1, 2), r.randint(1, 2), 0.4)
        which, j = plant_bug(r, c)
        S = summary(GAUGE, c)
        crit, on_any = routes_info(c, which, j)
        n += 1; agree += (is_top(S) == crit)
        # add an independent spec route for every (in,out): expected conversion f(in)^-1 f(out)
        if on_any:
            relevant += 1
            spec = [[gmul(ginv(c.frames[("in", i)]), c.frames[("out", o)]) for o in range(c.q)] for i in range(c.p)]
            with_spec += is_top(madd(GAUGE, S, spec))
    print(f"[3] 'some-but-not-all routes' criterion predicts detection exactly: {agree}/{n}")
    print(f"[3b] add a spec route (expected end-to-end conversion) in parallel: "
          f"every bug on a live route now detected {with_spec}/{relevant}")
