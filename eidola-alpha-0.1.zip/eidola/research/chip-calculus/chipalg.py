"""
Chip algebra: open graphs (chips) with input/output ports, edge weights in a semiring.
Summary  S[i][o] = (+)-sum over all paths input i -> output o of (x)-product of edge weights,
row convention so products are in path order (works for non-commutative (x)).
Operations: seq (wire outputs of G1 to inputs of G2), par (side by side), feedback (wire
some outputs back to some inputs).  We compare:
    flat  : glue the graphs, then summarise the big graph
    comp  : summarise the pieces, then combine summaries algebraically
"""
import random, math
from fractions import Fraction

# ---------------------------------------------------------------- semirings
class SR:
    def __init__(s, name, zero, one, add, mul, star, rand, eq=None):
        s.name, s.zero, s.one, s.add, s.mul, s.star, s.rand = name, zero, one, add, mul, star, rand
        s.eq = eq or (lambda a, b: a == b)

INF = math.inf
BOOL = SR("boolean reach", False, True, lambda a, b: a or b, lambda a, b: a and b,
          lambda a: True, lambda r: True)
MINPLUS = SR("min-plus latency", INF, 0, min, lambda a, b: a + b,
             lambda a: 0 if a >= 0 else -INF, lambda r: r.randint(1, 9))
def _mp_mul(a, b):
    if a == -INF or b == -INF: return -INF
    return a + b
MAXPLUS = SR("max-plus worst latency", -INF, 0, max, _mp_mul,
             lambda a: 0 if a <= 0 else INF, lambda r: r.randint(1, 9))
def _cnt_mul(a, b):
    if a == 0 or b == 0: return 0
    return a * b
COUNT = SR("path counting", 0, 1, lambda a, b: a + b, _cnt_mul,
           lambda a: 1 if a == 0 else INF, lambda r: 1)
def _pr_mul(a, b):
    if a == 0 or b == 0: return 0.0
    return a * b
def _pr_star(a):
    return 1.0 / (1.0 - a) if a < 1 else INF
PROB = SR("probabilistic flow", 0.0, 1.0, lambda a, b: a + b, _pr_mul, _pr_star,
          lambda r: r.uniform(0.05, 0.35),
          eq=lambda a, b: (a == b) or (abs(a - b) <= 1e-9 * max(1, abs(a), abs(b))))

# capability antichain semiring: element = antichain of frozensets (minimal capability sets
# some path needs).  zero = no path; one = {emptyset}
def _minimal(fam):
    fam = set(fam)
    return frozenset(f for f in fam if not any(g < f for g in fam))
CAPS = ["net", "disk", "gpu", "clock"]
CAP = SR("capability antichain", frozenset(), frozenset([frozenset()]),
         lambda a, b: _minimal(a | b),
         lambda a, b: _minimal(frozenset(x | y for x in a for y in b)),
         lambda a: frozenset([frozenset()]),
         lambda r: frozenset([frozenset([r.choice(CAPS)])]) if r.random() < 0.3 else frozenset([frozenset()]))

# coherence ("gauge") semiring over a group: values = group elements, plus BOT (no path), TOP (conflict)
BOT, TOP = ("BOT",), ("TOP",)
def make_gauge(gmul, gid, grand, name):
    def add(a, b):
        if a == BOT: return b
        if b == BOT: return a
        if a == TOP or b == TOP: return TOP
        return a if a == b else TOP
    def mul(a, b):
        if a == BOT or b == BOT: return BOT
        if a == TOP or b == TOP: return TOP
        return gmul(a, b)
    def star(a):
        if a == BOT: return gid
        if a == TOP: return TOP
        return gid if a == gid else TOP
    return SR(name, BOT, gid, add, mul, star, grand)

# ---------------------------------------------------------------- matrices
def mat(sr, r, c): return [[sr.zero] * c for _ in range(r)]
def ident(sr, n):
    M = mat(sr, n, n)
    for i in range(n): M[i][i] = sr.one
    return M
def mmul(sr, A, B):
    r, k, c = len(A), len(B), (len(B[0]) if B else 0)
    C = mat(sr, r, c)
    for i in range(r):
        for j in range(c):
            acc = sr.zero
            for t in range(k):
                acc = sr.add(acc, sr.mul(A[i][t], B[t][j]))
            C[i][j] = acc
    return C
def madd(sr, A, B):
    return [[sr.add(a, b) for a, b in zip(ra, rb)] for ra, rb in zip(A, B)]
def closure(sr, A):
    """Kleene/Lehmann elimination: returns A* = I + A + A^2 + ... for a closed semiring."""
    n = len(A)
    M = [row[:] for row in A]
    for k in range(n):
        s = sr.star(M[k][k])
        N = [row[:] for row in M]
        for i in range(n):
            if M[i][k] == sr.zero: continue
            left = sr.mul(M[i][k], s)
            for j in range(n):
                if M[k][j] == sr.zero: continue
                N[i][j] = sr.add(M[i][j], sr.mul(left, M[k][j]))
        M = N
    return madd(sr, ident(sr, n), M)
def meq(sr, A, B):
    return all(sr.eq(a, b) for ra, rb in zip(A, B) for a, b in zip(ra, rb))

# ---------------------------------------------------------------- chips
class Chip:
    """n internal nodes; ins: list of input-port edge lists; edges[(u,v)] = w; outs similar."""
    def __init__(s, n, p, q):
        s.n, s.p, s.q = n, p, q
        s.inE = []   # (port i, node v, w)
        s.E = []     # (u, v, w)
        s.outE = []  # (node v, port o, w)

def random_chip(sr, r, n, p, q, dens=0.3, dag=False):
    c = Chip(n, p, q)
    for i in range(p):
        for v in r.sample(range(n), r.randint(1, min(2, n))):
            c.inE.append((i, v, sr.rand(r)))
    for u in range(n):
        for v in range(n):
            if u == v: continue
            if dag and v <= u: continue
            if r.random() < dens: c.E.append((u, v, sr.rand(r)))
    for o in range(q):
        for v in r.sample(range(n), r.randint(1, min(2, n))):
            c.outE.append((v, o, sr.rand(r)))
    return c

def summary(sr, c):
    A = mat(sr, c.n, c.n)
    for u, v, w in c.E: A[u][v] = sr.add(A[u][v], w)
    B = mat(sr, c.p, c.n)
    for i, v, w in c.inE: B[i][v] = sr.add(B[i][v], w)
    C = mat(sr, c.n, c.q)
    for v, o, w in c.outE: C[v][o] = sr.add(C[v][o], w)
    return mmul(sr, mmul(sr, B, closure(sr, A)), C)

def glue_seq(c1, c2):
    """outputs of c1 -> inputs of c2 (c1.q == c2.p); each wire becomes a pass-through node."""
    k = c1.q; assert k == c2.p
    off2, offw = c1.n, c1.n + c2.n
    g = Chip(c1.n + c2.n + k, c1.p, c2.q)
    g.inE = list(c1.inE)
    g.E = list(c1.E) + [(u + off2, v + off2, w) for u, v, w in c2.E]
    g.E += [(v, offw + o, w) for v, o, w in c1.outE]
    g.E += [(offw + i, v + off2, w) for i, v, w in c2.inE]
    g.outE = [(v + off2, o, w) for v, o, w in c2.outE]
    return g

def glue_par(c1, c2):
    off = c1.n
    g = Chip(c1.n + c2.n, c1.p + c2.p, c1.q + c2.q)
    g.inE = list(c1.inE) + [(i + c1.p, v + off, w) for i, v, w in c2.inE]
    g.E = list(c1.E) + [(u + off, v + off, w) for u, v, w in c2.E]
    g.outE = list(c1.outE) + [(v + off, o + c1.q, w) for v, o, w in c2.outE]
    return g

def glue_fb(c, k):
    """last k outputs wired back to last k inputs."""
    px, qy = c.p - k, c.q - k
    offw = c.n
    g = Chip(c.n + k, px, qy)
    g.E = list(c.E)
    g.inE = [(i, v, w) for i, v, w in c.inE if i < px]
    g.E += [(offw + (i - px), v, w) for i, v, w in c.inE if i >= px]
    g.outE = [(v, o, w) for v, o, w in c.outE if o < qy]
    g.E += [(v, offw + (o - qy), w) for v, o, w in c.outE if o >= qy]
    return g

# algebraic combinators on summaries
def s_seq(sr, S1, S2): return mmul(sr, S1, S2)
def s_par(sr, S1, S2):
    p1, q1 = len(S1), len(S1[0]); p2, q2 = len(S2), len(S2[0])
    M = mat(sr, p1 + p2, q1 + q2)
    for i in range(p1):
        for j in range(q1): M[i][j] = S1[i][j]
    for i in range(p2):
        for j in range(q2): M[p1 + i][q1 + j] = S2[i][j]
    return M
def s_fb(sr, S, k):
    """Conway trace:  A + B D* C  with  S = [[A, B], [C, D]] (rows = inputs X|U, cols = outputs Y|U')."""
    p, q = len(S), len(S[0]); px, qy = p - k, q - k
    A = [row[:qy] for row in S[:px]]
    B = [row[qy:] for row in S[:px]]
    C = [row[:qy] for row in S[px:]]
    D = [row[qy:] for row in S[px:]]
    return madd(sr, A, mmul(sr, mmul(sr, B, closure(sr, D)), C))
