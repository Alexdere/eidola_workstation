from expC import analyse, reach_summary
from expC2 import to_nx
R = analyse(4, 1, 1); F = R["F"]
wired = live = 0; spec = None
for gs in R["amb"].values():
    a, b = gs
    Ga, Gb = to_nx(F, a), to_nx(F, b)
    w = all(Ga.out_degree(("i", 0)) and Ga.in_degree(("o", 0)) and Gb.out_degree(("i", 0)) and Gb.in_degree(("o", 0)) for _ in [0])
    wired += w
    if w and reach_summary(F, a)[0][0]:
        live += 1
        if spec is None or Ga.number_of_edges() < spec[0].number_of_edges(): spec = (Ga, Gb)
print(f"ambiguous chip pairs n=4: {len(R['amb'])}; both ports wired in both: {wired}; and with a live in->out route: {live}")
lab = lambda x: "IN" if x == ("i", 0) else ("OUT" if x == ("o", 0) else "abcd"[x])
for G in spec: print("  ", " ".join(f"{lab(u)}->{lab(v)}" for u, v in sorted(G.edges(), key=str)))
