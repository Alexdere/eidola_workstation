import random, math, sys
import networkx as nx
from chipalg import *

r = random.Random(7)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 400

def flat_graph(c):
    G = nx.DiGraph()
    for i, v, w in c.inE: G.add_edge(("i", i), v, w=w)
    for u, v, w in c.E: G.add_edge(u, v, w=w)
    for v, o, w in c.outE: G.add_edge(v, ("o", o), w=w)
    return G

def indep_bool(c):
    G = flat_graph(c)
    S = [[False] * c.q for _ in range(c.p)]
    for i in range(c.p):
        if ("i", i) not in G: continue
        R = nx.descendants(G, ("i", i))
        for o in range(c.q): S[i][o] = ("o", o) in R
    return S
def indep_minplus(c):
    G = flat_graph(c)
    S = [[INF] * c.q for _ in range(c.p)]
    for i in range(c.p):
        if ("i", i) not in G: continue
        d = nx.single_source_dijkstra_path_length(G, ("i", i), weight="w")
        for o in range(c.q): S[i][o] = d.get(("o", o), INF)
    return S
def indep_count_dag(c):
    G = flat_graph(c)
    S = [[0] * c.q for _ in range(c.p)]
    for i in range(c.p):
        for o in range(c.q):
            if ("i", i) in G and ("o", o) in G:
                S[i][o] = sum(1 for _ in nx.all_simple_paths(G, ("i", i), ("o", o)))
    return S

def trial(sr, op, dag, dens=0.3):
    if op == "seq":
        k = r.randint(1, 3)
        c1 = random_chip(sr, r, r.randint(2, 6), r.randint(1, 3), k, dens, dag)
        c2 = random_chip(sr, r, r.randint(2, 6), k, r.randint(1, 3), dens, dag)
        g = glue_seq(c1, c2); comp = s_seq(sr, summary(sr, c1), summary(sr, c2))
    elif op == "par":
        c1 = random_chip(sr, r, r.randint(2, 6), r.randint(1, 3), r.randint(1, 3), dens, dag)
        c2 = random_chip(sr, r, r.randint(2, 6), r.randint(1, 3), r.randint(1, 3), dens, dag)
        g = glue_par(c1, c2); comp = s_par(sr, summary(sr, c1), summary(sr, c2))
    else:
        k = r.randint(1, 2)
        c = random_chip(sr, r, r.randint(2, 7), k + r.randint(1, 2), k + r.randint(1, 2), dens, dag)
        g = glue_fb(c, k); comp = s_fb(sr, summary(sr, c), k)
    return g, summary(sr, g), comp

def run(sr, dag=False, dens=0.3, indep=None, ops=("seq", "par", "fb")):
    out = {}
    for op in ops:
        ok = ind_ok = inf_cells = cells = 0
        for _ in range(N):
            g, flat, comp = trial(sr, op, dag, dens)
            ok += meq(sr, flat, comp)
            if indep: ind_ok += meq(sr, flat, indep(g))
            for row in flat:
                for x in row:
                    cells += 1
                    if x in (INF,): inf_cells += 1
        out[op] = (ok, ind_ok if indep else None, inf_cells / max(cells, 1))
    return out

def show(label, res):
    for op, (ok, ind, frac_inf) in res.items():
        s = f"  {label:34s} {op:4s}  flat==composed {ok}/{N}"
        if ind is not None: s += f"   flat==independent {ind}/{N}"
        if frac_inf: s += f"   divergent cells {frac_inf:.0%}"
        print(s)

print("== idempotent semirings, arbitrary chips with internal cycles ==")
show("boolean reach", run(BOOL, indep=indep_bool))
show("min-plus latency", run(MINPLUS, indep=indep_minplus))
show("capability antichain", run(CAP))
print("== quantitative semirings ==")
show("path counting (DAG chips)", run(COUNT, dag=True, indep=indep_count_dag, ops=("seq", "par")))
show("path counting + feedback", run(COUNT, dag=True, ops=("fb",)))
show("max-plus worst latency (DAG)", run(MAXPLUS, dag=True, ops=("seq", "par")))
show("max-plus + feedback", run(MAXPLUS, dag=True, ops=("fb",)))
show("probabilistic, sparse (gain<1)", run(PROB, dens=0.15))
# unstable regime: heavier weights
PROB_HOT = SR("prob hot", 0.0, 1.0, PROB.add, PROB.mul, PROB.star, lambda rr: rr.uniform(0.5, 0.95), PROB.eq)
show("probabilistic, dense (gain>=1)", run(PROB_HOT, dens=0.5))
