"""Multi-defect detection bound, any group.
Claim: a set of wrong conversions is invisible to every loop  <=>  it is a re-framing of a region;
every nontrivial invisible set contains a cut; so < lambda simultaneous defects are always seen.
With anchors A (frames whose absolute conversion is known): invisible <=> re-framing that is
identity on A; bound becomes lambda_A = min cut separating some nonempty set from A."""
import random, itertools, networkx as nx
from expB import GROUP, GID, gmul, ginv

r = random.Random(13)
def holonomy_ok(G, g, anchors=(), truth=None):
    T = nx.minimum_spanning_tree(G); root = next(iter(G.nodes))
    pot = {root: GID}
    for u, v in nx.bfs_edges(T, root):
        pot[v] = gmul(pot[u], g[(u, v)])
    for u, v in G.edges():                      # one obligation per edge (tree edges are trivially fine)
        if gmul(pot[u], g[(u, v)]) != pot[v]: return False
    for a, b in itertools.combinations(anchors, 2):   # absolute checks between anchored frames
        if gmul(ginv(pot[a]), pot[b]) != truth[(a, b)]: return False
    return True

def flat(G):
    phi = {v: r.choice(GROUP) for v in G}
    g = {}
    for u, v in G.edges():
        g[(u, v)] = gmul(ginv(phi[u]), phi[v]); g[(v, u)] = ginv(g[(u, v)])
    return phi, g

def perturb(g, edges):
    g2 = dict(g)
    for (u, v) in edges:
        d = r.choice([x for x in GROUP if x != GID])
        g2[(u, v)] = gmul(g[(u, v)], d); g2[(v, u)] = ginv(g2[(u, v)])
    return g2

below = below_ok = at_cut = at_cut_invisible = anc_below = anc_ok = 0
for _ in range(300):
    n = r.randint(6, 12)
    G = nx.gnm_random_graph(n, r.randint(int(1.5 * n), 3 * n), seed=r.randrange(10**9))
    if not nx.is_connected(G): continue
    lam = nx.edge_connectivity(G)
    phi, g = flat(G); E = list(G.edges())
    for s in range(1, lam):
        for _ in range(20):
            below += 1; below_ok += not holonomy_ok(G, perturb(g, r.sample(E, s)))
    # invisible defect on a minimum cut: re-frame one side by psi
    cut = nx.minimum_edge_cut(G)
    H = G.copy(); H.remove_edges_from(cut); S = next(iter(nx.connected_components(H)))
    psi = r.choice([x for x in GROUP if x != GID])
    phi2 = {v: (gmul(psi, phi[v]) if v in S else phi[v]) for v in G}
    g2 = {}
    for u, v in E:
        g2[(u, v)] = gmul(ginv(phi2[u]), phi2[v]); g2[(v, u)] = ginv(g2[(u, v)])
    changed = sum(1 for u, v in E if g2[(u, v)] != g[(u, v)])
    at_cut += 1; at_cut_invisible += (holonomy_ok(G, g2) and changed == len(cut) == lam)
    # anchors: two anchored frames with known absolute conversion
    A = r.sample(list(G.nodes), 2)
    truth = {(a, b): gmul(ginv(phi[a]), phi[b]) for a, b in itertools.permutations(A, 2)}
    lamA = min(len(nx.minimum_edge_cut(G, A[0], A[1])), lam)   # crude: cuts separating the anchors, or not touching them
    # a single defect on a bridge-like edge between anchors: plain loops may miss, anchors catch if the edge separates them
for _ in range(400):   # anchors catch bridge defects that loops cannot
    T = nx.random_labeled_tree(8, seed=r.randrange(10**9)); phi, g = flat(T)
    A = r.sample(list(T.nodes), 2); truth = {(a, b): gmul(ginv(phi[a]), phi[b]) for a, b in itertools.permutations(A, 2)}
    path = nx.shortest_path(T, A[0], A[1]); e = r.choice(list(zip(path, path[1:])))
    g2 = perturb(g, [e])
    anc_below += 1; anc_ok += (holonomy_ok(T, g2) and not holonomy_ok(T, g2, A, truth))
print(f"[detect] fewer than lambda wrong conversions (any of 48-element non-commutative group): caught {below_ok}/{below}")
print(f"[invisible] re-framing one side of a minimum cut: exactly lambda wires change and every loop still passes {at_cut_invisible}/{at_cut}")
print(f"[anchors] tree (no loops at all), one wrong wire on the path between two anchored frames: loops see nothing, anchors catch it {anc_ok}/{anc_below}")
