import random, itertools, networkx as nx
from chipalg import *
from expB import GAUGE, GROUP, GID, gmul, ginv, coherent_chip, plant_bug, is_top

r = random.Random(5)
# ---------------- [4] hierarchical system: localization from 1x1 summaries
def split_chip(a):   # 1 in -> 2 out, identity conversions in frame a
    c = Chip(1, 1, 2); c.inE = [(0, 0, GID)]; c.outE = [(0, 0, GID), (0, 1, GID)]; return c
def merge_chip(b):
    c = Chip(1, 2, 1); c.inE = [(0, 0, GID), (1, 0, GID)]; c.outE = [(0, 0, GID)]; return c

def build(depth, a, b):
    """returns tree node dict; leaves are coherent chips with in-frame a, out-frame b"""
    if depth == 0:
        while True:   # every leaf is live: at least one in->out route
            leaf = coherent_chip(r, r.randint(3, 7), 1, 1, 0.35, frames={("in", 0): a, ("out", 0): b})
            if summary(GAUGE, leaf)[0][0] != BOT: break
        return dict(kind="leaf", chip=leaf, kids=[])
    if r.random() < 0.5:
        m = r.choice(GROUP)
        return dict(kind="serial", kids=[build(depth - 1, a, m), build(depth - 1, m, b)])
    return dict(kind="diamond", kids=[build(depth - 1, a, b), build(depth - 1, a, b)])

def flatten(t):
    if t["kind"] == "leaf": return t["chip"]
    X, Y = (flatten(k) for k in t["kids"])
    if t["kind"] == "serial": return glue_seq(X, Y)
    return glue_seq(glue_seq(split_chip(None), glue_par(X, Y)), merge_chip(None))

def summarise(t):
    if t["kind"] == "leaf":
        t["S"] = summary(GAUGE, t["chip"])
    else:
        SX, SY = (summarise(k) for k in t["kids"])
        if t["kind"] == "serial": t["S"] = s_seq(GAUGE, SX, SY)
        else:
            Ssp = summary(GAUGE, split_chip(None)); Smg = summary(GAUGE, merge_chip(None))
            t["S"] = s_seq(GAUGE, s_seq(GAUGE, Ssp, s_par(GAUGE, SX, SY)), Smg)
    return t["S"]

def leaves(t, path=()):
    if t["kind"] == "leaf": yield t, path
    for i, k in enumerate(t["kids"]): yield from leaves(k, path + ((t, i),))

def size(t): return t["chip"].n + len(t["chip"].E) if t["kind"] == "leaf" else sum(size(k) for k in t["kids"])

dead_ct = [0]; exact = trials = loc_ok = silent = 0; frac = []; ambiguous = 0
for _ in range(300):
    depth = 6
    T = build(depth, r.choice(GROUP), r.choice(GROUP))
    summarise(T); assert not is_top(T["S"])
    L = list(leaves(T)); leaf, path = r.choice(L)
    which, j = plant_bug(r, leaf["chip"])
    S_top = summarise(T)
    # exactness at the top vs flattening the whole system
    trials += 1
    # lowest node flagged TOP (walk down from leaf)
    chain = [leaf] + [p for p, _ in reversed(path)]
    flagged = next((x for x in chain if is_top(x["S"])), None)
    # prediction: leaf itself if leaf flagged, else lowest diamond ancestor (if the bad wire is live in the leaf)
    live = leaf["S"][0][0] != BOT and (is_top(leaf["S"]) or leaf["S"][0][0] != gmul(ginv(leaf["chip"].frames[("in", 0)]), leaf["chip"].frames[("out", 0)]))
    pred = leaf if is_top(leaf["S"]) else next((p for p, _ in reversed(path) if p["kind"] == "diamond"), None)
    if not live: pred = None
    loc_ok += (flagged is pred)
    if flagged is None:
        silent += 1
        dead_ct[0] += (not live)
    else: frac.append(size(flagged) / size(T))
# exactness vs flattening on smaller systems (flattened closure is cubic in Python)
for _ in range(60):
    T3 = build(3, r.choice(GROUP), r.choice(GROUP)); lf, _p = r.choice(list(leaves(T3))); plant_bug(r, lf["chip"])
    exact += meq(GAUGE, summarise(T3), summary(GAUGE, flatten(T3)))
print(f"[4] depth-6 hierarchy, one bad wire in one leaf ({trials} systems)")
print(f"    (depth-3 check) top summary from 1x1 pieces == flattened system: {exact}/60")
print(f"    lowest flagged composite == predicted (leaf-internal loop, else lowest diamond ancestor): {loc_ok}/{trials}")
print(f"    silent at top (no loop above the bug, or dead wire): {silent}/{trials}")
import statistics
print(f"    ...of which dead wires (on no route, cannot affect output): {dead_ct[0]}; live bugs with no loop above: {silent - dead_ct[0]}")
print(f"    when flagged, region left to inspect = median {statistics.median(frac):.1%}, mean {statistics.mean(frac):.1%} of the system")
