import random, numpy as np
from chipalg import *
from expA import trial, N, r
import expA
# (1) independent check for probabilistic stable regime via numpy linear solve
def indep_prob(c):
    A = np.zeros((c.n, c.n)); B = np.zeros((c.p, c.n)); C = np.zeros((c.n, c.q))
    for u, v, w in c.E: A[u, v] += w
    for i, v, w in c.inE: B[i, v] += w
    for v, o, w in c.outE: C[v, o] += w
    rho = max(abs(np.linalg.eigvals(A))) if c.n else 0
    return (B @ np.linalg.inv(np.eye(c.n) - A) @ C).tolist(), rho
ok = tot = 0
for _ in range(N):
    g, flat, comp = trial(PROB, "fb", False, 0.15)
    S, rho = indep_prob(g)
    if rho < 1:
        tot += 1; ok += meq(PROB, flat, S)
print(f"probabilistic feedback, numpy (I-A)^-1 vs flat elimination: {ok}/{tot} stable chips agree")
# (2) how often does feedback actually matter? compare trace vs A-block alone
for sr, dag, dens in [(BOOL, False, .3), (MINPLUS, False, .3), (CAP, False, .3), (PROB, False, .15)]:
    live = 0
    for _ in range(N):
        k = r.randint(1, 2)
        c = random_chip(sr, r, r.randint(2, 7), k + r.randint(1, 2), k + r.randint(1, 2), dens, dag)
        S = summary(sr, c); px, qy = c.p - k, c.q - k
        Ablk = [row[:qy] for row in S[:px]]
        live += not meq(sr, s_fb(sr, S, k), Ablk)
    print(f"  {sr.name:24s}: feedback changed the summary in {live}/{N} trials")
