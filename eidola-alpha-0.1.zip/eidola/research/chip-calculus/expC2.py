import collections, networkx as nx
from networkx.algorithms.isomorphism import DiGraphMatcher
from expC import analyse, reach_summary, Family
def to_nx(F, g, drop=None):
    G = nx.DiGraph()
    for v in range(F.n):
        if v != drop: G.add_node(v, kind="int")
    for i in range(F.P): G.add_node(("i", i), kind=("i", i))
    for o in range(F.Q): G.add_node(("o", o), kind=("o", o))
    for b, (a, c) in enumerate(F.slots):
        if (g >> b) & 1 and drop not in (a, c): G.add_edge(a, c)
    return G
nm = lambda a, b: a["kind"] == b["kind"]
iso = lambda G, H: DiGraphMatcher(G, H, node_match=nm).is_isomorphic()
def deck(F, g): return [to_nx(F, g, v) for v in range(F.n)]
def same_deck(F, g, h):
    A, B = deck(F, g), deck(F, h); used = [False] * len(B)
    for X in A:
        for j, Y in enumerate(B):
            if not used[j] and iso(X, Y): used[j] = True; break
        else: return False
    return True
for (n, P, Q, label) in [(5, 0, 0, "digraph n=5"), (4, 1, 1, "1-in/1-out chip n=4")]:
    R = analyse(n, P, Q); F = R["F"]; ok = tot = 0; first = None
    for gs in R["amb"].values():
        for a in range(len(gs)):
            for b in range(a + 1, len(gs)):
                tot += 1
                Ga, Gb = to_nx(F, gs[a]), to_nx(F, gs[b])
                ok += (not iso(Ga, Gb)) and same_deck(F, gs[a], gs[b])
                if first is None: first = (Ga, Gb)
    print(f"{label}: independently verified ambiguous pairs (non-isomorphic, same deck): {ok}/{tot}")
    Ga, Gb = first
    fmt = lambda G: sorted(((str(u), str(v)) for u, v in G.edges()))
    print("   specimen A:", fmt(Ga)); print("   specimen B:", fmt(Gb))
# summary-cards: replace each card by its port-to-port reach matrix only
for (n, P, Q) in [(3, 1, 1), (4, 1, 1), (3, 2, 2)]:
    F, Fm = Family(n, P, Q), Family(n - 1, P, Q)
    import numpy as np
    from expC import delete_map
    reps = np.unique(F.canon_table()).tolist(); dms = [delete_map(F, Fm, v) for v in range(n)]
    groups = collections.defaultdict(set)
    for g in reps:
        cs = []
        for dm in dms:
            c = 0
            for b, tb in enumerate(dm):
                if tb is not None and (g >> b) & 1: c |= 1 << tb
            cs.append(reach_summary(Fm, c))
        groups[tuple(sorted(cs))].add(reach_summary(F, g))
    bad = sum(1 for s in groups.values() if len(s) > 1)
    print(f"summary-cards, {P}-in/{Q}-out n={n}: {len(groups)} distinct summary-decks, {bad} of them fail to fix the whole summary")
