"""[5] debugging resolution: which wires can holonomy (loop) checks tell apart?
Undirected interface graph, commutative gauge (unit exponents, e.g. powers of ten).
Claim: two wires give identical failure patterns  <=>  they lie on exactly the same cycles
      <=>  they are in series (a 2-edge cut), or both are bridges."""
import random, networkx as nx
r = random.Random(9)
def fundamental_supports(G):
    T = nx.minimum_spanning_tree(G)   # any spanning tree
    sup = {frozenset(e): set() for e in G.edges()}
    for k, (u, v) in enumerate(e for e in G.edges() if not T.has_edge(*e)):
        path = nx.shortest_path(T, u, v)
        for a, b in zip(path, path[1:]): sup[frozenset((a, b))].add(k)
        sup[frozenset((u, v))].add(k)
    return sup
def same_cycles(G, e, f):
    be = nx.has_bridges(G) and frozenset(e) in {frozenset(x) for x in nx.bridges(G)}
    bf = frozenset(f) in {frozenset(x) for x in nx.bridges(G)}
    if be or bf: return be and bf
    H = G.copy(); H.remove_edge(*e)
    return frozenset(f) in {frozenset(x) for x in nx.bridges(H)}
agree = pairs = 0; res = []
for _ in range(200):
    n = r.randint(6, 14)
    G = nx.gnm_random_graph(n, r.randint(n, 2 * n), seed=r.randrange(10**9))
    if not nx.is_connected(G): continue
    sup = fundamental_supports(G)
    E = list(G.edges())
    for i in range(len(E)):
        for j in range(i + 1, len(E)):
            pairs += 1
            agree += ((sup[frozenset(E[i])] == sup[frozenset(E[j])]) == same_cycles(G, E[i], E[j]))
    classes = len({frozenset(s) for s in sup.values()})
    res.append((len(E), classes, G.number_of_edges() - n + 1))
print(f"[5] identical loop-failure pattern  <=>  same cycles (series / both bridges): {agree}/{pairs} wire pairs")
import statistics
print(f"    typical graph: {statistics.mean(x[0] for x in res):.1f} wires, {statistics.mean(x[2] for x in res):.1f} independent loops, "
      f"{statistics.mean(x[1] for x in res):.1f} distinguishable wire classes")
# one cross-link splits a series class: path graph with a single loop, then add a chord
G = nx.cycle_graph(8); s0 = len({frozenset(v) for v in fundamental_supports(G).values()})
G.add_edge(0, 4); s1 = len({frozenset(v) for v in fundamental_supports(G).values()})
G.add_edge(2, 6); s2 = len({frozenset(v) for v in fundamental_supports(G).values()})
print(f"    8-wire ring: {s0} class -> +1 cross-link: {s1} classes -> +2 cross-links: {s2} classes (wires: 8, 9, 10)")
