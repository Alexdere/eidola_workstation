import random, networkx as nx
from chipalg import *
r = random.Random(11)
# (1) live-feedback-only stress test
for sr in (BOOL, MINPLUS, CAP):
    live = ok = 0
    while live < 500:
        k = r.randint(1, 3)
        c = random_chip(sr, r, r.randint(2, 8), k + r.randint(1, 2), k + r.randint(1, 2), 0.3)
        S = summary(sr, c); px, qy = c.p - k, c.q - k
        comp = s_fb(sr, S, k)
        if meq(sr, comp, [row[:qy] for row in S[:px]]): continue
        live += 1; ok += meq(sr, summary(sr, glue_fb(c, k)), comp)
    print(f"{sr.name:22s} live feedback only: flat==composed {ok}/{live}")

# (2) acyclicity ("no combinational loop / no deadlock"): is reach + 1 bit a sufficient summary?
def has_cycle(c):
    G = nx.DiGraph(); G.add_nodes_from(range(c.n)); G.add_edges_from((u, v) for u, v, _ in c.E)
    return not nx.is_directed_acyclic_graph(G)
def fb_cycle_pred(S, cyc, k):   # predicted from summary only
    p, q = len(S), len(S[0]); D = [row[q - k:] for row in S[p - k:]]
    Dplus = mmul(BOOL, D, closure(BOOL, D))
    return cyc or any(Dplus[j][j] for j in range(k))
ok = n = 0
for _ in range(2000):
    k = r.randint(1, 2)
    c = random_chip(BOOL, r, r.randint(2, 7), k + 1, k + 1, 0.25, dag=r.random() < 0.7)
    S = summary(BOOL, c)
    n += 1; ok += (fb_cycle_pred(S, has_cycle(c), k) == has_cycle(glue_fb(c, k)))
print(f"acyclicity after feedback predicted from (reach matrix, 1 cycle bit): {ok}/{n}")
# reach alone is NOT enough: find two chips with same reach matrix, different cycle bit
seen = {}
for _ in range(5000):
    c = random_chip(BOOL, r, 3, 1, 1, 0.4, dag=r.random() < 0.5)
    key = str(summary(BOOL, c)); b = has_cycle(c)
    seen.setdefault(key, set()).add(b)
print("reach matrices shared by cyclic and acyclic chips:", sum(1 for v in seen.values() if len(v) == 2))
