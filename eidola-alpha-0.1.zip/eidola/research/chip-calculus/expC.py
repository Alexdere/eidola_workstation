"""
Card reconstruction for chips.
Structure family (n, P, Q, directed, undirected): n unlabeled internal nodes, P labeled input ports,
Q labeled output ports.  Slots = possible wires.  Isomorphism = permuting internal nodes only
(ports are named in the interface -> stay fixed).  Card = delete one internal node (Ulam deck),
recorded up to isomorphism = 'content hash'.
"""
import itertools, sys, collections
import numpy as np

class Family:
    def __init__(s, n, P=0, Q=0, directed=True):
        s.n, s.P, s.Q, s.directed = n, P, Q, directed
        sl = []
        for i in range(P):
            for v in range(n): sl.append((("i", i), v))
        for u in range(n):
            for v in range(n):
                if u == v: continue
                if not directed and v < u: continue
                sl.append((u, v))
        for v in range(n):
            for o in range(Q): sl.append((v, ("o", o)))
        s.slots = sl; s.idx = {x: k for k, x in enumerate(sl)}; s.B = len(sl)
        s.perm_maps = []
        for pi in itertools.permutations(range(n)):
            m = []
            for a, b in sl:
                a2 = pi[a] if isinstance(a, int) else a
                b2 = pi[b] if isinstance(b, int) else b
                if not directed and isinstance(a2, int) and isinstance(b2, int) and b2 < a2: a2, b2 = b2, a2
                m.append(s.idx[(a2, b2)])
            s.perm_maps.append(m)
        s._canon = None
    def canon_table(s):
        if s._canon is None:
            codes = np.arange(1 << s.B, dtype=np.int64)
            best = codes.copy()
            for m in s.perm_maps[1:]:
                pc = np.zeros_like(codes)
                for b, tb in enumerate(m):
                    pc |= ((codes >> b) & 1) << tb
                np.minimum(best, pc, out=best)
            s._canon = best
        return s._canon

def delete_map(F, Fm, v):
    """slot index map from F to F-minus-v (=Fm); None if slot touches v"""
    ren = lambda x: x if not isinstance(x, int) else (None if x == v else (x - 1 if x > v else x))
    out = []
    for a, b in F.slots:
        a2, b2 = ren(a), ren(b)
        out.append(None if a2 is None or b2 is None else Fm.idx[(a2, b2)])
    return out

def analyse(n, P=0, Q=0, directed=True, summary_fn=None):
    F, Fm = Family(n, P, Q, directed), Family(n - 1, P, Q, directed)
    canF, canFm = F.canon_table(), Fm.canon_table()
    reps = np.unique(canF)
    dmaps = [delete_map(F, Fm, v) for v in range(n)]
    decks = collections.defaultdict(list)
    for g in reps.tolist():
        cards = []
        for dm in dmaps:
            c = 0
            for b, tb in enumerate(dm):
                if tb is not None and (g >> b) & 1: c |= 1 << tb
            cards.append(int(canFm[c]))
        decks[tuple(sorted(cards))].append(g)
    amb = {d: gs for d, gs in decks.items() if len(gs) > 1}
    nonrec = sum(len(gs) for gs in amb.values())
    res = dict(classes=len(reps), decks=len(decks), nonrec=nonrec, amb=amb, F=F)
    if summary_fn:
        # does the deck at least determine the whole chip's port-to-port summary?
        res["summary_amb"] = sum(1 for gs in amb.values() if len({summary_fn(F, g) for g in gs}) > 1)
    return res

def reach_summary(F, g):
    """boolean in->out reachability matrix as a tuple"""
    adj = collections.defaultdict(list)
    for b, (a, c) in enumerate(F.slots):
        if (g >> b) & 1: adj[a].append(c)
    out = []
    for i in range(F.P):
        seen, st = set(), [("i", i)]
        while st:
            x = st.pop()
            for y in adj[x]:
                if y not in seen: seen.add(y); st.append(y)
        out.append(tuple(("o", o) in seen for o in range(F.Q)))
    return tuple(out)

if __name__ == "__main__":
    print("undirected graphs (classical Ulam):")
    for n in range(3, 7):
        R = analyse(n, directed=False)
        print(f"  n={n}: {R['classes']:6d} classes, non-reconstructible {R['nonrec']}")
    print("plain digraphs:")
    for n in range(3, 6):
        R = analyse(n)
        print(f"  n={n}: {R['classes']:6d} classes, {R['decks']:6d} distinct decks, non-reconstructible {R['nonrec']}")
        if n == 5: dig5 = R
    print("chips, 1 labeled input port + 1 labeled output port:")
    for n in range(2, 5):
        R = analyse(n, 1, 1, summary_fn=reach_summary)
        print(f"  n={n}: {R['classes']:6d} classes, {R['decks']:6d} distinct decks, non-reconstructible {R['nonrec']}, "
              f"decks not even fixing the in->out summary {R['summary_amb']}")
    print("chips, 2 inputs + 2 outputs:")
    for n in range(2, 4):
        R = analyse(n, 2, 2, summary_fn=reach_summary)
        print(f"  n={n}: {R['classes']:6d} classes, {R['decks']:6d} distinct decks, non-reconstructible {R['nonrec']}, "
              f"summary-ambiguous decks {R['summary_amb']}")
