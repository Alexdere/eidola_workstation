"""Probes against Elara's own oracle (graphmap 2026-10-14). Run: python3 -I probe_eidola.py <oracle_dir>"""
import sys, random, itertools, time
sys.path.insert(0, sys.argv[1])
from graphmap_oracle import FrameRegistry, flatten, GraphError, prim_unit, unit_id
from graphmap_oracle.model import port, container, pane, wire, graph, IN, OUT

# ============================================================== 1. Law 7: route agreement
def reg(frames, trans, fixtures=(-40, 0, 37, 100), tol=1e-9):
    r = FrameRegistry()
    for f in frames: r.add_frame(f, tol, list(fixtures))
    for (a, b), fn in trans.items(): r.add_transition(a, b, fn)
    return r

def holonomy_check(r):
    """Fundamental-loop check: BFS tree of routes from a root; every transition NOT used by the
    tree carries one obligation  t(route(root->a)(x)) == route(root->b)(x).  Linear in the
    number of transitions; covers round trips and loops of any length."""
    ids = list(r.frames); root = ids[0]
    tree = {root: []}; q = [root]
    while q:
        a = q.pop(0)
        for (f, t) in r.trans:
            if f == a and t not in tree:
                tree[t] = tree[a] + [(f, t)]; q.append(t)
    used = {hop for path in tree.values() for hop in path}
    bad, n_obl = [], 0
    for (a, b), fn in r.trans.items():
        if (a, b) in used or a not in tree or b not in tree: continue
        n_obl += 1
        for x in r.frames[root]["fixtures"]:
            lhs = fn(r.apply(tree[a], x)); rhs = r.apply(tree[b], x)
            if abs(lhs - rhs) > r.frames[b]["tol"]: bad.append(f"{a}->{b}"); break
    return bad, n_obl

C2F = lambda v: v * 9 / 5 + 32; F2C = lambda v: (v - 32) * 5 / 9
C2K = lambda v: v + 273.15; K2C = lambda v: v - 273.15
F2K = lambda v: (v - 32) * 5 / 9 + 273.15; K2F = lambda v: (v - 273.15) * 9 / 5 + 32
WRONG_F2C = lambda v: (v - 30) * 5 / 9          # one wrong constant

cases = {
  "conformance triangle, f->c wrong": reg(["temp.c", "temp.f", "temp.k"],
      {("temp.c","temp.f"): C2F, ("temp.f","temp.c"): WRONG_F2C, ("temp.c","temp.k"): C2K,
       ("temp.k","temp.c"): K2C, ("temp.f","temp.k"): F2K, ("temp.k","temp.f"): K2F}),
  "two frames c<->f, f->c wrong": reg(["temp.c", "temp.f"],
      {("temp.c","temp.f"): C2F, ("temp.f","temp.c"): WRONG_F2C}),
  "hub through kelvin (SI-style), f->k wrong": reg(["temp.c", "temp.f", "temp.k"],
      {("temp.c","temp.k"): C2K, ("temp.k","temp.c"): K2C,
       ("temp.f","temp.k"): lambda v: (v - 30) * 5 / 9 + 273.15, ("temp.k","temp.f"): K2F}),
}
# ring of n scale frames, x10 each step, one step wrong; both directions declared
def ring(n, wrong=True):
    fr = [f"s{i}" for i in range(n)]; tr = {}
    for i in range(n - 1):
        k = 10.0 if not (wrong and i == 2) else 10.5
        tr[(fr[i], fr[i+1])] = (lambda k: lambda v: v * k)(k)
        tr[(fr[i+1], fr[i])] = (lambda k: lambda v: v / k)(k)
    # closing edge: s_{n-1} -> s0 divides by 10^(n-1)
    tr[(fr[n-1], fr[0])] = (lambda n: lambda v: v / 10 ** (n - 1))(n)
    tr[(fr[0], fr[n-1])] = (lambda n: lambda v: v * 10 ** (n - 1))(n)
    return reg(fr, tr, fixtures=(1.0, 2.0), tol=1e-6)
for n in (4, 6, 8, 10, 12): cases[f"ring of {n} frames, one wrong factor (x10.5 on s2->s3 and back)"] = ring(n)

print("== Law 7 · route agreement: shipped check vs fundamental-loop check")
for name, r in cases.items():
    shipped = r.check_route_agreement(); hol, n_obl = holonomy_check(r)
    print(f"  {name:62s} shipped: {'CAUGHT' if shipped else 'missed':6s} | loops: {'CAUGHT' if hol else 'missed':6s} ({n_obl} obligations)")

print("== cost on a complete atlas (every frame converts to every other)")
for n in (4, 6, 8, 10):
    fr = [f"u{i}" for i in range(n)]
    tr = {(a, b): (lambda i, j: lambda v: v * 10 ** (j - i))(int(a[1:]), int(b[1:])) for a in fr for b in fr if a != b}
    r = reg(fr, tr, fixtures=(1.0,), tol=1e-6)
    t0 = time.time(); nroutes = sum(len(r.routes(a, b)) for a in fr for b in fr if a != b); t1 = time.time()
    print(f"  n={n:2d}: shipped enumerates {nroutes:7d} routes (capped at length 4, {t1-t0:.2f}s)   loop check: {holonomy_check(r)[1]} obligations")

# ============================================================== 2. Law 1 / F8: what the seam is missing
units = {}
def add(u): i = unit_id(u); units[i] = u; return i
NEG, ADD, DEL, CONST = (add(prim_unit(o)) for o in ("core.neg", "core.add", "core.delay", "core.const"))
def cports(nin, nout):
    return [port(f"i{k}", "in", "any") for k in range(nin)] + [port(f"o{k}", "out", "any") for k in range(nout)]
def mkpane(uid):
    u = units[uid]
    return pane(uid, mem="m" if any(p.startswith("mem:") for p in u["powers"]) else None)

X = add(container(cports(1, 1), graph({"n": mkpane(NEG)}, [wire((IN, "i0"), ("n", "a")), wire(("n", "out"), (OUT, "o0"))])))
Y = add(container(cports(1, 1), graph({"d": mkpane(DEL)}, [wire((IN, "i0"), ("d", "x")), wire(("d", "out"), (OUT, "o0"))])))
seam = lambda uid: (units[uid]["ports"], units[uid]["powers"], units[uid]["cls"])
print("== Law 1 · two composites with identical seams")
print("  seams identical:", seam(X) == seam(Y))
for nm, U in (("X (neg inside)", X), ("Y (delay inside)", Y)):
    root = graph({"p": mkpane(U)}, [wire(("p", "o0"), ("p", "i0"))])
    try: flatten(root, units, FrameRegistry()); res = "accepted"
    except GraphError as e: res = f"refused ({e})"
    print(f"  wire {nm}'s output back to its input: {res}")

# ---- the seam matrix: instantaneous in->out dependency, computed bottom-up and cached by unit id
MEMO = {}
def seam_matrix(uid):
    if uid in MEMO: return MEMO[uid]
    u = units[uid]; ins = [p["name"] for p in u["ports"] if p["dir"] == "in"]; outs = [p["name"] for p in u["ports"] if p["dir"] == "out"]
    if u["cls"] != "container":
        inst = u["cls"] in ("pure", "effect")
        MEMO[uid] = (True, {(i, o): inst for i in ins for o in outs}); return MEMO[uid]
    ok, R = interior(u["graph"], ins, outs)
    MEMO[uid] = (ok, R); return MEMO[uid]
def interior(g, ins=(), outs=()):
    adj = {}
    def e(a, b): adj.setdefault(a, set()).add(b)
    ok = True
    for occ, pn in g["panes"].items():
        cok, M = seam_matrix(pn["unit"]); ok &= cok
        for (i, o), v in M.items():
            if v: e((occ, i), (occ, o))
    for w in g["wires"]: e(tuple(w["from"]), tuple(w["to"]))
    # cycle?
    state = {}
    def dfs(x):
        state[x] = 1
        for y in adj.get(x, ()):
            s = state.get(y, 0)
            if s == 1: return True
            if s == 0 and dfs(y): return True
        state[x] = 2; return False
    if any(state.get(x, 0) == 0 and dfs(x) for x in list(adj)): ok = False
    R = {}
    for i in ins:
        seen, st = set(), [(IN, i)]
        while st:
            x = st.pop()
            for y in adj.get(x, ()):
                if y not in seen: seen.add(y); st.append(y)
        for o in outs: R[(i, o)] = (OUT, o) in seen
    return ok, R

def rand_graph(r, pool, nin, nout, n_children):
    occs = [f"c{k}" for k in range(n_children)]
    panes_ = {o: mkpane(r.choice(pool)) for o in occs}
    outs_avail = [(o, p["name"]) for o in occs for p in units[panes_[o]["unit"]]["ports"] if p["dir"] == "out"]
    srcs = outs_avail + [(IN, f"i{k}") for k in range(nin)]
    ws = []
    for o in occs:
        for p in units[panes_[o]["unit"]]["ports"]:
            if p["dir"] == "in" and r.random() < 0.8 and srcs: ws.append(wire(r.choice(srcs), (o, p["name"])))
    for k in range(nout):
        if r.random() < 0.9 and srcs: ws.append(wire(r.choice(srcs), (OUT, f"o{k}")))
    return graph(panes_, ws)

def rand_root(r, pool, n):
    occs = [f"r{k}" for k in range(n)]
    panes_ = {o: mkpane(r.choice(pool)) for o in occs}
    srcs = [(o, p["name"]) for o in occs for p in units[panes_[o]["unit"]]["ports"] if p["dir"] == "out"]
    ws = [wire(r.choice(srcs), (o, p["name"])) for o in occs for p in units[panes_[o]["unit"]]["ports"]
          if p["dir"] == "in" and r.random() < 0.7 and srcs]
    return graph(panes_, ws)

r = random.Random(42)
prims = [NEG, ADD, DEL, CONST, NEG, ADD]
L1 = [add(container(cports(ni := r.randint(1, 2), no := r.randint(1, 2)), rand_graph(r, prims, ni, no, r.randint(2, 4)))) for _ in range(40)]
L2 = [add(container(cports(ni := r.randint(1, 2), no := r.randint(1, 2)), rand_graph(r, L1 + prims, ni, no, r.randint(2, 4)))) for _ in range(40)]
agree = n = legal = conservative_refusals = other_err = 0
t_flat = t_seam = 0.0
for _ in range(3000):
    root = rand_root(r, L2 + L1 + prims, r.randint(2, 5))
    t0 = time.time()
    try: flatten(root, units, FrameRegistry()); oracle_ok = True
    except GraphError as e:
        oracle_ok = False
        if "cycle without a delay" not in str(e): other_err += 1
    t1 = time.time(); ok, _ = interior(root); t2 = time.time()
    t_flat += t1 - t0; t_seam += t2 - t1
    n += 1; agree += (ok == oracle_ok); legal += oracle_ok
    if oracle_ok:
        # what a check limited to today's seam (ports, powers, cls) must do: assume every in reaches every out
        saved = dict(MEMO)
        for uid, (cok, M) in list(MEMO.items()):
            if units[uid]["cls"] == "container": MEMO[uid] = (cok, {k: True for k in M})
        cons_ok, _ = interior(root); MEMO.clear(); MEMO.update(saved)
        conservative_refusals += (not cons_ok)
print("== F8 at the seam: legality from cached seam matrices vs the oracle's full flatten")
print(f"  random nested workspaces: {n}  (legal per oracle: {legal}; refusals for other reasons: {other_err})")
print(f"  seam-matrix verdict == oracle verdict: {agree}/{n}")
print(f"  legal workspaces a seam-only check (ports+powers+cls) would wrongly refuse: {conservative_refusals}/{legal}")
print(f"  time: oracle flatten {t_flat:.2f}s total vs seam check {t_seam:.2f}s (matrices cached per unit id: {len(MEMO)} entries)")
