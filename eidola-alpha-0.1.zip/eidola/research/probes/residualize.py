"""Export = specialise the Eidola tick to one fixed form (first Futamura projection, by hand).
Input: a flattened workspace (from the oracle) and a fixed observed set.
Output: plain Python source for `step(journal) -> (values, effects)` with no Eidola runtime:
no store, no hashing, no memo, no liveness pass, no Ctx. Delay folds become incremental
accumulators (F5). Only the source journal is needed for replay (Law 5)."""
import sys

INLINE = {   # op -> expression over helper names; a/b/c/i/x are input vars (None if absent)
    "core.add": "_n(a) + _n(b)", "core.sub": "_n(a) - _n(b)", "core.mul": "_n(a) * _n(b)",
    "core.neg": "-_n(a)", "core.gt": "_n(a) > _n(b)", "core.lt": "_n(a) < _n(b)",
    "core.not": "not _b(a)", "core.and": "_b(a) and _b(b)", "core.or": "_b(a) or _b(b)",
    "core.if": "(a if _b(c) else b)", "core.eq": "same_value(a, b)",
    "core.list2": "[a, b]", "core.abs": "abs(_n(a))",
    "core.min": "_minmax(a, b, True)", "core.max": "_minmax(a, b, False)",
    "core.floor": "_floor(a)",
    "core.len": "(float(len(a)) if isinstance(a, list) else math.nan)",
    "core.at": "_at({'a': a, 'i': i})",
    "core.append": "((list(a) if isinstance(a, list) else []) + [x])",
    "core.concat": "((a if isinstance(a, str) else '') + (b if isinstance(b, str) else ''))",
}

def residualize(engine, observed):
    f = engine.f
    live = engine._live_set(observed)
    sites = f.sites
    var = {}                                    # endpoint -> python variable name
    def v(e):
        if e not in var: var[e] = f"v{len(var)}"
        return var[e]
    L = ["def make():",
         "    logs = {}; accs = {}; last_fx = {}; JOURNAL = []",
         "    def step(journal):",
         "        JOURNAL.append(journal)        # replay needs only this (Law 5)",
         "        out = {}; fx = []; pend = []"]
    I = "        "
    readers = {}                                # mem address -> [(site path, fold kind, config)]
    def addr(path): return engine.mem_address(path, sites[path]["pane"]["mem"])
    # pass 0: sources
    for path, s in sites.items():
        if s["unit"]["cls"] != "source" or path not in live: continue
        k = f"{path}#out"
        L += [f"{I}if {k!r} in journal:", f"{I}    {v(k)} = journal[{k!r}]; out[{k!r}] = {v(k)}",
              f"{I}else:", f"{I}    {v(k)} = ABSENT"]
    # pass A: delay reads -> incremental accumulators
    for path, s in sites.items():
        if s["unit"]["cls"] != "delay" or path not in live: continue
        op = s["unit"]["body"]["op"]; cfg = s["pane"]["config"]; a = addr(path)
        readers.setdefault(a, []).append((path, op, cfg))
        k = f"{path}#out"
        L += [f"{I}{v(k)} = accs.get({path!r}, INIT[{path!r}]); out[{k!r}] = {v(k)}"]
    # pass B: pure + effect bodies, topological, inlined
    def gather(path):
        lines, names = [], {}
        for p in sites[path]["unit"]["ports"]:
            if p["dir"] != "in": continue
            ce = f"{path}#{p['name']}"
            r = f.resolved.get(ce)
            nm = f"{v(ce)}"
            names[p["name"]] = nm
            if r is None:
                lines.append(f"{I}{nm} = ABSENT"); continue
            src = v(r["producer"])
            conv = src if not r["route"] else f"(ROUTE[{ce!r}]({src}) if {src} is not ABSENT else ABSENT)"
            lines.append(f"{I}{nm} = {conv}")
            lines.append(f"{I}if {nm} is not ABSENT: out[{ce!r}] = {nm}")
        return lines, names
    for path in f.order:
        s = sites[path]
        if path not in live or s["unit"]["cls"] not in ("pure", "effect"): continue
        op = s["unit"]["body"]["op"]
        lines, names = gather(path); L += lines
        args = {k: f"(None if {n} is ABSENT else {n})" for k, n in names.items()}
        if s["unit"]["cls"] == "pure":
            k = f"{path}#out"
            if op == "core.const":
                expr = f"CFG[{path!r}]"
            else:
                expr = INLINE[op]
                for name in ("a", "b", "c", "i", "x"):
                    expr = expr.replace(f"_n({name})", f"_n({args.get(name, 'None')})") \
                               .replace(f"_b({name})", f"_b({args.get(name, 'None')})")
                # remaining bare variables
                import re
                expr = re.sub(r"(?<![\w'])([abcix])(?![\w'])", lambda m: args.get(m.group(1), "None"), expr)
            L += [f"{I}{v(k)} = {expr}; out[{k!r}] = {v(k)}"]
        else:   # effect fires when its input map changed (Law 6: it is live only if pinned)
            present = "{" + ", ".join(f"{p!r}: {n}" for p, n in names.items()) + "}"
            L += [f"{I}_i = {{k: w for k, w in {present}.items() if w is not ABSENT}}",
                  f"{I}_sig = canon(_i)",
                  f"{I}if last_fx.get({path!r}) != _sig:",
                  f"{I}    last_fx[{path!r}] = _sig; fx.append(_i.get('x'))"]
    # pass C: delay writes (buffered, same order as the oracle's pass C)
    for path, s in sites.items():
        if s["unit"]["cls"] != "delay" or path not in live: continue
        lines, names = gather(path); L += lines
        L += [f"{I}if {names['x']} is not ABSENT: pend.append(({addr(path)!r}, {names['x']}))"]
    # pass D: commit; update every accumulator that reads the address (incremental fold)
    L += [f"{I}for _a, _x in pend:",
          f"{I}    logs.setdefault(_a, []).append(_x)",
          f"{I}    for _p, _op in READERS.get(_a, ()):",
          f"{I}        accs[_p] = STEP[_op](accs.get(_p, INIT[_p]), _x)",
          f"{I}return out, fx",
          "    return step, JOURNAL"]
    init = {p: (c if op == "core.delay" else (_sum_init(c) if op == "core.sum" else []))
            for rs in readers.values() for (p, op, c) in rs}
    env = dict(INIT=init, READERS={a: [(p, op) for (p, op, _c) in rs] for a, rs in readers.items()},
               CFG={p: s["pane"]["config"] for p, s in sites.items()},
               ROUTE={ce: (lambda route: (lambda x: engine.frames.apply(route, x)))(r["route"])
                      for ce, r in f.resolved.items() if r["route"]})
    return "\n".join(L), env

from graphmap_oracle.prims import _n, _b, _minmax, _floor, _at, _sum_init, _sum_step
from graphmap_oracle.canon import same_value, canon
import math
ABSENT = object()
STEP = {"core.delay": lambda acc, x: x, "core.sum": _sum_step, "core.hist": lambda acc, x: acc + [x]}

def build(engine, observed):
    src, env = residualize(engine, observed)
    g = dict(_n=_n, _b=_b, _minmax=_minmax, _floor=_floor, _at=_at, same_value=same_value,
             canon=canon, math=math, ABSENT=ABSENT, STEP=STEP, **env)
    exec(compile(src, "<exported>", "exec"), g)
    return g["make"](), src
