import sys; sys.path.insert(0, sys.argv[1])
from graphmap_oracle import Engine, load_workspace, graph_hash
from graphmap_oracle.canon import h
def ws(order):
    panes = {"one": {"unit": "core.const", "config": {"d": "3ff0000000000000"}},     # 1.0
             "two": {"unit": "core.const", "config": {"d": "4000000000000000"}},     # 2.0
             "wa":  {"unit": "core.delay", "mem": "m", "pinned": True},
             "wb":  {"unit": "core.delay", "mem": "m", "pinned": True}}
    panes = {k: panes[k] for k in order}
    return {"@": "workspace/1", "units": {"core.const": {"prim": "core.const"}, "core.delay": {"prim": "core.delay"}},
            "root": {"panes": panes, "wires": [[["one", "out"], ["wa", "x"]], [["two", "out"], ["wb", "x"]]]}}
from graphmap_oracle.workspace import from_spec
res = []
for order in (["one", "two", "wa", "wb"], ["one", "two", "wb", "wa"]):
    root, units, _ = load_workspace(ws(order))
    e = Engine(root, units)
    t = [e.tick() for _ in range(3)]
    last = e.blobs[t[2]["sigma"]["wa#out"]]
    res.append((graph_hash(root), t[2]["sigmaHash"], last))
    print(f"pane order {order}: graph hash {res[-1][0][:12]}  tick-2 sigma {res[-1][1][:12]}  shared log's last = {last}")
print("same graph hash:", res[0][0] == res[1][0], "| same sigma:", res[0][1] == res[1][1])
