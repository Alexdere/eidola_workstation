import sys, random, time
sys.path.insert(0, sys.argv[1])
from graphmap_oracle import Engine, load_workspace
from residualize import build
def big(n, rng, n_src=8, p_delay=0.05):
    ops = ["core.add", "core.mul", "core.sub", "core.neg", "core.max", "core.min"]
    units = {o: {"prim": o} for o in ops + ["core.source", "core.delay"]}
    panes, wires, prod = {}, [], []
    for s in range(n_src):
        panes[f"s{s}"] = {"unit": "core.source"}; prod.append(f"s{s}")
    for i in range(n):
        occ = f"u{i:05d}"
        if rng.random() < p_delay:
            panes[occ] = {"unit": "core.delay", "mem": f"m{i}", "config": {"d": "0000000000000000"}}
            wires.append([[rng.choice(prod[-50:]), "out"], [occ, "x"]])
        else:
            op = rng.choice(ops); panes[occ] = {"unit": op}
            for p in (["a"] if op == "core.neg" else ["a", "b"]):
                wires.append([[rng.choice(prod[-50:]), "out"], [occ, p]])
        prod.append(occ)
    return {"@": "workspace/1", "units": units, "root": {"panes": panes, "wires": wires}}
rng = random.Random(1)
for n in (500, 2000, 8000):
    ws = big(n, rng); root, units, _ = load_workspace(ws)
    t0 = time.perf_counter(); e = Engine(root, units); t_flat = time.perf_counter() - t0
    observed = [list(ws["root"]["panes"])[-1]]     # watch the last unit; liveness prunes the rest
    observed = list(ws["root"]["panes"])           # watch everything: worst case for the export comparison
    t0 = time.perf_counter(); (step, _), src = build(e, observed); t_build = time.perf_counter() - t0
    J = [{f"s{s}#out": float(rng.randrange(-5, 6)) for s in range(8)} for _ in range(12)]
    t0 = time.perf_counter()
    for j in J: e.tick(observed=observed, journal=j)
    t_or = (time.perf_counter() - t0) / len(J)
    t0 = time.perf_counter()
    for _ in range(5): e.tick(observed=observed, journal=J[-1])
    t_memo = (time.perf_counter() - t0) / 5
    t0 = time.perf_counter()
    for j in J: step(j)
    t_ex = (time.perf_counter() - t0) / len(J)
    live = len(e.f.sites)
    print(f"n={n:5d} leaves: oracle tick {t_or*1e3:8.1f} ms ({t_or/live*1e6:5.1f} µs/leaf) · same inputs again (memo hits) {t_memo*1e3:7.1f} ms · "
          f"exported step {t_ex*1e3:6.2f} ms ({t_ex/live*1e6:4.2f} µs/leaf) · ratio {t_or/t_ex:5.0f}x · flatten {t_flat*1e3:.0f} ms, export build {t_build*1e3:.0f} ms")
