import sys, time
sys.path.insert(0, sys.argv[1])
from graphmap_oracle import Engine, load_workspace
from residualize import build
panes = {"s": {"unit": "core.source"}}
wires = []
for i in range(40):
    panes[f"acc{i:02d}"] = {"unit": "core.sum", "mem": f"m{i}", "pinned": True}
    wires.append([["s", "out"], [f"acc{i:02d}", "x"]])
ws = {"@": "workspace/1", "units": {"core.source": {"prim": "core.source"}, "core.sum": {"prim": "core.sum"}},
      "root": {"panes": panes, "wires": wires}}
root, units, _ = load_workspace(ws); e = Engine(root, units)
(step, J), _ = build(e, [])
marks = {}
for t in range(3001):
    j = {"s#out": 1.0}
    t0 = time.perf_counter(); e.tick(journal=j); a = time.perf_counter() - t0
    t0 = time.perf_counter(); step(j); b = time.perf_counter() - t0
    if t in (10, 1000, 3000): marks[t] = (a, b)
for t, (a, b) in marks.items():
    print(f"tick {t:4d}: oracle {a*1e3:7.2f} ms · exported {b*1e6:6.1f} µs")
print("running sums agree at tick 3000:", e.blobs[e.tick(journal={'s#out': 1.0})['sigma']['acc00#out']] == step({'s#out': 1.0})[0]['acc00#out'])
