import sys, random
ORACLE = sys.argv[1]; sys.path.insert(0, ORACLE)
from graphmap_oracle import Engine, load_workspace, conformance_frames
from graphmap_oracle.workspace import from_spec
from graphmap_oracle.canon import same_value
import grade
from residualize import build
rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 7)
ok = bad = refused = ticks = 0; first_bad = None
for i in range(int(sys.argv[3]) if len(sys.argv) > 3 else 1000):
    ws = grade.gen_workspace(rng)
    try:
        root, units, _ = load_workspace(ws); e = Engine(root, units, conformance_frames())
    except Exception:
        refused += 1; continue
    occs = list(ws["root"]["panes"]); observed = rng.sample(occs, rng.randrange(len(occs) + 1))
    sources = [o for o, p in ws["root"]["panes"].items() if p["unit"] == "core.source"]
    (step, journal_log), src = build(e, observed)
    good = True
    for t in range(rng.randrange(1, 8)):
        j = {f"{s}#out": from_spec(grade.rand_value(rng)) for s in sources if rng.random() < 0.8}
        r = e.tick(observed=observed, journal=j)
        out, fx = step(j); ticks += 1
        ov = {k: e.blobs[b] for k, b in r["sigma"].items()}
        same = set(ov) == set(out) and all(same_value(ov[k], out[k]) for k in ov) \
               and len(fx) == len(r["effects"]) and all(same_value(a, b) for a, b in zip(fx, r["effects"]))
        if not same:
            good = False
            if first_bad is None: first_bad = (i, t, sorted(set(ov) ^ set(out))[:5], [k for k in ov if k in out and not same_value(ov[k], out[k])][:5])
            break
    ok += good; bad += not good
print(f"workspaces: {ok + bad} run ({refused} refused by the oracle), {ticks} ticks")
print(f"exported plain code reproduces every sigma value and effect: {ok}/{ok + bad}")
if first_bad: print("first mismatch:", first_bad)
