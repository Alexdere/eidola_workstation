# research — the scripts behind docs/5-foundations

Python 3.9+, numpy and networkx for some. Run from this folder's subfolder; scripts that need the
oracle take its path as the first argument.

## chip-calculus/  (2026-11-09)
| script | what it established |
|---|---|
| `chipalg.py` | semiring library: chips, summaries, serial/parallel/feedback gluing, Conway trace |
| `expA*.py` | summaries compose exactly; which properties survive feedback; reach + 1 bit decides loop-freedom |
| `expB*.py` | frame coherence as a semiring; detection only on loops; localisation; series classes |
| `expC*.py` | Ulam decks for digraphs and chips; twins; summary-only cards lose information |
| `detect_bound.py` | fewer than λ wrong conversions are always caught; min-cut re-framings are invisible; anchors |
| `portgraph_recon.py` | reconstruction for port graphs with repeated identical units |

`cd research/chip-calculus && python3 expA.py`  (expB/expC import their siblings by name)

## probes/  (2026-11-09 … 11-12)
| script | what it showed |
|---|---|
| `probe_eidola.py ../../oracle` | Law 7 gaps, the seam leak, seam matrix vs flatten (2979/3000 before alpha-0.1; 3000/3000 since ADR-0004) |
| `order_probe.py ../../oracle` | the insertion-order bug (same hash, different sigma) — now shows equal sigma (ADR-0003) |
| `residualize.py`, `verify_export.py`, `bench.py`, `bench_log.py` | first export prototype; 89×–554× and the history-growth measurement |

Numbers quoted in the docs were produced by these exact scripts.
