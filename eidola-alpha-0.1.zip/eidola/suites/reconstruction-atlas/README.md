# suites/reconstruction-atlas — PLACEHOLDER

The first Eidola suite: structural analysis, graph fingerprints, projection decks, reconstruction.
It lives in the `research-buffer` repository (the `eidola/` tree there). Bring it here once it
imports only the public entry. `research/chip-calculus/expC*.py` and `portgraph_recon.py` are its
mathematical companions (card decks, twins, port-anchored reconstruction).
