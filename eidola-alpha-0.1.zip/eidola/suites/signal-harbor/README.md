# suites/signal-harbor — PLACEHOLDER

Research-grade video search across sources (YouTube Data API, Brave video search, SearXNG),
language/country filters, media inspection through yt-dlp, and search inside transcripts. v0.1 was a
standalone Node app; v0.2 moved its result pipeline (normalise, dedupe, filter, order) into authored
Eidola units. Neither zip is in this tree — copy v0.2 here and port its bridge from the bundled base
internals to `@eidola/core`'s public entry.

Needs from the platform: a node host (API calls and yt-dlp are `net`/`effect` powers), the worker
host for untrusted adapters, and a timestamp frame atlas (seconds, ms, frame index) checked with
`checkLoops()` — a pipeline where offset bugs typically hide.
