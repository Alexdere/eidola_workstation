# suites — applications built on the kernel

A suite brings nodes, lenses, presets, an atlas of frames and a default arrangement. Suites import
only `@eidola/core`'s public entry (ADR-0006). The SDK is extracted from whatever the first two real
suites both demand (STATUS).

| suite | where it is today | status |
|---|---|---|
| `home/` | designed (docs/4-heads-and-tiers) | placeholder |
| `signal-harbor/` | built in a ChatGPT session as v0.1 (standalone) and v0.2 (Eidola suite 02); the zips are not in this tree | placeholder |
| `reconstruction-atlas/` | the first suite, in the `research-buffer` repository on GitHub | placeholder |
