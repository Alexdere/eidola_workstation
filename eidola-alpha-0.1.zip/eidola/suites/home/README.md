# suites/home — PLACEHOLDER

The first suite: clock, feeds, notes, weather, each a sealed prior you can descend into. Its layout
is the "Horizon" the base already borrows. Design: `docs/4-heads-and-tiers/eidola-tiers.md` and
`eidola-001.md`. Needs: a clock source (`emit:clock`), a feed source behind a `net` power (so the
worker host first, or a host-side fetcher that journals), and its lenses.
