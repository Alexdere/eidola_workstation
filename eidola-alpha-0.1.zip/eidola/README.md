# Eidola

**A content-addressed dataflow kernel with a declared boundary.** Units are boundaries with an
interior; any graph of units, given a boundary, is a unit; two things are the same thing exactly
when they are built the same way. Everything a unit may touch is declared on its seam, new
information enters only through declared sources, and nothing runs unless someone downstream is
looking. Eight laws, about 1,400 lines of kernel, no dependencies.

> **Status: open alpha `0.1.0-alpha.0`, no guarantees.** What *is* promised — graded behaviour,
> versioned formats, honest labels — is in [`STATUS.md`](STATUS.md#the-alpha-contract). Two
> decisions are still open before tagging: [`pinned`](docs/adr/0002-pinned-flag-or-power.md) and
> the [license](docs/adr/0009-license.md). Until the worker host exists, **run code you wrote or
> reviewed** ([ADR-0008](docs/adr/0008-alpha-code-policy.md)).

## Try it in one minute

```
open head/dist/eidola-base.html                                   # the base: type `tour`
python3 cli/eidola.py check examples/running-total/workspace.json # derived seams, loops, frames
python3 cli/eidola.py run   examples/running-total/workspace.json --log examples/running-total/log.json --values
python3 cli/eidola.py export examples/running-total/workspace.json --observe total -o step.py
```

More in [`docs/guide/quickstart.md`](docs/guide/quickstart.md).

## What's here

| folder | what | state |
|---|---|---|
| [`spec/`](spec) | CVE/1 (canonical encoding and hash), CORE/1 (units, panes, wires, sigma, the five-pass tick), frozen golden vectors | running |
| [`core/`](core) | `@eidola/core` — the TypeScript kernel. Zero dependencies. Public API in `src/public.ts` | running · 72 claims |
| [`oracle/`](oracle) | an independent Python implementation of the same spec (stdlib only), static conformance, differential grader | running |
| [`grade/`](grade) | metamorphic grader: every transformation the laws call invisible must change nothing, in both cores | running |
| [`head/`](head) | `@eidola/base` — the browser surface, bundled to one HTML file | running · 93 + 39 + 35 + 43 browser checks |
| [`cli/`](cli) | `eidola` check · run · replay · export · grade (Python, over the oracle) | running · TS version is a placeholder |
| [`export/`](export) | plain code out: the tick specialised to one fixed form, no runtime | Python running · JS placeholder |
| [`hosts/`](hosts) | what runs opaque bodies; the sandboxed worker host that makes Laws 4 and 5 structural | **placeholder with requirements** |
| [`library/`](library) | authored units, harness units, ascriptions | placeholder (library lives in `head/src/library.ts` today) |
| [`suites/`](suites) | home · signal-harbor · reconstruction-atlas | placeholders, each saying where the code is and what it needs |
| [`examples/`](examples) | small workspaces for the CLI | running |
| [`research/`](research) | the scripts behind every number in `docs/5-foundations` | reproducible |
| [`docs/`](docs) | quickstart · decision records · the eight laws · architecture · build findings · formal foundations | — |

## The eight laws, in one line each

1. **Boundary** — a unit is a boundary plus an interior; nothing reaches across except through ports.
2. **Closure** — interiors are opaque or are graphs of units; any graph plus a boundary is a unit.
3. **Identity** — same construction (and occurrence names), same unit; the hash represents it.
4. **Authority** — ports are satisfied by wires, powers only by the runtime; no composite binds a power.
5. **Novelty** — every value is a constant, a function of values, or a source's emission at a tick.
6. **Demand** — a unit runs when stale and alive; alive means observed, pinned, or upstream of either.
7. **Frame** — ports carry frames; conversions must agree around every loop.
8. **Gauge** — presentation is not content.

Plain-language introduction: [`docs/1-laws/eight-laws-introduction.md`](docs/1-laws/eight-laws-introduction.md).
The mathematics — the core as the free algebra of a wiring operad, frames as a flat bundle, time as
a covering, and what is proved: [`docs/5-foundations/formal-foundations.md`](docs/5-foundations/formal-foundations.md).

## Why two cores

Identity is content and sigma is a map of hashes, so two independent implementations must tick to
**bit-identical sigma** or one of them is wrong. Grading them against each other forced the
serialisation spec to exist first. Since alpha-0.1 the grading is also **metamorphic**: shuffling
pane order, wire order or unit order must change nothing. That is how the alpha found its one real
bug — two delays sharing memory ticked differently depending on insertion order, under one hash
([ADR-0003](docs/adr/0003-canonical-pass-order.md)).

It proves *agreement*, not *correctness*. Two cores written from one spec share its blind spots,
which is why the base is also driven in a real browser.

## Develop

```
./setup.sh                 # once: npm ci in core/ and head/, plus a Chromium (or set PW_CHROME)
./check.sh                 # types, core claims, frozen vectors, oracle, browser checks,
                           # differential + metamorphic grading, export, CLI
N=1000 SEED=42 ./check.sh  # a longer fuzz run
SPEC_REGEN=1 ./check.sh    # only for a deliberate spec change; review the vector diff
```

Requirements: Node ≥ 18, Python ≥ 3.9 (nothing to install), a Chromium for the browser checks.

Rules of the repo: dependencies point one way (spec → core → hosts/cli/export/base → suites);
suites import only `@eidola/core`'s public entry; a change to a hash, a sigma, or what a workspace
may contain gets a decision record in [`docs/adr/`](docs/adr) first.

## Deliberately not here yet

- **A sandboxed host.** Novelty and Authority are convention for `host/1` bodies until
  `hosts/worker/` exists — the build that unlocks sharing other people's units.
- **Incremental folds (F5)** and **liveness cached per form**: today every tick recomputes
  liveness and every memory read folds the whole log (measured in `docs/5-foundations/build-layer-findings.md`).
- **Higher-order units (F9)** and **frame-relative time (F1)** — still open in a known shape.
- **A license** — [ADR-0009](docs/adr/0009-license.md).
