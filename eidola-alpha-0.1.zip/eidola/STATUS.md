# Where it stands — 2026-11-12 (alpha-0.1)

This uses the four states: **running**, **built but soft**, **designed but unbuilt**, and
**genuinely open**. Every "running" line has a check behind it in `./check.sh`.


## The alpha contract

This is an **open alpha with no guarantees** about theorems — `docs/5-foundations` says which are
proved and under what assumptions. What *is* promised:

1. **Graded behaviour.** Two independent cores (TypeScript, Python) tick every generated workspace
   to bit-identical sigma, reproduce the frozen vectors, and see nothing change under any
   transformation the laws call invisible. `./check.sh` is the contract.
2. **Versioned formats.** Every stored object is tagged (`unit/1`, `workspace/1`, `sigma/1`). If a
   format changes, the version changes and a migration ships with it. Your ids do not silently move.
3. **Honest labels.** Everything below sits in exactly one of four states.

And one rule (ADR-0008): **run code you wrote or reviewed.** `host/1` bodies run unsandboxed until
the worker host exists.

---

## Running

| what | where | proof |
|---|---|---|
| **The kernel.** Canonical encoding and hash (CVE/1), units / panes / wires, flatten, the five-pass tick, powers (with source doors), frames with route agreement, memory scoped by occurrence, liminal (melt · play · declare · collapse), store with lineage and drafts, `workspace/1`, hosts (`JsHost`, `PrimHost`). No vocabulary: no named folds, no default atlas | `core/src` | 67 vitest claims, typechecks clean |
| **The spec and golden vectors.** CVE/1 and CORE/1; 25 canon vectors, 26 unit hashes, 9 tick scenarios | `spec/` | regenerated from the core on every run |
| **The oracle.** An independent Python implementation, static conformance, and differential grading | `oracle/` | bit-identical sigma at every tick (300 workspaces at seed 7; 1000 at seed 42); runs on Python 3.9+ |
| **alpha-0.1 fixes.** Canonical pass order (one hash, one sigma), relay-only loops refused, Law 7 loop obligations (`checkLoops`) | both cores | `core/test/alpha.test.ts`, `oracle/test_oracle.py` — both fail on the 2026-10-14 cores |
| **Frozen vectors + metamorphic grading** | `check.sh`, `grade/metamorphic.py` | 300 scenarios × 3 invisible transformations, both cores |
| **CLI** — check (with derived seams), run, replay, export, grade | `cli/eidola.py` (over the oracle) | smoke-tested in `check.sh` |
| **Export to plain Python** | `export/py/` | reproduces every sigma value and effect of the oracle on the grader's workspaces |
| **Eidola · base.** The minimal surface: omnibar, authored library (no `prim/1` anywhere), author panel, wrap → draft → declare, descend, look-through windows, views (including `inspect`, which replaces the workstation), notes, zoom, undo, persistence of content, values, memory and clock, `dump`/load of WORKSPACE/1, the AI assembly with the key kept as a host secret, and `tour` | `head/src/eidola.ts`, `library.ts`, `host.ts`, `bg.ts` → `dist/eidola-base.html` | 93 walkthrough checks, 39 regression checks, 35 tour checks, 43 audit checks |

## Built but soft

- **The workstation is retired** (`head/legacy/`). It was prim-based and did nothing the base
  cannot; the base's `inspect` view and `dump` box replace it. Kept as a record, still builds.
- **The AI node of the workstation exists only as a hand-patched page.** That is `eidola.html`
  in the claude.ai project (Aug 25): an OpenAI-compatible `core.ai` source with `serviceAI`,
  views and a tools panel, built over the older core. It never went back into `app.ts`, and
  being parked it stays that way. The base has its own AI path (ask/reply), and that one is
  in source and tested.
- **Novelty is convention, not construction.** `JsHost` runs bodies with `new Function`, so a
  body *could* call `Date.now()`. Only a worker or process host makes that impossible. The
  replay test is what catches it today.
- **The oracle grades the machinery over `prim/1` bodies only.** Authored `host/1` (JS) bodies
  are graded within one language, by design: code is a blob, so cross-language identity is
  forbidden.
- **Persistence is localStorage.** The base saves its whole session (content and presentation
  kept apart, the key stripped). IndexedDB, OPFS and yjs drivers are unbuilt, and the
  persistence port is synchronous while IndexedDB is not.
- **`npm audit` flags the pinned esbuild (≤ 0.24) and vitest (≤ 4).** Both advisories are
  about their dev servers, and nothing here runs one: esbuild only bundles, and vitest only
  runs tests. The fix is a major-version bump, left for a deliberate upgrade.
- **Pinned is a flag, not a power.** The laws call it a power (Law 4); the build stores it on
  the pane, so pinning moves the hash. It needs a decision: content on the boundary, or a
  request to the runtime that is not hashed.
- **Undo across a reused name.** If a deleted pane's name is reused and both steps are undone,
  undo restores the more recent history, not the older one.
- **The root is still a declared workspace.** Wraps produce real drafts (`draft:N` tickets,
  provisional until declared), but the top surface itself is not liminal yet.

## Designed but unbuilt

- **alpha placeholders, each with its requirements:** `hosts/worker/` (the Floor by construction),
  `export/js/`, `cli/ts/`, `library/` (harness units, ascriptions), `suites/home`,
  `suites/signal-harbor`, `suites/reconstruction-atlas`.
- **Home.** The first suite (its layout is the "Horizon" the base borrows): clock, feeds, notes, weather, each a
  sealed prior you can descend into.
- **A worker ExecutionPort**, which makes Novelty structural. Its no-smuggling proof is the
  same replay test.
- **Persistence drivers:** yjs graph tier, idb cache, opfs corpus.
- **Suites:** graphmap (MapLibre / PMTiles; space, time, relation) and Closure (audio,
  "hear it while writing it").
- **The SDK and rendering contract.** To be extracted from whatever two real suites both
  demand, not designed first.
- **A Rust core for the T2 daemon.** Only once a concrete daemon workload outruns Python
  (`docs/2-architecture/core-implementations.md`).

## Genuinely open

- **ADR-0002 · `pinned`** — content or runtime request; decide before tagging 0.1 (it moves hashes).
- **ADR-0009 · license** — none yet; the alpha cannot be *open* without one.
- **F1 · frame-relative time.** No per-object local oscillator against a master tick. Still the
  one place the core is open in a known shape.
- **F5 · incremental folds.** Memory reads must be monoid homomorphisms; `memFold` still
  recomputes over the whole log.
- **F9 · higher-order units.** A port carrying a unit id.
- **F6 · a single-writer lint** for memory addresses.
- **Composite-level memoisation.** Today memoisation is at leaf granularity only.
- **The primitive table's boundary.** Now that behaviour is authored, what (if anything) stays
  as shared ground that two languages must agree on?

---

## Housekeeping in the claude.ai project (not done; your call)

- `liminal and head v0.1` (no extension, Aug 23) is a duplicate of
  `claude/liminal-and-head-v0.1.md` (Aug 22). The text is identical.
- `eidola.html` is the AI-node workstation page described above. It is worth keeping as a
  record, but it is not built from any source.
- `claude/eidola-tiers.md` and `claude/eidola-001.md` describe the base's persistence
  as "presentation only, graph reseeds". That is no longer true: the graph survives a reload
  (verify2).
