# library — authored units (PLACEHOLDER as a folder)

Behaviour lives in the library, never the kernel (`docs/4-heads-and-tiers/generated-from-core.md`).
Today the authored library lives in `head/src/library.ts` (precompiled into
`head/src/library.compiled.ts` on build). It moves here when a second consumer needs it.

**Planned contents**
- `units/` — authored leaves and composites as `workspace/1` fragments, so they can be loaded by the
  base, the CLI and suites alike.
- `harness/` — harness units: one-hole contexts that wrap a unit (an endpoint adapter, a legacy-code
  wrapper). They are authoring-time functions on forms, so they add no interior kind (Law 2).
  Harnesses that rebind powers (a transaction around db access) are effect handlers and belong at
  the floor (build-layer-findings §4).
- **ascriptions** — the two-layer pattern: raw pasted code inside, a declared upper bound on its
  seam outside, checked as derived ⊑ ascribed and reported as the trust surface
  (build-layer-findings §1). Not built.
