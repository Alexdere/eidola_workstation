# grade — what keeps two cores honest

- `../oracle/grade.py` — **differential**: random workspaces and journals through both cores,
  sigma compared at every tick.
- `metamorphic.py` — **metamorphic** (ADR-0007): every transformation the laws call invisible
  (pane order, wire order, unit order) must leave graph hash, unit ids, sigma and effects unchanged,
  in both cores. On the 2026-10-14 cores it found 10 violations in 300 scenarios (ADR-0003); since
  alpha-0.1 it is green.

Both run in `../check.sh`. Ideas for the next transformations: occurrence renaming under canonical
naming (if ADR-0001 is ever revisited), layout changes in the base (Law 8), melt→declare round trips.
