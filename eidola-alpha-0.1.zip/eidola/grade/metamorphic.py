"""Metamorphic grading: the laws name transformations that must be invisible. Apply each one to
a generated scenario and assert that both cores see nothing change: same graph hash, same unit
ids, same sigma hash at every tick, same effects, same refusal.

Invisible by Law 3 / Law 8 and CORE/1:
  * pane insertion order   (panes is a map; maps are canonically ordered)
  * wire order             (wires are sorted before hashing)
  * unit declaration order (the units table is a map of local names)

    python3 grade/metamorphic.py -n 300 --seed 7            # oracle only
    python3 grade/metamorphic.py -n 300 --seed 7 --core     # oracle and the TS core
"""
from __future__ import annotations

import argparse
import copy
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "oracle"))
from grade import gen_scenario          # noqa: E402  (the differential grader's generator)
from run import run_scenario            # noqa: E402


def _shuffle_map(m: dict, rng: random.Random) -> dict:
    ks = list(m)
    rng.shuffle(ks)
    return {k: m[k] for k in ks}


def _shuffle_graph(g: dict, rng: random.Random) -> dict:
    g = dict(g)
    g["panes"] = _shuffle_map(g["panes"], rng)
    g["wires"] = list(g["wires"])
    rng.shuffle(g["wires"])
    return g


def transform(s: dict, rng: random.Random) -> dict:
    s = copy.deepcopy(s)
    ws = s["workspace"]
    ws["root"] = _shuffle_graph(ws["root"], rng)
    units = {}
    for name, u in _shuffle_map(ws["units"], rng).items():
        if "container" in u:
            u = copy.deepcopy(u)
            u["container"]["graph"] = _shuffle_graph(u["container"]["graph"], rng)
        units[name] = u
    ws["units"] = units
    s["name"] += "~"
    return s


def observable(r: dict) -> dict:
    return {
        "error": bool(r.get("error")),
        "graphHash": r["graphHash"],
        "unitIds": r["unitIds"],
        "ticks": [(t["sigmaHash"], json.dumps(t["effects"], sort_keys=True)) for t in r["ticks"]],
    }


def run_core(scenarios: list[dict]) -> list[dict]:
    proc = subprocess.run(["npx", "tsx", "tools/run.ts"], cwd=ROOT / "core",
                          input=json.dumps({"scenarios": scenarios}), capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-2000:])
    return json.loads(proc.stdout)["results"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("-n", type=int, default=200)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--variants", type=int, default=3)
    ap.add_argument("--core", action="store_true", help="also grade the TS core")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    base = [gen_scenario(rng, i) for i in range(args.n)]
    variants = [[transform(s, rng) for _ in range(args.variants)] for s in base]
    flat = [s for group in variants for s in group]

    engines = {"oracle": (lambda ss: [run_scenario(s) for s in ss])}
    if args.core:
        engines["core"] = run_core

    bad = 0
    for name, runner in engines.items():
        b = runner(base)
        v = runner(flat)
        for i, s in enumerate(base):
            ref = observable(b[i])
            for j in range(args.variants):
                got = observable(v[i * args.variants + j])
                if got != ref:
                    bad += 1
                    if bad <= 5:
                        what = [k for k in ref if ref[k] != got[k]]
                        print(f"  {name}: {s['name']} variant {j}: differs in {what}")
        print(f"{name}: {args.n} scenarios x {args.variants} invisible transformations checked")
    print("metamorphic: all green" if not bad else f"metamorphic: {bad} violation(s)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
