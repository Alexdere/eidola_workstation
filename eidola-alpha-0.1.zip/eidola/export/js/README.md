# export/js — PLACEHOLDER

The product version of export: TypeScript next to `@eidola/core`, emitting an ES module with a
`step(journal)` function, graded by the same harness as `export/py/verify.py` (run both cores and
the export, compare sigma per tick).

**Needed**
- port `export/py/eidola_export.py` (about 200 lines): inline expressions for the primitive
  table, `host/1` bodies emitted as-is (JS host code *is* exportable to JS), conformance or suite
  atlas transitions;
- keep effects gated on input change (Law 6), and keep the source journal;
- a `--keep` flag per seam for what to leave in at runtime: contract checks, memo, journaling
  (the selective-residualisation spectrum, build-layer-findings §2).

Prior art worth reading first: Lustre/SCADE modular code generation (Biernacki, Colaço, Hamon,
Pouzet 2008).
