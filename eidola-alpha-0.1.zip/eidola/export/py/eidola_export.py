"""eidola export (Python target) — residualise the tick for one fixed form.

The exported module is plain Python: no store, no hashing of values, no memo table, no
liveness pass, no capability context. What it keeps:

  * the five-pass order, specialised to straight-line code in canonical path order (ADR-0003)
  * Law 6, fixed at export time: only units live for the chosen observed set are emitted, so an
    unpinned effect never fires
  * delays as incremental accumulators (F5), not folds over the whole log
  * the source journal, which is all replay needs (Law 5; docs/5-foundations Thm 3)

What it drops: enforcement (the floor), memoisation, hot swap, and the ability to change the
observed set without re-exporting. It reproduces every sigma value and effect of the oracle on
the grader's workspaces (export/py/verify.py).

    python3 export/py/eidola_export.py workspace.json --observe a,b -o app_step.py
"""
from __future__ import annotations

import argparse
import inspect
import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "oracle"))

from graphmap_oracle import Engine, load_workspace, conformance_frames            # noqa: E402
from graphmap_oracle import prims as _prims                                        # noqa: E402
import importlib                                                                   # noqa: E402
_canon = importlib.import_module("graphmap_oracle.canon")   # the module, not the re-exported function

INLINE = {
    "core.add": "_n(a) + _n(b)", "core.sub": "_n(a) - _n(b)", "core.mul": "_n(a) * _n(b)",
    "core.neg": "-_n(a)", "core.gt": "_n(a) > _n(b)", "core.lt": "_n(a) < _n(b)",
    "core.not": "not _b(a)", "core.and": "_b(a) and _b(b)", "core.or": "_b(a) or _b(b)",
    "core.if": "(a if _b(c) else b)", "core.eq": "same_value(a, b)",
    "core.list2": "[a, b]", "core.abs": "abs(_n(a))",
    "core.min": "_minmax(a, b, True)", "core.max": "_minmax(a, b, False)",
    "core.floor": "_floor(a)",
    "core.len": "(float(len(a)) if isinstance(a, list) else math.nan)",
    "core.at": "_at({'a': a, 'i': i})",
    "core.append": "((list(a) if isinstance(a, list) else []) + [x])",
    "core.concat": "((a if isinstance(a, str) else '') + (b if isinstance(b, str) else ''))",
}

# the v1 conformance atlas, as source. A suite atlas would be supplied the same way (TODO in
# export/README.md: --atlas module:function).
CONFORMANCE_TRANSITIONS = {
    ("temp.c", "temp.f"): "lambda v: _n(v) * 9 / 5 + 32",
    ("temp.f", "temp.c"): "lambda v: (_n(v) - 32) * 5 / 9",
    ("temp.c", "temp.k"): "lambda v: _n(v) + 273.15",
    ("temp.k", "temp.c"): "lambda v: _n(v) - 273.15",
    ("temp.f", "temp.k"): "lambda v: (_n(v) - 32) * 5 / 9 + 273.15",
    ("temp.k", "temp.f"): "lambda v: (_n(v) - 273.15) * 9 / 5 + 32",
}


def lit(v) -> str:
    """A Python literal for a value of the CVE/1 universe."""
    if isinstance(v, float):
        if math.isnan(v):
            return "math.nan"
        if math.isinf(v):
            return "math.inf" if v > 0 else "-math.inf"
        return repr(v)
    if v is None or isinstance(v, (bool, int, str, bytes)):
        return repr(v)
    if isinstance(v, list):
        return "[" + ", ".join(lit(x) for x in v) + "]"
    if isinstance(v, tuple):
        return "(" + "".join(lit(x) + ", " for x in v) + ")"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{lit(k)}: {lit(x)}" for k, x in v.items()) + "}"
    raise TypeError(f"no literal for {type(v).__name__}")


def residual(engine: Engine, observed: list[str]):
    """Returns (source of make(), data tables) for the fixed form held by `engine`."""
    f = engine.f
    live = engine._live_set(observed)
    order = sorted(f.sites)                       # ADR-0003: canonical path order
    var: dict[str, str] = {}

    def v(e: str) -> str:
        if e not in var:
            var[e] = f"v{len(var)}"
        return var[e]

    def addr(path: str):
        return engine.mem_address(path, f.sites[path]["pane"]["mem"])

    I = "        "
    L = ["def make():",
         "    logs = {}; accs = {}; last_fx = {}; JOURNAL = []",
         "    def step(journal):",
         f"{I}JOURNAL.append(journal)   # replay needs only this (Law 5)",
         f"{I}out = {{}}; fx = []; pend = []"]
    readers: dict[str, list] = {}
    routes: dict[str, list] = {}

    for path in order:                                         # pass 0
        s = f.sites[path]
        if s["unit"]["cls"] != "source" or path not in live:
            continue
        k = f"{path}#out"
        L += [f"{I}if {k!r} in journal:", f"{I}    {v(k)} = journal[{k!r}]; out[{k!r}] = {v(k)}",
              f"{I}else:", f"{I}    {v(k)} = ABSENT"]
    for path in order:                                         # pass A
        s = f.sites[path]
        if s["unit"]["cls"] != "delay" or path not in live:
            continue
        readers.setdefault(addr(path), []).append((path, s["unit"]["body"]["op"], s["pane"]["config"]))
        k = f"{path}#out"
        L += [f"{I}{v(k)} = accs.get({path!r}, INIT[{path!r}]); out[{k!r}] = {v(k)}"]

    def gather(path):
        lines, names = [], {}
        for p in f.sites[path]["unit"]["ports"]:
            if p["dir"] != "in":
                continue
            ce = f"{path}#{p['name']}"
            nm = v(ce)
            names[p["name"]] = nm
            r = f.resolved.get(ce)
            if r is None:
                lines.append(f"{I}{nm} = ABSENT")
                continue
            src = v(r["producer"])
            if r["route"]:
                routes[ce] = [tuple(h) for h in r["route"]]
                lines.append(f"{I}{nm} = _route({ce!r}, {src}) if {src} is not ABSENT else ABSENT")
            else:
                lines.append(f"{I}{nm} = {src}")
            lines.append(f"{I}if {nm} is not ABSENT: out[{ce!r}] = {nm}")
        return lines, names

    for path in f.order:                                       # pass B (topological)
        s = f.sites[path]
        if path not in live or s["unit"]["cls"] not in ("pure", "effect"):
            continue
        op = s["unit"]["body"]["op"]
        lines, names = gather(path)
        L += lines
        args = {k: f"(None if {n} is ABSENT else {n})" for k, n in names.items()}
        if s["unit"]["cls"] == "pure":
            k = f"{path}#out"
            if op == "core.const":
                expr = f"CFG[{path!r}]"
            else:
                expr = re.sub(r"(?<![\w'])([abcix])(?![\w'])",
                              lambda m: args.get(m.group(1), "None"), INLINE[op])
            L += [f"{I}{v(k)} = {expr}; out[{k!r}] = {v(k)}"]
        else:                                                  # effect: fires when its inputs change
            present = "{" + ", ".join(f"{p!r}: {n}" for p, n in names.items()) + "}"
            L += [f"{I}_i = {{k: w for k, w in {present}.items() if w is not ABSENT}}",
                  f"{I}_sig = canon(_i)",
                  f"{I}if last_fx.get({path!r}) != _sig:",
                  f"{I}    last_fx[{path!r}] = _sig; fx.append(_i.get('x'))"]
    for path in order:                                         # pass C
        s = f.sites[path]
        if s["unit"]["cls"] != "delay" or path not in live:
            continue
        lines, names = gather(path)
        L += lines
        L += [f"{I}if {names['x']} is not ABSENT: pend.append(({addr(path)!r}, {names['x']}))"]
    L += [f"{I}for _a, _x in pend:                       # pass D: commit",
          f"{I}    logs.setdefault(_a, []).append(_x)",
          f"{I}    for _p, _op in READERS.get(_a, ()):",
          f"{I}        accs[_p] = STEP[_op](accs.get(_p, INIT[_p]), _x)",
          f"{I}return out, fx",
          "    return step, JOURNAL"]

    init = {p: (c if op == "core.delay" else (_prims._sum_init(c) if op == "core.sum" else []))
            for rs in readers.values() for (p, op, c) in rs}
    data = {"INIT": init,
            "READERS": {a: [(p, op) for (p, op, _c) in rs] for a, rs in readers.items()},
            "CFG": {p: f.sites[p]["pane"]["config"] for p in order
                    if f.sites[p]["unit"]["cls"] == "pure" and f.sites[p]["unit"]["body"]["op"] == "core.const"},
            "ROUTES": routes}
    return "\n".join(L), data


def _strip_module_header(src: str) -> str:
    out = []
    for line in src.splitlines():
        if line.startswith("from __future__") or line.startswith("from typing"):
            continue
        out.append(line)
    return "\n".join(out)


def emit_module(engine: Engine, observed: list[str], name: str = "workspace") -> str:
    body, data = residual(engine, observed)
    helpers = "\n\n".join(inspect.getsource(getattr(_prims, fn)) for fn in
                          ("_n", "_b", "_is_num", "_sum_init", "_sum_step", "_minmax", "_floor", "_at"))
    missing = {hop for hops in data["ROUTES"].values() for hop in hops} - set(CONFORMANCE_TRANSITIONS)
    if missing:
        raise SystemExit(f"export: frame transitions outside the conformance atlas: {sorted(missing)} "
                         "(suite atlases are not exportable yet — see export/README.md)")
    trans = ",\n    ".join(f"{k!r}: {src}" for k, src in CONFORMANCE_TRANSITIONS.items())
    return "\n".join([
        f'"""Exported from Eidola: {name}. Plain Python, no Eidola runtime.',
        f"Observed set fixed at export: {observed!r}.",
        "Usage: step, journal_log = make();  values, effects = step({'src#out': value})",
        '"""',
        "import hashlib, math, struct",
        "from typing import Any",
        "",
        "# ---- CVE/1 canonical encoding (only used to decide whether an effect's inputs changed)",
        _strip_module_header(inspect.getsource(_canon)).split('"""', 2)[-1],
        "",
        "# ---- primitive-table semantics (spec/CORE-FORMAT.md §6)",
        helpers,
        "",
        "ABSENT = object()",
        "STEP = {'core.delay': lambda acc, x: x, 'core.sum': _sum_step, 'core.hist': lambda acc, x: acc + [x]}",
        f"TRANSITIONS = {{\n    {trans}\n}}",
        f"ROUTES = {lit(data['ROUTES'])}",
        "def _route(ce, x):",
        "    for hop in ROUTES[ce]:",
        "        x = TRANSITIONS[hop](x)",
        "    return x",
        f"INIT = {lit(data['INIT'])}",
        f"READERS = {lit(data['READERS'])}",
        f"CFG = {lit(data['CFG'])}",
        "",
        body,
        "",
    ])


def main() -> int:
    ap = argparse.ArgumentParser(description="export a workspace/1 file to a plain Python step function")
    ap.add_argument("workspace")
    ap.add_argument("--observe", default="", help="comma-separated root occurrences to keep live")
    ap.add_argument("-o", "--out", default="-")
    a = ap.parse_args()
    ws = json.load(open(a.workspace))
    root, units, _ = load_workspace(ws)
    e = Engine(root, units, conformance_frames())
    observed = [x for x in a.observe.split(",") if x]
    src = emit_module(e, observed, Path(a.workspace).stem)
    if a.out == "-":
        sys.stdout.write(src)
    else:
        Path(a.out).write_text(src)
        print(f"wrote {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
