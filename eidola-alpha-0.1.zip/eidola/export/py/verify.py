"""Export conformance: the standalone exported module must reproduce every sigma value and every
effect the oracle produces, tick by tick, on the differential grader's random workspaces.

    python3 export/py/verify.py -n 600 --seed 7
"""
import argparse, random, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(HERE), str(ROOT / "oracle")]
from graphmap_oracle import Engine, load_workspace, conformance_frames   # noqa: E402
from graphmap_oracle.workspace import from_spec                         # noqa: E402
from graphmap_oracle.canon import same_value                            # noqa: E402
import grade                                                            # noqa: E402
from eidola_export import emit_module                                   # noqa: E402

ap = argparse.ArgumentParser(); ap.add_argument("-n", type=int, default=600); ap.add_argument("--seed", type=int, default=7)
a = ap.parse_args()
rng = random.Random(a.seed)
ok = bad = refused = ticks = 0
for i in range(a.n):
    ws = grade.gen_workspace(rng)
    try:
        root, units, _ = load_workspace(ws); e = Engine(root, units, conformance_frames())
    except Exception:
        refused += 1; continue
    occs = list(ws["root"]["panes"]); observed = rng.sample(occs, rng.randrange(len(occs) + 1))
    sources = [o for o, p in ws["root"]["panes"].items() if p["unit"] == "core.source"]
    g = {"__name__": "exported"}
    exec(compile(emit_module(e, observed, f"fuzz-{i}"), f"<fuzz-{i}>", "exec"), g)
    step, _journal = g["make"]()
    good = True
    for t in range(rng.randrange(1, 8)):
        j = {f"{s}#out": from_spec(grade.rand_value(rng)) for s in sources if rng.random() < 0.8}
        r = e.tick(observed=observed, journal=j); out, fx = step(j); ticks += 1
        ov = {k: e.blobs[b] for k, b in r["sigma"].items()}
        if not (set(ov) == set(out) and all(same_value(ov[k], out[k]) for k in ov)
                and len(fx) == len(r["effects"]) and all(same_value(x, y) for x, y in zip(fx, r["effects"]))):
            good = False; break
    ok += good; bad += not good
print(f"export: {ok + bad} workspaces ({refused} refused), {ticks} ticks — exported code reproduces sigma and effects in {ok}/{ok + bad}")
sys.exit(1 if bad else 0)
