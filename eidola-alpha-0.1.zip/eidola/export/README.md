# export — plain code out

`eidola export` residualises the tick for one fixed form: straight-line code in canonical pass
order, Law 6 fixed at export time, delays as incremental accumulators, the source journal kept for
replay. It drops enforcement, memoisation, hot swap and a changeable observed set
(`docs/5-foundations/build-layer-findings.md` §2).

| target | status | verified |
|---|---|---|
| `py/` | **running** | `py/verify.py`: reproduces every sigma value and effect of the oracle on the grader's workspaces |
| `js/` | **placeholder** | — |

Limits of the Python target: `prim/1` bodies only (host code is language-locked — README finding
1); frame transitions only from the conformance atlas (a suite atlas needs `--atlas module:fn`, not
built); one fixed observed set per export.
