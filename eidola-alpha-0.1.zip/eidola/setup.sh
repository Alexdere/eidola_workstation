#!/usr/bin/env bash
# One-time setup: install the pinned dev dependencies and a browser for the head checks.
# Needs node ≥ 18 and npm. Python needs nothing installed (the oracle is stdlib only, ≥ 3.9).
set -euo pipefail
cd "$(dirname "$0")"

echo "=== core: npm ci (typescript, vitest, tsx) ==="
(cd core && npm ci)

echo "=== head: npm ci (esbuild, typescript, playwright) ==="
(cd head && npm ci)

if [ -z "${PW_CHROME:-}" ]; then
  echo "=== head: a Chromium for the browser checks ==="
  (cd head && npx playwright install chromium)
fi

echo
echo "ready — run ./check.sh"
