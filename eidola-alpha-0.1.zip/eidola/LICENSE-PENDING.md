# No license yet

This tree carries no license, so nobody else may legally use, copy or modify it. That is the one
thing that stops the alpha from being *open*. See `docs/adr/0009-license.md` for the options; add a
`LICENSE` file at the root and a `license` field in each `package.json` once decided.
