# cli — `eidola`

`eidola.py` is the alpha CLI: Python 3.9+, stdlib only, built over the oracle (the reference core).

    python3 cli/eidola.py check  examples/running-total/workspace.json
    python3 cli/eidola.py run    examples/running-total/workspace.json --log examples/running-total/log.json --values
    python3 cli/eidola.py replay WS.json --log LOG.json --expect RUN.json
    python3 cli/eidola.py export WS.json --observe total -o step.py
    python3 cli/eidola.py grade  -n 200 --core

`check` reports well-formedness, the **derived seam** of every container (powers inside, purity,
same-tick input→output paths, undelayed loops — computed from content, cached by unit id, no ninth
law) and the frame loop obligations.

`ts/` is a placeholder for the same commands over `@eidola/core`, so that `host/1` JavaScript bodies
can run from the command line (the oracle runs `prim/1` bodies only).
