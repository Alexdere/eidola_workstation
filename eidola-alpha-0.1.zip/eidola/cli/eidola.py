#!/usr/bin/env python3
"""eidola — the alpha command line. Python, stdlib only, built over the oracle (the reference
core). A TypeScript CLI over @eidola/core is planned (cli/README.md).

    eidola check  WS.json                     well-formedness + derived seams + frame loops
    eidola run    WS.json [--log LOG.json]    tick it; print sigma hash, effects, observed values
    eidola replay WS.json --log LOG.json --expect RUN.json   replay and compare sigma hashes
    eidola export WS.json --observe a,b -o step.py           plain Python, no Eidola runtime
    eidola grade  [-n N] [--core]             differential + metamorphic grading

WS.json is a workspace/1 file (what the base's `dump` produces). LOG.json is a list of ticks,
each {"observed": [...], "journal": {"occ#out": <VSpec>}} — the scenario log format of spec/vectors.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "oracle"), str(ROOT / "export" / "py")]

from graphmap_oracle import Engine, GraphError, conformance_frames, graph_hash, load_workspace  # noqa: E402
from graphmap_oracle.model import IN, OUT                                                        # noqa: E402
from graphmap_oracle.workspace import from_spec, to_spec                                         # noqa: E402


# ------------------------------------------------------------------ derived seams
# The facts Law 1 says the boundary should tell you, computed bottom-up and cached by unit id
# (docs/5-foundations Thm 1, Thm 2, Prop 1.2). They are derived, not declared: no ninth law.

class Seams:
    def __init__(self, units: dict):
        self.units = units
        self.memo: dict[str, dict] = {}

    def of(self, uid: str) -> dict:
        if uid in self.memo:
            return self.memo[uid]
        u = self.units[uid]
        ins = [p["name"] for p in u["ports"] if p["dir"] == "in"]
        outs = [p["name"] for p in u["ports"] if p["dir"] == "out"]
        if u["cls"] != "container":
            inst = u["cls"] in ("pure", "effect")
            s = {"powers": set(u["powers"]), "pure": u["cls"] == "pure",
                 "dep": {(i, o) for i in ins for o in outs} if inst else set(),
                 "loop": False, "leaves": 1}
        else:
            s = self._interior(u["graph"], ins, outs)
        self.memo[uid] = s
        return s

    def _interior(self, g: dict, ins=(), outs=()) -> dict:
        adj: dict = {}
        powers, pure, leaves, loop = set(), True, 0, False
        for occ, pn in g["panes"].items():
            c = self.of(pn["unit"])
            powers |= c["powers"]; pure &= c["pure"]; leaves += c["leaves"]; loop |= c["loop"]
            for (i, o) in c["dep"]:
                adj.setdefault((occ, i), set()).add((occ, o))
        for w in g["wires"]:
            adj.setdefault(tuple(w["from"]), set()).add(tuple(w["to"]))
        state: dict = {}

        def cyc(x) -> bool:
            state[x] = 1
            for y in adj.get(x, ()):
                if state.get(y) == 1 or (state.get(y) is None and cyc(y)):
                    return True
            state[x] = 2
            return False
        loop |= any(state.get(x) is None and cyc(x) for x in list(adj))
        dep = set()
        for i in ins:
            seen, st = set(), [(IN, i)]
            while st:
                for y in adj.get(st.pop(), ()):
                    if y not in seen:
                        seen.add(y); st.append(y)
            dep |= {(i, o) for o in outs if (OUT, o) in seen}
        return {"powers": powers, "pure": pure, "dep": dep, "loop": loop, "leaves": leaves}

    def root(self, g: dict) -> dict:
        return self._interior(g)


def _load(path: str):
    ws = json.load(open(path))
    root, units, ids = load_workspace(ws)
    return ws, root, units, ids


def cmd_check(a) -> int:
    ws, root, units, ids = _load(a.workspace)
    frames = conformance_frames()
    print(f"workspace  {a.workspace}")
    print(f"graph hash {graph_hash(root)}")
    try:
        Engine(root, units, frames)
        print("well-formed  yes (rule 1–8 of CORE/1 §2)")
        ok = True
    except GraphError as e:
        print(f"well-formed  NO — {e}")
        ok = False
    seams = Seams(units)
    print("\nderived seams (computed from content, cached by unit id):")
    for name, uid in sorted(ids.items()):
        u = units[uid]
        if u["cls"] != "container":
            continue
        s = seams.of(uid)
        dep = ", ".join(f"{i}→{o}" for i, o in sorted(s["dep"])) or "none"
        print(f"  {name:20s} leaves {s['leaves']:3d} · pure {str(s['pure']).lower():5s} · "
              f"powers inside {sorted(s['powers']) or '[]'} · same-tick paths {dep}"
              + (" · UNDELAYED LOOP INSIDE" if s["loop"] else ""))
    r = seams.root(root)
    print(f"  {'(root)':20s} leaves {r['leaves']:3d} · pure {str(r['pure']).lower():5s} · "
          f"powers inside {sorted(r['powers']) or '[]'}" + (" · UNDELAYED LOOP" if r["loop"] else ""))
    loops = frames.check_loops()
    print(f"\nframes (conformance atlas): loop obligations {'hold' if not loops else 'BROKEN'}")
    for b in loops[:10]:
        print("  ", b)
    return 0 if ok and not loops else 1


def _log(path: str | None) -> list[dict]:
    if not path:
        return [{}]
    return json.load(open(path))


def _run(a):
    ws, root, units, ids = _load(a.workspace)
    e = Engine(root, units, conformance_frames())
    out = []
    for step in _log(a.log):
        j = {k: from_spec(v) for k, v in (step.get("journal") or {}).items()}
        r = e.tick(observed=step.get("observed"), journal=j)
        out.append({"tick": r["tick"], "sigmaHash": r["sigmaHash"],
                    "effects": [to_spec(x) for x in r["effects"]],
                    "values": {k: to_spec(e.blobs[b]) for k, b in sorted(r["sigma"].items())
                               if k.endswith("#out")}})
    return out


def cmd_run(a) -> int:
    for t in _run(a):
        print(f"tick {t['tick']}  sigma {t['sigmaHash'][:16]}  effects {t['effects']}")
        if a.values:
            for k, v in t["values"].items():
                print(f"    {k:28s} {from_spec(v)!r}")
    if a.save:
        Path(a.save).write_text(json.dumps(_run(a), indent=1))
        print(f"saved {a.save}")
    return 0


def cmd_replay(a) -> int:
    got = _run(a)
    want = json.load(open(a.expect))
    bad = [i for i, (x, y) in enumerate(zip(got, want)) if x["sigmaHash"] != y["sigmaHash"]]
    if len(got) != len(want) or bad:
        print(f"replay DIVERGES at tick {bad[0] if bad else min(len(got), len(want))}")
        return 1
    print(f"replay identical: {len(got)} ticks, every sigma hash matches")
    return 0


def cmd_export(a) -> int:
    from eidola_export import emit_module
    ws, root, units, ids = _load(a.workspace)
    e = Engine(root, units, conformance_frames())
    src = emit_module(e, [x for x in a.observe.split(",") if x], Path(a.workspace).stem)
    Path(a.out).write_text(src)
    print(f"wrote {a.out} — plain Python; import it and call make()")
    return 0


def cmd_grade(a) -> int:
    rc = subprocess.call([sys.executable, str(ROOT / "grade" / "metamorphic.py"), "-n", str(a.n)]
                         + (["--core"] if a.core else []))
    if a.core:
        rc |= subprocess.call([sys.executable, "grade.py", "-n", str(a.n)], cwd=ROOT / "oracle")
    return rc


def main() -> int:
    ap = argparse.ArgumentParser(prog="eidola", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("check"); p.add_argument("workspace"); p.set_defaults(fn=cmd_check)
    p = sub.add_parser("run"); p.add_argument("workspace"); p.add_argument("--log")
    p.add_argument("--values", action="store_true"); p.add_argument("--save"); p.set_defaults(fn=cmd_run)
    p = sub.add_parser("replay"); p.add_argument("workspace"); p.add_argument("--log", required=True)
    p.add_argument("--expect", required=True); p.set_defaults(fn=cmd_replay)
    p = sub.add_parser("export"); p.add_argument("workspace"); p.add_argument("--observe", default="")
    p.add_argument("-o", "--out", required=True); p.set_defaults(fn=cmd_export)
    p = sub.add_parser("grade"); p.add_argument("-n", type=int, default=200)
    p.add_argument("--core", action="store_true"); p.set_defaults(fn=cmd_grade)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
