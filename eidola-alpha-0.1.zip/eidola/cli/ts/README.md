# cli/ts — PLACEHOLDER

Same commands as `cli/eidola.py`, over `@eidola/core`'s public entry, run with `tsx` or compiled.
Needed because the Python CLI cannot execute `host/1` JavaScript bodies. Start from
`core/tools/run.ts`, which already loads a workspace and ticks it.
