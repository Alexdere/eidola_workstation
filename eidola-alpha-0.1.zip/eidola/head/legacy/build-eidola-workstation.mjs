// RETIRED 2026-10-14. The workstation was the inspect / debug surface (visible wires,
// inspector, node view). It does nothing the base cannot: the base's `inspect` view is the same
// chrome over the same graph, and `dump` is its workspace box. It also drew its palette from
// the core's primitive table, which breaks generated-from-core. Kept here, still buildable,
// as a record. Not part of check.sh.
import * as esbuild from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
mkdirSync(join(here, "dist"), { recursive: true });

const out = await esbuild.build({
  entryPoints: [join(here, "src/app.ts")],
  bundle: true, format: "iife", target: "es2022", write: false, legalComments: "none",
});
const js = out.outputFiles[0].text;

const shell = readFileSync(join(here, "index-workstation.html"), "utf8")
  .replace("<title>Eidola Workspace</title>", "<title>Eidola · Workstation</title>");
const page = shell.replace("/*APP*/", () => js);

writeFileSync(
  join(here, "dist/eidola-workstation.html"),
  `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n` +
  `<meta name="viewport" content="width=device-width,initial-scale=1">\n` +
  page.replace(/^(<title>[\s\S]*?<\/style>)/, "$1\n</head>\n<body>") + "\n</body>\n</html>\n",
);

const kb = (s) => `${(Buffer.byteLength(s) / 1024).toFixed(0)} kB`;
console.log(`eidola-workstation: js ${kb(js)}, page ${kb(page)}`);
