// The presentation store — Law 8, in a file.
//
// A second relational structure over the same vertex set: where things are, what they are
// called, which are collapsed. It is SAVED and INERT at the same time. Saved, because the
// composer's arrangement is real thinking and losing it is losing work. Inert, because none
// of it participates: delete this whole file's contents and the graph computes exactly the
// same thing.
//
// Note what is in here that people expect to be content: LABELS. A name is not a unit's
// identity — identity is content — so renaming is a gauge transformation and changes no hash.

export interface Presentation {
  "@": "presentation/1";
  /** occurrence path -> [x, y] */
  pos: Record<string, [number, number]>;
  /** occurrence path -> a human name */
  paneLabel: Record<string, string>;
  /** unit id -> a human name, for the palette */
  unitLabel: Record<string, string>;
  /** occurrence paths a viewer has folded away. Folding is gauge — and it stops the
   *  computation, because collapsed means unobserved. Vantage with no content, that
   *  nonetheless decides what runs. */
  collapsed: Record<string, boolean>;
  pan: [number, number];
  zoom: number;
}

export function emptyPresentation(): Presentation {
  return {
    "@": "presentation/1",
    pos: {}, paneLabel: {}, unitLabel: {}, collapsed: {},
    pan: [0, 0], zoom: 1,
  };
}

export function posOf(p: Presentation, occ: string, i = 0): [number, number] {
  if (!p.pos[occ]) p.pos[occ] = [80 + (i % 5) * 210, 70 + Math.floor(i / 5) * 150];
  return p.pos[occ];
}
