// eidola — a minimal head.
//
// Two stores over one vertex set: the graph, which is projected from the core and never
// mutated directly, and the presentation, which is saved and inert. Every command goes
// through `engine.apply()`; every pixel is rendered from state. There is no optimistic
// update anywhere in this file, and there is no path by which a click reaches a unit except
// by becoming a command first.

import {
  Engine, Graph, Liminal, MemoryPersistence, Pane, Port, Store, Value, Wire,
  collapse, dumpWorkspace, findPort, fromSpec, graph, loadWorkspace, melt, pane,
  primUnit, toSpec, wire, PRIMS, WorkspaceSpec, IN, OUT,
} from "../../../core/src/index.js";
import { Presentation, emptyPresentation, posOf } from "./present.js";
import { short, shapeClass } from "../../src/lens.js";

/** This head's own storage key. eidola-base owns "eidola/session"; sharing it let either head
 *  overwrite the other's room (and `reset` here wiped the base). */
const STORAGE_KEY = "eidola-workstation/session";
const BASE_KEY = "eidola/session";

const W = 176;          // pane width — fixed, so port geometry is arithmetic
const HEAD_H = 26;
const ROW_H = 20;
const FOOT_H = 26;

type Level =
  | { kind: "workspace"; engine: Engine }
  | { kind: "liminal"; occ: string; lim: Liminal; stubs: Record<string, Value> };

interface Drag {
  kind: "pane" | "wire" | "pan";
  occ?: string;
  port?: string;
  dir?: "in" | "out";
  ox: number; oy: number;
  x: number; y: number;
}

const PALETTE: Array<[string, string[]]> = [
  ["values", ["core.const", "core.source"]],
  ["number", ["core.add", "core.sub", "core.mul", "core.neg", "core.abs", "core.min",
              "core.max", "core.floor"]],
  ["test", ["core.gt", "core.lt", "core.eq", "core.not", "core.and", "core.or", "core.if"]],
  ["text & list", ["core.concat", "core.list2", "core.append", "core.at", "core.len"]],
  ["memory", ["core.delay", "core.sum", "core.hist"]],
  ["world", ["core.print"]],
];

// ---------------------------------------------------------------------------- app

class App {
  store = new Store(new MemoryPersistence());
  present: Presentation = emptyPresentation();
  levels: Level[] = [];
  sigma: Record<string, string> = {};
  scratch: Store | null = null;      // where liminal values live while descended
  ran: string[] = [];
  effects: Value[] = [];
  selected = new Set<string>();
  selectedWire: number | null = null;
  drag: Drag | null = null;
  srcValues: Record<string, Value> = {};
  running = false;
  lastHash = "";
  hashFlash = 0;
  gaugeOps = 0;
  message = "";
  messageKind: "ok" | "no" = "ok";
  seq = 0;

  el = {
    canvas: document.getElementById("canvas") as HTMLDivElement,
    wires: document.getElementById("wires") as unknown as SVGSVGElement,
    panes: document.getElementById("panes") as HTMLDivElement,
    palette: document.getElementById("palette") as HTMLDivElement,
    inspector: document.getElementById("inspector") as HTMLDivElement,
    bar: document.getElementById("bar") as HTMLDivElement,
    log: document.getElementById("log") as HTMLDivElement,
    crumb: document.getElementById("crumb") as HTMLDivElement,
  };

  constructor() {
    this.levels = [{ kind: "workspace", engine: new Engine(this.store, graph({}, [])) }];
    this.load();
    this.buildPalette();
    this.wireEvents();
    document.getElementById("b-dump")?.addEventListener("click", () => this.dumpFile());
    document.getElementById("b-loadtext")?.addEventListener("click", () => this.loadFile());
    this.tick();
    this.render();
  }

  // -------------------------------------------------------------------- level access

  get level(): Level { return this.levels[this.levels.length - 1]; }
  get isLiminal(): boolean { return this.level.kind === "liminal"; }

  get graph(): Graph {
    const l = this.level;
    return l.kind === "workspace" ? l.engine.root : l.lim.graph;
  }

  unitOf(occ: string) { return this.store.unit(this.graph.panes[occ].unit); }

  valueStore(): Store { return this.scratch ?? this.store; }

  valueAt(ep: string): Value | undefined {
    const id = this.sigma[ep];
    if (id === undefined) return undefined;
    try { return this.valueStore().blob(id); } catch { return undefined; }
  }
  /** A composite's boundary is an ALIAS, not a copy: nothing is stored at `box#y`, because the
   *  value already lives at the interior producer `@out.y` is wired from. Follow it down. */
  epOf(unitId: string, path: string, portName: string): string {
    const u = this.store.unit(unitId);
    if (!u.graph) return `${path}#${portName}`;
    const w = u.graph.wires.find((x) => x.to[0] === OUT && x.to[1] === portName);
    if (!w || !u.graph.panes[w.from[0]]) return `${path}#${portName}`;
    return this.epOf(u.graph.panes[w.from[0]].unit, `${path}/${w.from[0]}`, w.from[1]);
  }
  /** The in-side twin: the value at `box#x` is wherever `@in.x` lands inside. */
  inValue(unitId: string, path: string, portName: string): Value | undefined {
    const u = this.store.unit(unitId);
    if (!u.graph) return this.valueAt(`${path}#${portName}`);
    for (const w of u.graph.wires) {
      if (w.from[0] !== IN || w.from[1] !== portName) continue;
      const inner = u.graph.panes[w.to[0]]; if (!inner) continue;
      const v = this.inValue(inner.unit, `${path}/${w.to[0]}`, w.to[1]);
      if (v !== undefined) return v;
    }
    return undefined;
  }
  outValue(occ: string, portName: string): Value | undefined {
    return this.valueAt(this.epOf(this.graph.panes[occ].unit, this.pathOf(occ), portName));
  }


  // -------------------------------------------------------------------- commands

  /** Every graph change goes through here. A rejection is shown, not swallowed — a wire
   *  refused at wire time is the law being visible rather than merely true. */
  edit(fn: (g: Graph) => Graph, what: string): boolean {
    const l = this.level;
    if (l.kind === "workspace") {
      const before = l.engine.root;
      l.engine.root = fn(before);
      try {
        l.engine.validate();
      } catch (e) {
        l.engine.root = before;
        l.engine.validate();
        this.say((e as Error).message, "no");
        this.render();          // a refusal the user cannot see is not a refusal
        return false;
      }
    } else {
      const before = l.lim.graph;
      l.lim.graph = fn(before);
      // a draft is not validated into existence; it is validated when you try to run it
      try {
        this.tick();
      } catch (e) {
        l.lim.graph = before;
        this.say((e as Error).message, "no");
        this.render();
        return false;
      }
    }
    this.say(what, "ok");
    this.tick();
    this.render();
    return true;
  }

  addPane(unitId: string, at?: [number, number]): void {
    const u = this.store.unit(unitId);
    const base = u.body && u.body["@"] === "prim/1"
      ? u.body.op.replace("core.", "")
      : (this.present.unitLabel[unitId] ?? "box").toLowerCase().replace(/[^a-z0-9]/g, "");
    let occ = base, n = 1;
    while (this.graph.panes[occ]) occ = `${base}${++n}`;
    const p = pane(unitId, {
      config: u.body && u.body["@"] === "prim/1" && u.body.op === "core.const" ? 1 : undefined,
      mem: u.powers.some((x) => x.startsWith("mem:")) ? `${occ}.${++this.seq}` : undefined,
      pinned: u.cls === "effect",
    });
    if (at) this.present.pos[this.pathOf(occ)] = at;
    this.edit((g) => graph({ ...g.panes, [occ]: p }, g.wires), `+ ${occ}`);
    this.selected = new Set([occ]);
    this.refreshSelection();
  }

  removeSelected(): void {
    if (this.selectedWire !== null) {
      const i = this.selectedWire;
      this.selectedWire = null;
      this.edit((g) => graph(g.panes, g.wires.filter((_, k) => k !== i)), "− wire");
      return;
    }
    if (!this.selected.size) return;
    const sel = new Set(this.selected);
    this.selected = new Set();
    this.edit((g) => {
      const panes: Record<string, Pane> = {};
      for (const k of Object.keys(g.panes)) if (!sel.has(k)) panes[k] = g.panes[k];
      return graph(panes, g.wires.filter((w) => !sel.has(w.from[0]) && !sel.has(w.to[0])));
    }, `− ${[...sel].join(", ")}`);
  }

  connect(from: [string, string], to: [string, string]): void {
    this.edit((g) => graph(g.panes, [...g.wires, wire(from, to)]),
      `${from[0]}.${from[1]} → ${to[0]}.${to[1]}`);
  }

  // -------------------------------------------------------------------- closure

  /** The whole gesture: select, melt, declare, splice. What was several panes is now one
   *  unit — usable anywhere any unit is usable, with no new construct. */
  group(): void {
    if (this.selected.size < 1) return this.say("select some panes first", "no");
    if (this.isLiminal) return this.say("declare this draft before grouping inside it", "no");
    const occs = [...this.selected];
    const name = prompt("name this composite", `box${Object.keys(this.present.unitLabel).length + 1}`);
    if (name === null) return;
    let out;
    try {
      out = collapse(this.graph, occs, this.store, this.freshOcc(name));
    } catch (e) { return this.say((e as Error).message, "no"); }
    this.present.unitLabel[out.unit] = name;
    const centre = occs.map((o) => posOf(this.present, this.pathOf(o)));
    const at: [number, number] = [
      Math.round(centre.reduce((a, c) => a + c[0], 0) / centre.length),
      Math.round(centre.reduce((a, c) => a + c[1], 0) / centre.length),
    ];
    const newOcc = Object.keys(out.graph.panes).find((k) => !(k in this.graph.panes))!;
    this.present.pos[this.pathOf(newOcc)] = at;
    // the children's paths just gained a level; a source's typed value lives at its path, so
    // move it or the value silently disappears the moment it is grouped
    for (const o of occs) {
      const was = this.pathOf(o), now = `${this.pathOf(newOcc)}/${o}`;
      if (this.srcValues[was] !== undefined) { this.srcValues[now] = this.srcValues[was]; delete this.srcValues[was]; }
    }
    this.selected = new Set([newOcc]);
    this.edit(() => out!.graph, `declared ${name}`);
    this.buildPalette();
  }

  freshOcc(base: string): string {
    const stem = base.toLowerCase().replace(/[^a-z0-9_.-]/g, "") || "box";
    let occ = stem, n = 1;
    while (this.graph.panes[occ]) occ = `${stem}${++n}`;
    return occ;
  }

  /** Descend. You cannot reach into a composite from outside; you go in. The interior
   *  becomes a DRAFT — mutable, unaddressed, playable — and the parent learns nothing until
   *  you come back up. */
  descend(occ: string): void {
    const u = this.unitOf(occ);
    if (u.cls !== "container") return this.say("only a composite has an inside", "no");
    const stubs: Record<string, Value> = {};
    for (const p of u.ports) {
      if (p.dir !== "in") continue;
      const v = this.inValue(this.graph.panes[occ].unit, this.pathOf(occ), p.name);
      if (v !== undefined) stubs[p.name] = v;
    }
    this.levels.push({ kind: "liminal", occ, lim: melt(this.store, this.graph.panes[occ].unit), stubs });
    this.selected = new Set();
    this.tick();
    this.render();
  }

  /** Ascend: freeze the boundary. The hash exists only now. */
  ascend(): void {
    const l = this.level;
    if (l.kind !== "liminal") return;
    let id: string;
    try { id = l.lim.declare(this.store); }
    catch (e) { return this.say((e as Error).message, "no"); }
    const parentLabel = this.present.unitLabel[l.lim.meltedFrom ?? ""] ?? "box";
    this.present.unitLabel[id] = parentLabel;
    this.levels.pop();
    const occ = l.occ;
    const ok = this.edit(
      (g) => graph({ ...g.panes, [occ]: { ...g.panes[occ], unit: id } }, g.wires),
      l.lim.meltedFrom === id ? "unchanged" : `declared ${parentLabel}`,
    );
    if (!ok) {
      // the interface changed under wires that no longer fit: go back in rather than
      // silently dropping them
      this.levels.push(l);
      this.say("the new boundary does not fit the wires outside; adjust and try again", "no");
    }
    this.buildPalette();
    this.tick();
    this.render();
  }

  pathOf(occ: string): string {
    const prefix = this.levels.slice(1).map((l) => (l as { occ: string }).occ);
    return [...prefix, occ].join("/");
  }

  // -------------------------------------------------------------------- the tick

  tick(): void {
    const l = this.level;
    const g = this.graph;
    const observed = Object.keys(g.panes).filter((o) => !this.present.collapsed[this.pathOf(o)]);

    const prefix = this.levels.slice(1).map((x) => (x as { occ: string }).occ).join("/");
    // A source emits wherever it lives, nested or not, or its value vanishes the moment it is
    // grouped. Keys are relative to the graph being ticked; srcValues are keyed by full path.
    const journal: Record<string, Value> = {};
    const walk = (gr: Graph, rel: string) => {
      for (const occ of Object.keys(gr.panes)) {
        const u = this.store.unit(gr.panes[occ].unit);
        const r = rel ? `${rel}/${occ}` : occ;
        if (u.cls === "source") {
          const cfg = gr.panes[occ].config as { widget?: string } | null;
          const widget = (cfg && typeof cfg === "object" && !Array.isArray(cfg) && cfg.widget) || "number";
          const v = widget === "clock" ? (l.kind === "workspace" ? l.engine.tickIndex : 0)
            : this.srcValues[prefix ? `${prefix}/${r}` : r];
          if (v !== undefined) journal[`${r}#out`] = v;
        }
        if (u.graph) walk(u.graph, r);
      }
    };
    walk(g, "");

    if (l.kind === "workspace") {
      const r = l.engine.tick({ observed, journal });
      this.sigma = r.sigma; this.ran = r.ran; this.scratch = null;
      this.effects = r.effects;
      if (r.effects.length) this.logEffects(r.effects);
    } else {
      const { result, scratch } = l.lim.play(this.store, l.stubs, { observed, journal });
      const abs = (k: string) => (prefix ? `${prefix}/${k}` : k);
      this.sigma = Object.fromEntries(Object.entries(result.sigma).map(([k, v]) => [abs(k), v]));
      this.ran = result.ran.map(abs); this.scratch = scratch;
      this.effects = result.effects;
    }
  }

  step(): void { this.tick(); this.render(); }

  toggleRun(): void {
    this.running = !this.running;
    if (this.running) {
      const loop = () => {
        if (!this.running) return;
        this.step();
        setTimeout(loop, 120);
      };
      loop();
    }
    this.render();
  }

  logEffects(vs: Value[]): void {
    for (const v of vs) {
      const line = document.createElement("div");
      line.className = "logline";
      line.textContent = short(v);
      this.el.log.prepend(line);
    }
    while (this.el.log.children.length > 60) this.el.log.lastChild!.remove();
  }

  say(m: string, kind: "ok" | "no"): void { this.message = m; this.messageKind = kind; }

  // -------------------------------------------------------------------- geometry

  paneRows(occ: string): { ins: Port[]; outs: Port[] } {
    const u = this.unitOf(occ);
    return { ins: u.ports.filter((p) => p.dir === "in"), outs: u.ports.filter((p) => p.dir === "out") };
  }

  paneHeight(occ: string): number {
    if (this.present.collapsed[this.pathOf(occ)]) return HEAD_H;
    const { ins, outs } = this.paneRows(occ);
    return HEAD_H + Math.max(ins.length, outs.length) * ROW_H + FOOT_H;
  }

  portXY(occ: string, name: string, dir: "in" | "out"): [number, number] {
    const [x, y] = posOf(this.present, this.pathOf(occ), Object.keys(this.graph.panes).indexOf(occ));
    if (this.present.collapsed[this.pathOf(occ)])
      return [dir === "in" ? x : x + W, y + HEAD_H / 2];
    const { ins, outs } = this.paneRows(occ);
    const list = dir === "in" ? ins : outs;
    const i = Math.max(0, list.findIndex((p) => p.name === name));
    return [dir === "in" ? x : x + W, y + HEAD_H + i * ROW_H + ROW_H / 2];
  }

  // -------------------------------------------------------------------- rendering

  /** Selection is presentation. Repaint the classes, never rebuild the nodes — a rebuild
   *  between the two halves of a double-click destroys the double-click. */
  refreshSelection(): void {
    for (const occ of [...this.selected]) if (!(occ in this.graph.panes)) this.selected.delete(occ);
    for (const el of Array.from(this.el.panes.children) as HTMLElement[])
      el.classList.toggle("sel", this.selected.has(el.dataset.occ!));
    this.renderWires();
    this.renderInspector();
    this.renderBar();
  }

  render(): void {
    // a selection is a reference to occurrences that may no longer exist — after a descend,
    // an ascend, or a load. Prune before painting rather than reading through a dangling name.
    for (const occ of [...this.selected]) if (!(occ in this.graph.panes)) this.selected.delete(occ);
    if (this.selectedWire !== null && this.selectedWire >= this.graph.wires.length)
      this.selectedWire = null;
    this.renderBar();
    this.renderPanes();
    this.renderWires();
    this.renderInspector();
    this.renderCrumb();
  }

  renderBar(): void {
    const l = this.level;
    const h = l.kind === "workspace" ? l.engine.graphHash() : "— liminal, no hash yet —";
    const changed = h !== this.lastHash;
    if (changed && l.kind === "workspace") { this.lastHash = h; this.hashFlash = Date.now(); this.gaugeOps = 0; }
    const flash = Date.now() - this.hashFlash < 700;
    const idle = l.kind === "workspace" ? "" : " liminal";
    this.el.bar.innerHTML = `
      <div class="grp">
        <button id="b-step">step</button>
        <button id="b-run" class="${this.running ? "on" : ""}">${this.running ? "pause" : "run"}</button>
        <span class="tickno">t${l.kind === "workspace" ? l.engine.tickIndex : "—"}</span>
      </div>
      <div class="grp">
        <button id="b-group">group ⌘G</button>
        <button id="b-del">delete ⌫</button>
      </div>
      <div class="hashbox${flash ? " flash" : ""}${idle}">
        <span class="hlabel">graph</span>
        <code>${l.kind === "workspace" ? h.slice(0, 20) : h}</code>
        <span class="gauge">${this.gaugeOps} gauge ops since it last moved</span>
      </div>
      <div class="grp right">
        <button id="b-save">save</button>
        <button id="b-clear">reset</button>
      </div>
      <div class="msg ${this.messageKind}">${escapeHtml(this.message)}</div>`;

    on("b-step", () => this.step());
    on("b-run", () => this.toggleRun());
    on("b-group", () => this.group());
    on("b-del", () => this.removeSelected());
    on("b-save", () => { this.save(); this.say("saved to this browser", "ok"); this.renderBar(); });
    on("b-clear", () => { if (confirm("discard this workspace?")) this.reset(); });
  }

  renderCrumb(): void {
    const parts = ["workspace", ...this.levels.slice(1).map((l) => (l as { occ: string }).occ)];
    this.el.crumb.innerHTML = parts.map((p, i) =>
      `<span class="${i === parts.length - 1 ? "here" : ""}">${escapeHtml(p)}</span>`).join(
      `<span class="sep">▸</span>`)
      + (this.isLiminal ? `<button id="b-up">declare &amp; ascend</button>` : "");
    on("b-up", () => this.ascend());
  }

  renderPanes(): void {
    const g = this.graph;
    const occs = Object.keys(g.panes);
    this.el.panes.innerHTML = "";
    occs.forEach((occ, i) => {
      const path = this.pathOf(occ);
      const u = this.unitOf(occ);
      const [x, y] = posOf(this.present, path, i);
      const collapsed = !!this.present.collapsed[path];
      const { ins, outs } = this.paneRows(occ);
      const label = this.present.paneLabel[path]
        ?? (u.body && u.body["@"] === "prim/1" ? u.body.op.replace("core.", "") : (this.present.unitLabel[g.panes[occ].unit] ?? "box"));

      const d = document.createElement("div");
      d.className = `pane cls-${u.cls}${this.selected.has(occ) ? " sel" : ""}${collapsed ? " collapsed" : ""}${this.ran.includes(path) ? " ran" : ""}`;
      d.style.left = `${x}px`;
      d.style.top = `${y}px`;
      d.style.width = `${W}px`;
      d.dataset.occ = occ;

      const rows = collapsed ? "" : Array.from(
        { length: Math.max(ins.length, outs.length) },
        (_, r) => {
          const a = ins[r], b = outs[r];
          return `<div class="row">
            ${a ? `<span class="dot in ${shapeClass[a.shape] ?? "sh-any"}" data-port="${a.name}" data-dir="in"></span><span class="pname">${a.name}</span>` : `<span class="pname"></span>`}
            ${b ? `<span class="pname out">${b.name}<b>${escapeHtml(short(this.outValue(occ, b.name)))}</b></span><span class="dot out ${shapeClass[b.shape] ?? "sh-any"}" data-port="${b.name}" data-dir="out"></span>` : ""}
          </div>`;
        }).join("");

      d.innerHTML = `
        <div class="head">
          <span class="ttl">${escapeHtml(label)}</span>
          <span class="badges">
            ${g.panes[occ].pinned ? `<span class="badge pin" title="pinned: a declared reason to be alive">pin</span>` : ""}
            ${u.cls === "container" ? `<span class="badge box">▣</span>` : ""}
            <span class="badge fold" data-fold="1" title="folding is gauge — and it stops the computation">${collapsed ? "+" : "–"}</span>
          </span>
        </div>
        ${rows}
        ${collapsed ? "" : `<div class="foot">${this.footFor(occ, u)}</div>`}`;
      this.el.panes.appendChild(d);
    });
  }

  footFor(occ: string, u: ReturnType<App["unitOf"]>): string {
    const g = this.graph;
    const p = g.panes[occ];
    if (u.cls === "source") {
      const cfg = p.config as { widget?: string } | null;
      const widget = (cfg && typeof cfg === "object" && !Array.isArray(cfg) && cfg.widget) || "number";
      if (widget === "clock") return `<span class="hint">clock — a source, journalled</span>`;
      const v = this.srcValues[this.pathOf(occ)];
      if (widget === "toggle")
        return `<button class="wid" data-src="${escapeHtml(this.pathOf(occ))}" data-w="toggle">${v === true ? "true" : "false"}</button>`;
      if (widget === "text")
        return `<input class="wid" data-src="${escapeHtml(this.pathOf(occ))}" data-w="text" value="${escapeHtml(typeof v === "string" ? v : "")}">`;
      return `<input class="wid" type="number" data-src="${escapeHtml(this.pathOf(occ))}" data-w="number" value="${typeof v === "number" ? v : 0}">`;
    }
    if (u.body && u.body["@"] === "prim/1" && u.body.op === "core.const")
      return `<input class="wid" data-cfg="${occ}" value="${escapeHtml(JSON.stringify(p.config ?? null))}">`;
    if (u.cls === "container") return `<span class="hint">double-click to descend</span>`;
    return `<span class="hint">${u.cls}</span>`;
  }

  renderWires(): void {
    const g = this.graph;
    const svg = this.el.wires;
    const parts: string[] = [];
    g.wires.forEach((w, i) => {
      const from = w.from[0] === "@in" ? null : this.portXY(w.from[0], w.from[1], "out");
      const to = w.to[0] === "@out" ? null : this.portXY(w.to[0], w.to[1], "in");
      // boundary endpoints of a draft are drawn as stubs off the side of the canvas
      const a = from ?? [20, (to ? to[1] : 100)];
      const b = to ?? [(from ? from[0] : 100) + 90, (from ? from[1] : 100)];
      const dx = Math.max(28, Math.abs(b[0] - a[0]) * 0.45);
      parts.push(
        `<path class="wire${this.selectedWire === i ? " sel" : ""}${from ? "" : " boundary"}${to ? "" : " boundary"}" data-i="${i}"
           d="M${a[0]},${a[1]} C${a[0] + dx},${a[1]} ${b[0] - dx},${b[1]} ${b[0]},${b[1]}"/>`);
      if (!from) parts.push(`<text class="btag" x="6" y="${a[1] - 6}">@in.${w.from[1]}</text>`);
      if (!to) parts.push(`<text class="btag" x="${b[0] - 8}" y="${b[1] - 6}">@out.${w.to[1]}</text>`);
    });
    if (this.drag?.kind === "wire") {
      const s = this.portXY(this.drag.occ!, this.drag.port!, this.drag.dir!);
      parts.push(`<path class="wire ghost" d="M${s[0]},${s[1]} L${this.drag.x},${this.drag.y}"/>`);
    }
    svg.innerHTML = parts.join("");
  }

  renderInspector(): void {
    const occs = [...this.selected];
    if (occs.length !== 1) {
      this.el.inspector.innerHTML = `<div class="ihint">${occs.length ? `${occs.length} panes selected — <b>group</b> makes them one unit` : "select a pane"}</div>`;
      return;
    }
    const occ = occs[0];
    const g = this.graph;
    const p = g.panes[occ];
    const u = this.unitOf(occ);
    const path = this.pathOf(occ);
    const lineage = this.store.ancestry(p.unit);
    this.el.inspector.innerHTML = `
      <div class="irow"><span>occurrence</span><code>${escapeHtml(path)}</code></div>
      <div class="irow"><span>unit</span><code title="${p.unit}">${p.unit.slice(0, 18)}…</code></div>
      <div class="irow"><span>class</span><code>${u.cls}</code></div>
      <div class="irow"><span>powers</span><code>${u.powers.join(" ") || "—"}</code></div>
      ${p.mem ? `<div class="irow"><span>mem</span><code>${escapeHtml(p.mem)}</code></div>` : ""}
      ${lineage.length ? `<div class="irow"><span>melted from</span><code>${lineage[0].slice(0, 14)}…</code></div>` : ""}
      <label class="irow"><span>label</span><input id="i-label" value="${escapeHtml(this.present.paneLabel[path] ?? "")}" placeholder="gauge — changes no hash"></label>
      <label class="irow"><span>config</span><input id="i-config" value="${escapeHtml(JSON.stringify(p.config ?? null))}"></label>
      <label class="irow"><span>pinned</span><input id="i-pin" type="checkbox" ${p.pinned ? "checked" : ""}></label>
      ${u.cls === "container" ? `<button id="i-desc">descend into it</button>` : ""}
      <div class="ihint">${u.cls === "effect" ? "an effect has no output, so nothing can observe it: it is dead unless pinned." : ""}</div>`;

    const lab = document.getElementById("i-label") as HTMLInputElement | null;
    lab?.addEventListener("input", () => {
      // a name is not identity. This edit must not move the hash.
      this.present.paneLabel[path] = lab.value;
      this.gaugeOps++;
      this.renderPanes(); this.renderBar();
    });
    const cfg = document.getElementById("i-config") as HTMLInputElement | null;
    cfg?.addEventListener("change", () => this.setConfig(occ, cfg.value));
    const pin = document.getElementById("i-pin") as HTMLInputElement | null;
    pin?.addEventListener("change", () =>
      this.edit((gg) => graph({ ...gg.panes, [occ]: { ...gg.panes[occ], pinned: pin.checked } }, gg.wires),
        pin.checked ? `${occ} pinned` : `${occ} unpinned`));
    on("i-desc", () => this.descend(occ));
  }

  setConfig(occ: string, raw: string): void {
    let v: Value;
    try { v = JSON.parse(raw) as Value; } catch { return this.say("config must be JSON", "no"); }
    this.edit((g) => graph({ ...g.panes, [occ]: { ...g.panes[occ], config: v } }, g.wires),
      `${occ} config`);
  }

  // -------------------------------------------------------------------- palette

  buildPalette(): void {
    const groups = PALETTE.map(([name, ops]) => {
      const items = ops.map((op) => {
        const id = this.store.putUnit(primUnit(op));
        return `<button class="pal" data-unit="${id}">${op.replace("core.", "")}</button>`;
      }).join("");
      return `<div class="palgroup"><h4>${name}</h4><div class="palrow">${items}</div></div>`;
    });
    const mine = this.store.persist.unitIds()
      .filter((id) => this.store.unit(id).cls === "container")
      .map((id) => `<button class="pal own" data-unit="${id}">${escapeHtml(this.present.unitLabel[id] ?? "box")}</button>`);
    if (mine.length)
      groups.push(`<div class="palgroup"><h4>yours</h4><div class="palrow">${mine.join("")}</div></div>`);
    this.el.palette.innerHTML = groups.join("");
  }

  // -------------------------------------------------------------------- events

  wireEvents(): void {
    const canvas = this.el.canvas;

    this.el.palette.addEventListener("click", (e) => {
      const b = (e.target as HTMLElement).closest(".pal") as HTMLElement | null;
      if (b) this.addPane(b.dataset.unit!);
    });

    canvas.addEventListener("mousedown", (e) => {
      const t = e.target as HTMLElement;
      const paneEl = t.closest(".pane") as HTMLElement | null;
      const r = canvas.getBoundingClientRect();
      const mx = e.clientX - r.left + canvas.scrollLeft;
      const my = e.clientY - r.top + canvas.scrollTop;

      if (t.classList.contains("dot") && paneEl) {
        this.drag = {
          kind: "wire", occ: paneEl.dataset.occ!, port: t.dataset.port!,
          dir: t.dataset.dir as "in" | "out", ox: 0, oy: 0, x: mx, y: my,
        };
        e.preventDefault();
        return;
      }
      if (t.dataset.fold && paneEl) {
        // gauge: folding changes no hash — and stops the computation behind it
        const path = this.pathOf(paneEl.dataset.occ!);
        this.present.collapsed[path] = !this.present.collapsed[path];
        this.gaugeOps++;
        this.tick(); this.render();
        return;
      }
      if (t.closest(".wid")) return;

      if (paneEl) {
        const occ = paneEl.dataset.occ!;
        if (!e.shiftKey && !this.selected.has(occ)) this.selected = new Set([occ]);
        else if (e.shiftKey) this.selected.has(occ) ? this.selected.delete(occ) : this.selected.add(occ);
        this.selectedWire = null;
        const [px, py] = posOf(this.present, this.pathOf(occ));
        this.drag = { kind: "pane", occ, ox: mx - px, oy: my - py, x: mx, y: my };
        this.refreshSelection();
        return;
      }
      const wireEl = t.closest("path.wire") as SVGPathElement | null;
      if (wireEl) {
        this.selectedWire = Number(wireEl.dataset.i);
        this.selected = new Set();
        this.refreshSelection();
        return;
      }
      this.selected = new Set();
      this.selectedWire = null;
      this.refreshSelection();
    });

    window.addEventListener("mousemove", (e) => {
      if (!this.drag) return;
      const r = canvas.getBoundingClientRect();
      const mx = e.clientX - r.left + canvas.scrollLeft;
      const my = e.clientY - r.top + canvas.scrollTop;
      this.drag.x = mx; this.drag.y = my;
      if (this.drag.kind === "pane") {
        // MOVING A PANE IS GAUGE. Nothing here touches the graph, so nothing here can
        // touch the hash — which is the whole point, and is visible in the bar.
        const occs = this.selected.size > 1 && this.selected.has(this.drag.occ!)
          ? [...this.selected] : [this.drag.occ!];
        const path = this.pathOf(this.drag.occ!);
        const [ox, oy] = this.present.pos[path];
        const nx = Math.round(mx - this.drag.ox), ny = Math.round(my - this.drag.oy);
        for (const o of occs) {
          const pp = this.pathOf(o);
          const cur = posOf(this.present, pp);
          this.present.pos[pp] = o === this.drag.occ! ? [nx, ny] : [cur[0] + (nx - ox), cur[1] + (ny - oy)];
        }
        this.renderPanes(); this.renderWires();
      } else if (this.drag.kind === "wire") {
        this.renderWires();
      }
    });

    window.addEventListener("mouseup", (e) => {
      const d = this.drag;
      this.drag = null;
      if (!d) return;
      if (d.kind === "pane") { this.gaugeOps++; this.renderBar(); return; }
      if (d.kind === "wire") {
        const t = e.target as HTMLElement;
        const paneEl = t.closest(".pane") as HTMLElement | null;
        if (!t.classList.contains("dot") || !paneEl) { this.renderWires(); return; }
        const other = { occ: paneEl.dataset.occ!, port: t.dataset.port!, dir: t.dataset.dir as "in" | "out" };
        if (other.dir === d.dir) { this.say("a wire joins an out port to an in port", "no"); this.renderBar(); this.renderWires(); return; }
        if (d.dir === "out") this.connect([d.occ!, d.port!], [other.occ, other.port]);
        else this.connect([other.occ, other.port], [d.occ!, d.port!]);
      }
    });

    canvas.addEventListener("dblclick", (e) => {
      const paneEl = (e.target as HTMLElement).closest(".pane") as HTMLElement | null;
      if (paneEl) this.descend(paneEl.dataset.occ!);
    });

    canvas.addEventListener("change", (e) => {
      const t = e.target as HTMLInputElement;
      if (t.dataset.src) {
        const w = t.dataset.w;
        this.srcValues[t.dataset.src] = w === "text" ? t.value : Number(t.value);
        this.tick(); this.render();
      } else if (t.dataset.cfg) {
        this.setConfig(t.dataset.cfg, t.value);
      }
    });
    canvas.addEventListener("click", (e) => {
      const t = e.target as HTMLElement;
      if (t.dataset.w === "toggle" && t.dataset.src) {
        this.srcValues[t.dataset.src] = !(this.srcValues[t.dataset.src] === true);
        this.tick(); this.render();
      }
    });

    window.addEventListener("keydown", (e) => {
      // any field being typed in owns its keys — the workspace-file textarea included, where
      // Space used to step the graph (and vanish) and Backspace deleted the selected panes
      const t = e.target as HTMLElement;
      if (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable) return;
      if (e.key === "Backspace" || e.key === "Delete") { e.preventDefault(); this.removeSelected(); }
      if (e.key.toLowerCase() === "g" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); this.group(); }
      if (e.key === "Escape" && this.isLiminal) this.ascend();
      if (e.key === " ") { e.preventDefault(); this.step(); }
    });
  }

  // -------------------------------------------------------------------- persistence

  session(): unknown {
    const l = this.levels[0] as { kind: "workspace"; engine: Engine };
    return {
      "@": "session/1",
      // the two halves stay separate: throw the presentation away and you lose an
      // arrangement, never a fact
      workspace: dumpWorkspace(this.store, l.engine.root),
      presentation: this.present,
      inputs: Object.fromEntries(Object.entries(this.srcValues).map(([k, v]) => [k, toSpec(v)])),
      lineage: Object.fromEntries(this.store.lineage),
    };
  }

  save(): void {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.session())); } catch { /* private mode */ }
  }

  load(): void {
    let raw: string | null = null;
    // Its own key. It used to share "eidola/session" with eidola-base, so saving (or resetting)
    // here silently replaced the base's room. Any head may still LOAD any workspace (the
    // coherence contract), so with nothing of its own it opens the base's content — read-only.
    try { raw = localStorage.getItem(STORAGE_KEY) ?? localStorage.getItem(BASE_KEY); } catch { /* ignore */ }
    if (!raw) { this.seed(); return; }
    try { this.restore(JSON.parse(raw)); } catch { this.seed(); }
  }

  restore(s: any): void {
    const store = new Store(new MemoryPersistence());
    const { root } = loadWorkspace(s.workspace as WorkspaceSpec, store);
    for (const [c, p] of Object.entries(s.lineage ?? {})) store.lineage.set(c, p as string);
    this.store = store;
    this.levels = [{ kind: "workspace", engine: new Engine(store, root) }];
    this.selected = new Set();
    this.selectedWire = null;
    this.present = { ...emptyPresentation(), ...(s.presentation ?? {}) };
    this.srcValues = Object.fromEntries(
      Object.entries(s.inputs ?? {}).map(([k, v]) => [k, fromSpec(v as any)]));
    this.buildPalette();
  }

  /** The file, in a text box. No download link and no file picker: this page runs in
   *  sandboxes where neither works, and a control that silently does nothing is worse than
   *  no control. The text is the artifact — WORKSPACE/1 plus a separate presentation block,
   *  readable by anything that reads JSON. */
  dumpFile(): void {
    const ta = document.getElementById("filetext") as HTMLTextAreaElement;
    ta.value = JSON.stringify(this.session(), null, 2);
    ta.focus(); ta.select();
    this.say("dumped — content and presentation are separate blocks; drop the second and lose only an arrangement", "ok");
    this.renderBar();
  }

  loadFile(): void {
    const ta = document.getElementById("filetext") as HTMLTextAreaElement;
    if (!ta.value.trim()) return this.say("paste a workspace into the box first", "no");
    try {
      this.restore(JSON.parse(ta.value));
      this.tick(); this.render();
      this.say("loaded", "ok");
    } catch (e) { this.say(`could not load: ${(e as Error).message}`, "no"); this.renderBar(); }
  }

  reset(): void {
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* ignore — and never the base's key */ }
    this.store = new Store(new MemoryPersistence());
    this.present = emptyPresentation();
    this.srcValues = {};
    this.levels = [{ kind: "workspace", engine: new Engine(this.store, graph({}, [])) }];
    this.seed();
    this.buildPalette();
    this.tick(); this.render();
  }

  /** A workspace that already does something: a counter, so the delay and the tick are
   *  visible on arrival rather than described. */
  seed(): void {
    const k = this.store.putUnit(primUnit("core.const"));
    const add = this.store.putUnit(primUnit("core.add"));
    const del = this.store.putUnit(primUnit("core.delay"));
    const src = this.store.putUnit(primUnit("core.source"));
    const mul = this.store.putUnit(primUnit("core.mul"));
    const root = graph(
      {
        step: pane(src, { config: { widget: "number" } }),
        prev: pane(del, { mem: "counter", config: 0 }),
        total: pane(add, { pinned: true }),
        two: pane(k, { config: 2 }),
        dbl: pane(mul),
      },
      [
        wire(["step", "out"], ["total", "b"]),
        wire(["prev", "out"], ["total", "a"]),
        wire(["total", "out"], ["prev", "x"]),
        wire(["total", "out"], ["dbl", "a"]),
        wire(["two", "out"], ["dbl", "b"]),
      ],
    );
    this.levels = [{ kind: "workspace", engine: new Engine(this.store, root) }];
    this.srcValues.step = 1;
    Object.assign(this.present.pos, {
      step: [60, 60], prev: [60, 210], total: [300, 120], two: [300, 300], dbl: [540, 210],
    });
    this.present.paneLabel = { total: "running total", dbl: "×2" };
  }
}

// ---------------------------------------------------------------------------- utils

function on(id: string, fn: () => void): void {
  document.getElementById(id)?.addEventListener("click", fn);
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

declare global { interface Window { app: App } }
window.app = new App();
