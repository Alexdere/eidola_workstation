# Retired: eidola-workstation

The workstation was the inspect / debug surface: wires always drawn, an inspector, a
workspace-file box. On 2026-10-14 it was folded into the base:

- `view inspect` in the base is the same chrome over the same graph (every pane, every wire,
  the inspector open, the hash showing);
- `dump` in the base is the workspace box (copy a WORKSPACE/1 file out, paste one in).

It was also prim-based: its palette came from the core's primitive table, which breaks
generated-from-core. It is kept here as a record and still builds and passes its own smoke
test, but it is not part of `check.sh` and it will not be extended.

```
node build-eidola-workstation.mjs   # dist/eidola-workstation.html
node smoke.mjs                      # its 22 original checks
```

`dist/eidola001.html` is the Aug 23 first instance of the base, kept for reference.
`../fixtures/workstation-session.json` is a session in the workstation's format, which the
base's regression checks use to prove it opens such a session without overwriting it.
