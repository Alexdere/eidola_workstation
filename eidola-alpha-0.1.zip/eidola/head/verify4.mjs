import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1380,height:900}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(450);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(160);};
const bd=o=>page.$eval(`[data-occ="${o}"] .bd`,e=>e.textContent.trim()).catch(()=>null);

// 1. opens EMPTY
const n0 = await page.$$eval('.pane',e=>e.length);
ok('opens empty — no demo, no presets placed', n0===0);

// 2. a new pane is nothing
await cmd('new');
const cls0 = await page.evaluate(()=>{const g=window.eidola.graph;const o=Object.keys(g.panes)[0];
  const u=window.eidola.store.unit(g.panes[o].unit);return {occ:o,cls:u.cls,ports:u.ports.length,body:!!u.body,inside:u.graph?Object.keys(u.graph.panes).length:0};});
ok(`a new pane is nothing (${cls0.occ}: ${cls0.cls}, ${cls0.ports} ports, body=${cls0.body}, ${cls0.inside} inside)`,
   cls0.ports===0 && !cls0.body && cls0.inside===0);
await page.screenshot({path:'dist/n-empty.png'});

// 3. author a leaf with FIVE ports — no kernel knows what it does
await page.evaluate(()=>window.eidola.openAuthor());
await page.waitForTimeout(300);
const authorOpen = await page.$eval('#author',e=>e.classList.contains('on'));
ok('author panel opens in the sky', authorOpen);
// add three more ports (starts with a + out)
for (let i=0;i<3;i++){ await page.click('[data-addport="1"]'); await page.waitForTimeout(60); }
const nPorts = await page.$$eval('.pedit',e=>e.length);
ok('boundary is authorable — '+nPorts+' ports declared', nPorts===5);
// name them
const names=['a','out','b','c','d'];
await page.evaluate((nm)=>{
  document.querySelectorAll('[data-f="name"]').forEach((el,i)=>{ el.value=nm[i];
    el.dispatchEvent(new Event('input',{bubbles:true})); });
  // make port 1 the out, rest in
  const dirs=document.querySelectorAll('[data-f="dir"]');
  dirs.forEach((el,i)=>{ el.value = i===1?'out':'in'; el.dispatchEvent(new Event('change',{bubbles:true})); });
}, names);
await page.waitForTimeout(120);
await page.evaluate(()=>{const t=document.querySelector('#a-src');
  t.value="return (i) => ({ out: (i.a||0)+(i.b||0)+(i.c||0)+(i.d||0) })";
  t.dispatchEvent(new Event('input',{bubbles:true}));});
await page.click('[data-run="1"]'); await page.waitForTimeout(300);
const authored = await page.evaluate(()=>{const g=window.eidola.graph;const o=Object.keys(g.panes)[0];
  const u=window.eidola.store.unit(g.panes[o].unit);
  return {cls:u.cls,ins:u.ports.filter(p=>p.dir==='in').length,body:u.body&&u.body['@'],lang:u.body&&u.body.lang};});
ok(`declared a leaf: ${authored.cls}, ${authored.ins} inputs, body=${authored.body}/${authored.lang}`,
   authored.body==='host/1' && authored.ins===4);

// 4. it actually computes
await cmd('library'); await page.waitForTimeout(250);
await page.click('.lcard[data-add="number"]'); await page.waitForTimeout(250);
await page.keyboard.type('10'); await page.keyboard.press('Enter'); await page.waitForTimeout(200);
const tags = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
const numOcc = tags.find(t=>/number/.test(t));
await cmd(`${numOcc} > ${cls0.occ}.a`);
await page.waitForTimeout(250);
const v = await bd(cls0.occ);
ok(`the authored 4-input leaf computes (${v})`, v==='10');

// 5. the starter library is authored source, not a prim
const libSrc = await page.evaluate(()=>{
  const g=window.eidola.graph;
  for(const o of Object.keys(g.panes)){const u=window.eidola.store.unit(g.panes[o].unit);
    if(u.body&&u.body['@']==='host/1'&&u.cls==='source') return u.body.src.slice(0,40);}
  return null;});
ok('library units are authored JS, not prims: "'+String(libSrc).replace(/\n/g,' ')+'…"', !!libSrc);
const anyPrim = await page.evaluate(()=>{
  const g=window.eidola.graph;
  return Object.keys(g.panes).some(o=>{const u=window.eidola.store.unit(g.panes[o].unit);
    return u.body && u.body['@']==='prim/1';});});
ok('no prim/1 body anywhere in the workspace', anyPrim===false);

// 6. powers are enforced
await page.evaluate(()=>window.eidola.empty());
await page.waitForTimeout(150);
await page.evaluate(()=>window.eidola.openAuthor());
await page.waitForTimeout(250);
await page.evaluate(()=>{const t=document.querySelector('#a-src');
  t.value="return (i,c) => ({ out: c.memFold('last',0) })";
  t.dispatchEvent(new Event('input',{bubbles:true}));});
await page.click('[data-run="1"]'); await page.waitForTimeout(350);
const errTxt = await page.$eval('#echo',e=>e.textContent);
ok('a body cannot take a power it did not declare: "'+errTxt.slice(0,60)+'"', /PowerDenied|mem:r/.test(errTxt));
await page.keyboard.press('Escape'); await page.waitForTimeout(200);

// 7. library + guide
await cmd('guide'); await page.waitForTimeout(300);
const guide = await page.$eval('#lib-body',e=>e.textContent);
ok('the guide is in the library', /a pane is nothing until you say so/.test(guide));
await page.screenshot({path:'dist/n-guide.png'});
await page.click('[data-tab="starter"]'); await page.waitForTimeout(250);
await page.screenshot({path:'dist/n-lib.png'});
await page.keyboard.press('Escape'); await page.waitForTimeout(200);

// 8. survives reload with an authored body
await page.evaluate(()=>window.eidola.save()); await page.waitForTimeout(200);
await page.reload(); await page.waitForTimeout(600);
const after = await page.evaluate(()=>{const g=window.eidola.graph;
  return Object.keys(g.panes).map(o=>{const u=window.eidola.store.unit(g.panes[o].unit);
    return u.body&&u.body['@']==='host/1'?u.body.src.length:0;}).filter(Boolean).length;});
ok('authored bodies survive the file ('+after+' leaves)', after>=2);

console.log('\nerrors:',errs.length?errs:'none');
await b.close();
