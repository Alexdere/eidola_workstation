import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1440,height:920}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(450);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(180);};
const tags=async()=>page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
const uid=o=>page.evaluate(x=>window.eidola.graph.panes[x].unit, o);
const ports=o=>page.evaluate(x=>window.eidola.unitOf(x).ports.map(p=>p.name+':'+p.dir), o);

// ---- wrapping makes an UNDECLARED node
await cmd('num 20'); await cmd('num 22');
let t=await tags(); await cmd(`add ${t[0]} ${t[1]}`);
t=await tags(); await cmd(`wrap ${t.join(' ')}`); await page.waitForTimeout(300);
const chip=(await tags()).find(x=>/^container/.test(x));
ok('wrap produces an undeclared node: '+chip, !!chip);
ok('its id is a ticket, not a hash: '+(await uid(chip)).slice(0,10), (await uid(chip)).startsWith('draft:'));
const cls=await page.$eval(`[data-occ="${chip}"]`,e=>e.className);
const badge=await page.$eval(`[data-occ="${chip}"] .draftmk`,e=>e.textContent).catch(()=>null);
ok('the pane says draft (badge="'+badge+'")', /isdraft/.test(cls) && badge==='draft');
const hashTxt=await page.$eval('#hash',e=>e.textContent);
ok('the whole workspace reads provisional: "'+hashTxt+'"', /draft/.test(hashTxt));
await page.screenshot({path:'dist/w-draft.png'});

// ---- a draft still runs, and can be given ports
const inner=(await page.evaluate(o=>Object.keys(window.eidola.unitOf(o).graph.panes), chip));
const addIn=inner.find(x=>/^add/.test(x));
await cmd(`expose ${chip} ${addIn}.out sum`); await page.waitForTimeout(250);
ok('a draft can be given ports: '+(await ports(chip)).join(' '), (await ports(chip)).includes('sum:out'));
await cmd(`look ${chip}`); await page.waitForTimeout(300);
const vals=await page.$$eval('.sub .sval',e=>e.map(x=>x.textContent));
ok('a draft computes while undeclared: '+vals.join(','), vals.includes('42'));
const shown=await page.$eval(`[data-occ="${chip}"] .bd`,e=>e.textContent);
ok('the container shows its boundary value: "'+shown.trim().slice(0,20)+'"', /42/.test(shown));

// ---- DECLARE seals it into one thing
await cmd(`declare ${chip}`); await page.waitForTimeout(400);
const after=await uid(chip);
ok('declared — the id is now a hash: '+after.slice(0,12), after.startsWith('unit:'));
const cls2=await page.$eval(`[data-occ="${chip}"]`,e=>e.className);
ok('it no longer reads as a draft', !/isdraft/.test(cls2));
const hash2=await page.$eval('#hash',e=>e.textContent);
ok('the workspace has an identity again: "'+hash2+'"', !/draft/.test(hash2));
const stillWorks=await page.$eval(`[data-occ="${chip}"] .bd`,e=>e.textContent);
ok('the chip still computes after sealing', /42/.test(stillWorks));
await page.screenshot({path:'dist/w-chip.png'});

// ---- it is in the library now
await cmd('library'); await page.waitForTimeout(300);
await page.click('[data-tab="mine"]'); await page.waitForTimeout(250);
const mine=(await page.$eval('#lib-body',e=>e.textContent)).replace(/\s+/g,' ');
ok('the chip landed in your library — tail: "'+mine.slice(-70)+'"', /container1/.test(mine));
await page.screenshot({path:'dist/w-lib.png'});
await page.keyboard.press('Escape');

// ---- two chips built the same way are the SAME chip
const seen = new Set(await tags());
await cmd('num 5');
const nA = (await tags()).find(x=>!seen.has(x));
await cmd(`wrap ${nA}`); await page.waitForTimeout(250);
const gA = (await tags()).find(x=>/^container/.test(x) && !seen.has(x));
seen.add(gA);
await cmd('num 5');
const nB = (await tags()).find(x=>!seen.has(x) && /^number/.test(x));
await cmd(`wrap ${nB}`); await page.waitForTimeout(250);
const gB = (await tags()).find(x=>/^container/.test(x) && !seen.has(x));
await cmd(`declare ${gA}`); await cmd(`declare ${gB}`); await page.waitForTimeout(400);
const [iA,iB] = await page.evaluate(([a,c])=>[a,c].map(o=>window.eidola.graph.panes[o].unit), [gA,gB]);
ok('two chips built the same way ARE one chip ('+iA.slice(0,14)+')', iA===iB && iA.startsWith('unit:'));

console.log('\nerrors:',errs.length?errs:'none');
await b.close();
