// The 2026-10-14 audit: smuggling and bugs found by driving the base, each phrased the way a
// person would notice it breaking. Run: node audit.mjs (after build-eidola-base.mjs).

import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { launchOpts } from "./chrome.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const BASE = pathToFileURL(join(here, "dist/eidola-base.html")).href;

const fails = [];
const ok = (name, cond, extra = "") => {
  console.log(`  ${cond ? "ok" : "XX"}  ${name}${cond ? "" : "  << " + extra}`);
  if (!cond) fails.push(name);
};

const browser = await chromium.launch(launchOpts);
const ctx = await browser.newContext({ viewport: { width: 1440, height: 920 } });
const errs = [];
const page = await ctx.newPage();
page.on("pageerror", (e) => errs.push(e.message));
page.on("dialog", (d) => d.dismiss());
await page.goto(BASE); await page.waitForTimeout(300);

const omni = page.locator("#omni");
const cmd = async (c) => { await omni.fill(c); await omni.press("Enter"); await page.waitForTimeout(120); };
const E = (f, a) => page.evaluate(f, a);
const echo = () => page.$eval("#echo", (e) => e.textContent);
const bd = (o) => page.$eval(`[data-occ="${o}"] .bd`, (e) => e.textContent.trim()).catch(() => null);
const fresh = async () => { await E(() => { window.eidola.running = false; window.eidola.reset(); }); await page.waitForTimeout(120); };
const hash = () => E(() => window.eidola.levels[0].engine.graphHash());
const out = (o, p) => E(([o, p]) => window.eidola.outValue(o, p), [o, p]);
const steps = async (n) => { for (let i = 0; i < n; i++) await cmd("step"); };
const declareAndCopy = async (box) => {
  await cmd(`declare ${box}`);
  return E((b) => { const e = window.eidola; return e.addPane(e.graph.panes[b].unit, "copy"); }, box);
};

console.log("smuggling");

// S1 — memory addresses do not depend on history
await fresh(); await cmd("total"); await cmd("total");
const h1 = await hash();
await fresh(); await cmd("num 1"); await cmd("total number1"); await cmd("del number1"); await cmd("total");
ok("the same structure hashes the same, however it was built", h1 === (await hash()));

// S2 — two copies of one declared counter keep their own memory
await fresh();
await cmd("num 1"); await cmd("total number1"); await cmd("wrap total1"); await cmd("expose container1 total1.out");
const copy = await declareAndCopy("container1");
await cmd(`number1 > ${copy}`);
await steps(4);
const a = await out("container1", "total1_out"), b = await out(copy, "total1_out");
// the original has counted since it was built; the copy only since it was placed. Shared,
// they would show one number, and it would climb twice as fast.
ok("two copies of one counter count separately, not each other's ticks", a > b && b >= 4 && b <= 6, `${a} / ${b}`);
ok("…each in its own log", await E((c) => { const p = window.eidola.store.persist;
  return p.readMem(`${c}/total1`).length > 0 && p.readMem("container1/total1").length > p.readMem(`${c}/total1`).length; }, copy));

// S2b — wrapping a counter keeps its count: its history follows its new name
await fresh(); await cmd("num 1"); await cmd("total number1"); await steps(3);
const before = await out("total1");
await cmd("wrap total1"); await cmd("expose container1 total1.out");
ok("wrapping a counter keeps its count (Closure: a level changes names, nothing else)",
  (await out("container1", "total1_out")) >= before, `${before} → ${await out("container1", "total1_out")}`);

// S3 — what a source receives is part of what it is (its door), so a copy behaves the same
await fresh();
await cmd("clock"); await cmd("show clock1"); await cmd("wrap clock1 show1"); await cmd("expose container1 show1.out");
const ccopy = await declareAndCopy("container1");
await steps(3);
ok("a copy of a chip with a clock inside still ticks", typeof (await out(ccopy, "show1_out")) === "number", String(await out(ccopy, "show1_out")));
ok("…because the clock's door is on its boundary (emit:clock)", await E(() => {
  const e = window.eidola; return e.store.unit(e.graph.panes.container1.unit).graph.panes.clock1 !== undefined
    && e.store.unit(e.store.unit(e.graph.panes.container1.unit).graph.panes.clock1.unit).powers.includes("emit:clock");
}));

// S4 — renaming or switching views cannot change what a prompt says
await fresh();
await cmd("num 3"); await cmd("round number1"); await cmd("wrap round1"); await cmd("ai container1"); await cmd("step");
const ctx1 = await out("context1");
await cmd("name container1 widget"); await cmd("step");
ok("renaming the described container leaves the context's text alone", ctx1 === (await out("context1")), `${String(ctx1).slice(0, 60)}`);
await fresh(); await cmd("num 3"); await cmd("ai"); await cmd("step");
const j1 = await out("join1");
await cmd("view new other"); await cmd("view free"); await cmd("step");
ok("making and switching views leaves an unscoped prompt alone", j1 === (await out("join1")));
ok("the description names no labels, kinds or views", !/view "|free|number \(number\)/.test(String(await out("context1"))), String(await out("context1")).slice(0, 120));

console.log("bugs");

// B1 — wrapping the talking assembly no longer feeds on itself
await fresh(); await cmd("ai");
await E(() => { const e = window.eidola; for (const o of Object.keys(e.graph.panes)) e.marked.add(o); });
await cmd("wrap"); await steps(6);
const len = await E(() => { const e = window.eidola; const v = e.valueAt("container1/context1#out"); return typeof v === "string" ? v.length : -1; });
ok("a wrapped assembly's context stays small (no runaway growth)", len >= 0 && len < 3000, String(len));
await cmd("ai"); await steps(2);
ok("…and a second assembly beside it does not hang the page", (await E(() => Object.keys(window.eidola.graph.panes).length)) >= 7);

// B2 — wrapping a draft
await fresh(); await cmd("num 1"); await cmd("round number1"); await cmd("wrap round1"); await cmd("wrap container1");
ok("a draft can be wrapped again", await E(() => !!window.eidola.graph.panes.container2 && window.eidola.isDraftPane("container2")), await echo());
await cmd("declare container2");
ok("…and declaring the outer one seals both", await E(() => !window.eidola.isDraftPane("container2")), await echo());

// B3 — fetch exists in the library
await fresh(); await cmd("fetch example.invalid"); await page.waitForTimeout(400);
ok("fetch places a fetch pane (whatever the network says)", await E(() => !!window.eidola.graph.panes.fetch1), await echo());

// B4 — the clock keeps counting inside a draft
await fresh(); await cmd("clock"); await cmd("show clock1"); await cmd("wrap clock1 show1"); await steps(3);
await cmd("into container1"); await steps(3);
ok("inside a draft the clock is not stuck at 0", (await out("clock1")) > 3, String(await out("clock1")));
await cmd("up");

// B5 — undo after up gives back the room as it was on the way down, values included
await fresh();
await cmd("num 1"); await cmd("num 2"); await cmd("add number1 number2");
await cmd("wrap number2 add1"); await cmd("expose container1 add1.out");
await cmd("into container1"); await cmd("del number2"); await cmd("up"); await cmd("undo");
await cmd("into container1");
ok("undo after up restores the deleted pane with its value", (await bd("number2")) === "2", String(await bd("number2")));
await cmd("up");

// B6 — notes belong to a level and go with it
await fresh();
await cmd("num 1"); await cmd("round number1"); await cmd("wrap round1"); await cmd("into container1");
await cmd("note N1"); await cmd("up"); await cmd("del container1");
await cmd("num 5"); await cmd("wrap number1"); await cmd("into container1");
ok("a deleted container's notes do not haunt the next one with its name", !(await page.$$eval(".note", (n) => n.map((x) => x.textContent))).some((t) => /N1/.test(t)));
await cmd("up");

// B7 — zoom refuses words
await fresh(); await cmd("zoom abc"); await cmd("zoom in");
ok("zoom abc leaves zoom a number", await E(() => Number.isFinite(window.eidola.view.zoom)));

// B8 — a name points at one thing
await fresh(); await cmd("num 1"); await cmd("num 2"); await cmd("name number1 number2");
ok("a name that is another pane's name is refused", await E(() => !window.eidola.present.label.number1), await echo());
await cmd("name number1 x"); await cmd("name number2 x");
ok("…and so is a label already in use", await E(() => window.eidola.present.label.number2 !== "x"));

// B9 — memory and the clock survive a reload
await fresh(); await cmd("num 1"); await cmd("total number1"); await steps(5);
const t0 = await out("total1"), c0 = await E(() => window.eidola.clockT);
await E(() => window.eidola.save());
await page.reload(); await page.waitForTimeout(400);
ok("a running total survives a reload", (await out("total1")) >= t0, `${t0} → ${await out("total1")}`);
ok("…and the clock carries on from where it was", (await E(() => window.eidola.clockT)) >= c0);

// B10 — a reload does not ask again
await fresh(); await cmd("ai");
await page.click('[data-occ="text1"] .editable'); await page.keyboard.type("hello"); await page.keyboard.press("Enter");
await page.waitForTimeout(300);
await E(() => window.eidola.save());
await page.reload(); await page.waitForTimeout(400);
ok("reloading a room with a question in it does not ask it again", await E(() => window.eidola.askLog.size === 0));

// B11 — wrapping in one view keeps the result in the others
await fresh(); await cmd("num 1"); await cmd("round number1");
await cmd("view new b"); await cmd("view add number1 round1"); await cmd("view free"); await cmd("wrap round1"); await cmd("view b");
ok("wrap in one view shows the container in the other views that showed its panes", await E(() => !!window.eidola.view.members.container1));

// B12 — one gesture, one undo
await fresh(); await cmd("const 5"); await cmd("undo");
ok("const then one undo leaves nothing behind", await E(() => Object.keys(window.eidola.graph.panes).length === 0));
await cmd("num 1"); await cmd("num 2"); await cmd("add number1 number2"); await cmd("undo");
ok("add with wires then one undo removes the add and its wires", await E(() => !window.eidola.graph.panes.add1 && window.eidola.graph.wires.length === 0));
await cmd("ai"); await cmd("undo");
ok("ai then one undo removes the whole assembly", await E(() => Object.keys(window.eidola.graph.panes).length === 2));
const u0 = await E(() => window.eidola.undoStack.length);
await cmd("wrap number1"); const u1 = await E(() => window.eidola.undoStack.length);
await cmd("into container1"); await cmd("up");
ok("going in and out of a draft without changing it adds no undo step", (await E(() => window.eidola.undoStack.length)) === u1 && u1 === u0 + 1);

// B13 — bodies written before folds became steps still run
await fresh();
await E(() => {
  const e = window.eidola;
  const u = { "@": "unit/1", ports: [{ "@": "port/1", name: "x", dir: "in", shape: "num", frame: null }, { "@": "port/1", name: "out", dir: "out", shape: "num", frame: null }],
    powers: ["mem:r", "mem:w"], cls: "delay", graph: null,
    body: { "@": "host/1", lang: "js", src: "return {\n  read:  (ctx)    => ({ out: ctx.memFold('sum', ctx.config ?? 0) }),\n  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }\n}" } };
  e.addPane(e.store.putUnit(u), "old");
});
await cmd("num 2"); await cmd("number1 > old1"); await steps(3);
ok("an old total body (memFold('sum')) still adds up", (await out("old1")) >= 4, String(await out("old1")));

console.log("second pass");

// R1 — redo inside a draft is refused, as undo is
await fresh(); await cmd("num 1"); await cmd("num 2"); await cmd("wrap number1"); await cmd("num 3"); await cmd("undo");
await cmd("into container1"); await cmd("redo"); await cmd("up");
ok("redo inside a draft is refused and the root stays whole", await E(() => !!window.eidola.graph.panes.container1 && !!window.eidola.graph.panes.number2));

// R2 — undo after loading a file never reaches back into the old room
await fresh(); await cmd("num 1"); await cmd("total number1"); await cmd("wrap total1"); await cmd("into container1");
await cmd("dump");
await page.$eval("#wsbox textarea", (t) => { t.value = JSON.stringify({ "@": "workspace/1", units: {}, root: { panes: {}, wires: [] } }); });
await page.click("#wsbox [data-wsload]"); await page.waitForTimeout(150);
await cmd("num 5"); await cmd("undo");
ok("undo after a load does not bring the old room back", await E(() => Object.keys(window.eidola.graph.panes).length === 0), await echo());

// R3 — wrapping the reply does not let the answer back into the context
await fresh(); await cmd("ai"); await cmd("wrap reply1"); await cmd("container1 > show1");
await page.click('[data-occ="text1"] .editable'); await page.keyboard.type("hi"); await page.keyboard.press("Enter");
await page.waitForTimeout(250); await steps(2);
ok("a wrapped reply's answer is not described back into the prompt", !/No API key/.test(String(await out("context1"))), String(await out("context1")).slice(0, 120));

// R4 — a context pointed at something gone describes nothing, not everything
await fresh(); await cmd("num 3"); await cmd("round number1"); await cmd("wrap round1"); await cmd("num 99");
await cmd("ai container1"); await cmd("wrap container1"); await steps(2);
const c4 = String(await out("context1"));
ok("a context whose target moved says so instead of widening to the surface", /not here/.test(c4) && !/99/.test(c4), c4.slice(0, 120));

// R5 — a new copy of a chip does not inherit a deleted copy's memory
await fresh();
await cmd("num 1"); await cmd("total number1"); await cmd("wrap total1"); await cmd("expose container1 total1.out");
const k1 = await declareAndCopy("container1");
await cmd(`number1 > ${k1}`); await steps(6); await cmd(`del ${k1}`);
const k2 = await E(() => { const e = window.eidola; return e.addPane(e.graph.panes.container1.unit, "copy"); });
await cmd(`number1 > ${k2}`); await steps(1);
ok("a re-placed copy starts its count fresh", (await out(k2, "total1_out")) <= 3, `${k2}: ${await out(k2, "total1_out")}`);
await cmd(`del ${k2}`); await cmd("undo");
ok("…and undoing a delete brings the copy back with its count", (await out(k2, "total1_out")) >= 2, String(await out(k2, "total1_out")));

// R6 — reloading inside a draft keeps what you did there
await fresh(); await cmd("num 1"); await cmd("wrap number1"); await cmd("into container1"); await cmd("num 7"); await cmd("const 9");
await E(() => window.eidola.save());
await page.reload(); await page.waitForTimeout(400);
await cmd("into container1");
ok("a reload while inside a draft keeps the draft's edits", await E(() => ["number1", "number2", "const1"].every((o) => o in window.eidola.graph.panes)),
  await E(() => Object.keys(window.eidola.graph.panes).join(",")));
await cmd("up");

// R7 — history no longer changes the hash
await fresh(); await cmd("num 1"); await cmd("total number1"); const hA = await hash();
await fresh(); await cmd("num 1"); await cmd("total number1"); await steps(2); await cmd("undo"); await cmd("total number1");
ok("place, tick, undo, place again hashes like placing once", hA === (await hash()), await E(() => window.eidola.graph.panes.total1?.mem));
await fresh(); await cmd("tour"); await cmd("run"); const hT = await hash(); await cmd("undo"); await cmd("tour"); await cmd("run");
ok("tour, undo, tour hashes like the first tour", hT === (await hash()));

// R8 — a counter inside a draft keeps counting while you work there
await fresh(); await cmd("num 1"); await cmd("total number1"); await cmd("wrap number1 total1"); await cmd("into container1");
await steps(1); const d0 = await out("total1"); await steps(4);
ok("inside a draft, a running total keeps counting", (await out("total1")) >= d0 + 3, `${d0} → ${await out("total1")}`);
await cmd("up");

console.log("inspect and dump (the workstation, folded in)");

// W1 — the inspect view
await fresh(); await cmd("num 1"); await cmd("num 2"); await cmd("add number1 number2"); await cmd("view inspect");
ok("view inspect shows every pane, the inspector and the hash",
  (await E(() => window.eidola.visible().length)) === 3
  && (await page.$eval("#insp", (e) => e.classList.contains("on")))
  && (await page.$eval("#hashwrap", (e) => e.style.display !== "none")));
const hv = await hash();
await cmd("view free");
ok("…and it is only a view: the hash did not move", hv === (await hash()));

// W2 — dump and load round-trip
await cmd("dump");
const text = await page.$eval("#wsbox textarea", (t) => t.value);
ok("dump shows a workspace/1 file", JSON.parse(text).workspace["@"] === "workspace/1");
await fresh(); await cmd("dump");
await page.$eval("#wsbox textarea", (t, v) => { t.value = v; }, text);
await page.click("#wsbox [data-wsload]"); await page.waitForTimeout(200);
ok("…and loading it back gives the same graph", (await hash()) === hv, await echo());

console.log(`\npage errors: ${errs.length ? errs.join(" | ") : "none"}`);
await browser.close();
if (fails.length || errs.length) { console.log(`\naudit: ${fails.length} failing`); process.exit(1); }
console.log("\naudit: all green");
