import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1280,height:860}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(400);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(140);};
const hash=()=>page.evaluate(()=>window.eidola.levels[0].engine.graphHash());
const ft=o=>page.$eval(`[data-occ="${o}"] .ft`,e=>e.textContent.trim()).catch(()=>'');

// ---------- routing
await cmd('num 1'); await cmd('num 2'); await cmd('num 3');
await cmd('add number1 number2');
ok('add wired from two', /a←number1/.test(await ft('add1')) && /b←number2/.test(await ft('add1')));
// explicit port, replacing
await cmd('number3 > add1.b');
ok('explicit port replaces (b←number3)', /b←number3/.test(await ft('add1')));
const wires1 = await page.evaluate(()=>window.eidola.graph.wires.length);
ok('replace did not duplicate the wire ('+wires1+' wires)', wires1===2);
// bad port name is explained, not silently wrong
await cmd('number1 > add1.zzz');
const m1 = await page.$eval('#echo',e=>e.textContent);
ok('unknown port explains options: "'+m1+'"', /no port/.test(m1)&&/a, b/.test(m1));
// full node -> chains instead of refusing
await cmd('number1 > add1');
await page.waitForTimeout(200);
const tags = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
const m2 = await page.$eval('#echo',e=>e.textContent);
ok('full node chained a second add: '+tags.filter(t=>/add/.test(t)).join(','), tags.includes('add2')&&/chained/.test(m2));
ok('chain is fed by the original + the new', /a←add1/.test(await ft('add2')) && /b←number1/.test(await ft('add2')));
// absent, not broken
await cmd('mul');
ok('unwired ports read as absent', /a·|·/.test(await ft('mul1')));

// ---------- ports command + inspector
await cmd('ports add1');
const inspOn = await page.$eval('#insp',e=>e.classList.contains('on'));
const inspTxt = await page.$eval('#insp-body',e=>e.textContent);
ok('inspect opens and shows the three groups', inspOn && /identity/.test(inspTxt) && /content/.test(inspTxt) && /presentation/.test(inspTxt));
ok('inspector says who declared the ports (authored leaf, not a kernel op)', /declared by whoever wrote it/.test(inspTxt));
await page.screenshot({path:'dist/i-insp.png'});
// gauge vs content in the inspector: rename must not move the hash
const h0=await hash();
await page.fill('#i-name','total'); await page.locator('#i-name').press('Enter'); await page.waitForTimeout(200);
const h1=await hash();
ok('inspector rename is gauge ('+h0.slice(0,10)+')', h0===h1);
// config IS content
await page.fill('#i-cfg','7'); await page.locator('#i-cfg').press('Enter'); await page.waitForTimeout(250);
const h2=await hash();
ok('inspector config moves the hash', h2!==h1);
await cmd('undo');

// ---------- zoom + endless ground
const z0=await page.evaluate(()=>window.eidola.view.zoom);
await page.evaluate(()=>{window.eidola.setZoom(1.6);});
await page.waitForTimeout(250);
const z1=await page.evaluate(()=>window.eidola.view.zoom);
const hz=await hash();
const scaled=await page.$eval('#ground-host',e=>e.style.transform);
ok('zoom '+z0+' -> '+z1+' ('+scaled+')', z1===1.6 && /scale/.test(scaled));
ok('zoom is gauge — hash still still', hz===await hash());
const canvasW=await page.$eval('#gcanvas',e=>parseFloat(e.style.width));
const groundW=await page.$eval('#ground',e=>e.clientWidth);
ok('canvas exceeds the viewport (endless): '+Math.round(canvasW)+' > '+groundW, canvasW>groundW);
await page.screenshot({path:'dist/i-zoom.png'});
await page.evaluate(()=>window.eidola.setZoom(1));

// ---------- box over nothing = a size
await page.evaluate(()=>window.eidola.toggleInsp(false)); await page.waitForTimeout(200);
// find genuinely empty ground: below every placed pane
const below = await page.evaluate(()=>{
  const v=window.eidola.view; let b=0;
  for(const m of Object.values(v.members)) if(m.zone==='ground') b=Math.max(b,m.y+m.h);
  return b+30;
});
const g=await page.$eval('#ground',e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,h:r.height};});
const sy = g.y + below - (await page.$eval('#ground',e=>e.scrollTop));
await page.mouse.move(g.x+120, sy); await page.mouse.down();
await page.mouse.move(g.x+430, sy+150,{steps:12});
await page.waitForTimeout(120);
const makeCls=await page.$eval('#marquee',e=>e.className);
await page.mouse.up(); await page.waitForTimeout(250);
const menuUp=await page.$('.menu')!==null;
const menuHdr=await page.$eval('.menu .mh',e=>e.textContent).catch(()=>'');
ok('box over nothing offers a size: "'+menuHdr.trim()+'"', menuUp && /\u00d7/.test(menuHdr) && /make/.test(makeCls));
if(menuUp){
  await page.click('.menu button[data-add="text"]'); await page.waitForTimeout(300);
  const madeW=await page.evaluate(()=>{const v=window.eidola.view;const ks=Object.keys(v.members).filter(k=>/^text/.test(k));return ks.length?Math.round(v.members[ks[ks.length-1]].w):0;});
  ok('pane made at the boxed size (w='+madeW+')', madeW>280&&madeW<340);
}
await page.keyboard.press('Escape');
await page.screenshot({path:'dist/i-final.png'});
console.log('\nerrors:',errs.length?errs:'none');
await b.close();
