import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1500,height:940}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);

// stand in for the model: echo back what it was asked, so we can prove what it SAW
await page.route('**/v1/messages', async (route) => {
  const body = JSON.parse(route.request().postData() || '{}');
  const prompt = body.messages?.[0]?.content ?? '';
  await route.fulfill({ status:200, contentType:'application/json',
    body: JSON.stringify({ content:[{ text: 'SAW>>' + prompt }] }) });
});

await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(450);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(180);};
const tags=async()=>page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
const byName=async n=>page.evaluate(x=>{const E=window.eidola;
  for(const o of Object.keys(E.graph.panes)) if((E.present.label[E.pathOf(o)]??o)===x) return o; return null;},n);

// ---- something to be scoped to
await cmd('num 20'); await cmd('num 22');
let t=await tags(); await cmd(`add ${t[0]} ${t[1]}`);
t=await tags(); await cmd(`wrap ${t.join(' ')}`); await page.waitForTimeout(250);
const box=(await tags()).find(x=>/^container/.test(x));
await cmd(`declare ${box}`); await page.waitForTimeout(300);

// ---- one gesture builds the assembly
await cmd(`ai ${box}`); await page.waitForTimeout(400);
const all=await tags();
ok('ai builds the assembly: '+all.filter(x=>/text|ask|reply|context|join/.test(x)).join(','),
   all.some(x=>/^ask/.test(x)) && all.some(x=>/^reply/.test(x)) && all.some(x=>/^context/.test(x)));
const askOcc=all.find(x=>/^ask/.test(x));
const cfg=await page.evaluate(o=>window.eidola.graph.panes[o].config, askOcc);
ok('ask knows where the answer lands (config='+cfg+')', /^reply/.test(String(cfg)));
await page.screenshot({path:'dist/v-ai.png'});

// ---- no key: it says so, and nothing leaks
const you=await byName('you');
await page.evaluate(o=>{const E=window.eidola; E.srcValues[E.pathOf(o)]='hello'; E.safeTick(); E.render();}, you);
await page.waitForTimeout(500);
const noKey=await page.evaluate(()=>{const E=window.eidola;
  const p=E.findPane('','reply'); return E.srcValues[p];});
ok('without a key it explains rather than failing: "'+String(noKey).slice(0,42)+'…"', /API key/.test(String(noKey)));

// ---- with a key: the loop closes
await cmd('key test-key-123');
await page.evaluate(o=>{const E=window.eidola; E.srcValues[E.pathOf(o)]=' — what is in there?'; E.safeTick(); E.render();}, you);
await page.waitForTimeout(900);
const answer=await page.evaluate(()=>{const E=window.eidola;
  const p=E.findPane('','reply'); return E.srcValues[p];});
ok('the answer came back through the reply source', String(answer).startsWith('SAW>>'));
ok('it saw the container it was scoped to: "'+String(answer).replace(/\n/g,' ').slice(5,64)+'…"',
   /container1/.test(String(answer)) && /add1/.test(String(answer)) && /42/.test(String(answer)));
ok('and it saw what I typed', /what is in there/.test(String(answer)));
const shown=await page.evaluate(async()=>{const E=window.eidola;
  for(const o of Object.keys(E.graph.panes)) if((E.present.label[E.pathOf(o)]??'')==='it says') return E.outValue(o); return null;});
ok('the display pane shows it', String(shown).startsWith('SAW>>'));
await page.screenshot({path:'dist/v-answer.png'});

// ---- the key is host state, not content
const dumped=await page.evaluate(()=>JSON.stringify(window.eidola.session()));
const inUnits=await page.evaluate(()=>JSON.stringify(window.eidola.session().workspace));
ok('the key is nowhere in the workspace', !inUnits.includes('test-key-123'));
ok('the key is not in the presentation either', !JSON.parse(dumped).present.opts.apiKey);
ok('it is kept beside, as a host secret', JSON.parse(dumped).secrets.apiKey==='test-key-123');

// ---- scope is wiring: point context elsewhere and it sees only that
await cmd('num 7'); await page.waitForTimeout(200);
const answer2=await page.evaluate(()=>{const E=window.eidola;
  const p=E.findPane('','reply'); return E.srcValues[p];});
ok('an unwired pane is not in what it sees', !/number3|number4/.test(String(answer2)));

console.log('\nerrors:',errs.length?errs:'none');
await b.close();
