import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const url = pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href;
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1280,height:860}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(url); await page.waitForTimeout(400);
const omni = page.locator('#omni');
const cmd = async c => { await omni.fill(c); await omni.press('Enter'); await page.waitForTimeout(140); };
const hash = ()=>page.evaluate(()=>window.eidola.levels[0].engine.graphHash());

// build something worth keeping
await cmd('num 20'); await cmd('num 22'); await cmd('add number1 number2'); await cmd('name add1 total');
await cmd('text a note to keep');
const h0 = await hash();
const tags0 = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent).sort());
await page.waitForTimeout(700);  // let the debounced save land

// --- background painted?
const bgUrl = await page.$eval('#bg', e=>e.style.backgroundImage.slice(0,30));
ok('background is painted ('+bgUrl+'…)', /^url\("?data:image\/png/.test(bgUrl));

// --- preset switch changes the painting
await page.click('#gear'); await page.waitForTimeout(300);
const before = await page.$eval('#bg', e=>e.style.backgroundImage.length);
await page.click('[data-seg="bg"][data-v="ridge"]'); await page.waitForTimeout(500);
const after = await page.$eval('#bg', e=>e.style.backgroundImage.length);
ok('preset switch repaints (ridge)', after!==before && after>1000);
await page.screenshot({path:'dist/b-ridge.png'});
await page.click('[data-seg="bg"][data-v="deep"]'); await page.waitForTimeout(500);
await page.screenshot({path:'dist/b-deep.png'});
await page.click('[data-seg="bg"][data-v="ridge"]'); await page.waitForTimeout(450);
await page.click('[data-close="1"]'); await page.waitForTimeout(200);

// --- fold the sky -> wall (no horizon)
const painted0 = await page.$eval('#bg', e=>e.style.backgroundImage.length);
await page.evaluate(()=>{ window.eidola.view.horizon=0; window.eidola.layout(); window.eidola.render(); });
await page.waitForTimeout(450);
const gone = await page.$eval('#horizon', e=>e.classList.contains('gone'));
const painted1 = await page.$eval('#bg', e=>e.style.backgroundImage.length);
ok('sky folded -> wall repaint, horizon gone', gone && painted1!==painted0);
await page.screenshot({path:'dist/b-wall.png'});
await page.evaluate(()=>{ window.eidola.view.horizon=0.34; window.eidola.layout(); window.eidola.render(); });
await page.waitForTimeout(400);

// --- RELOAD: does the graph survive?
await page.evaluate(()=>window.eidola.save());
await page.waitForTimeout(200);
await page.reload(); await page.waitForTimeout(600);
const h1 = await hash();
const tags1 = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent).sort());
const names1 = await page.$$eval('.pane .name',e=>e.map(x=>x.textContent));
const total = await page.$$eval('.pane', els=>{const p=els.find(e=>e.querySelector('.tag').textContent==='add1');return p?p.querySelector('.bd').textContent.trim():null;});
ok('graph survives reload (hash '+h0+' -> '+h1+')', h0===h1);
ok('panes survive: '+tags1.join(' '), JSON.stringify(tags0)===JSON.stringify(tags1));
ok('renamed label survives', names1.includes('total'));
ok('source values survive (total='+total+')', total==='42');
const bgAfter = await page.evaluate(()=>window.eidola.present.opts.bg);
ok('background choice survives ('+bgAfter+')', bgAfter==='ridge');

// --- refresh does not rebuild DOM while running
await cmd('clock');
await cmd('run'); await page.waitForTimeout(120);
// mark AFTER the render that starting a run legitimately performs
await page.evaluate(()=>{ document.querySelectorAll('.pane').forEach(e=>e.dataset.mark='keep'); });
const t0 = await page.evaluate(()=>window.eidola.levels[0].engine.tickIndex);
await page.waitForTimeout(1200);
const t1 = await page.evaluate(()=>window.eidola.levels[0].engine.tickIndex);
const kept = await page.evaluate(()=>{const a=[...document.querySelectorAll('.pane')];return a.length&&a.every(e=>e.dataset.mark==='keep');});
await cmd('run');
ok('ticks advanced '+t0+'->'+t1+' without rebuilding panes', kept && t1>t0);

await page.screenshot({path:'dist/b-final.png'});
console.log('\nerrors:', errs.length?errs:'none');
await b.close();
