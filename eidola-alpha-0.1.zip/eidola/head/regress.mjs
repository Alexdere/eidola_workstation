// Regression checks for the bugs found and fixed on 2026-10-13 (see CHANGELOG.md).
// Each check is phrased the way a user would notice it breaking. Run: node regress.mjs
// (after build-eidola-base.mjs). The retired workstation's own checks are legacy/smoke.mjs.

import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { launchOpts } from "./chrome.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const BASE = pathToFileURL(join(here, "dist/eidola-base.html")).href;

const fails = [];
const ok = (name, cond, extra = "") => {
  console.log(`  ${cond ? "ok" : "XX"}  ${name}${cond ? "" : "  << " + extra}`);
  if (!cond) fails.push(name);
};

const browser = await chromium.launch(launchOpts);
const ctx = await browser.newContext({ viewport: { width: 1440, height: 920 } });
const errs = [];
const open = async (url) => {
  const p = await ctx.newPage();
  p.on("pageerror", (e) => errs.push(`${url.split("/").pop()}: ${e.message}`));
  p.on("dialog", (d) => d.accept("box"));
  await p.goto(url); await p.waitForTimeout(400);
  return p;
};

// ============================================================ eidola-base
console.log("eidola-base");
let page = await open(BASE);
await page.evaluate(() => localStorage.clear()); await page.reload(); await page.waitForTimeout(400);
const omni = page.locator("#omni");
const cmd = async (c) => { await omni.fill(c); await omni.press("Enter"); await page.waitForTimeout(170); };
const tags = () => page.$$eval(".pane .tag", (e) => e.map((x) => x.textContent));
const bd = (o) => page.$eval(`[data-occ="${o}"] .bd`, (e) => e.textContent.trim()).catch(() => null);
const depth = () => page.evaluate(() => window.eidola.levels.length);

// B1 — descending in the free view shows the interior, with live values
await cmd("num 20"); await cmd("num 22"); await cmd("add number1 number2");
await cmd("wrap number1 number2 add1"); await page.waitForTimeout(250);
const chip = (await tags()).find((t) => /container/.test(t));
await cmd(`into ${chip}`); await page.waitForTimeout(300);
ok("descend (free view) shows the interior panes", (await tags()).length === 3, JSON.stringify(await tags()));
ok("…with the source's value inside (number1 = 20)", (await bd("number1")) === "20", await bd("number1"));
ok("…and the computed value inside (add1 = 42)", (await bd("add1")) === "42", await bd("add1"));
await cmd("up"); await page.waitForTimeout(300);
ok("up returns to the surface", (await depth()) === 1);

// B2 — a container with IN ports hears its real inputs when you descend
await cmd("num 5"); await cmd("num 6");
const [n3, n4] = (await tags()).filter((t) => /^number/.test(t)).slice(-2);
await cmd(`add ${n3} ${n4}`);
const add2 = (await tags()).filter((t) => /^add/.test(t)).pop();
await cmd(`wrap ${add2}`); await page.waitForTimeout(250);
const chip2 = (await tags()).filter((t) => /container/.test(t)).pop();
await cmd(`into ${chip2}`); await page.waitForTimeout(300);
ok("descend hands the draft its real inputs (inner add = 11)", (await bd(add2)) === "11", await bd(add2));
await cmd("up"); await page.waitForTimeout(300);

// B3 — a field in the author panel owns its keys
await cmd("num 1");
const nlast = (await tags()).filter((t) => /^number/.test(t)).pop();
const before = await page.evaluate(() => Object.keys(window.eidola.graph.panes).length);
await page.evaluate((o) => { window.eidola.focus = o; window.eidola.openAuthor(o); }, nlast);
await page.waitForTimeout(200);
const pname = page.locator('#author [data-f="name"]').first();
await pname.click(); await pname.press("End");
await page.keyboard.type("xy"); await page.keyboard.press("Backspace"); await page.waitForTimeout(120);
ok("typing into an author port name types there", (await pname.inputValue()) === "outx", await pname.inputValue());
ok("…the omnibar did not steal the letters", (await omni.inputValue()) === "", await omni.inputValue());
ok("…and Backspace did not delete the focused pane",
  (await page.evaluate(() => Object.keys(window.eidola.graph.panes).length)) === before);
await page.keyboard.press("Escape"); await page.waitForTimeout(150);
ok("Escape in the field still closes the panel",
  !(await page.$eval("#author", (e) => e.classList.contains("on"))));
await page.evaluate(() => window.eidola.save());
const baseRoom = await page.evaluate(() => Object.keys(window.eidola.graph.panes).sort());
await page.goto("about:blank");

// B4 — a session saved under the base's key by the OLD workstation (session/1) is kept aside
// and opened, never overwritten. The workstation is retired (head/legacy/); its format is a
// fixture now, captured from its last build.
{
  const { readFileSync } = await import("node:fs");
  const oldSession = JSON.stringify(JSON.parse(readFileSync(join(here, "fixtures/workstation-session.json"), "utf8")));
  page = await open(BASE);
  // this page must not save over it on the way out
  await page.evaluate((s) => { window.eidola.save = () => {}; localStorage.setItem("eidola/session", s); }, oldSession);
  await page.goto("about:blank");
  page = await open(BASE); await page.waitForTimeout(200);
  const kept = await page.evaluate(() => localStorage.getItem("eidola/session.other"));
  ok("base keeps a foreign session aside instead of overwriting it", kept === oldSession);
  ok("…and opens its content",
    (await page.evaluate(() => Object.keys(window.eidola.graph.panes).length)) > 0);
  await page.goto("about:blank");
}

// ============================================================ eidola-base, round 2 (Horizon review)
console.log("eidola-base · horizon review");
page = await open(BASE);
await page.evaluate(() => window.eidola.reset()); await page.waitForTimeout(200);
const om = page.locator("#omni");
const c2 = async (c) => { await om.fill(c); await om.press("Enter"); await page.waitForTimeout(170); };
const E = (f, a) => page.evaluate(f, a);
const echo2 = () => page.$eval("#echo", (e) => e.textContent);
const tags2 = () => page.$$eval(".pane .tag", (e) => e.map((x) => x.textContent));
const names2 = () => page.$$eval(".pane .name", (e) => e.map((x) => x.textContent));
const bd2 = (o) => page.$eval(`[data-occ="${o}"] .bd`, (e) => e.textContent.trim()).catch(() => null);
const fresh = async () => { await E(() => window.eidola.reset()); await page.waitForTimeout(150); };

// H1 — paste a number
await E(() => document.activeElement.blur());
await E(() => { const ev = new ClipboardEvent("paste", { clipboardData: new DataTransfer() }); ev.clipboardData.setData("text", "42"); document.dispatchEvent(ev); });
await page.waitForTimeout(200);
ok("pasting a number makes a number pane", (await tags2()).includes("number1") && (await bd2("number1")) === "42", await echo2());
await fresh();

// H2 — the old prim names still work, and every verb the omnibar suggests exists
for (const [v, want] of [["concat", "join1"], ["sum", "total1"], ["delay", "last1"], ["hist", "history1"], ["if", "pick1"], ["print", "log1"]]) {
  await c2(v);
  ok(`"${v}" still makes a ${want.replace(/1$/, "")}`, (await tags2()).includes(want), await echo2());
}
await fresh();
const libIds = await E(() => { const ids = []; for (const ch of "abcdefghijklmnopqrstuvwxyz") { window.eidola.el.omni.value = ch; window.eidola.suggest(); ids.push(...window.eidola.suggItems); } window.eidola.el.omni.value = ""; window.eidola.hideSugg(); return ids; });
await fresh();
const unknown = [];
for (const v of libIds) {
  if (["reset", "key", "ai", "fetch", "help", "options", "library", "guide", "inspect", "author", "new", "run", "undo", "step", "view", "zoom", "look", "expose", "declare", "into", "up", "name", "lens", "fold", "pin", "del", "grid", "sky", "ground", "ports", "wrap", "num", "text", "clock", "dump", "tour"].includes(v)) continue;
  await c2(v);
  if (/^unknown/.test(await echo2())) unknown.push(v);
}
ok(`no suggested verb is unknown (${libIds.length} suggested)`, unknown.length === 0, unknown.join(","));
await fresh();

// H3 — a name survives being wrapped; H4 — a deleted name does not haunt its successor
await c2("num 20"); await c2("num 22"); await c2("add number1 number2"); await c2("name add1 total");
await c2("wrap number1 number2 add1"); await page.waitForTimeout(200);
const ch = (await tags2()).find((t) => /container/.test(t));
await c2(`into ${ch}`); await page.waitForTimeout(250);
ok("a renamed pane keeps its name inside the container", (await names2()).includes("total"), JSON.stringify(await names2()));

// H5 — coming up out of a draft keeps it a draft (and records no lineage to a ticket)
await c2("up"); await page.waitForTimeout(250);
ok("up out of a draft leaves it a draft", await E((o) => window.eidola.isDraftPane(o), ch));
ok("…with no lineage pointing at a draft ticket", (await E(() => [...window.eidola.store.lineage.values()].filter((v) => v.startsWith("draft:")).length)) === 0);
await c2(`into ${ch}`); await page.waitForTimeout(200);
await c2("declare"); await page.waitForTimeout(250);
ok("declare from inside seals it on the way out", (await E(() => window.eidola.levels.length)) === 1 && !(await E((o) => window.eidola.isDraftPane(o), ch)));
await fresh();

await c2("text hello"); await c2("name text1 notes"); await c2("del text1"); await c2("text fresh");
ok("a new pane reusing a deleted name starts clean", !(await names2()).includes("notes"), JSON.stringify(await names2()));
await E(() => window.eidola.undo()); await page.waitForTimeout(150);
await E(() => window.eidola.undo()); await page.waitForTimeout(150);
ok("…and undoing the delete brings the name back", (await names2()).includes("notes"), JSON.stringify(await names2()));
await fresh();

// H6 — undo of a wrap puts the panes back, in view, with their values
await c2("num 20"); await c2("num 22"); await c2("add number1 number2");
await c2("wrap number1 number2 add1"); await page.waitForTimeout(200);
await E(() => window.eidola.undo()); await page.waitForTimeout(250);
ok("undo of a wrap restores panes and values", JSON.stringify([await bd2("number1"), await bd2("number2"), await bd2("add1")]) === JSON.stringify(["20", "22", "42"]),
  JSON.stringify([await bd2("number1"), await bd2("number2"), await bd2("add1")]));
await fresh();

// H7 — a refused edit inside a draft does not eat a root undo step
await c2("num 1"); await c2("num 2"); await c2("add number1 number2"); await c2("wrap add1"); await page.waitForTimeout(200);
const ch2 = (await tags2()).find((t) => /container/.test(t));
const depth0 = await E(() => window.eidola.undoStack.length);
await c2(`into ${ch2}`); await page.waitForTimeout(200);
await E(() => window.eidola.edit((g) => ({ ...g, wires: [...g.wires, { "@": "wire/1", from: ["add1", "out"], to: ["add1", "a"] }] }), "cycle"));
ok("a refused edit inside a draft leaves root undo alone", (await E(() => window.eidola.undoStack.length)) === depth0);
await c2("up"); await page.waitForTimeout(200);
await fresh();

// H8 — click a value to edit it; a number field refuses words
await c2("num 5");
await page.click('[data-occ="number1"] .editable'); await page.waitForTimeout(200);
ok("clicking a value opens an editor that keeps focus", (await page.$$eval(".ed", (e) => e.length)) === 1
  && (await E(() => document.activeElement?.classList.contains("ed"))));
await page.locator(".ed").fill("abc"); await page.locator(".ed").press("Enter"); await page.waitForTimeout(200);
ok("a number field refuses “abc” and keeps 5", (await bd2("number1")) === "5" && (await E(() => window.eidola.srcValues["number1"])) === 5);
await page.click('[data-occ="number1"] .editable'); await page.waitForTimeout(150);
await page.locator(".ed").fill("12"); await page.locator(".ed").press("Enter"); await page.waitForTimeout(200);
ok("…and takes 12", (await bd2("number1")) === "12");
await fresh();

// H9 — "x" only breaks a route as a word
await c2("num 3"); await c2("max"); await page.waitForTimeout(100);
ok("a word with an x in it is not read as a break", !/✕/.test(await echo2()));
await fresh();

// H10 — draft names stay with their drafts across a reload
await c2("num 1"); await c2("wrap number1"); await c2("num 2"); await c2("wrap number2"); await page.waitForTimeout(200);
await c2("del container1"); await page.waitForTimeout(100);
await E(() => window.eidola.save()); await page.reload(); await page.waitForTimeout(500);
const k = await E(() => Object.keys(window.eidola.graph.panes).map((o) => window.eidola.kindOf(o)));
ok(`after a reload the surviving draft is still called container2 (${k})`, JSON.stringify(k) === JSON.stringify(["container2"]));
await page.goto("about:blank");

// H11 — the talking assembly in an empty room: no freeze, and one question asks once
page = await open(BASE);
await page.evaluate(() => window.eidola.reset()); await page.waitForTimeout(200);
let calls = 0;
await page.route("**/v1/messages", async (route) => { calls++;
  await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ content: [{ text: "answer " + calls }] }) }); });
const raced = await Promise.race([
  page.evaluate(() => { window.eidola.run("ai"); return Object.keys(window.eidola.graph.panes).length; }),
  new Promise((r) => setTimeout(() => r("FROZE"), 5000)),
]);
ok(`ai in an empty room builds the assembly without freezing (${raced} panes)`, raced === 6, String(raced));
await page.evaluate(() => { window.eidola.present.opts.apiKey = "test"; const you = Object.keys(window.eidola.graph.panes).find((o) => window.eidola.present.label[o] === "you"); window.eidola.commitEdit(you, "hello"); });
for (let i = 0; i < 10; i++) { await page.evaluate(() => window.eidola.step()); await page.waitForTimeout(100); }
ok(`one typed question asks the model once, not on every tick (${calls} call)`, calls === 1);
// an answer wired back into its own prompt: it must stop by itself and say why
await page.evaluate(() => { const E = window.eidola; E.connect(["reply1", "out"], ["join1", "b"]); });
for (let i = 0; i < 12; i++) { await page.evaluate(() => window.eidola.step()); await page.waitForTimeout(120); }
const loopCalls = calls;
ok(`an answer fed back into its own prompt stops itself (${loopCalls - 1} more calls)`, loopCalls - 1 <= 3,
  String(loopCalls));
ok("…and says why", /keeps asking by itself/.test(await page.$eval("#echo", (e) => e.textContent)));
ok("context does not describe its own prompt or the reply",
  !/join1|reply1|ask1|show1/.test(await page.evaluate(() => window.eidola.describe("", window.eidola.graph, "context1"))));
await page.goto("about:blank");

// H12 — on a page that forbids eval (strict CSP: an artifact frame, an extension) the library still runs
{
  const { readFileSync, writeFileSync, mkdtempSync } = await import("node:fs");
  const { tmpdir } = await import("node:os");
  const art = readFileSync(join(here, "dist/eidola-base.artifact.html"), "utf8");
  const dir = mkdtempSync(join(tmpdir(), "eidola-csp-"));
  writeFileSync(join(dir, "csp.html"), `<!doctype html><html><head><meta charset="utf-8">`
    + `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'">`
    + `</head><body>${art}</body></html>`);
  page = await open(pathToFileURL(join(dir, "csp.html")).href);
  // typed, not evaluated: code run through the test driver is exempt from the page's CSP
  const o3 = page.locator("#omni");
  const c3 = async (c) => { await o3.fill(c); await o3.press("Enter"); await page.waitForTimeout(170); };
  await c3("num 20"); await c3("num 22"); await c3("add number1 number2");
  await page.waitForTimeout(150);
  ok("with eval forbidden, library bodies still compute (20 + 22)", (await page.$eval('[data-occ="add1"] .bd', (e) => e.textContent.trim()).catch(() => null)) === "42");
  await c3("new"); await c3("author empty1"); await page.waitForTimeout(150);
  await page.locator("#a-src").fill("return (i) => ({ out: 7 })");
  await page.click('#author [data-run="1"]'); await page.waitForTimeout(150);
  ok("…and a new body is refused with the reason", /CSP forbids eval/.test(await page.$eval("#echo", (e) => e.textContent)), await page.$eval("#echo", (e) => e.textContent));
  await page.goto("about:blank");
}

console.log(`\npage errors: ${errs.length ? errs.join(" | ") : "none"}`);
await browser.close();
if (fails.length || errs.length) { console.log(`\nregress: ${fails.length} failing`); process.exit(1); }
console.log("\nregress: all green");
