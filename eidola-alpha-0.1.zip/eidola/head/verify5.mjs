import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1400,height:900}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(450);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(160);};

// build something with an inside
await cmd('num 20'); await cmd('num 22'); await cmd('add number1 number2');
await cmd('wrap number1 number2 add1'); await page.waitForTimeout(250);
const tags = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
ok('wrapped into a container: '+tags.join(','), tags.some(t=>/container/.test(t)));
const grp = tags.find(t=>/container/.test(t));

// --- DOUBLE-CLICK must descend (was broken by the focus rebuild)
const box = await page.$eval(`[data-occ="${grp}"]`, e=>{const r=e.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height-18};});
await page.mouse.dblclick(box.x, box.y); await page.waitForTimeout(350);
const depth = await page.evaluate(()=>window.eidola.levels.length);
const crumb = await page.$eval('#tabs',e=>e.textContent);
ok('double-click descends (depth '+depth+', "'+crumb.trim().slice(0,40)+'")', depth===2);
await page.screenshot({path:'dist/y-inside.png'});
await page.keyboard.press('Escape'); await page.waitForTimeout(400);
ok('escape declares & ascends', (await page.evaluate(()=>window.eidola.levels.length))===1);

// --- LOOK THROUGH: same layer, interior visible
await cmd(`look ${grp}`); await page.waitForTimeout(350);
const subs = await page.$$eval('.sub .stag',e=>e.map(x=>x.textContent));
const vals = await page.$$eval('.sub .sval',e=>e.map(x=>x.textContent));
const stillTop = await page.evaluate(()=>window.eidola.levels.length);
ok('look-through shows the interior in place: '+subs.join(','), subs.length===3 && stillTop===1);
ok('through-view carries the real live values: '+vals.join(','), vals.includes('42'));
await page.screenshot({path:'dist/y-through.png'});

// --- two windows at once, on two different containers
await cmd('num 5'); await cmd('num 6'); await cmd('add number3 number4');
await cmd('wrap number3 number4 add2'); await page.waitForTimeout(250);
const tags2 = await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
const grp2 = tags2.filter(t=>/container/.test(t)).find(t=>t!==grp);
await cmd(`look ${grp2}`); await page.waitForTimeout(350);
const windows = await page.$$eval('.through',e=>e.length);
ok('two sublayers open side by side ('+windows+' windows)', windows===2);
await page.screenshot({path:'dist/y-two.png'});

// --- rearranging inside a window is gauge
const h0 = await page.evaluate(()=>window.eidola.levels[0].engine.graphHash());
const sb = await page.$eval('.sub', e=>{const r=e.getBoundingClientRect();return{x:r.x+40,y:r.y+14};});
await page.mouse.move(sb.x,sb.y); await page.mouse.down();
await page.mouse.move(sb.x+40, sb.y+46,{steps:8}); await page.mouse.up();
await page.waitForTimeout(250);
const h1 = await page.evaluate(()=>window.eidola.levels[0].engine.graphHash());
ok('moving a child through the window is gauge', h0===h1);

console.log('\nerrors:',errs.length?errs:'none');
await b.close();
