import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';
const url = pathToFileURL(join(process.cwd(), 'dist/eidola-base.html')).href;
const b = await chromium.launch(launchOpts);
const page = await b.newPage({ viewport: { width: 1280, height: 860 } });
const errs=[]; page.on('pageerror',e=>errs.push('PAGE: '+e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C: '+m.text());});
await page.goto(url); await page.waitForTimeout(350);
const omni = page.locator('#omni');
const cmd = async c => { await omni.fill(c); await omni.press('Enter'); await page.waitForTimeout(130); };
const hash = () => page.$eval('#hash', e=>e.textContent);
const tags = () => page.$$eval('.pane .tag', e=>e.map(x=>x.textContent));
const ok = (n,c)=>console.log((c?'  ok  ':'  XX  ')+n);

// --- naming from type+sequence
await cmd('num 20'); await cmd('num 22'); await cmd('text hello');
let t = await tags();
ok('names are type+sequence: '+t.join(' '), t.includes('number1')&&t.includes('number2')&&t.includes('text1'));

// --- op wired from named args
await cmd('add number1 number2');
await page.waitForTimeout(150);
const sum = await page.$$eval('.pane', els=>{const p=els.find(e=>e.querySelector('.tag').textContent==='add1');return p?p.querySelector('.bd').textContent.trim():null;});
ok('add number1 number2 = '+sum, sum==='42');

// --- rename then use the name
await cmd('name add1 total');
const named = await page.$$eval('.pane .name', e=>e.map(x=>x.textContent));
ok('rename shows label', named.includes('total'));

// --- free drag: hash unchanged
const h0 = await hash();
const hd = await page.$eval('[data-occ="number1"] .hd', e=>{const r=e.getBoundingClientRect();return{x:r.x+40,y:r.y+13};});
await page.mouse.move(hd.x,hd.y); await page.mouse.down();
await page.mouse.move(hd.x+90, hd.y+170,{steps:10}); await page.mouse.up();
await page.waitForTimeout(180);
const h1 = await hash();
const echoTxt = await page.$eval('#echo', e=>({t:e.textContent, c:e.className}));
ok('drag leaves hash still ('+h0+')', h0===h1);
ok('gauge echo is grey (silence=gauge): "'+echoTxt.t+'"', echoTxt.c==='');

// --- box select then wrap
await page.mouse.move(600,700); await page.mouse.down();
await page.mouse.move(180,430,{steps:10}); await page.mouse.up();
await page.waitForTimeout(160);
const markedN = await page.$$eval('.pane.marked', e=>e.length);
ok('box-select marked '+markedN+' panes', markedN>=1);
await page.screenshot({path:'dist/s-marked.png'});

// --- views: switching must not move the hash
const hv0 = await hash();
await page.click('.tab[data-view="media"]'); await page.waitForTimeout(200);
const mediaPanes = await page.$$eval('.pane', e=>e.length);
await page.click('.tab[data-view="systems"]'); await page.waitForTimeout(250);
const sysPanes = await page.$$eval('.pane', e=>e.length);
const hv1 = await hash();
ok('view switch keeps hash ('+hv0+' -> '+hv1+')', hv0===hv1);
ok('systems shows all ('+sysPanes+') vs media ('+mediaPanes+')', sysPanes>mediaPanes);
await page.screenshot({path:'dist/s-systems.png'});
await page.click('.tab[data-view="free"]'); await page.waitForTimeout(200);

// --- horizon drag (sky resize)
const skyH0 = await page.$eval('#sky', e=>e.clientHeight);
const hz = await page.$eval('#horizon', e=>{const r=e.getBoundingClientRect();return{x:r.x+300,y:r.y+8};});
await page.mouse.move(hz.x,hz.y); await page.mouse.down();
await page.mouse.move(hz.x, hz.y+120,{steps:8}); await page.mouse.up();
await page.waitForTimeout(180);
const skyH1 = await page.$eval('#sky', e=>e.clientHeight);
ok('horizon drag resizes sky ('+skyH0+' -> '+skyH1+')', skyH1>skyH0+50);

// --- options open in the sky
await page.click('#gear'); await page.waitForTimeout(250);
const optOn = await page.$eval('#options', e=>e.classList.contains('on'));
ok('options open in the sky', optOn);
await page.screenshot({path:'dist/s-options.png'});
// toggle one
await page.click('[data-opt="recede"]'); await page.waitForTimeout(120);
await page.click('[data-close="1"]'); await page.waitForTimeout(150);

// --- suggestions
await omni.fill('wr'); await page.waitForTimeout(200);
const suggOn = await page.$eval('#sugg', e=>e.classList.contains('on'));
const suggTxt = await page.$$eval('#sugg .k', e=>e.map(x=>x.textContent));
ok('suggestions show: '+suggTxt.join(','), suggOn&&suggTxt.includes('wrap'));
await omni.fill('');

// --- undo
const hU0 = await hash();
await cmd('num 7');
const hU1 = await hash();
await page.keyboard.press('Control+z'); await page.waitForTimeout(220);
const hU2 = await hash();
ok('undo restores structure ('+hU1+' -> '+hU2+')', hU2===hU0 && hU1!==hU0);

// --- drop-to-connect
await cmd('num 3'); await cmd('mul');
await page.waitForTimeout(150);
const src = await page.$('[data-occ="number3"]'); 
if (src) {
  const sb = await page.$eval('[data-occ="number3"] .hd', e=>{const r=e.getBoundingClientRect();return{x:r.x+40,y:r.y+13};});
  const tb = await page.$eval('[data-occ="mul1"]', e=>{const r=e.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2};});
  await page.mouse.move(sb.x,sb.y); await page.mouse.down();
  await page.mouse.move(tb.x,tb.y,{steps:12}); await page.mouse.up();
  await page.waitForTimeout(200);
  const ft = await page.$eval('[data-occ="mul1"] .ft', e=>e.textContent).catch(()=>'');
  ok('drop-to-connect wired: "'+ft.trim()+'"', /number3/.test(ft));
}

// --- Tab does not leak
await page.keyboard.press('Escape'); await page.waitForTimeout(80);
await page.keyboard.press('Tab'); await page.waitForTimeout(120);
const ae = await page.evaluate(()=>document.activeElement?.tagName||'NONE');
ok('Tab stays in page ('+ae+')', ae!=='NONE');

await page.screenshot({path:'dist/s-final.png'});
console.log('\nerrors:', errs.length?errs:'none');
await b.close();
