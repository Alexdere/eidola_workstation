// The tour view — checks for the showcase added 2026-10-13. Each one is phrased the way a
// person would notice it breaking. Run: node tour.mjs (after build-eidola-base.mjs).

import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { readFileSync, writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { launchOpts } from "./chrome.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const BASE = pathToFileURL(join(here, "dist/eidola-base.html")).href;

const fails = [];
const ok = (name, cond, extra = "") => {
  console.log(`  ${cond ? "ok" : "XX"}  ${name}${cond ? "" : "  << " + extra}`);
  if (!cond) fails.push(name);
};

const browser = await chromium.launch(launchOpts);
const errs = [];
const open = async (url, viewport = { width: 1440, height: 920 }) => {
  const ctx = await browser.newContext({ viewport });
  const p = await ctx.newPage();
  p.on("pageerror", (e) => errs.push(`${url.split("/").pop()}: ${e.message}`));
  await p.goto(url); await p.waitForTimeout(400);
  return p;
};
const driver = (page) => {
  const omni = page.locator("#omni");
  return {
    cmd: async (c) => { await omni.fill(c); await omni.press("Enter"); await page.waitForTimeout(170); },
    bd: (o) => page.$eval(`[data-occ="${o}"] .bd`, (e) => e.textContent.trim()).catch(() => null),
    E: (f, a) => page.evaluate(f, a),
    echo: () => page.$eval("#echo", (e) => e.textContent),
  };
};
const fizz = (n) => (n % 15 === 0 ? "FizzBuzz" : n % 3 === 0 ? "Fizz" : n % 5 === 0 ? "Buzz" : String(n));

console.log("tour");
let page = await open(BASE);
await page.evaluate(() => localStorage.clear()); await page.reload(); await page.waitForTimeout(400);
let { cmd, bd, E, echo } = driver(page);

// T1 — it is offered, not imposed
ok("opens empty, and the hint offers the tour", (await E(() => Object.keys(window.eidola.graph.panes).length)) === 0
  && /tour/.test(await page.$eval("#emptyhint", (e) => e.textContent)));
await page.click("[data-tour]"); await page.waitForTimeout(700);
await cmd("run");                         // hold still while we look
ok("clicking it builds a view called tour and opens it", (await E(() => window.eidola.present.active)) === "tour"
  && (await E(() => window.eidola.present.order.includes("tour"))));

// T2 — it lives in its own view
ok("the free view stays empty", (await E(() => Object.keys(window.eidola.present.views.free.members).length)) === 0);
ok("…and the hint does not show over the tour", (await page.$eval("#emptyhint", (e) => getComputedStyle(e).opacity)) === "0");
ok("the tour has captions (five stations and the sky)", (await page.$$eval(".note", (n) => n.length)) === 6);

// T3 — every station computes
ok("① 20 + 22 shows 42", (await bd("add1")) === "42");
const clockV = await E(() => window.eidola.outValue("clock1"));
ok("③ fizzbuzz agrees with the clock it reads", (await bd("fizzbuzz1")) === fizz(Math.floor(clockV)), `${await bd("fizzbuzz1")} vs clock ${clockV}`);
ok("④ 21 °C through the window is 69.8 °F", (await bd("show1")) === "69.8");
ok("④ the converter is declared, not a draft", (await E(() => !window.eidola.isDraftPane("container1"))));
ok("④ chip1 is the same unit as the converter", await E(() => window.eidola.graph.panes.chip1.unit === window.eidola.graph.panes.container1.unit));
ok("④ …with its own input: 100 °C is 212", /^212/.test(await bd("chip1") ?? ""), await bd("chip1"));
ok("④ the window is open and shows the interior live", (await page.$$eval('[data-through="container1"] .sub', (s) => s.length)) === 4);
ok("④ the constants are content — 1.8 is inside the unit", await E(() => {
  const e = window.eidola, u = e.store.unit(e.graph.panes.container1.unit);
  return Object.values(u.graph.panes).some((p) => p.config === 1.8) && Object.values(u.graph.panes).some((p) => p.config === 32);
}));
ok("② the always-counter is pinned, the other is not", await E(() => window.eidola.graph.panes.total2.pinned && !window.eidola.graph.panes.total1.pinned));
ok("⑤ the talking assembly is scoped to the converter", (await E(() => window.eidola.graph.panes.context1.config)) === "container1");
ok("fizzbuzz and c-to-f are in your library", await E(() => Object.values(window.eidola.present.mine).map((m) => m.name).sort().join() === "c-to-f,fizzbuzz"));

// T4 — nothing asked by itself
await cmd("run"); await page.waitForTimeout(1300);
ok("running, it asks nothing while “you” is empty", (await E(() => window.eidola.srcValues.reply1)) === "");

// T5 — watching is computing (stepped by hand, so the count is exact)
await cmd("run");                         // stop
const n = async (o) => Number(await bd(o));
const w0 = await n("total1"), a0 = await n("total2");
const h0 = await E(() => window.eidola.levels[0].engine.graphHash());
await cmd("view free");
for (let i = 0; i < 8; i++) await cmd("step");
const hFree = await E(() => window.eidola.levels[0].engine.graphHash());
await cmd("view tour");
const w1 = await n("total1"), a1 = await n("total2");
ok("switching views leaves the hash where it was", h0 === hFree && hFree === (await E(() => window.eidola.levels[0].engine.graphHash())));
ok("out of view, the watched counter paused (one tick, on the way back)", w1 - w0 <= 1, `${w0} → ${w1}`);
ok("…and the pinned one kept counting (every tick)", a1 - a0 >= 9, `${a0} → ${a1}`);

// T6 — a body written here can be read
await cmd("author fizzbuzz1"); await page.waitForTimeout(150);
ok("author opens fizzbuzz's own source", /FizzBuzz/.test(await page.$eval("#a-src", (e) => e.value).catch(() => "")));
await page.keyboard.press("Escape"); await page.waitForTimeout(100);

// T7 — tour again does not build twice
const nPanes = await E(() => Object.keys(window.eidola.graph.panes).length);
await cmd("view free"); await cmd("tour");
ok("tour again just opens it — nothing is built twice", (await E(() => window.eidola.present.active)) === "tour"
  && (await E(() => Object.keys(window.eidola.graph.panes).length)) === nPanes);

// T8 — notes are gauge
const h1 = await E(() => window.eidola.levels[0].engine.graphHash());
await cmd("note remember the converter");
ok("note adds a caption to this view", (await page.$$eval(".note", (x) => x.map((e) => e.textContent))).some((t) => /remember the converter/.test(t)));
ok("…and the hash does not move", h1 === (await E(() => window.eidola.levels[0].engine.graphHash())));
await cmd("note clear");
ok("note clear removes the captions here", (await page.$$eval(".note", (n) => n.length)) === 0);
await cmd("undo");
ok("undo brings them back", (await page.$$eval(".note", (n) => n.length)) === 7);

// T9 — a constant from the omnibar
await cmd("view free"); await cmd("const 5");
ok("const 5 makes a constant that shows 5, held in config", (await bd("const1")) === "5"
  && (await E(() => window.eidola.graph.panes.const1.config)) === 5);
await cmd("undo"); await cmd("view tour");

// T10 — survives a reload
await E(() => window.eidola.save());
await page.reload(); await page.waitForTimeout(500);
({ cmd, bd, E, echo } = driver(page));
ok("after a reload the tour is still there, captions and all", (await E(() => window.eidola.present.active)) === "tour"
  && (await page.$$eval(".note", (n) => n.length)) === 7);
ok("…and still computes (chip1 212, 69.8 °F)", /^212/.test(await bd("chip1") ?? "") && (await bd("show1")) === "69.8");

// T11 — one undo takes it all away
await cmd("reset yes");                  // (a reload would save the room again on the way out)
await cmd("tour"); await cmd("run");
await cmd("undo");
ok("one undo removes the whole tour", (await E(() => Object.keys(window.eidola.graph.panes).length)) === 0
  && !(await E(() => window.eidola.present.order.includes("tour"))) && (await E(() => window.eidola.present.active)) === "free");
await cmd("tour"); await cmd("run");
ok("…and tour builds it again", (await E(() => Object.keys(window.eidola.graph.panes).length)) === nPanes);

// T12 — with no key, talking says what is missing, once
await page.click('[data-occ="text1"] .editable'); await page.waitForTimeout(120);
await page.keyboard.type("what does this do?"); await page.keyboard.press("Enter"); await page.waitForTimeout(300);
ok("typing in “you” with no key answers that a key is needed", /No API key yet/.test(await E(() => window.eidola.srcValues.reply1) ?? ""));
ok("…without tripping the runaway guard", !/keeps asking/.test(await echo()));

// T13 — a narrow window fits the tour by zooming its own view
page = await open(BASE, { width: 820, height: 760 });
await page.evaluate(() => localStorage.clear()); await page.reload(); await page.waitForTimeout(400);
({ cmd, bd, E, echo } = driver(page));
await cmd("tour"); await cmd("run");
ok("in a narrow window the tour zooms out to fit", (await E(() => window.eidola.view.zoom)) < 1
  && (await E(() => window.eidola.present.views.free.zoom)) === 1);

// T14 — under a strict CSP (an artifact frame), the tour still builds and computes
{
  const art = readFileSync(join(here, "dist/eidola-base.artifact.html"), "utf8");
  const dir = mkdtempSync(join(tmpdir(), "eidola-csp-"));
  writeFileSync(join(dir, "csp.html"), `<!doctype html><html><head><meta charset="utf-8">`
    + `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; connect-src 'none'">`
    + `</head><body>${art}</body></html>`);
  page = await open(pathToFileURL(join(dir, "csp.html")).href);
  // typed, not evaluated: code run through the test driver is exempt from the page's CSP
  const o3 = page.locator("#omni");
  await o3.fill("tour"); await o3.press("Enter"); await page.waitForTimeout(900);
  await o3.fill("run"); await o3.press("Enter"); await page.waitForTimeout(150);
  const b3 = (o) => page.$eval(`[data-occ="${o}"] .bd`, (e) => e.textContent.trim()).catch(() => null);
  ok("with eval forbidden, the tour builds and its bodies compute", /^212/.test(await b3("chip1") ?? "")
    && (await b3("add1")) === "42" && !["—", null].includes(await b3("fizzbuzz1")), `${await b3("chip1")} ${await b3("fizzbuzz1")}`);
}

console.log(`\npage errors: ${errs.length ? errs.join(" | ") : "none"}`);
await browser.close();
if (fails.length || errs.length) { console.log(`\ntour: ${fails.length} failing`); process.exit(1); }
console.log(`\ntour: all green`);
