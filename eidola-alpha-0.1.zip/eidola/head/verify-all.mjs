// Runs the eight browser walkthroughs of eidola-base (verify.mjs … verify8.mjs) in order and
// fails if any check prints XX, any page error is reported, or any script crashes. Each script
// still runs on its own: `node verify5.mjs`. Screenshots they take land in shots/.
import { spawnSync } from "node:child_process";
import { mkdirSync, readdirSync, renameSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const scripts = ["verify", "verify2", "verify3", "verify4", "verify5", "verify6", "verify7", "verify8"];
let bad = 0, checks = 0;
for (const s of scripts) {
  const r = spawnSync(process.execPath, [`${s}.mjs`], { cwd: here, encoding: "utf8", timeout: 180_000 });
  const out = (r.stdout ?? "") + (r.stderr ?? "");
  const oks = out.split("\n").filter((l) => /^\s+ok\s/.test(l)).length;
  const xx = out.split("\n").filter((l) => /^\s+XX\s/.test(l));
  const errLine = out.split("\n").find((l) => l.startsWith("errors:")) ?? "";
  const pageErr = errLine && !/errors: none/.test(errLine);
  checks += oks + xx.length;
  const fail = r.status !== 0 || xx.length > 0 || pageErr;
  if (fail) bad++;
  console.log(`  ${fail ? "XX" : "ok"}  ${s.padEnd(8)} ${oks} ok${xx.length ? `, ${xx.length} failing` : ""}${pageErr ? ", page errors" : ""}${r.status ? `, exit ${r.status}` : ""}`);
  for (const l of xx) console.log("        " + l.trim());
  if (r.status && !xx.length) console.log(out.split("\n").slice(-12).join("\n"));
}
mkdirSync(join(here, "shots"), { recursive: true });
for (const f of readdirSync(join(here, "dist"))) if (f.endsWith(".png")) renameSync(join(here, "dist", f), join(here, "shots", f));
console.log(bad ? `\nverify: ${bad} script(s) failing` : `\nverify: all green (${checks} checks)`);
process.exit(bad ? 1 : 0);
