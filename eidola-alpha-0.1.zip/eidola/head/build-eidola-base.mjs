// Bundle core + eidola.ts into ONE self-contained page: Eidola · base.
//
// Naming, fixed 2026-10-14: core (the kernel) · base (this — the minimal surface) · home (the
// first suite, not built yet). "Horizon" is only the name of the sky/ground layout this page
// still borrows from Home. The old workstation is the `inspect` view of this page now.
// Behaviour comes from the authored library (generated-from-core), never a kernel table.
import * as esbuild from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
await import("./tools/compile-library.mjs");   // regenerate src/library.compiled.ts from library.ts
mkdirSync(join(here, "dist"), { recursive: true });

const out = await esbuild.build({
  entryPoints: [join(here, "src/eidola.ts")],
  bundle: true, format: "iife", target: "es2022", write: false, legalComments: "none",
});
const js = out.outputFiles[0].text;

const shell = readFileSync(join(here, "index-eidola.html"), "utf8")
  .replace("<title>Eidola</title>", "<title>Eidola · base</title>");
const page = shell.replace("/*APP*/", () => js);

// the artifact form (no doctype/head/body — the host wraps it), published as "Eidola · base"
writeFileSync(join(here, "dist/eidola-base.artifact.html"), page);

writeFileSync(
  join(here, "dist/eidola-base.html"),
  `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n` +
  `<meta name="viewport" content="width=device-width,initial-scale=1">\n` +
  page.replace(/^(<title>[\s\S]*?<\/style>)/, "$1\n</head>\n<body>") + "\n</body>\n</html>\n",
);

const kb = (s) => `${(Buffer.byteLength(s) / 1024).toFixed(0)} kB`;
console.log(`eidola-base: js ${kb(js)}, page ${kb(page)}`);
