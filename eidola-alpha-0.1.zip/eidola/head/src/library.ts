// The library — presets, the things you make, and the things you import.
//
// NOTHING here is core. Every entry below is an ordinary authored leaf: a class, a boundary,
// declared powers, and a body written in JavaScript. `add` is not a primitive of anything —
// it is four lines someone wrote, and you can open it, change it, and declare your own.
// That is the whole point: the core limits what a node IS, never what a node DOES.

import { Cls, Port, Unit, Value, leaf, port } from "../../core/src/index.js";

export interface Authored {
  id: string;                 // library key, not identity — identity is the hash of the unit
  name: string;
  group: string;
  note: string;
  cls: Exclude<Cls, "container">;
  ports: Array<[string, "in" | "out", string]>;
  powers: string[];
  src: string;
}

const P = (ps: Array<[string, "in" | "out", string]>): Port[] =>
  ps.map(([n, d, s]) => port(n, d, s));

export function unitOf(a: Authored): Unit {
  return leaf(a.cls, { "@": "host/1", lang: "js", src: a.src }, P(a.ports), a.powers);
}

const A = (
  id: string, name: string, group: string, cls: Authored["cls"],
  ports: Authored["ports"], powers: string[], src: string, note: string,
): Authored => ({ id, name, group, cls, ports, powers, src, note });

const n = (x: Value | undefined) => (typeof x === "number" ? x : 0);

export const STARTER: Authored[] = [
  // ---------------------------------------------------------------- values
  A("number", "number", "values", "source",
    [["out", "out", "num"]], ["emit:typed"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "A number you type. Novelty enters only at a source — so this declares `emit:typed`: the power to receive what a person types. The door is part of what it IS."),

  A("text", "text", "values", "source",
    [["out", "out", "str"]], ["emit:typed"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "Some text. Same shape as number — a source is defined by where change enters, not by what it carries."),

  A("clock", "clock", "values", "source",
    [["out", "out", "num"]], ["emit:clock"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "Ticks. There is no `now` anywhere in a ctx — time is not a power. A clock is a source with the clock door (`emit:clock`), or it does not exist."),

  A("fetch", "fetch", "values", "source",
    [["out", "out", "str"]], ["emit:fetch"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "What a url answered. The host does the fetching and journals the text; the unit only says which door it listens at."),

  A("const", "constant", "values", "pure",
    [["out", "out", "any"]], [],
    `return (i, ctx) => ({ out: ctx.config ?? 0 })`,
    "A fixed value, held in config — so it is content, part of the hash. A number you type is novelty and enters at a source; a constant is part of what a thing IS. Change it in inspect."),

  // ---------------------------------------------------------------- number
  A("add", "add", "number", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: (i.a || 0) + (i.b || 0) })`,
    "a + b. Four lines. Nothing in the kernel knows what addition is — copy this and make one that takes five inputs."),

  A("sub", "subtract", "number", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: (i.a || 0) - (i.b || 0) })`, "a − b."),

  A("mul", "multiply", "number", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: (i.a || 0) * (i.b || 0) })`, "a × b."),

  A("div", "divide", "number", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: (i.b || 0) === 0 ? 0 : (i.a || 0) / i.b })`, "a ÷ b, and 0 rather than an explosion."),

  A("sum5", "sum (five in)", "number", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["c", "in", "num"], ["d", "in", "num"],
     ["e", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: (i.a||0)+(i.b||0)+(i.c||0)+(i.d||0)+(i.e||0) })`,
    "Five inputs, because a boundary is whatever you declare. There is no arity limit anywhere — this exists to prove it."),

  A("round", "round", "number", "pure",
    [["a", "in", "num"], ["out", "out", "num"]], [],
    `return (i) => ({ out: Math.round(i.a || 0) })`, "Nearest whole number."),

  // ---------------------------------------------------------------- test
  A("gt", "greater than", "test", "pure",
    [["a", "in", "num"], ["b", "in", "num"], ["out", "out", "bool"]], [],
    `return (i) => ({ out: (i.a || 0) > (i.b || 0) })`, "a > b."),

  A("eq", "equal", "test", "pure",
    [["a", "in", "any"], ["b", "in", "any"], ["out", "out", "bool"]], [],
    `return (i) => ({ out: JSON.stringify(i.a ?? null) === JSON.stringify(i.b ?? null) })`, "Same value?"),

  A("pick", "pick", "test", "pure",
    [["c", "in", "bool"], ["a", "in", "any"], ["b", "in", "any"], ["out", "out", "any"]], [],
    `return (i) => ({ out: i.c === true ? (i.a ?? null) : (i.b ?? null) })`,
    "c ? a : b. Both branches are computed — this is dataflow, not control flow."),

  // ---------------------------------------------------------------- text
  A("join", "join", "text", "pure",
    [["a", "in", "any"], ["b", "in", "any"], ["out", "out", "str"]], [],
    `return (i) => ({ out: String(i.a ?? '') + String(i.b ?? '') })`, "Two things, one string."),

  A("label", "label", "text", "pure",
    [["x", "in", "any"], ["out", "out", "str"]], [],
    `return (i, ctx) => ({ out: String(ctx.config ?? '') + String(i.x ?? '') })`,
    "Puts its config in front of whatever arrives. Config is content — it is part of the hash."),

  A("show", "show", "text", "pure",
    [["x", "in", "any"], ["out", "out", "any"]], [],
    `return (i) => ({ out: i.x === undefined ? '' : i.x })`,
    "Passes a value straight through. A source holds what you type; this shows what arrives — which is why a display is a pure node and not a special kind of pane."),

  // ---------------------------------------------------------------- memory
  A("last", "last tick", "memory", "delay",
    [["x", "in", "any"], ["out", "out", "any"]], ["mem:r", "mem:w"],
    `return {
  read:  (ctx)    => ({ out: ctx.memFold((acc, v) => v, ctx.config ?? null) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
    "What came in last tick. A delay reads BEFORE anything computes and writes after — which is why it can safely close a loop. The fold is written here: the core names no folds."),

  A("total", "running total", "memory", "delay",
    [["x", "in", "num"], ["out", "out", "num"]], ["mem:r", "mem:w"],
    `return {
  read:  (ctx)    => ({ out: ctx.memFold((acc, v) => acc + (typeof v === 'number' ? v : 0),
                                         typeof ctx.config === 'number' ? ctx.config : 0) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
    "Adds up everything it has ever seen. The log is append-only, so this is replayable."),

  A("history", "history", "memory", "delay",
    [["x", "in", "any"], ["out", "out", "list"]], ["mem:r", "mem:w"],
    `return {
  read:  (ctx)    => ({ out: ctx.memFold((acc, v) => { acc.push(v); return acc; }, []) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
    "The whole log, as a value. A chart of history is then an ordinary node, not a feature."),

  // ---------------------------------------------------------------- talking
  // A key is NOT content. It never appears in a body, never in a config, never in the hash —
  // it lives with the host, and a unit asks for the power to use it. That is Law 4 doing the
  // only job it has.
  A("ask", "ask", "talking", "effect",
    [["prompt", "in", "str"]], ["world"],
    `return {
  act: (i, ctx) => {
    if (i.prompt === undefined || i.prompt === '') return;
    ctx.world({ "@": "ask/1", prompt: String(i.prompt), to: String(ctx.config ?? '') });
  }
}`,
    "Sends its prompt out of the graph. An effect has no output — the answer comes back as novelty, through a reply. Its config names which reply pane receives it."),

  A("reply", "reply", "talking", "source",
    [["out", "out", "str"]], ["emit:reply"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "Where an answer arrives. Novelty enters only at a source, so this is the only shape an async reply can take — and it means a conversation replays exactly."),

  A("context", "context", "talking", "source",
    [["out", "out", "str"]], ["emit:context"],
    `return (i, ctx) => {
  const v = ctx.journal();
  return v === undefined ? {} : { out: v };
}`,
    "Describes what it is pointed at — a container, or this view. Reflection is an ordinary source, not a privileged channel. Wire it into a prompt and that is exactly what gets seen: scope is wiring, not permission."),

  // ---------------------------------------------------------------- world
  A("log", "log", "world", "effect",
    [["x", "in", "any"]], ["world"],
    `return { act: (i, ctx) => ctx.world(i.x ?? null) }`,
    "Sends a value out of the graph. An effect has no output, so nothing can observe it — it is dead unless pinned."),
];

/**
 * Examples — authored leaves that are not presets. They are not offered in the palette or the
 * omnibar; the tour writes them into a room as "a body written here", and from then on they are
 * yours like anything you author. Kept in this file only so they ship precompiled.
 */
export const EXAMPLES: Authored[] = [
  A("fizzbuzz", "fizzbuzz", "examples", "pure",
    [["n", "in", "num"], ["out", "out", "str"]], [],
    `return (i) => {
  if (typeof i.n !== "number") return {};
  const n = Math.floor(i.n);
  if (n % 15 === 0) return { out: "FizzBuzz" };
  if (n % 3 === 0) return { out: "Fizz" };
  if (n % 5 === 0) return { out: "Buzz" };
  return { out: String(n) };
}`,
    "One port in, one out, a few lines. Nothing absent is invented: with no number arriving it says nothing at all."),
];

/**
 * Bodies written before 2026-10-14 named their folds (`ctx.memFold('sum', 0)`); the kernel no
 * longer knows those names. Their source text is their identity, so it is not rewritten — the
 * head reads these three old names on their behalf instead. Library vocabulary, kept with the
 * library, never in the core.
 */
export const LEGACY_FOLDS: Record<string, { step: (acc: Value, v: Value) => Value; init: (i: Value) => Value }> = {
  last: { step: (_a, v) => v, init: (i) => i },
  sum: { step: (a, v) => (a as number) + (typeof v === "number" ? v : 0), init: (i) => (typeof i === "number" ? i : 0) },
  all: { step: (a, v) => [...(a as Value[]), v], init: () => [] },
};

/** the delay bodies as they were written before 2026-10-14 — still shipped precompiled, so a
 *  room saved with them still runs on a page that may not eval */
export const LEGACY_SRC: string[] = [
  `return {
  read:  (ctx)    => ({ out: ctx.memFold('last', ctx.config ?? null) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
  `return {
  read:  (ctx)    => ({ out: ctx.memFold('sum', ctx.config ?? 0) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
  `return {
  read:  (ctx)    => ({ out: ctx.memFold('all', []) }),
  write: (i, ctx) => { if (i.x !== undefined) ctx.memAppend(i.x); }
}`,
];

/** which door a source listens at — read off its declared powers, so it is content */
export function doorOf(powers: string[]): string | null {
  const p = powers.find((x) => x.startsWith("emit:"));
  return p ? p.slice(5) : null;
}

/** The words, fixed. Anything not on this list is not a concept. */
export const WORDS: Array<[string, string]> = [
  ["unit", "The thing itself — what something IS. Content-addressed: change a character and it is a different unit. Every unit is one of exactly two kinds."],
  ["leaf", "A unit with a BODY: source you wrote, plus the ports and powers it declares. It computes directly."],
  ["container", "A unit with an INTERIOR: a graph of panes and wires. It computes by way of what is inside it. Nothing outside can reach in except through its ports."],
  ["pane", "An OCCURRENCE of a unit — and the rectangle you see. Two panes may hold the same unit, in which case they are one thing computed once."],
  ["port", "A named opening on a unit's boundary, with a direction and a shape. A unit may have any number."],
  ["wire", "A connection between two ports at ONE level. There is no such thing as a wire that crosses a boundary."],
  ["draft", "A unit that exists and has no identity yet. It runs, it can be built in and given ports — but nothing may cite it, and it is not in your library."],
  ["declared", "A unit that has been sealed and hashed. Citable, shareable, memoised, in your library."],
  ["wrap", "Verb. Make the marked panes the interior of a new container. What you get is a DRAFT."],
  ["declare", "Verb. Seal a draft. Everything below it is sealed too, and the whole assembly becomes one unit with one identity."],
  ["expose", "Verb. Turn a child's port into a port on its container's boundary."],
  ["look", "Verb. Open a window through a container: its interior, live, inside its own rectangle, without leaving this level."],
  ["enter", "Verb. Go inside a container as a whole surface, one level down."],
];

export const GUIDE: Array<[string, string]> = [
  ["two kinds of unit, and nothing else",
   "A leaf has a body — code you wrote. A container has an interior — a graph. That is the whole taxonomy. A pane is where one of them appears; wrap makes a container; declare gives it an identity."],
  ["a pane is nothing until you say so",
   "Box out an area and you get an empty pane. It has no ports, no body and computes nothing — and that is the base state, not a broken state. It becomes something because you put something in it."],
  ["two ways to fill one",
   "Write a body — a class, a boundary, and some source — and it is a leaf. Or go inside it and build from other panes, and it is a group. Both end up as ordinary units with a content hash."],
  ["ports are yours",
   "Any number, in or out, any shape you like. The core never limits arity; it only cares that a boundary exists. If something you use has two inputs and you want five, open it and write one that takes five."],
  ["class is the one thing the core cares about",
   "pure computes · source is where novelty enters · delay remembers across ticks · effect touches the world. That is about time and consequence, not about what you compute — which is why the kernel needs it and needs nothing else."],
  ["powers are asked for, never assumed",
   "A body only gets what its unit declares: mem:r, mem:w, emit, world. Ask for nothing and the ctx has nothing on it — a violation is unwritable, not merely caught."],
  ["identity is content",
   "Change a character of a body and it is a different unit with a different hash. So moving, renaming, folding and zooming can never change what a thing is — and two panes over one unit really are one thing, computed once."],
  ["shape, then declare",
   "Fix a boundary while the inside is still moving: it can be wired and played. Freeze it when it settles and it gets a hash, a name, and a place in your library."],
];
