// The environment — painted, not shipped.
//
// The reference art works by one trick repeated: terrain is drawn as stepped blocks, and
// each band fades between *complementary* warm and cool. Where two bands meet, the eye is
// pulled through a neutral zone it reads as haze, which is what gives the depth without any
// perspective. Everything here is procedural, so the whole environment costs a few hundred
// bytes instead of a megabyte of PNG, and it re-paints to any size.
//
// A preset with no layers is a WALL — flat ground and grain, no horizon at all. That is what
// gets painted when the sky is folded away, so folding really does remove the horizon rather
// than just hiding a line.

export interface Layer {
  y: number;      // baseline, as a fraction of height
  amp: number;    // ridge height, as a fraction of height
  freq: number;   // ridge frequency
  block: number;  // step size in px — the blockiness
  seed: number;
  top: string;    // colour at the crest
  bot: string;    // colour at the foot — the complement, which is the whole effect
}
export interface BgPreset {
  id: string; name: string;
  sky: Array<[number, string]>;
  glow?: { y: number; c: string; r: number };
  layers: Layer[];
  grain: number;
  stars: number;
  /** scrim toward the foot. An environment must lose to the panes standing on it. */
  dim: number;
}

const L = (y: number, amp: number, freq: number, seed: number, top: string, bot: string, block = 24): Layer =>
  ({ y, amp, freq, block, seed, top, bot });

export const BGS: BgPreset[] = [
  {
    id: "calm", name: "calm",
    sky: [[0, "#191716"], [0.5, "#232020"], [1, "#2b2725"]],
    glow: { y: 0.42, c: "rgba(180,83,9,.16)", r: 0.85 },
    layers: [
      L(0.70, 0.035, 0.0042, 1.3, "#262220", "#1c1a19", 22),
      L(0.85, 0.032, 0.0067, 4.1, "#1e1b1a", "#151313", 18),
    ],
    grain: 10, stars: 16, dim: 0.16,
  },
  {
    id: "ridge", name: "ridge",
    sky: [[0, "#0c1c1f"], [0.36, "#122826"], [0.56, "#33200f"], [0.68, "#4a2814"], [1, "#141d1c"]],
    glow: { y: 0.62, c: "rgba(190,105,45,.20)", r: 0.7 },
    layers: [
      L(0.70, 0.042, 0.0037, 0.4, "#4e2b15", "#132225", 20),
      L(0.79, 0.042, 0.0051, 2.2, "#132523", "#452513", 18),
      L(0.88, 0.038, 0.0072, 5.0, "#472716", "#101c1f", 16),
      L(0.96, 0.032, 0.0096, 7.7, "#0f1c1d", "#301b0f", 16),
    ],
    grain: 13, stars: 12, dim: 0.30,
  },
  {
    id: "deep", name: "deep",
    sky: [[0, "#080d17"], [0.44, "#0e1726"], [0.64, "#152537"], [1, "#0d1420"]],
    glow: { y: 0.60, c: "rgba(110,150,200,.14)", r: 0.68 },
    layers: [
      L(0.74, 0.038, 0.0036, 1.1, "#1a2b3d", "#0b111b", 20),
      L(0.84, 0.038, 0.0058, 3.4, "#0d1521", "#1e3247", 18),
      L(0.93, 0.032, 0.0083, 6.2, "#182a3b", "#080d16", 16),
    ],
    grain: 11, stars: 46, dim: 0.24,
  },
  {
    id: "ember", name: "ember",
    sky: [[0, "#151020"], [0.38, "#26142a"], [0.58, "#48211d"], [0.70, "#5c2d1a"], [1, "#181316"]],
    glow: { y: 0.64, c: "rgba(210,120,60,.20)", r: 0.68 },
    layers: [
      L(0.74, 0.038, 0.0040, 2.6, "#63321a", "#191428", 20),
      L(0.84, 0.040, 0.0060, 4.8, "#1a1528", "#5b2d18", 18),
      L(0.93, 0.034, 0.0088, 8.1, "#572916", "#120e14", 16),
    ],
    grain: 12, stars: 22, dim: 0.28,
  },
  {
    id: "plain", name: "plain",
    sky: [[0, "#1a1817"], [0.55, "#242121"], [1, "#2c2826"]],
    layers: [], grain: 8, stars: 0, dim: 0,
  },
];

export const bgById = (id: string): BgPreset => BGS.find((b) => b.id === id) ?? BGS[0];

/** deterministic ridge — stable across repaints, so a resize doesn't reshuffle the world */
function ridge(x: number, freq: number, seed: number): number {
  return Math.sin(x * freq + seed) * 0.5
    + Math.sin(x * freq * 2.31 + seed * 1.7) * 0.3
    + Math.sin(x * freq * 4.13 + seed * 0.63) * 0.2;
}

/**
 * Paint the environment to a data URL.
 * `wall` drops every layer and the glow: flat ground, grain only, no horizon.
 */
export function paint(p: BgPreset, w: number, h: number, wall: boolean): string {
  const S = Math.min(1, 1500 / Math.max(1, w));       // cap the raster; CSS scales it back up
  const W = Math.max(2, Math.round(w * S)), H = Math.max(2, Math.round(h * S));
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const g = c.getContext("2d");
  if (!g) return "";

  const sky = g.createLinearGradient(0, 0, 0, H);
  for (const [at, col] of p.sky) sky.addColorStop(at, col);
  g.fillStyle = sky; g.fillRect(0, 0, W, H);

  if (!wall && p.glow) {
    const r = g.createRadialGradient(W / 2, H * p.glow.y, 0, W / 2, H * p.glow.y, W * p.glow.r);
    r.addColorStop(0, p.glow.c); r.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = r; g.fillRect(0, 0, W, H);
  }

  if (!wall) {
    for (const l of p.layers) {
      const grad = g.createLinearGradient(0, H * (l.y - l.amp), 0, H);
      grad.addColorStop(0, l.top); grad.addColorStop(1, l.bot);   // complements across the band
      g.fillStyle = grad;
      const step = Math.max(6, Math.round(l.block * S));
      for (let x = 0; x < W; x += step) {
        const n = (ridge(x / S, l.freq, l.seed) + 1) / 2;
        let y = H * l.y - n * H * l.amp;
        y = Math.round(y / step) * step;                           // stepped, not smooth
        g.fillRect(x, y, step + 1, H - y);
      }
    }
    if (p.stars) {
      g.fillStyle = "rgba(255,236,190,.5)";
      for (let i = 0; i < p.stars; i++) {
        const x = ((i * 8161) % 977) / 977 * W;
        const y = ((i * 5087) % 613) / 613 * H * (p.layers.length ? p.layers[0].y * 0.7 : 0.4);
        g.globalAlpha = 0.18 + ((i * 37) % 50) / 100;
        g.fillRect(Math.round(x), Math.round(y), 1.4, 1.4);
      }
      g.globalAlpha = 1;
    }
  }

  // scrim: the environment has to lose to whatever stands on it
  if (p.dim) {
    const s = g.createLinearGradient(0, 0, 0, H);
    s.addColorStop(0, `rgba(10,9,8,${p.dim * 0.45})`);
    s.addColorStop(0.5, `rgba(10,9,8,${p.dim * 0.7})`);
    s.addColorStop(1, `rgba(10,9,8,${p.dim})`);
    g.fillStyle = s; g.fillRect(0, 0, W, H);
  }

  if (p.grain) {
    const img = g.getImageData(0, 0, W, H), d = img.data, amt = p.grain;
    for (let i = 0; i < d.length; i += 4) {
      const n = (Math.random() - 0.5) * amt;
      d[i] += n; d[i + 1] += n; d[i + 2] += n;
    }
    g.putImageData(img, 0, 0);
  }
  return c.toDataURL("image/png");
}
