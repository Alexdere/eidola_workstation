// eidola — the homepage head.
//
// A room with a horizon. Sky above (tools, scratch, options), ground below (work), a
// draggable divider between them. Panes are freely placed and named from type+sequence
// (num1, text2, clock1); a name is gauge — it never enters identity. Views are browser-like
// tabs over ONE graph: switching a view changes positions, lenses and membership, never the
// hash. Wires are not objects; you see the effect of a connection, not the connection.
//
// Discipline: every graph change goes through `edit()`; every pixel renders from state; a
// click reaches a unit only by becoming a command first (Head Laws 4 & 5).
// SILENCE MEANS GAUGE — a coloured message means the world changed; a grey echo means only
// the description did.

import {
  Cls, Engine, Graph, Liminal, MemoryPersistence, Pane, Port, Store, Unit, Value, WorkspaceSpec,
  collapse, container, dumpWorkspace, fromSpec, graph, leaf, loadWorkspace, melt, pane,
  port, toSpec, wire, inPorts, outPorts, unitId,
} from "../../core/src/index.js";
import { short } from "./lens.js";
import { BGS, bgById, paint } from "./bg.js";
import { Authored, EXAMPLES, GUIDE, STARTER, doorOf, unitOf } from "./library.js";
import { ROOM_HOST } from "./host.js";
// the same bodies, compiled ahead of time — so a page that may not eval still runs its library
import "./library.compiled.js";

// ------------------------------------------------------------------ presentation model
type Zone = "sky" | "ground";

interface PaneView {
  x: number; y: number; w: number; h: number; zone: Zone; lens: string; folded: boolean;
  /** look THROUGH this container: its interior renders inside its own rectangle, live, and
   *  you never leave the layer you are on. Two sublayers can be open side by side. */
  open?: boolean;
}
/** a caption that belongs to a view. Gauge: it is never in the graph, so it can't move the hash */
interface Note { x: number; y: number; w: number; text: string; title?: string; zone?: Zone; at?: string }
interface View {
  id: string; name: string;
  members: Record<string, PaneView>;   // path -> placement. absent = not in this view
  showsAll: boolean;                   // systems-style: every pane, auto-placed
  horizon: number;                     // 0..1 — where the divider sits
  rich: boolean;                       // prefer generous lenses
  zoom: number;                        // ground scale — gauge, like everything else here
  notes?: Note[];                      // captions, by level ("" = the surface)
  /** the inspect mode — what the old workstation was: every pane, every wire, the inspector
   *  open and the hash showing. Chrome, not a different program: the same graph, computed
   *  the same way. */
  inspect?: boolean;
}
interface Options {
  suggest: boolean; snap: boolean; recede: boolean; motion: boolean;
  hash: "never" | "systems" | "always"; rate: number; bg: string;
  /** host secrets. NEVER content — they are not in any unit, config or hash, and they do not
   *  travel with a workspace. A unit asks for the power; the host holds the key. */
  apiKey: string; apiUrl: string; model: string;
}
interface Present {
  "@": "presentation/2";
  views: Record<string, View>; order: string[]; active: string; home: string;
  label: Record<string, string>;        // path -> human name (gauge)
  unitLabel: Record<string, string>;    // unit id -> name
  kind: Record<string, string>;         // path -> source kind
  inner: Record<string, [number, number]>;  // interior layout, by full path — gauge
  mine: Record<string, { name: string; note: string }>;   // units you declared
  opts: Options;
}

const DEF_SIZE: Record<string, [number, number]> = {
  num: [180, 104], text: [252, 152], clock: [180, 104], fetch: [300, 190],
  container: [204, 122], op: [176, 100],
};
const sizeFor = (k: string) => DEF_SIZE[k] ?? DEF_SIZE.op;

function emptyPresent(): Present {
  const mk = (id: string, name: string, showsAll: boolean, rich: boolean): View =>
    ({ id, name, members: {}, showsAll, horizon: id === "systems" ? 0.16 : 0.34, rich, zoom: 1 });
  return {
    "@": "presentation/2",
    views: { free: mk("free", "free", false, false), media: mk("media", "media", false, true), systems: mk("systems", "systems", true, false) },
    order: ["free", "media", "systems"], active: "free", home: "free",
    label: {}, unitLabel: {}, kind: {}, inner: {}, mine: {},
    opts: { suggest: true, snap: false, recede: true, motion: true, hash: "systems", rate: 200, bg: "calm",
      apiKey: "", apiUrl: "https://api.anthropic.com/v1/messages", model: "claude-sonnet-4-5" },
  };
}

// hash → a tone. Identity is content, so the same unit is the same colour everywhere:
// two panes over one node look like one thing without being told.
const TONES: Array<[number, number]> = [[38, 92], [16, 78], [344, 60], [268, 52], [200, 60], [168, 52], [92, 48], [56, 68]];
function toneOf(unitId: string): [number, number] {
  let h = 0;
  for (let i = unitId.length - 6; i < unitId.length; i++) h = (h * 31 + unitId.charCodeAt(i)) >>> 0;
  return TONES[h % TONES.length];
}

type Level =
  | { kind: "root"; engine: Engine }
  | { kind: "liminal"; occ: string; lim: Liminal; stubs: Record<string, Value>; title: string };

interface Snap { graph: Graph; present: string; src: Record<string, Value> }

// ------------------------------------------------------------------ verbs (for suggestions + help)
/** Older words for library entries. The prim-era names still work as you type them; the
 *  library's own names are what is shown. Nothing here reaches the kernel. */
const ALIAS: Record<string, string> = {
  concat: "join", sum: "total", delay: "last", hist: "history", if: "pick", print: "log",
};
const HEAD_VERBS: Array<[string, string]> = [
  ["new", "an empty pane — nothing yet, on purpose"],
  ["author", "give the focused pane a body: class, ports, powers, source"],
  ["ai", "build something you can talk to — ai <container> to scope it"],
  ["key", "your model key, kept by this browser and nothing else"],
  ["look", "see through a container without leaving this layer"],
  ["expose", "give a container a port — expose grp child.out"],
  ["declare", "seal a draft — everything below becomes part of one unit"],
  ["library", "presets, what you have made, and the guide"],
  ["guide", "how any of this works"],
  ["tour", "a view that shows what this can do — built when you ask, undone in one step"],
  ["dump", "the workspace as a file you can copy — or paste one in and load it"],
  ["note", "a caption in this view — note some words · note clear"],
  ["num", "a number — num 42"], ["text", "some text — text hello"], ["clock", "a live tick source"],
  ["fetch", "fetch a url — fetch example.com"],
];
const TAIL_VERBS: Array<[string, string]> = [
  ["wrap", "make the marked panes one prior"], ["into", "descend into a prior"], ["up", "back out (a draft stays a draft)"],
  ["name", "rename — name number1 revenue"], ["lens", "how it renders — lens number1 big"],
  ["fold", "recede to a name-tag"], ["pin", "stay alive while unwatched"], ["del", "remove"],
  ["grid", "tidy the marked panes"], ["sky", "send to the sky"], ["ground", "send to the ground"],
  ["view", "switch/create a view — view media · view inspect · view new notes"],
  ["zoom", "zoom in · out · fit · 150"], ["inspect", "the manifest of what's focused"],
  ["ports", "what it takes and gives — ports add1"],
  ["run", "start/stop ticking"], ["step", "one tick"], ["undo", "step back"],
  ["options", "settings"], ["help", "everything"],
];
/** every op the omnibar offers comes from the library itself, so the two can never drift */
const VERBS: Array<[string, string]> = [
  ...HEAD_VERBS,
  ...STARTER.filter((a) => !["number", "text", "clock", "fetch"].includes(a.id)).map((a): [string, string] => {
    const ins = a.ports.filter((p) => p[1] === "in").map((p) => p[0]);
    return [a.id, `${a.cls}${ins.length ? " · " + ins.join(" ") : ""} — ${a.note.split(/[.—]/)[0].trim().toLowerCase()}`];
  }),
  ...TAIL_VERBS,
];

// ------------------------------------------------------------------ app
class Eidola {
  store = new Store(new MemoryPersistence());
  present: Present = emptyPresent();
  levels: Level[] = [];
  sigma: Record<string, string> = {};
  ran: string[] = [];
  scratch: Store | null = null;
  srcValues: Record<string, Value> = {};
  fetchStatus: Record<string, "wait" | "ok" | "no"> = {};

  focus: string | null = null;
  marked = new Set<string>();
  editing: string | null = null;
  routeFrom: string | null = null;
  running = false;
  lastHash = "";
  undoStack: Snap[] = [];
  redoStack: Snap[] = [];
  menuEl: HTMLDivElement | null = null;
  suggIdx = 0;
  suggItems: string[] = [];
  pulses = new Set<string>();

  pendingSize: { w: number; h: number } | null = null;   // a box drawn over nothing = a size
  authoring: string | null = null;
  draft: { cls: Exclude<Cls, "container">; ports: Array<[string, "in" | "out", string]>;
           powers: string[]; src: string } | null = null;
  libTab: "starter" | "mine" | "guide" = "starter";
  drag: { occ: string; dx: number; dy: number; moved: boolean; zone: Zone } | null = null;
  subDrag: { path: string; el: HTMLElement; ox: number; oy: number } | null = null;
  dotDrag: { host: string; sub: string; port: string; dir: "in" | "out"; x: number; y: number } | null = null;
  hdrag = false;
  marq: { x: number; y: number; zone: Zone } | null = null;
  rz: { occ: string; x: number; y: number; w: number; h: number } | null = null;

  el = {
    sky: document.getElementById("sky") as HTMLDivElement,
    skyHost: document.getElementById("sky-host") as HTMLDivElement,
    ground: document.getElementById("ground") as HTMLDivElement,
    gcanvas: document.getElementById("gcanvas") as HTMLDivElement,
    groundHost: document.getElementById("ground-host") as HTMLDivElement,
    app: document.getElementById("app") as HTMLDivElement,
    draftbar: document.getElementById("draftbar") as HTMLDivElement,
    insp: document.getElementById("insp") as HTMLElement,
    inspBody: document.getElementById("insp-body") as HTMLDivElement,
    inspBtn: document.getElementById("inspbtn") as HTMLButtonElement,
    lib: document.getElementById("lib") as HTMLDivElement,
    libBody: document.getElementById("lib-body") as HTMLDivElement,
    libBtn: document.getElementById("libbtn") as HTMLButtonElement,
    author: document.getElementById("author") as HTMLDivElement,
    authorBody: document.getElementById("author-body") as HTMLDivElement,
    zoomtag: document.getElementById("zoomtag") as HTMLElement,
    horizon: document.getElementById("horizon") as HTMLDivElement,
    hgrip: document.getElementById("hgrip") as HTMLDivElement,
    wires: document.getElementById("wires") as unknown as SVGSVGElement,
    tabs: document.getElementById("tabs") as HTMLDivElement,
    omni: document.getElementById("omni") as HTMLInputElement,
    ombox: document.getElementById("ombox") as HTMLDivElement,
    echo: document.getElementById("echo") as HTMLDivElement,
    sugg: document.getElementById("sugg") as HTMLDivElement,
    selchip: document.getElementById("selchip") as HTMLElement,
    hash: document.getElementById("hash") as HTMLElement,
    hashwrap: document.getElementById("hashwrap") as HTMLElement,
    tickno: document.getElementById("tickno") as HTMLElement,
    clock: document.getElementById("clock") as HTMLElement,
    ambient: document.getElementById("ambient") as HTMLElement,
    empty: document.getElementById("emptyhint") as HTMLElement,
    help: document.getElementById("help") as HTMLDivElement,
    helpCard: document.getElementById("help-card") as HTMLDivElement,
    options: document.getElementById("options") as HTMLDivElement,
    optionsBody: document.getElementById("options-body") as HTMLDivElement,
    gear: document.getElementById("gear") as HTMLButtonElement,
    wordmark: document.getElementById("wordmark") as HTMLElement,
    marquee: document.getElementById("marquee") as HTMLDivElement,
  };

  constructor() {
    this.levels = [{ kind: "root", engine: new Engine(this.store, graph({}, []), undefined, ROOM_HOST) }];
    this.load();
    this.buildHelp();
    this.events();
    this.safeTick();
    this.paintBg();
    this.layout();
    this.render();
    this.startClock();
    window.addEventListener("beforeunload", () => this.save());
    this.el.omni.focus();
  }

  // ------------------------------------------------------------ access
  get level(): Level { return this.levels[this.levels.length - 1]; }
  get isLiminal(): boolean { return this.level.kind === "liminal"; }
  get graph(): Graph { const l = this.level; return l.kind === "root" ? l.engine.root : l.lim.graph; }
  get view(): View { return this.present.views[this.present.active]; }
  unitOf(occ: string): Unit { return this.store.unit(this.graph.panes[occ].unit); }
  valueStore(): Store { return this.scratch ?? this.store; }
  pathOf(occ: string): string {
    return [...this.levels.slice(1).map((l) => (l as { occ: string }).occ), occ].join("/");
  }
  valueAt(ep: string): Value | undefined {
    const id = this.sigma[ep]; if (id === undefined) return undefined;
    try { return this.valueStore().blob(id); } catch { return undefined; }
  }
  /**
   * A boundary is an ALIAS, not a copy: nothing is stored at `chip#sum` because the value
   * already lives at the interior producer. Follow it down to show what a chip is putting out.
   */
  epOf(unitId: string, path: string, portName: string): string {
    const u = this.store.unit(unitId);
    if (!u.graph) return `${path}#${portName}`;
    const w = u.graph.wires.find((x) => x.to[0] === "@out" && x.to[1] === portName);
    if (!w || !u.graph.panes[w.from[0]]) return `${path}#${portName}`;
    return this.epOf(u.graph.panes[w.from[0]].unit, `${path}/${w.from[0]}`, w.from[1]);
  }
  /**
   * The IN-side twin of epOf. Nothing is stored at `chip#x` either; the value lands at the
   * interior consumer that `@in.x` feeds. Descending uses this to hand the draft the values it
   * actually receives out here, so you hear it in context rather than in a vacuum.
   */
  inValue(unitId: string, path: string, portName: string): Value | undefined {
    const u = this.store.unit(unitId);
    if (!u.graph) return this.valueAt(`${path}#${portName}`);
    for (const w of u.graph.wires) {
      if (w.from[0] !== "@in" || w.from[1] !== portName) continue;
      const inner = u.graph.panes[w.to[0]]; if (!inner) continue;
      const v = this.inValue(inner.unit, `${path}/${w.to[0]}`, w.to[1]);
      if (v !== undefined) return v;
    }
    return undefined;
  }
  outValue(occ: string, portName?: string): Value | undefined {
    const p = portName ?? outPorts(this.unitOf(occ))[0]?.name;
    if (!p) return undefined;
    return this.valueAt(this.epOf(this.graph.panes[occ].unit, this.pathOf(occ), p));
  }
  nameOf(occ: string): string { return this.present.label[this.pathOf(occ)] ?? occ; }
  /** a source a person types into — number or text, read off its door and its port's shape */
  typedAs(occ: string): "number" | "text" | null {
    const p = this.graph.panes[occ]; if (!p) return null;
    const u = this.store.unit(p.unit);
    if (this.doorAt(u, this.pathOf(occ)) !== "typed") return null;
    return outPorts(u)[0]?.shape === "num" ? "number" : "text";
  }
  kindOf(occ: string): string {
    const k = this.present.kind[this.pathOf(occ)];
    if (k) return k;
    const door = doorOf(this.unitOf(occ).powers);
    if (door && door !== "typed") return door;
    const named = this.present.unitLabel[this.graph.panes[occ].unit];
    if (named) return named;
    const u = this.unitOf(occ);
    if (u.cls === "container") return Object.keys(u.graph?.panes ?? {}).length ? "group" : "empty";
    return u.body && u.body["@"] === "prim/1" ? u.body.op.replace("core.", "") : u.cls;
  }

  /** membership of the active view, with systems auto-including everything */
  pv(occ: string): PaneView | null {
    const path = this.pathOf(occ), v = this.view;
    let m = v.members[path];
    // Going inside is asking to see the inside: a descended level shows its interior in every
    // view, not only in showsAll ones. (Wrap drops the children's surface membership, so
    // without this a free/media view descended into an empty-looking room that computed
    // nothing — unobserved means not alive.)
    if (!m && (v.showsAll || this.isLiminal)) { m = this.autoPlace(occ); v.members[path] = m; }
    return m ?? null;
  }
  inView(occ: string): boolean { return this.pv(occ) !== null; }
  visible(): string[] { return Object.keys(this.graph.panes).filter((o) => this.inView(o)); }

  /** first free ground spot that overlaps nothing already placed in this view */
  spotFor(w: number, h: number): { x: number; y: number; zone: Zone } {
    const taken: Array<{ x: number; y: number; w: number; h: number }> = [
      ...Object.values(this.view.members).filter((m) => m.zone === "ground"),
      ...this.notesHere().filter((n) => (n.zone ?? "ground") === "ground").map((n) => ({ ...n, h: noteHeight(n) })),
    ];
    const W = Math.max(440, this.el.ground.clientWidth - 16);
    for (let y = 18; y < 5000; y += 26)
      for (let x = 22; x + w < W; x += 26)
        if (!taken.some((m) => x < m.x + m.w + 18 && x + w + 18 > m.x && y < m.y + m.h + 16 && y + h + 16 > m.y))
          return { x, y, zone: "ground" };
    return { x: 22, y: 18, zone: "ground" };
  }
  autoPlace(occ: string): PaneView {
    const [w, h] = sizeFor(this.kindOf(occ));
    const s = this.spotFor(w, h);
    return { x: s.x, y: s.y, w, h, zone: "ground", lens: "auto", folded: false };
  }

  resolve(tok: string): string | null {
    if (!tok) return null;
    const t = tok.toLowerCase();
    if (this.graph.panes[t]) return t;
    for (const o of Object.keys(this.graph.panes))
      if ((this.present.label[this.pathOf(o)] ?? "").toLowerCase() === t) return o;
    return null;
  }
  /** args, defaulting to the marked set (then focus) when none are typed */
  argsOrMarked(rest: string[]): string[] {
    const named = rest.map((r) => this.resolve(r)).filter(Boolean) as string[];
    if (named.length) return named;
    if (this.marked.size) return [...this.marked];
    return this.focus ? [this.focus] : [];
  }

  // ------------------------------------------------------------ presentation follows paths
  // Everything a head keeps beside the graph (names, kinds, placements, typed values) is keyed
  // by PATH. When a path moves (wrap) the record must move with it, and when a path ends
  // (delete) it must end too — or the next pane to reuse the name inherits a ghost.
  private pathRecords(): Array<Record<string, unknown>> {
    return [this.present.label, this.present.kind, this.present.inner, this.srcValues, this.fetchStatus,
      ...Object.values(this.present.views).map((v) => v.members)] as Array<Record<string, unknown>>;
  }
  movePath(from: string, to: string): void {
    for (const rec of this.pathRecords())
      for (const k of Object.keys(rec))
        if (k === from || k.startsWith(from + "/")) { rec[to + k.slice(from.length)] = rec[k]; delete rec[k]; }
    // a note made inside a level belongs to that level's path, so it travels with it
    for (const v of Object.values(this.present.views))
      for (const n of v.notes ?? [])
        if (n.at && (n.at === from || n.at.startsWith(from + "/"))) n.at = to + n.at.slice(from.length);
  }
  dropPath(path: string): void {
    for (const rec of this.pathRecords())
      for (const k of Object.keys(rec))
        if (k === path || k.startsWith(path + "/")) delete rec[k];
    for (const v of Object.values(this.present.views))
      if (v.notes) v.notes = v.notes.filter((n) => !(n.at && (n.at === path || n.at.startsWith(path + "/"))));
  }

  // ------------------------------------------------------------ undo
  snap(): Snap { return { graph: this.graph, present: JSON.stringify(this.present), src: { ...this.srcValues } }; }
  /** did it push? A draft has no undo stack, and a build in progress (the tour) records one
   *  step for the whole of itself — so callers take back only what they actually pushed. */
  pushUndo(): boolean {
    if (this.isLiminal || this.quiet) return false;
    // coming up out of a draft: the step to undo is the whole visit, so the snapshot is the
    // one taken on the way down — graph, names AND values as they were then
    this.undoStack.push(this.undoBase ?? this.snap());
    this.undoBase = null;
    if (this.undoStack.length > 60) this.undoStack.shift();
    this.redoStack = [];
    return true;
  }
  quiet = 0;
  clockT = 0;
  undoBase: Snap | null = null;
  /**
   * Several edits, one undo step. Runs `fn` quietly and records the state from before it, if
   * anything changed. Nested batches fold into the outermost one.
   */
  batch<T>(fn: () => T): T {
    if (this.quiet || this.isLiminal) return fn();
    const before = this.snap();
    this.quiet++;
    let out: T;
    try { out = fn(); } finally { this.quiet--; }
    if (before.graph !== this.graph || before.present !== JSON.stringify(this.present)
        || JSON.stringify(before.src) !== JSON.stringify(this.srcValues)) {
      this.undoStack.push(before);
      if (this.undoStack.length > 60) this.undoStack.shift();
      this.redoStack = [];
    }
    return out;
  }
  undo(): void {
    if (this.isLiminal) return this.say("come up first", "no");
    const s = this.undoStack.pop();
    if (!s) return this.echo("nothing to undo");
    this.redoStack.push(this.snap());
    this.restoreSnap(s);
    this.echo("undo");
  }
  redo(): void {
    if (this.isLiminal) return this.say("come up first", "no");    // as undo: drafts have no history
    const s = this.redoStack.pop(); if (!s) return this.echo("nothing to redo");
    this.undoStack.push(this.snap()); this.restoreSnap(s); this.echo("redo");
  }
  restoreSnap(s: Snap): void {
    const l = this.levels[0] as { kind: "root"; engine: Engine };
    l.engine.root = s.graph; l.engine.validate();
    this.present = JSON.parse(s.present) as Present;
    // values are immutable, so a shallow copy is a true snapshot. Without this, undoing a wrap
    // left the sources' values at the paths the wrap had moved them to — they read as absent.
    this.srcValues = { ...s.src };
    this.marked.clear(); this.focus = null;
    this.resurrectMemory(); this.gcMemory();      // the logs of the panes this state has
    this.tick(); this.layout(); this.render();
  }

  // ------------------------------------------------------------ memory belongs to living panes
  // A log is history at an address. When the pane bound to it is gone, its history goes too —
  // or the next pane at that address inherits a ghost (a counter that starts at 8), and the
  // address has to be dodged with a suffix, which made the hash depend on history. Ended logs
  // are kept aside for this session only, so undo and redo can bring a pane back WITH its
  // history; a new pane never resurrects anything.
  graveyard = new Map<string, string[]>();
  boundMem(): Set<string> {
    const e = (this.levels[0] as { engine: Engine }).engine;
    const out = new Set<string>();
    const walk = (g: Graph, at: string) => {
      for (const occ of Object.keys(g.panes)) {
        const p = g.panes[occ], path = at ? `${at}/${occ}` : occ;
        const a = e.memAddress(path, p.mem); if (a) out.add(a);
        const u = this.store.unit(p.unit); if (u.graph) walk(u.graph, path);
      }
    };
    walk(e.root, "");
    return out;
  }
  gcMemory(): void {
    const live = this.boundMem(), P = this.store.persist;
    for (const a of P.memAddrs()) if (!live.has(a)) { this.graveyard.set(a, P.readMem(a)); P.dropMem(a); }
  }
  resurrectMemory(): void {
    const P = this.store.persist;
    for (const a of this.boundMem()) {
      const g = this.graveyard.get(a);
      if (g && !P.readMem(a).length) { for (const id of g) P.appendMem(a, id); this.graveyard.delete(a); }
    }
  }

  // ------------------------------------------------------------ edit
  /**
   * Every graph change goes through here — and every one of them can be refused. A body is
   * something a person wrote, so it will throw; when it does, the change is rolled back and
   * reported. A bad node must never take the room down with it.
   */
  edit(fn: (g: Graph) => Graph, what: string): boolean {
    const l = this.level;
    const isRoot = l.kind === "root";
    const before = isRoot ? (l as { engine: Engine }).engine.root : (l as { lim: Liminal }).lim.graph;
    const restore = () => {
      if (isRoot) { (l as { engine: Engine }).engine.root = before; (l as { engine: Engine }).engine.validate(); }
      else { (l as { lim: Liminal }).lim.graph = before; }
    };
    const pushed = this.pushUndo();        // a no-op inside a draft: drafts have no undo stack
    if (isRoot) (l as { engine: Engine }).engine.root = fn(before);
    else (l as { lim: Liminal }).lim.graph = fn(before);
    try {
      if (isRoot) (l as { engine: Engine }).engine.validate();
      this.tick();
      if (isRoot) this.gcMemory();
    } catch (e) {
      restore();
      if (pushed) this.undoStack.pop();    // only take back what this edit pushed
      try { this.tick(); } catch { /* the room stands even if the last good state also throws */ }
      this.say((e as Error).message, "no");
      this.render();
      return false;
    }
    this.render(); this.touch();
    if (what) this.say(what, "ok");
    return true;
  }

  /** a tick that cannot take the page down. Used anywhere a throw would be fatal. */
  safeTick(): boolean {
    try { this.tick(); return true; }
    catch (e) {
      this.running = false;
      this.say(`${(e as Error).message} — stopped`, "no");
      return false;
    }
  }

  freshOcc(type: string): string {
    const base = (type || "n").toLowerCase().replace(/[^a-z0-9]/g, "") || "n";
    let i = 1; while (this.graph.panes[`${base}${i}`]) i++;
    return `${base}${i}`;
  }

  addPane(unitId: string, kind: string, at?: { x: number; y: number; zone: Zone }, config?: Value): string | null {
    const occ = this.freshOcc(kind);
    this.dropPath(this.pathOf(occ));        // a reused name must not inherit anything
    const u = this.store.unit(unitId);
    const p = pane(unitId, {
      mem: u.powers.some((x) => x.startsWith("mem:")) ? this.memFor(occ) : undefined,
      pinned: u.cls === "effect",
      config,
    });
    const ps = this.pendingSize; this.pendingSize = null;
    const [w, h] = ps ? [ps.w, ps.h] : sizeFor(kind);
    const spot = at ?? this.freeSpot(w, h);
    this.view.members[this.pathOf(occ)] = { x: spot.x, y: spot.y, w, h, zone: spot.zone, lens: "auto", folded: false };
    // Only sources need a remembered kind: they all share core.source, so nothing else can
    // tell a clock from a note. Every other unit already says what it is.
    if (u.cls === "source") this.present.kind[this.pathOf(occ)] = kind;
    if (!this.edit((g) => graph({ ...g.panes, [occ]: p }, g.wires), occ)) return null;
    this.focus = occ; this.marked.clear();
    return occ;
  }

  /**
   * A memory address for a new pane. It is content, so it must not depend on history: the
   * occurrence name, and only if a log already lives there (a deleted pane of the same name)
   * a suffix, so the new pane never inherits a ghost's memory. The kernel scopes it by the
   * enclosing occurrence, so copies of one unit never share it.
   */
  memFor(occ: string): string {
    const prefix = this.levels.slice(1).map((l) => (l as { occ: string }).occ).join("/");
    const used = (m: string) => this.store.persist.readMem(prefix ? `${prefix}/${m}` : m).length > 0
      || Object.values(this.graph.panes).some((p) => p.mem === m);
    let m = occ, i = 1;
    while (used(m)) m = `${occ}.${++i}`;
    return m;
  }

  /** as spotFor, but a showsAll view first places everything it displays */
  freeSpot(w: number, h: number): { x: number; y: number; zone: Zone } {
    if (this.view.showsAll) for (const o of Object.keys(this.graph.panes)) this.pv(o);
    return this.spotFor(w, h);
  }

  /** an EMPTY pane: a unit with no boundary and no interior. It is nothing yet, on purpose. */
  empty(at?: { x: number; y: number; zone: Zone }): string | null {
    const u = this.store.putUnit(container([], graph({}, [])));
    const occ = this.addPane(u, "empty", at);
    if (occ) this.say(`${occ} — nothing yet. Give it a body, or go inside it.`, "wait");
    return occ;
  }

  /** put an authored unit into a pane (from the library) */
  fromLibrary(a: Authored, at?: { x: number; y: number; zone: Zone }, value?: Value): string | null {
    const uid = this.store.putUnit(unitOf(a));
    this.present.unitLabel[uid] = a.id;
    const occ = this.addPane(uid, a.id, at);
    if (occ && value !== undefined) this.srcValues[this.pathOf(occ)] = value;
    if (occ) { this.safeTick(); this.render(); }
    return occ;
  }

  /**
   * A constant: a fixed value held in the pane's config. Config is content, so unlike a number
   * you type (novelty, journalled at a source) it is part of the hash — and it travels with a
   * unit when that unit is declared and placed again somewhere else.
   */
  constant(value: Value, at?: { x: number; y: number; zone: Zone }): string | null {
    const a = STARTER.find((x) => x.id === "const")!;
    const uid = this.store.putUnit(unitOf(a));
    this.present.unitLabel[uid] = a.id;
    const occ = this.addPane(uid, a.id, at, value);      // one edit: placed with its value
    if (!occ) return null;
    this.say(`${occ} = ${short(value)} — a constant, so it is part of the hash`, "ok");
    return occ;
  }

  source(kind: string, value: Value, at?: { x: number; y: number; zone: Zone }): string | null {
    const a = STARTER.find((x) => x.id === kind);
    if (!a) { this.say(`no “${kind}” in the library`, "no"); return null; }
    return this.fromLibrary(a, at, value);
  }

  op(prim: string, args: string[], at?: { x: number; y: number; zone: Zone }): void {
    this.batch(() => this.op_(prim, args, at));            // placed and wired is one step
  }
  private op_(prim: string, args: string[], at?: { x: number; y: number; zone: Zone }): void {
    const a = STARTER.find((x) => x.id === prim);
    if (!a) return this.say(`no “${prim}” in the library`, "no");
    const from = this.argsOrMarked(args);
    const uid = this.store.putUnit(unitOf(a));
    this.present.unitLabel[uid] = a.id;
    const occ = this.addPane(uid, a.id, at);
    if (!occ) return;
    const ins = inPorts(this.unitOf(occ));
    let n = 0;
    from.slice(0, ins.length).forEach((f, i) => {
      const fp = outPorts(this.unitOf(f))[0]?.name;
      if (!fp) return;
      const ok = this.edit((g) => graph(g.panes, [...g.wires, wire([f, fp], [occ, ins[i].name])]), "");
      if (ok) n++;
    });
    if (n) { this.safeTick(); this.render(); this.say(`${this.nameOf(occ)} ← ${from.slice(0, n).map((f) => this.nameOf(f)).join(", ")}`, "ok"); }
  }

  // ---------------------------------------------------------------- routing
  // A port with nothing in it is not broken — absence is a member of the set, so an unwired
  // input simply reads as absent. Nothing here refuses: a taken port is REPLACED, and a unit
  // with no room left offers to chain rather than saying no. Presets, never walls.

  /** "num1" | "num1.out" -> [occ, port] */
  endpoint(tok: string, dir: "in" | "out"): [string, string] | null {
    const dot = tok.lastIndexOf(".");
    const name = dot > 0 ? tok.slice(0, dot) : tok;
    const want = dot > 0 ? tok.slice(dot + 1) : null;
    const occ = this.resolve(name); if (!occ) return null;
    const ps = dir === "in" ? inPorts(this.unitOf(occ)) : outPorts(this.unitOf(occ));
    if (want) { const p = ps.find((x) => x.name === want); return p ? [occ, p.name] : null; }
    return ps[0] ? [occ, ps[0].name] : null;
  }
  wireInto(occ: string, port: string) { return this.graph.wires.find((w) => w.to[0] === occ && w.to[1] === port); }
  freeIns(occ: string) { return inPorts(this.unitOf(occ)).filter((p) => !this.wireInto(occ, p.name)); }

  /** connect, replacing whatever already fed that port */
  connect(from: [string, string], to: [string, string]): boolean {
    return this.edit((g) => graph(
      g.panes,
      [...g.wires.filter((w) => !(w.to[0] === to[0] && w.to[1] === to[1])), wire(from, to)],
    ), `${this.nameOf(from[0])} → ${this.nameOf(to[0])}.${to[1]}`);
  }

  route(a: string, b: string): void {
    const src = this.endpoint(a, "out");
    if (!src) return this.say(`no output on “${a}”`, "no");
    const dot = b.lastIndexOf(".");
    const to = this.resolve(dot > 0 ? b.slice(0, dot) : b);
    if (!to) return this.say(`no “${b}”`, "no");
    const ins = inPorts(this.unitOf(to));
    if (!ins.length) return this.say(`${this.nameOf(to)} takes no input`, "no");
    if (dot > 0) {                                   // explicit port — do exactly that
      const want = b.slice(dot + 1);
      const p = ins.find((x) => x.name === want);
      if (!p) return this.say(`${this.nameOf(to)} has no port “${want}” (${ins.map((x) => x.name).join(", ")})`, "no");
      this.connect(src, [to, p.name]); return;
    }
    const free = this.freeIns(to);
    if (free.length) { this.connect(src, [to, free[0].name]); return; }
    this.chainOrPick(src, to);                       // full: offer, don't force
  }

  /** every in-port is taken. Chain a second op of the same kind, or replace a port. */
  chainOrPick(src: [string, string], to: string): void {
    const u = this.unitOf(to);
    const ins = inPorts(u);
    if (ins.length === 2 && outPorts(u).length === 1) {
      // one honest way to get a third input: another node. (The other is to open it and
      // declare a third port — the core has no opinion either way.)
      const m = this.pv(to);
      const at = m ? { x: m.x + m.w + 26, y: m.y, zone: m.zone } : undefined;
      const occ = this.addPane(this.graph.panes[to].unit, this.kindOf(to), at);
      if (!occ) return;
      const nIns = inPorts(this.unitOf(occ));
      const tOut = outPorts(u)[0].name;
      this.connect([to, tOut], [occ, nIns[0].name]);
      this.connect(src, [occ, nIns[1].name]);
      this.say(`${this.nameOf(to)} was full — chained ${this.nameOf(occ)}. Or open it and declare a third port.`, "ok");
      return;
    }
    this.pickPort(src, to);
  }

  /** a small menu of ports, so an ambiguous drop is a choice and not a guess */
  pickPort(src: [string, string], to: string, at?: { x: number; y: number }): void {
    const ins = inPorts(this.unitOf(to));
    const el = document.createElement("div"); el.className = "menu";
    el.innerHTML = `<div class="mh">${esc(this.nameOf(src[0]))} → ${esc(this.nameOf(to))}</div>`
      + ins.map((p) => {
        const w = this.wireInto(to, p.name);
        return `<button data-p="${esc(p.name)}"><span class="g">${w ? "↻" : "→"}</span>${esc(p.name)}`
          + `<span style="margin-left:auto;color:var(--ink4);font-size:10px">${esc(p.shape)}${w ? " · replaces " + esc(this.nameOf(w.from[0])) : ""}</span></button>`;
      }).join("");
    el.addEventListener("click", (ev) => {
      const b = (ev.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      this.closeMenu(); this.connect(src, [to, b.dataset.p!]);
    });
    const m = this.pv(to);
    const p = at ?? (m ? { x: 0, y: 0 } : { x: 0, y: 0 });
    if (!at && m) { const [sx, sy] = this.toScreen(m.zone, m.x + m.w, m.y); p.x = sx + 6; p.y = sy; }
    this.closeMenu(); this.placeMenu(el, p.x, p.y);
  }

  unroute(a: string, b: string): void {
    const from = this.resolve(a);
    const dot = b.lastIndexOf(".");
    const to = this.resolve(dot > 0 ? b.slice(0, dot) : b);
    const port = dot > 0 ? b.slice(dot + 1) : null;
    if (!from || !to) return this.say("need two names", "no");
    this.edit((g) => graph(g.panes, g.wires.filter((w) =>
      !(w.from[0] === from && w.to[0] === to && (!port || w.to[1] === port)))),
      `${this.nameOf(from)} ✕ ${this.nameOf(to)}`);
  }

  del(targets: string[]): void {
    const occs = this.argsOrMarked(targets);
    if (!occs.length) return this.say("nothing marked", "no");
    const set = new Set(occs);
    const names = occs.map((o) => this.nameOf(o));
    if (this.focus && set.has(this.focus)) this.focus = null;
    // The paths end, so what was kept at them ends too (names, kinds, placements in EVERY
    // view, typed values). Snapshot first: undo brings all of it back, and a refused delete
    // puts it back at once.
    const saved = { present: JSON.stringify(this.present), src: { ...this.srcValues } };
    const pushed = this.pushUndo();
    const depth = this.undoStack.length;
    for (const o of occs) { this.marked.delete(o); this.dropPath(this.pathOf(o)); }
    const ok = this.edit((g) => {
      const panes: Record<string, Pane> = {};
      for (const k of Object.keys(g.panes)) if (!set.has(k)) panes[k] = g.panes[k];
      return graph(panes, g.wires.filter((w) => !set.has(w.from[0]) && !set.has(w.to[0])));
    }, `− ${names.join(", ")}`);
    if (this.undoStack.length > depth) this.undoStack.splice(depth, 1);   // edit's own, of the half-cleared state
    if (!ok) {
      this.present = JSON.parse(saved.present) as Present; this.srcValues = saved.src;
      if (pushed) this.undoStack.pop();
      this.render();
    }
  }

  // ---- gauge acts: no coloured message, only a grey echo
  rename(a: string, name: string): void {
    const occ = this.resolve(a); if (!occ) return this.say(`no “${a}”`, "no");
    if (!name) return this.say("name it what?", "no");
    // a name is how you point at something, so it must point at one thing only
    const low = name.toLowerCase();
    const clash = Object.keys(this.graph.panes).find((o) => o !== occ
      && (o.toLowerCase() === low || (this.present.label[this.pathOf(o)] ?? "").toLowerCase() === low));
    if (clash) return this.say(`“${name}” already points at ${clash} — pick another name`, "no");
    this.pushUndo();
    this.present.label[this.pathOf(occ)] = name;
    this.render(); this.echo(`name ${occ} ${name}`);
  }
  setLens(a: string, id: string): void {
    const occs = a ? [this.resolve(a)].filter(Boolean) as string[] : this.argsOrMarked([]);
    if (!occs.length) return this.say("nothing marked", "no");
    this.pushUndo();
    for (const o of occs) { const m = this.pv(o); if (m) m.lens = id; }
    this.render(); this.echo(`lens ${occs.map((o) => this.nameOf(o)).join(" ")} ${id}`);
  }
  fold(targets: string[]): void {
    const occs = this.argsOrMarked(targets); if (!occs.length) return;
    this.pushUndo();
    for (const o of occs) { const m = this.pv(o); if (m) m.folded = !m.folded; }
    this.safeTick(); this.render(); this.echo(`fold ${occs.map((o) => this.nameOf(o)).join(" ")}`);
  }
  toZone(targets: string[], zone: Zone): void {
    const occs = this.argsOrMarked(targets); if (!occs.length) return;
    this.pushUndo();
    let i = 0;
    for (const o of occs) {
      const m = this.pv(o); if (!m) continue;
      m.zone = zone; m.x = 22 + (i % 5) * (m.w + 18); m.y = 14 + Math.floor(i / 5) * (m.h + 16); i++;
    }
    if (zone === "sky" && this.view.horizon < 0.24) this.view.horizon = 0.34;
    this.layout(); this.safeTick(); this.render(); this.echo(`${zone} ${occs.map((o) => this.nameOf(o)).join(" ")}`);
  }
  grid(targets: string[]): void {
    const occs = this.argsOrMarked(targets); if (occs.length < 2) return this.say("mark a few panes first", "no");
    this.pushUndo();
    const ms = occs.map((o) => this.pv(o)!).filter(Boolean);
    const zone = ms[0].zone;
    const w = Math.max(...ms.map((m) => m.w)), h = Math.max(...ms.map((m) => m.h));
    const x0 = Math.min(...ms.map((m) => m.x)), y0 = Math.min(...ms.map((m) => m.y));
    const cols = Math.max(1, Math.round(Math.sqrt(ms.length)));
    ms.forEach((m, i) => { m.zone = zone; m.w = w; m.h = h; m.x = x0 + (i % cols) * (w + 20); m.y = y0 + Math.floor(i / cols) * (h + 18); });
    this.render(); this.echo(`grid ${occs.map((o) => this.nameOf(o)).join(" ")}`);
  }
  pin(targets: string[]): void {
    const occs = this.argsOrMarked(targets); if (!occs.length) return;
    const on = !this.graph.panes[occs[0]].pinned;
    this.edit((g) => {
      const panes = { ...g.panes };
      for (const o of occs) panes[o] = { ...panes[o], pinned: on };
      return graph(panes, g.wires);
    }, `${occs.map((o) => this.nameOf(o)).join(", ")} ${on ? "pinned" : "unpinned"}`);
  }

  // ------------------------------------------------------------ composition & depth
  wrap(targets: string[]): void {
    if (this.isLiminal) return this.say("declare this draft first", "no");
    const occs = this.argsOrMarked(targets);
    if (occs.length < 1) return this.say("mark some panes first", "no");
    const name = this.freshOcc("container");
    let out;
    // straight to a draft: it may hold drafts of its own, and a draft cannot be hashed
    try { out = collapse(this.graph, occs, this.store, name, undefined, { draft: true }); }
    catch (e) { return this.say((e as Error).message, "no"); }
    // Wrapping makes a node that is NOT yet a thing. It runs, it can be built inside, it can
    // be given ports — but it has no identity, nothing may cite it, and it is not in your
    // library. Declaring is the moment it becomes one thing: a chip.
    const first = this.pv(occs[0]);
    // every OTHER view that showed any of these panes must show the container instead, or
    // wrapping here strands them there (their placements move inside, out of sight)
    const elsewhere: Array<[View, PaneView]> = [];
    for (const v of Object.values(this.present.views)) {
      if (v === this.view || v.showsAll) continue;
      const m = occs.map((o) => v.members[this.pathOf(o)]).find(Boolean);
      if (m) elsewhere.push([v, m]);
    }
    const newOcc = Object.keys(out.graph.panes).find((k) => !(k in this.graph.panes))!;
    // snapshot BEFORE the presentation moves: undo must put the panes back where they were,
    // in view, with their values — not restore the old graph under the new arrangement
    const saved = { present: JSON.stringify(this.present), src: { ...this.srcValues } };
    const pushed = this.pushUndo();
    const depth = this.undoStack.length;
    this.present.unitLabel[out.unit] = name;
    const [w, h] = sizeFor("container");
    this.view.members[this.pathOf(newOcc)] = first
      ? { x: first.x, y: first.y, w, h, zone: first.zone, lens: "auto", folded: false }
      : { ...this.freeSpot(w, h), w, h, lens: "auto", folded: false };
    // the children's paths just gained a level; their journalled values and kinds live at a
    // path, so move them or the values silently disappear
    // (names too — renaming is gauge, but losing a name you gave is still losing something)
    for (const [v, m] of elsewhere)
      v.members[this.pathOf(newOcc)] = { x: m.x, y: m.y, w, h, zone: m.zone, lens: "auto", folded: false };
    for (const o of occs) this.movePath(this.pathOf(o), `${this.pathOf(newOcc)}/${o}`);
    // memory lives at an address scoped by the enclosing occurrence, so a wrapped counter's
    // log would be left behind at the old scope and it would start again from nothing.
    // Wrapping changes names and nothing else (Closure), so the history follows the names.
    for (const o of occs) this.carryMemory(o, newOcc);
    this.marked.clear(); this.focus = newOcc;
    const ok = this.edit(() => out!.graph, "");
    if (this.undoStack.length > depth) this.undoStack.splice(depth, 1);
    if (!ok) {
      this.present = JSON.parse(saved.present) as Present; this.srcValues = saved.src;
      if (pushed) this.undoStack.pop();
      this.render(); return;
    }
    this.say(`${occs.map((o) => this.nameOf(o)).join(" + ")} → ${name} — a draft. Build inside it, give it ports, then declare it.`, "wait");
  }

  /** copy the logs of `occ` (its own and everything inside it) to where they live once `occ`
   *  sits inside `into`. Logs are append-only, so the old ones stay — orphaned, never reused:
   *  a new pane of the old name gets a fresh address (memFor). */
  carryMemory(occ: string, into: string): void {
    const P = this.store.persist;
    const prefix = this.levels.slice(1).map((l) => (l as { occ: string }).occ).join("/");
    const at = (x: string) => (prefix ? `${prefix}/${x}` : x);
    const moves: Array<[string, string]> = [];
    const m = this.graph.panes[occ]?.mem;
    if (m) moves.push([at(m), at(`${into}/${m}`)]);
    for (const addr of P.memAddrs())
      if (addr.startsWith(at(occ) + "/")) moves.push([addr, at(`${into}/${addr.slice(at("").length)}`)]);
    for (const [from, to] of moves)
      if (!P.readMem(to).length) for (const id of P.readMem(from)) P.appendMem(to, id);
  }

  /** is this pane still unfinished work? */
  isDraftPane(occ: string): boolean {
    const id = this.graph.panes[occ]?.unit;
    return !!id && (Store.isDraft(id) || this.store.hasDraft(this.store.unit(id)));
  }

  /**
   * DECLARE — the moment a draft becomes one thing. Everything below it is sealed too (Merkle
   * leaves no choice), so what was a loose interior becomes a chip: one name, one hash, and
   * an inside that nothing outside can reach except through the ports it chose to show.
   */
  declareChip(targets: string[]): void {
    const occs = this.argsOrMarked(targets);
    if (!occs.length) return this.say("mark a draft to declare", "no");
    const drafts = occs.filter((o) => Store.isDraft(this.graph.panes[o].unit));
    if (!drafts.length) return this.say(`${occs.map((o) => this.nameOf(o)).join(", ")} — already declared`, "no");
    const sealed: Record<string, string> = {};
    for (const o of drafts) {
      try { sealed[o] = this.store.declare(this.graph.panes[o].unit); }
      catch (e) { return this.say((e as Error).message, "no"); }
    }
    const names: string[] = [];
    const ok = this.edit((g) => {
      const panes = { ...g.panes };
      for (const [o, id] of Object.entries(sealed)) {
        panes[o] = { ...panes[o], unit: id };
        const nm = this.present.label[this.pathOf(o)] ?? o;
        this.present.unitLabel[id] = nm;
        this.present.mine[id] = { name: nm, note: `container · ${this.store.unit(id).ports.length} ports` };
        names.push(nm);
      }
      return graph(panes, g.wires);
    }, "");
    if (ok) this.say(`${names.join(", ")} declared — one unit now, and in your library.`, "ok");
  }

  descend(a?: string): void {
    const occ = a ? this.resolve(a) : this.focus;
    if (!occ) return this.say("focus a prior first", "no");
    const u = this.unitOf(occ);
    if (u.cls !== "container") return this.say(`${this.nameOf(occ)} has no inside`, "no");
    const stubs: Record<string, Value> = {};
    for (const p of inPorts(u)) {
      const v = this.inValue(this.graph.panes[occ].unit, this.pathOf(occ), p.name);
      if (v !== undefined) stubs[p.name] = v;
    }
    const title = this.nameOf(occ);
    // the whole visit is one undo step: remember the surface as it was on the way down
    if (this.levels.length === 1) this.undoBase = this.snap();
    this.levels.push({ kind: "liminal", occ, lim: melt(this.store, this.graph.panes[occ].unit), stubs, title });
    this.focus = null; this.marked.clear();
    this.safeTick(); this.layout(); this.render();
    this.say(this.insideDraft
      ? `inside ${title} — a draft. Nothing is stored until you declare it.`
      : `inside ${title} — melted for editing. Coming up declares a new version (the old one stays what it was).`, "wait");
  }
  /** was the thing we are inside a draft when we went in? */
  get insideDraft(): boolean {
    const l = this.level;
    return l.kind === "liminal" && !!l.lim.meltedFrom && Store.isDraft(l.lim.meltedFrom);
  }
  /**
   * Come back up. Out of a declared unit this declares the new version (same id if nothing
   * changed). Out of a DRAFT it stays a draft — working on something is not finishing it, the
   * same rule editing through a window already keeps. `seal` declares it on the way out.
   */
  ascend(seal = false): void {
    const l = this.level; if (l.kind !== "liminal") return;
    const draft = this.insideDraft;
    const occ = l.occ;
    // nothing changed inside: come up without making a new version or an undo step
    const was = l.lim.meltedFrom;
    if (was && unitId(container(l.lim.ports, l.lim.graph)) === unitId(this.store.unit(was))) {
      this.levels.pop();
      if (this.levels.length === 1) this.undoBase = null;
      this.focus = occ; this.safeTick(); this.layout(); this.render();
      if (draft && seal) this.declareChip([occ]);
      else this.echo(`up from ${l.title}`);
      return;
    }
    let id: string;
    if (draft) {
      // a fresh ticket rather than overwriting the old one, so undo still has the old content
      id = this.store.putDraft(container(l.lim.ports, l.lim.graph));
    } else {
      try { id = l.lim.declare(this.store); }
      catch (e) { return this.say((e as Error).message, "no"); }
    }
    this.present.unitLabel[id] = l.title;
    this.levels.pop();
    const base = this.undoBase;
    const ok = this.edit((g) => graph({ ...g.panes, [occ]: { ...g.panes[occ], unit: id } }, g.wires),
      draft || l.lim.meltedFrom === id ? "" : `declared ${l.title}`);
    if (!ok) { this.levels.push(l); this.undoBase = base; return this.say("the new boundary doesn't fit the wires outside", "no"); }
    this.focus = occ; this.layout(); this.render();
    if (draft && seal) this.declareChip([occ]);           // sealing seals nested drafts too
    else if (draft) this.say(`${l.title} — still a draft. Declare it when it settles.`, "wait");
  }

  // ------------------------------------------------------------ views
  switchView(id: string): void {
    if (!this.present.views[id]) return this.say(`no view “${id}”`, "no");
    this.present.active = id;
    this.marked.clear(); this.focus = null;
    if (this.view.inspect) this.toggleInsp(true);
    this.layout(); this.safeTick(); this.render();
    this.echo(`view ${id}`);        // gauge: the hash cannot move here
  }
  /** the inspect mode: what the workstation was, as a view of this same room */
  inspectView(): void {
    this.pushUndo();
    this.present.views.inspect = { id: "inspect", name: "inspect", members: {}, showsAll: true,
      horizon: 0.12, rich: false, zoom: 1, inspect: true };
    if (!this.present.order.includes("inspect")) this.present.order.push("inspect");
    this.switchView("inspect");
    this.say("inspect — every pane, every wire, the inspector and the hash. The same graph, computed the same way; only the chrome differs.", "ok");
  }

  /**
   * The workspace as a file: WORKSPACE/1 plus the typed values, exactly what any conformant
   * reader can open. Edit it or paste another in, and load it — a load replaces the room's
   * content and keeps nothing presentational from it, because a file carries none.
   */
  dumpBox(): void {
    const l = this.levels[0] as { engine: Engine };
    void l;
    const file = { "@": "eidola/1", workspace: dumpWorkspace(this.store, this.rootForSave()),
      inputs: Object.fromEntries(Object.entries(this.srcValues).map(([k, v]) => [k, toSpec(v)])) };
    document.getElementById("wsbox")?.remove();
    const box = document.createElement("div");
    box.id = "wsbox";
    box.innerHTML = `<div class="wscard">
      <div class="ah"><span>WORKSPACE/1 <em>content only — no layout, no names, no key</em></span>
        <span><button data-wsload="1">load what is in the box</button><button data-wsclose="1">close ⎋</button></span></div>
      <textarea spellcheck="false">${esc(JSON.stringify(file, null, 1))}</textarea>
      <div class="anote">Copy it out to keep or send. Paste another workspace in and load it to open it here — the room's undo history starts again, because the old steps refer to content that will be gone.</div></div>`;
    document.body.appendChild(box);
    const ta = box.querySelector("textarea") as HTMLTextAreaElement;
    ta.focus(); ta.select();
    box.addEventListener("click", (ev) => {
      const t = ev.target as HTMLElement;
      if (t.closest("[data-wsclose]") || t === box) { box.remove(); this.el.omni.focus(); }
      else if (t.closest("[data-wsload]")) {
        try {
          const f = JSON.parse(ta.value) as { workspace?: WorkspaceSpec; inputs?: Record<string, unknown> } & WorkspaceSpec;
          const ws = f.workspace ?? (f["@"] === "workspace/1" ? f : null);
          if (!ws || ws["@"] !== "workspace/1") throw new Error("not a workspace/1 file");
          const keep = this.present;
          this.restore({ workspace: ws, present: { ...emptyPresent(), opts: keep.opts }, inputs: f.inputs });
          this.present.active = "systems";
          this.undoStack = []; this.redoStack = []; this.undoBase = null; this.graveyard.clear();
          box.remove();
          this.assembling = true;
          try { this.tick(); } finally { this.assembling = false; }
          this.layout(); this.render(); this.touch();
          this.say(`loaded — ${Object.keys(this.graph.panes).length} panes, shown in systems`, "ok");
        } catch (e) { this.say(`could not load: ${(e as Error).message}`, "no"); }
      }
    });
    ta.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Escape") { box.remove(); this.el.omni.focus(); } });
  }

  newView(name: string): void {
    const id = (name || "view").toLowerCase().replace(/[^a-z0-9_-]/g, "") || `v${this.present.order.length}`;
    if (this.present.views[id]) return this.switchView(id);
    this.pushUndo();
    this.present.views[id] = { id, name: id, members: {}, showsAll: false, horizon: 0.34, rich: false, zoom: 1 };
    this.present.order.push(id);
    this.switchView(id);
  }
  addToView(targets: string[]): void {
    const occs = this.argsOrMarked(targets); if (!occs.length) return this.say("nothing marked", "no");
    this.pushUndo();
    for (const o of occs) if (!this.view.members[this.pathOf(o)]) this.view.members[this.pathOf(o)] = this.autoPlace(o);
    this.safeTick(); this.render(); this.echo(`added ${occs.length} to ${this.view.name}`);
  }

  // ------------------------------------------------------------ notes — captions that are gauge
  /** the notes of the active view at the level you are on */
  notesHere(): Note[] {
    const at = this.levels.slice(1).map((x) => (x as { occ: string }).occ).join("/");
    return (this.view.notes ?? []).filter((n) => (n.at ?? "") === at);
  }
  addNote(text: string): void {
    this.pushUndo();
    const w = Math.min(420, Math.max(220, text.length * 4));
    const spot = this.spotFor(w, noteHeight({ x: 0, y: 0, w, text }));
    const at = this.levels.slice(1).map((x) => (x as { occ: string }).occ).join("/");
    (this.view.notes ??= []).push({ x: spot.x, y: spot.y, w, text, at: at || undefined });
    this.render(); this.echo("note");     // grey: a caption describes, it changes nothing
  }
  clearNotes(): void {
    const here = new Set(this.notesHere());
    if (!here.size) return this.echo("no notes here");
    this.pushUndo();
    this.view.notes = (this.view.notes ?? []).filter((n) => !here.has(n));
    this.render(); this.echo(`cleared ${here.size} note${here.size > 1 ? "s" : ""}`);
  }

  // ------------------------------------------------------------ the tour
  /**
   * A view that shows what this head can do, built out of the gestures you would use yourself:
   * library units and wires, lenses, pin, a body written here, wrap · expose · declare, a window
   * to look through, a second pane over one unit, and the talking assembly. Nothing is staged —
   * it is an ordinary view over the one graph, so it can be taken apart, and one `undo` takes
   * all of it away. The other views never see it: building it here observes it only here.
   */
  tour(): void {
    if (this.isLiminal) return this.say("come up first — the tour is built on the surface", "no");
    const was = this.present.views.tour;
    if (was && Object.keys(was.members).some((p) => !p.includes("/") && this.graph.panes[p]))
      return this.switchView("tour");
    const before = this.snap();
    const v: View = was ?? { id: "tour", name: "tour", members: {}, showsAll: false, horizon: 0.24, rich: false, zoom: 1 };
    v.members = {}; v.notes = []; v.horizon = 0.24;
    if (!was) { this.present.views.tour = v; this.present.order.push("tour"); }
    this.present.active = "tour"; this.focus = null; this.marked.clear();
    this.layout();
    const asm = this.assembling;
    this.quiet++; this.assembling = true;       // one undo step; nothing asks while it is wired
    try { this.buildTour(v); }
    catch (e) {
      this.quiet--; this.assembling = asm;
      this.restoreSnap(before);
      return this.say(`the tour could not be built: ${(e as Error).message}`, "no");
    }
    this.quiet--; this.assembling = asm;
    this.undoStack.push(before);
    if (this.undoStack.length > 60) this.undoStack.shift();
    this.redoStack = [];
    // fit its width — zoom is gauge, and it belongs to this view alone
    v.zoom = Math.max(0.55, Math.min(1, Number(((this.el.ground.clientWidth - 24) / 1100).toFixed(3))));
    this.focus = null; this.marked.clear();
    this.layout(); this.safeTick(); this.render();
    this.el.ground.scrollTo(0, 0);
    if (!this.running) this.toggleRun();
    this.touch();
    this.say("the tour — five things this can do, made of ordinary units. It is running; undo takes all of it away.", "ok");
  }

  private buildTour(v: View): void {
    type At = { x: number; y: number; zone: Zone };
    const at = (x: number, y: number, zone: Zone = "ground"): At => ({ x, y, zone });
    const lib = (id: string) => STARTER.find((a) => a.id === id) ?? EXAMPLES.find((a) => a.id === id);
    const put = (id: string, p: At, o: { value?: Value; name?: string; w?: number; h?: number; lens?: string } = {}): string => {
      const a = lib(id); if (!a) throw new Error(`no ${id} in the library`);
      const occ = this.fromLibrary(a, p, o.value);
      if (!occ) throw new Error(`could not place ${id}`);
      const m = v.members[this.pathOf(occ)];
      if (o.w) m.w = o.w;
      if (o.h) m.h = o.h;
      if (o.lens) m.lens = o.lens;
      if (o.name) this.present.label[this.pathOf(occ)] = o.name;
      return occ;
    };
    const link = (from: string, to: string, port: string, fromPort?: string) => {
      const fp = fromPort ?? outPorts(this.unitOf(from))[0]?.name;
      if (!fp || !this.connect([from, fp], [to, port])) throw new Error(`could not wire ${from} → ${to}.${port}`);
    };
    const note = (x: number, y: number, w: number, title: string, text: string, zone: Zone = "ground") =>
      v.notes!.push({ x, y, w, title, text, zone });

    // ① values flow
    note(22, 14, 470, "① values flow",
      "Two numbers and an add. Click 20, type another number, press enter — the sum follows. A wire is not an object here: you see what a connection does. Focus a pane to see its wires.");
    const a = put("number", at(22, 100), { value: 20, name: "a", w: 160, h: 96 });
    const b = put("number", at(22, 212), { value: 22, name: "b", w: 160, h: 96 });
    const sum = put("add", at(222, 150), { name: "a + b", w: 210, h: 112, lens: "big" });
    link(a, sum, "a"); link(b, sum, "b");

    // ② watching is computing
    note(560, 14, 470, "② watching is computing",
      "Two running totals of the same 1. Out of view means not computed, so only the pinned one ◈ keeps counting while you are somewhere else. Switch to free, wait, come back.");
    const one = put("number", at(560, 156), { value: 1, name: "one", w: 140, h: 96 });
    const seen = put("total", at(740, 100), { name: "while watched", w: 230, h: 104, lens: "big" });
    const kept = put("total", at(740, 222), { name: "always", w: 230, h: 104, lens: "big" });
    link(one, seen, "x"); link(one, kept, "x");
    if (!this.edit((g) => graph({ ...g.panes, [kept]: { ...g.panes[kept], pinned: true } }, g.wires), ""))
      throw new Error("could not pin");

    // ③ a body written here — reading a clock that lives in the sky
    const clk = put("clock", at(22, 16, "sky"), { name: "clock", w: 200, h: 96, lens: "bar" });
    note(244, 22, 330, "the sky", "is for what you glance at. This clock is what fizzbuzz reads, down on the ground.", "sky");
    note(22, 352, 330, "③ a body written here",
      "fizzbuzz is not a preset. It is a few lines of JavaScript, one port in and one out. Focus it and type `author` to read it — change a word and it is a different unit.");
    const fz = put("fizzbuzz", at(22, 458), { w: 230, h: 104, lens: "big" });
    link(clk, fz, "n");
    const fzId = this.graph.panes[fz].unit;
    this.present.mine[fzId] = { name: "fizzbuzz", note: "pure · n → out — written in the tour" };

    // ④ wrap · expose · declare — then a second pane over the same unit
    note(400, 352, 640, "④ wrap · expose · declare",
      "A ×1.8 and a +32 — constants, so they are part of what it is — wrapped into a draft, given two ports (`c` in, `f` out) and declared into one unit. You are looking through it, live. Below, chip1 is a second pane over the same unit: same colour, its own input.");
    const c = put("number", at(400, 478), { value: 21, name: "°C", w: 130, h: 96 });
    // constants, not typed numbers: a typed number is novelty that belongs to one pane, so a
    // second copy of the unit would start blank. A constant is config — content — and travels.
    const k = this.constant(1.8, at(560, 440));
    const mul = put("mul", at(560, 440));
    const k32 = this.constant(32, at(560, 440));
    if (!k || !k32) throw new Error("could not place a constant");
    const add = put("add", at(560, 440));
    link(k, mul, "b"); link(mul, add, "a"); link(k32, add, "b");
    this.wrap([mul, k, k32, add]);
    const box = this.focus;
    if (!box || !this.graph.panes[box] || this.unitOf(box).cls !== "container") throw new Error("could not wrap");
    const bp = this.pathOf(box);
    this.present.inner[`${bp}/${k}`] = [26, 62];
    this.present.inner[`${bp}/${mul}`] = [132, 12];
    this.present.inner[`${bp}/${k32}`] = [132, 104];
    this.present.inner[`${bp}/${add}`] = [238, 56];
    this.expose(box, mul, "a", "c");
    this.expose(box, add, "out", "f");
    if (this.unitOf(box).ports.length !== 2) throw new Error("could not expose");
    link(c, box, "c");
    const f = put("show", at(930, 478), { name: "°F", w: 140, h: 96, lens: "big" });
    link(box, f, "x", "f");
    this.present.label[bp] = "c-to-f";
    this.declareChip([box]);
    if (Store.isDraft(this.graph.panes[box].unit)) throw new Error("could not declare");
    Object.assign(v.members[bp], { x: 556, y: 430, w: 356, h: 196, open: true });
    const sealed = this.graph.panes[box].unit;
    const boil = put("number", at(400, 668), { value: 100, name: "boil", w: 130, h: 96 });
    const twin = this.addPane(sealed, "chip", at(556, 654));
    if (!twin) throw new Error("could not place a second c-to-f");
    Object.assign(v.members[this.pathOf(twin)], { w: 230, h: 118 });
    link(boil, twin, "c");

    // ⑤ something to talk to — scoped to the converter
    note(22, 806, 760, "⑤ something to talk to",
      "Six ordinary panes: what you type, a context pointed at c-to-f (it sees only what it is wired to), a join, an ask that leaves the graph, and the reply that comes back in. Add a key in options, type in “you”, and it answers.");
    this.makeAI(box, at(22, 896));
  }

  // ------------------------------------------------------------ tick
  tick(): void {
    const l = this.level, g = this.graph;
    // observed = in this view and not folded. Out of view means unobserved means it does not
    // compute — the viewport as a garbage collector, with `pin` as the declared exception.
    // looking through a container observes its interior: liveness follows the eye, and the
    // engine already speaks in `parent/child` paths, so this is the whole of it.
    const observed = Object.keys(g.panes).filter((o) => this.inView(o) && !this.pv(o)!.folded);
    const prev = new Set(this.ran);
    const prefix = this.levels.slice(1).map((x) => (x as { occ: string }).occ).join("/");
    // the clock is the head's: it keeps counting inside a draft and across a reload
    const journal = this.journalFor(g, prefix, this.clockT++);
    let effects: Value[] = [];
    if (l.kind === "root") {
      const r = l.engine.tick({ observed, journal });
      this.sigma = r.sigma; this.ran = r.ran; this.scratch = null; effects = r.effects;
    } else {
      // A draft is played as its own little world, so its engine speaks in paths RELATIVE to
      // the draft. Everything the head keeps (values, kinds, membership) is keyed by the full
      // path. Translate at the seam, both ways — or a descended room shows no values and its
      // sources never emit.
      const rel = (k: string) => (prefix && k.startsWith(prefix + "/") ? k.slice(prefix.length + 1) : k);
      const abs = (k: string) => (prefix ? `${prefix}/${k}` : k);
      const relJournal = Object.fromEntries(Object.entries(journal).map(([k, v]) => [rel(k), v]));
      const { result, scratch } = l.lim.play(this.store, l.stubs, { observed, journal: relJournal }, undefined, prefix, ROOM_HOST);
      this.sigma = Object.fromEntries(Object.entries(result.sigma).map(([k, v]) => [abs(k), v]));
      this.ran = result.ran.map(abs); this.scratch = scratch; effects = result.effects;
    }
    // decide now, not when the microtask runs: an assembly being wired asks nothing
    if (effects.length && !this.assembling) queueMicrotask(() => this.pump(effects));
    if (this.present.opts.motion) {
      this.pulses.clear();
      for (const p of this.ran) if (!prev.has(p)) this.pulses.add(p);
    }
  }
  /** a tick changes values, not structure — so touch only what changed. Rebuilding the DOM
   *  every 200ms would kill text selection, scroll position and any in-flight edit. */
  /**
   * A source emits wherever it lives — nested inside a group just as much as on the surface.
   * Novelty enters only at sources (Law 5), so the journal has to reach ALL of them or a
   * value quietly vanishes the moment you wrap it.
   */
  journalFor(g: Graph, prefix: string, tickIndex: number): Record<string, Value> {
    const out: Record<string, Value> = {};
    const walk = (gr: Graph, at: string) => {
      for (const occ of Object.keys(gr.panes)) {
        const u = this.store.unit(gr.panes[occ].unit);
        const path = at ? `${at}/${occ}` : occ;
        if (u.cls === "source") {
          // which novelty a source receives is read off its boundary (its door), not off
          // anything the head keeps beside it — so a copy of a chip behaves like the original
          const door = this.doorAt(u, path);
          const v = door === "clock" ? tickIndex
            : door === "context" ? this.describe(String(gr.panes[occ].config ?? ""), gr, at)
            : this.srcValues[path];
          const op = outPorts(u)[0]?.name ?? "out";
          if (v !== undefined) out[`${path}#${op}`] = v;
        }
        if (u.graph) walk(u.graph, path);
      }
    };
    walk(g, prefix);
    return out;
  }

  /**
   * Effects leave the graph; answers come back in through a source. The engine only re-runs
   * an effect when its inputs change, so one prompt asks once — and because the reply is
   * journalled like any other novelty, the whole conversation replays exactly.
   */
  pump(effects: Value[]): void {
    for (const e of effects) {
      if (!e || typeof e !== "object" || Array.isArray(e)) continue;
      const m = e as Record<string, Value>;
      if (m["@"] !== "ask/1") continue;
      const prompt = String(m.prompt ?? ""), to = String(m.to ?? "");
      if (!prompt) continue;
      const target = this.findPane(to, "reply") ?? this.findPane("", "reply");
      if (!target) { this.say("nothing to answer into — add a reply pane and name it in ask's config", "no"); continue; }
      // one question in flight per reply; a newer one waits and goes next, instead of being lost
      if (this.asking.has(target)) { this.pendingAsk.set(target, prompt); continue; }
      // A guard that says so, rather than a loop that freezes or bills: one thing a person does
      // should lead to a question or two, never a stream. Several asks with nobody touching
      // anything in between means the prompt is feeding on its own answers.
      const since = (this.askLog.get(target) ?? []).filter((t) => t >= this.lastHuman);
      if (since.length >= 3) {
        this.say(`${target} keeps asking by itself — its prompt changes with its own answers. Narrow the context or unwire it; it will ask again after your next edit.`, "no");
        this.running = false;
        continue;
      }
      this.askLog.set(target, [...since, Date.now()]);
      void this.callModel(prompt, target);
    }
  }
  asking = new Set<string>();
  pendingAsk = new Map<string, string>();
  askLog = new Map<string, number[]>();
  /** when a person last did something — keys, clicks, paste. Asks are counted against it. */
  lastHuman = 0;
  assembling = false;

  /**
   * What a `context` source emits. Point it at a container and it describes that container;
   * point it at nothing and it describes the graph it lives in. Scope is WIRING, not
   * permission: whatever you connect is exactly what is seen, and nothing else can be reached.
   *
   * It describes CONTENT only — occurrence names, classes, ports, wires and values. Never
   * labels, kinds or views: those are gauge, and a description is a value that flows into the
   * graph (and on into an ask that may cost money). Renaming a pane or switching a view must
   * not be able to change what a prompt says.
   */
  describe(target: string, home: Graph, at: string): string {
    try { return this.describe_(target, home, at); }
    catch (e) { return `(could not describe: ${(e as Error).message})`; }
  }
  /** which door a source listens at: its declared power, or — for a unit made before doors
   *  existed — the kind it was placed as */
  doorAt(u: Unit, path: string): string | null {
    const d = doorOf(u.powers);
    if (d) return d;
    if (u.cls !== "source") return null;
    const k = this.present.kind[path] ?? "number";
    return k === "number" || k === "text" ? "typed" : k;
  }
  /**
   * What a context must NOT see, in one graph: every context and every reply there, all they
   * feed, and all that feeds that. Those are functions of a context's own output — the prompt
   * it builds, the answer that comes back. Describing them closes a loop through the head: each
   * answer changes the context, which changes the prompt, which asks again. With no key that
   * recursed until the tab froze; with a key it would ask forever, paid. It is the AI-node
   * freeze (the-ai-node.md §1) arriving by reflection instead of by wire. It is applied at
   * EVERY depth, so wrapping the assembly cannot smuggle the loop back in.
   */
  talkLoop(g: Graph, at: string): Set<string> {
    const out = new Set<string>();
    // a container counts if a context or a reply is anywhere inside it — wrapping the reply
    // must not let what it feeds back into the description
    const talks = (u: Unit, path: string): boolean => {
      const d = this.doorAt(u, path);
      if (d === "context" || d === "reply") return true;
      return !!u.graph && Object.keys(u.graph.panes).some((o) => talks(this.store.unit(u.graph!.panes[o].unit), `${path}/${o}`));
    };
    for (const occ of Object.keys(g.panes))
      if (talks(this.store.unit(g.panes[occ].unit), at ? `${at}/${occ}` : occ)) out.add(occ);
    for (const dir of ["down", "up"] as const) {
      let grew = true;
      while (grew) {
        grew = false;
        for (const w of g.wires) {
          const [a, b] = dir === "down" ? [w.from[0], w.to[0]] : [w.to[0], w.from[0]];
          if (out.has(a) && !out.has(b) && g.panes[b]) { out.add(b); grew = true; }
        }
      }
    }
    return out;
  }
  private describe_(target: string, home: Graph, at: string): string {
    const lines: string[] = [];
    const clip = (v: Value | undefined) => { const t = short(v); return t.length > 160 ? `${t.slice(0, 157)}…` : t; };
    const sig = (u: Unit) => {
      const ins = inPorts(u).map((p) => p.name), outs = outPorts(u).map((p) => p.name);
      return `${u.cls}${ins.length ? ` ${ins.join(",")}` : ""}${outs.length ? ` → ${outs.join(",")}` : ""}`;
    };
    const one = (g: Graph, gat: string, depth: number) => {
      const skip = this.talkLoop(g, gat);
      for (const occ of Object.keys(g.panes)) {
        if (skip.has(occ)) continue;
        const path = gat ? `${gat}/${occ}` : occ;
        const u = this.store.unit(g.panes[occ].unit);
        const v = u.graph ? undefined : this.valueAt(`${path}#${outPorts(u)[0]?.name ?? "out"}`);
        const fed = g.wires.filter((w) => w.to[0] === occ && !skip.has(w.from[0]))
          .map((w) => `${w.to[1]}←${w.from[0]}.${w.from[1]}`).join(" ");
        lines.push(`${"  ".repeat(depth)}${occ} (${sig(u)})`
          + (v !== undefined ? ` = ${clip(v)}` : "")
          + (fed ? `  [${fed}]` : ""));
        if (u.graph && depth < 3) one(u.graph, path, depth + 1);
      }
    };
    if (target && !home.panes[target]) {
      // scoped to something that is not here (moved, wrapped, deleted): say so. Widening to
      // everything instead would be a permission the wiring never gave.
      return `${target} — not here; this context describes nothing until it is pointed at something that is`;
    }
    if (target && home.panes[target]) {
      const u = this.store.unit(home.panes[target].unit);
      const path = at ? `${at}/${target}` : target;
      lines.push(`${target} — ${u.graph ? "container" : "leaf"}, ports: ${u.ports.map((p) => `${p.name}:${p.dir}:${p.shape}`).join(" ") || "none"}`);
      if (u.graph) one(u.graph, path, 1);
      else lines.push(`  value = ${clip(this.valueAt(`${path}#${outPorts(u)[0]?.name ?? "out"}`))}`);
    } else {
      lines.push(`${at || "the surface"} — ${Object.keys(home.panes).length} panes`);
      one(home, at, 1);
    }
    return lines.join("\n");
  }

  /** find a pane by occ name at any depth; door narrows it (e.g. only reply panes) */
  findPane(occName: string, door?: string): string | null {
    let hit: string | null = null;
    const walk = (g: Graph, at: string) => {
      for (const occ of Object.keys(g.panes)) {
        const path = at ? `${at}/${occ}` : occ;
        const u = this.store.unit(g.panes[occ].unit);
        if (!hit && (!occName || occ === occName) && (!door || this.doorAt(u, path) === door)) hit = path;
        if (u.graph) walk(u.graph, path);
      }
    };
    walk(this.graph, this.levels.slice(1).map((x) => (x as { occ: string }).occ).join("/"));
    return hit;
  }

  async callModel(prompt: string, targetPath: string): Promise<void> {
    const o = this.present.opts;
    if (!o.apiKey) {
      this.srcValues[targetPath] = "No API key yet. Open options → talking and paste one. It is kept by this browser and never enters the graph, a unit or a hash.";
      this.safeTick(); this.render(); return;
    }
    this.asking.add(targetPath);
    this.srcValues[targetPath] = "…thinking";
    this.safeTick(); this.render();
    try {
      const res = await window.fetch(o.apiUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": o.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({ model: o.model, max_tokens: 1024, messages: [{ role: "user", content: prompt }] }),
      });
      const j = await res.json() as { content?: Array<{ text?: string }>; error?: { message?: string } };
      this.srcValues[targetPath] = j.error?.message
        ? `error: ${j.error.message}`
        : (j.content ?? []).map((c) => c.text ?? "").join("") || "(empty)";
    } catch (err) {
      this.srcValues[targetPath] = `could not reach the model: ${(err as Error).message}`;
    }
    this.asking.delete(targetPath);
    this.safeTick(); this.render();
    const next = this.pendingAsk.get(targetPath);
    if (next !== undefined) {
      this.pendingAsk.delete(targetPath);
      this.pump([{ "@": "ask/1", prompt: next, to: targetPath.split("/").pop()! }]);
    }
  }

  step(): void { if (this.safeTick()) this.refresh(); else this.render(); }
  toggleRun(): void {
    this.running = !this.running;
    this.el.ambient.textContent = this.running ? "running" : "a quiet space";
    if (this.running) {
      const loop = () => { if (!this.running) return; this.step(); if (this.running) setTimeout(loop, this.present.opts.rate); };
      loop();
    }
    this.render();
  }

  // ------------------------------------------------------------ omnibar
  run(raw: string): void {
    const line = raw.trim(); if (!line) return;
    const [head, ...rest] = line.split(/\s+/);
    const cmd = head.toLowerCase();

    // a routing token may carry a port: `grp.sum > other.factor`
    const base = (tok: string) => tok.includes(".") ? tok.slice(0, tok.lastIndexOf(".")) : tok;
    const rM = line.match(/^(\S+)\s*(->|>|→)\s*(\S+)$/);
    if (rM && this.resolve(base(rM[1]))) return this.route(rM[1], rM[3]);
    // "x" only as a word of its own — "max2" or "next" must never read as a break
    const bM = line.match(/^(\S+)\s+x\s+(\S+)$/i) ?? line.match(/^(\S+)\s*(?:✕|!>)\s*(\S+)$/);
    if (bM && this.resolve(base(bM[1])) && this.resolve(base(bM[2]))) return this.unroute(bM[1], bM[2]);

    switch (cmd) {
      case "num": case "number": { const n = Number(rest[0]); if (!Number.isFinite(n)) return this.say("num 42", "no"); this.source("number", n); return; }
      case "text": this.source("text", line.slice(head.length).trim().replace(/^["']|["']$/g, "")); return;
      case "clock": this.source("clock", 0); return;
      case "const": case "constant": {
        const t = line.slice(head.length).trim();
        let v: Value = 0;
        if (t) { const n = Number(t); v = Number.isFinite(n) ? n : t.replace(/^["']|["']$/g, ""); }
        this.constant(v); return;
      }
      case "fetch": void this.fetch(rest[0]); return;
      case "go": case "focus": { const o = this.resolve(rest[0]); if (o) { this.focus = o; this.marked.clear(); this.render(); this.reveal(); } else this.say(`no “${rest[0]}”`, "no"); return; }
      case "mark": { const o = this.resolve(rest[0]); if (o) { this.marked.add(o); this.render(); } return; }
      case "route": if (rest.length >= 2) return this.route(rest[0], rest[1]); return this.say("route a b", "no");
      case "name": case "rename": return this.rename(rest[0], rest.slice(1).join(" ").replace(/^["']|["']$/g, ""));
      case "lens": { const t = this.resolve(rest[0]); return t ? this.setLens(rest[0], rest[1] ?? "auto") : this.setLens("", rest[0] ?? "auto"); }
      case "fold": return this.fold(rest);
      case "pin": return this.pin(rest);
      case "del": case "rm": case "delete": return this.del(rest);
      case "grid": return this.grid(rest);
      case "sky": return this.toZone(rest, "sky");
      case "ground": return this.toZone(rest, "ground");
      case "wrap": case "group": return this.wrap(rest);
      case "into": case "descend": return this.descend(rest[0]);
      case "up": case "ascend": return this.ascend();
      case "declare": case "seal": case "chip":
        if (this.isLiminal && !rest.length) return this.ascend(true);
        return this.declareChip(rest);
      case "view": {
        const a = (rest[0] ?? "").toLowerCase();
        if (a === "new") return this.newView(rest[1] ?? "");
        if (a === "home") { this.present.home = this.present.active; this.render(); return this.echo(`${this.view.name} is home`); }
        if (a === "add") return this.addToView(rest.slice(1));
        if (a === "inspect" && !this.present.views.inspect) return this.inspectView();
        if (a) return this.switchView(a);
        return this.say(`views: ${this.present.order.join(" · ")}`, "ok");
      }
      case "zoom": {
        const a = (rest[0] ?? "").toLowerCase();
        if (a === "in") return this.setZoom(this.view.zoom * 1.2);
        if (a === "out") return this.setZoom(this.view.zoom / 1.2);
        if (a === "fit" || a === "reset" || !a) return this.setZoom(1);
        const n = Number(a.replace(/%$/, ""));
        if (!Number.isFinite(n) || n <= 0) return this.say("zoom in · out · fit · 150", "no");
        return this.setZoom(n > 3 ? n / 100 : n);
      }
      case "ai": case "talk": case "chat": return this.makeAI(rest[0]);
      case "tour": case "demo": case "showcase": return this.tour();
      case "workstation": case "inspector": return this.present.views.inspect ? this.switchView("inspect") : this.inspectView();
      case "dump": case "export": return this.dumpBox();
      case "note": case "caption": {
        const t = line.slice(head.length).trim();
        if (t.toLowerCase() === "clear") return this.clearNotes();
        if (!t) return this.say("note some words — a caption that lives in this view, never in the graph", "no");
        return this.addNote(t);
      }
      case "key": {
        const k = line.slice(head.length).trim();
        if (!k) { this.toggleOptions(true); return this.say("paste a key in options → talking", "wait"); }
        this.present.opts.apiKey = k; this.touch();
        return this.say(`key kept by this browser only — not in any unit, config or hash`, "ok");
      }
      case "look": case "through": case "peek": return this.look(rest);
      case "expose": {
        const h = this.resolve(rest[0] ?? "");
        const cp = (rest[1] ?? "").split(".");
        if (!h || cp.length !== 2) return this.say("expose <container> <child>.<port> [name]", "no");
        return this.expose(h, cp[0], cp[1], rest[2]);
      }
      case "unexpose": {
        const h = this.resolve(rest[0] ?? "");
        if (!h || !rest[1]) return this.say("unexpose <container> <port>", "no");
        return this.unexpose(h, rest[1]);
      }
      case "inspect": case "manifest": this.toggleInsp(true); return;
      case "new": case "pane": case "empty": this.empty(); return;
      case "author": case "body": case "edit": this.openAuthor(this.resolve(rest[0] ?? "") ?? undefined); return;
      case "library": case "lib": this.toggleLib(true); return;
      case "guide": this.libTab = "guide"; this.toggleLib(true); return;
      case "ports": {
        const o = this.resolve(rest[0] ?? "") ?? this.focus;
        if (!o) return this.say("ports <name>", "no");
        const u = this.unitOf(o);
        const ins = inPorts(u).map((p) => `${p.name}:${p.shape}${this.wireInto(o, p.name) ? "←" + this.nameOf(this.wireInto(o, p.name)!.from[0]) : "·"}`);
        const outs = outPorts(u).map((p) => `${p.name}:${p.shape}`);
        this.focus = o; this.toggleInsp(true); this.render();
        return this.say(`${this.nameOf(o)}  in[${ins.join(" ")}]  out[${outs.join(" ")}]`, "ok");
      }
      case "run": case "play": this.toggleRun(); return;
      case "step": this.step(); return;
      case "undo": return this.undo();
      case "redo": return this.redo();
      case "options": case "settings": this.toggleOptions(true); return;
      case "save": this.save(); this.say("saved", "ok"); return;
      case "reset": {
        // `reset yes` needs no dialog — some hosts (an artifact frame) refuse confirm() silently
        let sure = rest[0] === "yes";
        if (!sure) { try { sure = confirm("discard everything?"); } catch { sure = false; } }
        if (sure) { this.reset(); return this.say("an empty room", "ok"); }
        return this.say("type reset yes to discard everything", "wait");
      }
      case "help": case "?": this.el.help.classList.add("on"); return;
    }
    const opId = ALIAS[cmd] ?? cmd;
    if (STARTER.some((a) => a.id === opId)) return this.op(opId, rest);
    this.say(`unknown: ${cmd} — try help`, "no");
  }

  async fetch(url?: string, at?: { x: number; y: number; zone: Zone }): Promise<void> {
    if (!url) return this.say("fetch example.com", "no");
    const full = /^https?:\/\//.test(url) ? url : `https://${url}`;
    const occ = this.source("fetch", "", at); if (!occ) return;
    const path = this.pathOf(occ);
    this.fetchStatus[path] = "wait"; this.render(); this.say(`fetching ${full}…`, "wait");
    try {
      const res = await window.fetch(full);
      const t = await res.text();
      this.srcValues[path] = t.slice(0, 4000); this.fetchStatus[path] = "ok";
      this.say(`${this.nameOf(occ)} ← ${t.length} bytes`, "ok");
    } catch {
      this.srcValues[path] = "(blocked — the browser tier can't reach this origin)";
      this.fetchStatus[path] = "no";
      this.say("blocked by CORS — most origins need the extension tier", "no");
    }
    this.safeTick(); this.render();
  }

  // ------------------------------------------------------------ messages
  say(m: string, kind: "ok" | "no" | "wait" = "ok"): void {
    this.el.echo.textContent = m;
    this.el.echo.className = kind === "ok" ? "say" : kind;
    if (this.present.opts.motion && kind === "ok") {
      this.el.horizon.classList.add("settling");
      setTimeout(() => this.el.horizon.classList.remove("settling"), 420);
    }
  }
  /** grey: a description changed, the world did not */
  echo(m: string): void { this.el.echo.textContent = m; this.el.echo.className = ""; this.touch(); }

  // ------------------------------------------------------------ layout (sky / ground split)
  layout(): void {
    const h = Math.max(0, Math.min(0.72, this.view.horizon));
    const top = 36;
    const dockH = 96;
    const avail = window.innerHeight - top - dockH;
    const skyH = Math.round(avail * h);
    // with the sky folded the tab strip has nothing to float over, so the ground yields to it
    const pad = skyH < 44 ? 34 : 0;
    this.el.sky.style.height = `${skyH}px`;
    this.el.horizon.style.top = `${top + skyH - 8}px`;
    const draft = this.isLiminal ? 26 : 0;
    this.el.draftbar.style.top = `${top + skyH + pad}px`;
    this.el.ground.style.top = `${top + skyH + pad + draft}px`;
    this.el.ground.style.bottom = `${dockH}px`;
    this.el.wordmark.style.opacity = skyH > 92 ? "1" : "0";
    this.el.sky.style.display = skyH < 6 ? "none" : "block";
    this.paintBg();
  }

  // ------------------------------------------------------------ render
  render(): void {
    if (this.focus && !this.graph.panes[this.focus]) this.focus = null;
    for (const m of [...this.marked]) if (!this.graph.panes[m]) this.marked.delete(m);
    this.renderStatus(); this.renderTabs(); this.renderPanes(); this.renderWires(); this.renderSel();
    this.renderInsp();
    const bare = !this.visible().length && !this.notesHere().length;
    this.el.empty.style.opacity = bare ? "1" : "0";
    this.el.empty.classList.toggle("on", bare && !this.isLiminal);
    this.el.hgrip.innerHTML = this.view.horizon > 0.04
      ? `<span>sky</span><button data-h="0">fold up</button>`
      : `<span>sky</span><button data-h="0.34">open</button>`;
  }

  renderStatus(): void {
    const l = this.level;
    this.el.app.classList.toggle("liminal", this.isLiminal);
    if (this.isLiminal) {
      const t = (l as { title: string }).title;
      const n = Object.keys(this.graph.panes).length;
      this.el.draftbar.innerHTML =
        `<span>◈ <b>${esc(t)}</b> is a draft <span class="dim">— mutable, playable, and it has no identity yet.`
        + ` Nothing here is stored until you declare it.</span></span>`
        + `<span class="dim">${n} inside</span>`
        + (this.insideDraft
          ? `<span><button data-up="1">up ⎋</button> <button data-declare="1">declare &amp; up</button></span>`
          : `<button data-declare="1">declare &amp; ascend ⎋</button>`);
      this.el.draftbar.onclick = (ev) => {
        const t = ev.target as HTMLElement;
        if (t.closest("[data-up]")) this.ascend();
        else if (t.closest("[data-declare]")) this.ascend(true);
      };
    }
    const showHash = this.present.opts.hash === "always" || !!this.view.inspect
      || (this.present.opts.hash === "systems" && this.view.showsAll);
    this.el.hashwrap.style.display = showHash ? "" : "none";
    if (l.kind === "root") {
      const h = l.engine.graphHash();
      this.lastHash = h;
      const drafts = Object.keys(l.engine.root.panes).filter((o) => this.isDraftPane(o)).length;
      this.el.hash.textContent = drafts ? `${drafts} draft${drafts > 1 ? "s" : ""} — provisional` : h.slice(7, 19);
      this.el.hashwrap.classList.toggle("draft", drafts > 0);
      this.el.tickno.textContent = `t${l.engine.tickIndex}`;
    } else { this.el.hash.textContent = "no identity yet"; this.el.tickno.textContent = "t—"; }
  }

  renderTabs(): void {
    const crumb = this.levels.slice(1).map((l) => (l as { title: string }).title);
    const tabs = this.present.order.map((id) => {
      const v = this.present.views[id];
      return `<button class="tab${id === this.present.active ? " on" : ""}" data-view="${id}">${esc(v.name)}${this.present.home === id ? `<span class="home">◆</span>` : ""}</button>`;
    }).join("");
    const inside = crumb.length
      ? `<button class="tab on" data-up="1">▸ ${esc(crumb[crumb.length - 1])} · ${this.insideDraft ? "up" : "declare &amp; up"}</button>` : "";
    this.el.tabs.innerHTML = inside || (tabs + `<button class="tab-add" data-newview="1">+</button>`);
  }

  renderSel(): void {
    const n = this.marked.size;
    this.el.selchip.style.display = n ? "" : "none";
    if (n) this.el.selchip.textContent = [...this.marked].map((o) => this.nameOf(o)).join(" ");
  }

  renderPanes(): void {
    const skyF = document.createDocumentFragment(), grF = document.createDocumentFragment();
    for (const occ of this.visible()) {
      const m = this.pv(occ)!, path = this.pathOf(occ), u = this.unitOf(occ);
      const kind = this.kindOf(occ);
      const lit = this.focus === occ, marked = this.marked.has(occ);
      const live = this.ran.includes(path) || this.graph.panes[occ].pinned;
      const [th, ts] = toneOf(this.graph.panes[occ].unit);

      const d = document.createElement("div");
      const isEmpty = u.cls === "container" && !u.body && !(u.graph && Object.keys(u.graph.panes).length);
      const isDraft = this.isDraftPane(occ);
      d.className = `pane${lit ? " lit" : ""}${marked ? " marked" : ""}${m.folded ? " folded" : ""}${isEmpty ? " isempty" : ""}${isDraft ? " isdraft" : ""}`
        + `${!live && this.present.opts.recede && !lit ? " quiet" : ""}${this.pulses.has(path) ? " pulse" : ""}`
        + `${this.routeFrom === occ ? " marked" : ""}`;
      d.style.cssText = `left:${m.x}px;top:${m.y}px;width:${m.w}px;height:${m.h}px;--tone:${th};--tone-s:${ts}%`;
      d.dataset.occ = occ;
      const label = this.present.label[path];
      d.innerHTML = `
        <div class="hd">
          <span class="tag">${esc(occ)}</span>
          ${label ? `<span class="name">${esc(label)}</span>` : `<span class="name">${esc(kind)}</span>`}
          ${this.graph.panes[occ].pinned ? `<span class="mk" title="pinned">◈</span>` : ""}
          ${isDraft ? `<span class="draftmk" data-declare="${esc(occ)}" title="a draft — no identity yet. Click to declare it into one thing.">draft</span>` : ""}
          ${u.cls === "container" && !isDraft ? `<span class="mk" title="a declared container">▣</span>` : ""}
        </div>
        <div class="bd">${this.renderValue(occ, u, m)}</div>
        <div class="ft">${esc(this.footFor(occ, u))}</div>
        <div class="rz" data-rz="1"></div>`;
      (m.zone === "sky" ? skyF : grF).appendChild(d);
    }
    for (const n of this.notesHere()) {
      const d = document.createElement("div");
      d.className = "note";
      d.style.cssText = `left:${n.x}px;top:${n.y}px;width:${n.w}px`;
      d.innerHTML = (n.title ? `<b>${esc(n.title)}</b>` : "")
        + `<span>${esc(n.text).replace(/`([^`]+)`/g, "<code>$1</code>")}</span>`;
      (n.zone === "sky" ? skyF : grF).appendChild(d);
    }
    this.el.skyHost.innerHTML = ""; this.el.skyHost.appendChild(skyF);
    this.el.groundHost.innerHTML = ""; this.el.groundHost.appendChild(grF);
    this.sizeGround();
    if (this.editing) {
      const ed = document.querySelector(`[data-edit="${this.editing}"]`) as HTMLInputElement | HTMLTextAreaElement | null;
      if (ed) { this.attachEditor(ed); if (document.activeElement !== ed) { ed.focus(); if (ed.tagName !== "TEXTAREA") (ed as HTMLInputElement).select(); } }
    }
    if (this.pulses.size) setTimeout(() => { this.pulses.clear(); }, 560);
  }

  /**
   * Focus and marking are presentation. Repaint the CLASSES, never rebuild the nodes — a
   * rebuild between the two halves of a double-click destroys the double-click.
   */
  paintFocus(): void {
    for (const el of Array.from(this.el.skyHost.children).concat(Array.from(this.el.groundHost.children)) as HTMLElement[]) {
      const o = el.dataset.occ; if (!o) continue;
      el.classList.toggle("lit", this.focus === o);
      el.classList.toggle("marked", this.marked.has(o) || this.routeFrom === o);
    }
    this.renderWires(); this.renderSel(); this.renderInsp();
  }

  /** value + liveness only. Never rebuilds a node, so nothing under the cursor is disturbed. */
  refresh(): void {
    this.renderStatus();
    for (const occ of this.visible()) {
      const el = document.querySelector(`[data-occ="${occ}"]`) as HTMLElement | null;
      if (!el) return this.render();                    // structure drifted — full paint
      const m = this.pv(occ)!, path = this.pathOf(occ), u = this.unitOf(occ);
      if (this.editing !== path) {
        const bd = el.querySelector(".bd") as HTMLElement | null;
        const html = this.renderValue(occ, u, m);
        if (bd && bd.innerHTML !== html) bd.innerHTML = html;
      }
      const live = this.ran.includes(path) || this.graph.panes[occ].pinned;
      el.classList.toggle("quiet", !live && this.present.opts.recede && this.focus !== occ);
      if (this.pulses.has(path) && this.present.opts.motion) {
        el.classList.remove("pulse"); void el.offsetWidth; el.classList.add("pulse");
      }
    }
  }

  /** the ground has no edge: it is always the work plus room to keep going */
  sizeGround(): void {
    const z = this.view.zoom;
    let w = 0, h = 0;
    for (const o of this.visible()) {
      const m = this.pv(o)!; if (m.zone !== "ground") continue;
      w = Math.max(w, m.x + m.w); h = Math.max(h, m.y + m.h);
    }
    for (const n of this.notesHere()) if ((n.zone ?? "ground") === "ground") {
      w = Math.max(w, n.x + n.w); h = Math.max(h, n.y + noteHeight(n));
    }
    const W = Math.max(w + 600, this.el.ground.clientWidth / z + 200);
    const H = Math.max(h + 500, this.el.ground.clientHeight / z + 160);
    this.el.groundHost.style.width = `${W}px`;
    this.el.groundHost.style.height = `${H}px`;
    this.el.groundHost.style.transform = z === 1 ? "" : `scale(${z})`;
    this.el.gcanvas.style.width = `${W * z}px`;
    this.el.gcanvas.style.height = `${H * z}px`;
    const wires = this.el.wires as unknown as SVGSVGElement & { style: CSSStyleDeclaration };
    wires.style.width = `${W}px`; wires.style.height = `${H}px`;
    this.el.zoomtag.textContent = z === 1 ? "" : `${Math.round(z * 100)}%`;
  }

  /** zoom is presentation: it cannot move the hash, so it lives on the view */
  setZoom(z: number, anchor?: { x: number; y: number }): void {
    if (!Number.isFinite(z) || z <= 0) return;
    const nz = Math.max(0.35, Math.min(2.5, Number(z.toFixed(3))));
    const old = this.view.zoom;
    if (nz === old) return;
    const g = this.el.ground;
    const ax = anchor ? anchor.x : g.clientWidth / 2, ay = anchor ? anchor.y : g.clientHeight / 2;
    const wx = (g.scrollLeft + ax) / old, wy = (g.scrollTop + ay) / old;   // world point under the cursor
    this.view.zoom = nz;
    this.render();
    g.scrollLeft = wx * nz - ax; g.scrollTop = wy * nz - ay;               // keep it under the cursor
    this.echo(`zoom ${Math.round(nz * 100)}%`);
  }

  /**
   * LOOK THROUGH. The container's interior drawn inside the container's own rectangle: a
   * viewport, not a journey. The values are the real ones — nesting is already flattened, so
   * sigma holds `parent/child#port` and nothing extra has to be computed. Two of these open
   * at once is two sublayers worked on at the same time.
   */
  renderThrough(occ: string, inside: Graph): string {
    const base = this.pathOf(occ);
    const kids = Object.keys(inside.panes);
    const cells = kids.map((k, i) => {
      const cp = `${base}/${k}`;
      const cu = this.store.unit(inside.panes[k].unit);
      const op = outPorts(cu)[0]?.name;
      const v = op ? this.valueAt(`${cp}#${op}`) : undefined;
      const pos = this.present.inner[cp] ?? [12 + (i % 2) * 104, 10 + Math.floor(i / 2) * 52];
      this.present.inner[cp] = pos;
      const [th, ts] = toneOf(inside.panes[k].unit);
      const ran = this.ran.includes(cp);
      const ins = inPorts(cu), outs = outPorts(cu);
      const bound = (nm: string, dir: "in" | "out") => inside.wires.some((w) =>
        dir === "in" ? (w.to[0] === k && w.to[1] === nm) : (w.from[0] === k && w.from[1] === nm));
      const dots = (ps: typeof ins, dir: "in" | "out") => ps.map((pp) =>
        `<span class="sdot ${dir}${bound(pp.name, dir) ? " on" : ""}" data-dot="${esc(pp.name)}"
           data-dir="${dir}" data-sub="${esc(k)}" data-in="${esc(occ)}"
           title="${esc(pp.name)} · ${esc(pp.shape)} — drag to another port, or out to the wall to expose"></span>`).join("");
      return `<div class="sub${ran ? " ran" : ""}" data-sub="${esc(k)}" data-in="${esc(occ)}"
        style="left:${pos[0]}px;top:${pos[1]}px;--tone:${th};--tone-s:${ts}%">
        <span class="sports in">${dots(ins, "in")}</span>
        <span class="sports out">${dots(outs, "out")}</span>
        <span class="stag">${esc(k)}</span>
        <span class="sval">${v === undefined ? "—" : esc(short(v))}</span>
      </div>`;
    }).join("");
    const wires = inside.wires.filter((w) => w.from[0] !== "@in" && w.to[0] !== "@out")
      .map((w) => {
        const a = this.present.inner[`${base}/${w.from[0]}`], b = this.present.inner[`${base}/${w.to[0]}`];
        if (!a || !b) return "";
        return `<line x1="${a[0] + 96}" y1="${a[1] + 15}" x2="${b[0]}" y2="${b[1] + 15}"/>`;
      }).join("");
    const u = this.unitOf(occ);
    const edge = (dir: "in" | "out") => u.ports.filter((pp) => pp.dir === dir).map((pp) =>
      `<span class="bport ${dir}" data-bport="${esc(pp.name)}" data-in="${esc(occ)}"
        title="boundary ${dir} port — click to remove">${esc(pp.name)}</span>`).join("");
    return `<div class="through" data-through="${esc(occ)}">
      <svg class="swires">${wires}</svg>${cells}
      <span class="bports left">${edge("in")}</span>
      <span class="bports right">${edge("out")}</span>
      <span class="thru-tag">${u.ports.length ? `${u.ports.length} port${u.ports.length > 1 ? "s" : ""}` : "no ports yet — drag one to the wall"}</span></div>`;
  }

  // ---------------------------------------------------------------- editing THROUGH a window
  // A container's interior is just a graph, so changing it is an ordinary edit: build the new
  // interior, rebuild the unit, swap it in. No descent, no draft — which is what makes two
  // windows editable at the same time.

  /** replace a container's interior (and optionally its boundary) in place */
  editInside(host: string, fn: (g: Graph) => Graph, what: string, ports?: Port[]): boolean {
    const u = this.unitOf(host);
    if (!u.graph) { this.say(`${this.nameOf(host)} has no inside`, "no"); return false; }
    const nu = container(ports ?? u.ports, fn(u.graph));
    const old = this.graph.panes[host].unit;
    // editing a draft must not declare it. Working on something is not finishing it.
    const id = Store.isDraft(old) ? this.store.putDraft(nu) : this.store.putUnit(nu);
    const label = this.present.unitLabel[old];
    if (label) this.present.unitLabel[id] = label;
    if (this.present.mine[old]) this.present.mine[id] = this.present.mine[old];
    // a declared unit edited through a window becomes a NEW unit, in this pane only. Other
    // panes holding the old one keep it — identity is content — so say which.
    const others = Object.keys(this.graph.panes).filter((o) => o !== host && this.graph.panes[o].unit === old);
    const note = !Store.isDraft(old) && others.length
      ? ` — ${others.map((o) => this.nameOf(o)).join(", ")} still ${others.length > 1 ? "hold" : "holds"} the earlier version` : "";
    const ok = this.edit((g) => graph({ ...g.panes, [host]: { ...g.panes[host], unit: id } }, g.wires), what ? what + note : "");
    if (ok && note && !what) this.say(`${this.nameOf(host)} is a new version${note}`, "ok");
    return ok;
  }

  /** wire two children of the same container, without going inside */
  wireInside(host: string, from: [string, string], to: [string, string]): void {
    this.editInside(host, (gi) => graph(
      gi.panes,
      [...gi.wires.filter((w) => !(w.to[0] === to[0] && w.to[1] === to[1])), wire(from, to)],
    ), `${from[0]}.${from[1]} → ${to[0]}.${to[1]} inside ${this.nameOf(host)}`);
  }

  /**
   * EXPOSE — the gesture that makes containers wireable to each other. A child's port becomes
   * a port on the container's own boundary, with the internal wire that connects them. This
   * is the authoring path a boundary always needed: `collapse` can only derive ports from
   * what happened to cross a selection, which is no use when you are building deliberately.
   */
  expose(host: string, child: string, portName: string, as?: string): void {
    const u = this.unitOf(host);
    if (!u.graph || !u.graph.panes[child]) return this.say(`${child} is not inside ${this.nameOf(host)}`, "no");
    const cu = this.store.unit(u.graph.panes[child].unit);
    const p = cu.ports.find((x) => x.name === portName);
    if (!p) return this.say(`${child} has no port “${portName}”`, "no");
    let bn = (as ?? `${child}_${portName}`).replace(/[^A-Za-z0-9_.-]/g, "_");
    let i = 1; while (u.ports.some((x) => x.name === bn)) bn = `${as ?? `${child}_${portName}`}${++i}`;
    const ports = [...u.ports, port(bn, p.dir, p.shape)];
    const rewire = (gi: Graph): Graph => p.dir === "in"
      ? graph(gi.panes, [...gi.wires.filter((w) => !(w.to[0] === child && w.to[1] === portName)),
                         wire(["@in", bn], [child, portName])])
      : graph(gi.panes, [...gi.wires, wire([child, portName], ["@out", bn])]);
    if (this.editInside(host, rewire, "", ports))
      this.say(`${this.nameOf(host)}.${bn} — a ${p.dir} port. It can be wired now.`, "ok");
  }

  /** unexpose: drop a boundary port and the wire that served it */
  unexpose(host: string, portName: string): void {
    const u = this.unitOf(host);
    if (!u.graph) return;
    if (!u.ports.some((x) => x.name === portName)) return this.say(`no port “${portName}”`, "no");
    const ports = u.ports.filter((x) => x.name !== portName);
    this.editInside(host, (gi) => graph(gi.panes,
      gi.wires.filter((w) => !((w.from[0] === "@in" && w.from[1] === portName)
        || (w.to[0] === "@out" && w.to[1] === portName)))), `${this.nameOf(host)}.${portName} removed`, ports);
  }

  /** open / close the window into a container */
  look(targets: string[]): void {
    const occs = this.argsOrMarked(targets); if (!occs.length) return this.say("nothing marked", "no");
    let opened = 0;
    for (const o of occs) {
      const u = this.unitOf(o), m = this.pv(o);
      if (!m) continue;
      if (u.cls !== "container" || !u.graph || !Object.keys(u.graph.panes).length) {
        this.say(`${this.nameOf(o)} has nothing inside to look at`, "no"); continue;
      }
      m.open = !m.open;
      if (m.open) { m.w = Math.max(m.w, 250); m.h = Math.max(m.h, 170); opened++; }
    }
    this.safeTick(); this.render();
    this.echo(opened ? `looking through ${occs.map((o) => this.nameOf(o)).join(" ")}` : "closed");
  }

  renderValue(occ: string, u: Unit, m: PaneView): string {
    const path = this.pathOf(occ), kind = this.typedAs(occ);
    if (kind) {
      const raw = this.srcValues[path];
      if (this.editing === path)
        return kind === "text"
          ? `<textarea class="ed" data-edit="${esc(path)}">${esc(String(raw ?? ""))}</textarea>`
          : `<input class="ed" data-edit="${esc(path)}" value="${esc(String(raw ?? 0))}"/>`;
      const disp = raw === undefined ? "—" : (kind === "number" ? short(raw) : String(raw) || "—");
      return `<div class="${kind === "number" ? "val-num" : "val-str"} editable" title="click to edit">${esc(disp)}</div>`;
    }
    if (u.cls === "container") {
      const inside = u.graph;
      const n = inside ? Object.keys(inside.panes).length : 0;
      if (m.open && inside && n) return this.renderThrough(occ, inside);
      const v = this.outValue(occ);
      if (!n) return `<div class="val-muted">▢</div><div class="val-muted" style="margin-top:6px">nothing yet — give it a body, or go inside</div>`;
      const draft = this.isDraftPane(occ);
      const outs = outPorts(u);
      const vals = outs.length
        ? outs.map((pp) => `<div class="val-num" style="font-size:18px">${esc(short(this.outValue(occ, pp.name)))}<span class="val-muted" style="font-size:9.5px;margin-left:6px">${esc(pp.name)}</span></div>`).join("")
        : `<div class="val-muted">${draft ? "no ports yet" : "▣"}</div>`;
      return vals + `<div class="val-muted" style="margin-top:6px">${n} inside · ${draft
        ? `<b style="color:#a5b4fc">a draft</b> — <b>declare</b> to seal it`
        : `sealed`} · <b>look</b> or double-click</div>`;
    }
    const v = this.outValue(occ);
    if (v === undefined)
      return `<div class="val-muted">${this.fetchStatus[path] === "wait" ? "fetching…" : "—"}</div>`;
    return renderLens(m.lens === "auto" && this.view.rich ? "big" : m.lens, v);
  }

  footFor(occ: string, u: Unit): string {
    if (u.cls === "source") return "source";
    const ins = inPorts(u); if (!ins.length) return u.cls;
    return ins.map((p) => {
      const w = this.graph.wires.find((w) => w.to[0] === occ && w.to[1] === p.name);
      return `${p.name}${w ? "←" + this.nameOf(w.from[0]) : "·"}`;
    }).join("  ");
  }

  renderWires(): void {
    const parts: string[] = [];
    const show = this.view.showsAll || this.focus !== null;
    if (show) {
      for (const w of this.graph.wires) {
        if (w.from[0] === "@in" || w.to[0] === "@out") continue;
        const a = this.anchor(w.from[0], "out"), b = this.anchor(w.to[0], "in");
        if (!a || !b) continue;
        const near = this.view.showsAll || w.from[0] === this.focus || w.to[0] === this.focus;
        const dx = Math.max(28, Math.abs(b[0] - a[0]) * 0.4);
        parts.push(`<path class="wire${near ? "" : " dim"}" d="M${a[0]},${a[1]} C${a[0] + dx},${a[1]} ${b[0] - dx},${b[1]} ${b[0]},${b[1]}"/>`);
      }
    }
    this.el.wires.innerHTML = parts.join("");
  }
  /** ground-space anchor; sky panes have none (wires are drawn in the ground layer only) */
  anchor(occ: string, dir: "in" | "out"): [number, number] | null {
    if (!this.graph.panes[occ] || !this.inView(occ)) return null;
    const m = this.pv(occ)!; if (m.zone !== "ground") return null;
    return [dir === "out" ? m.x + m.w : m.x, m.y + 13];
  }

  // ------------------------------------------------------------ zones & pointer
  /** screen → world. The ground is scrolled and scaled, so both come out here. */
  zoneOf(e: MouseEvent): { zone: Zone; x: number; y: number } | null {
    const sr = this.el.sky.getBoundingClientRect(), gr = this.el.ground.getBoundingClientRect();
    if (this.el.sky.style.display !== "none" && e.clientY >= sr.top && e.clientY <= sr.bottom)
      return { zone: "sky", x: e.clientX - sr.left, y: e.clientY - sr.top };
    if (e.clientY >= gr.top && e.clientY <= gr.bottom) {
      const z = this.view.zoom;
      return {
        zone: "ground",
        x: (e.clientX - gr.left + this.el.ground.scrollLeft) / z,
        y: (e.clientY - gr.top + this.el.ground.scrollTop) / z,
      };
    }
    return null;
  }
  /** world → screen, for overlays that live outside the scaled host */
  toScreen(zone: Zone, x: number, y: number): [number, number] {
    if (zone === "sky") {
      const r = this.el.sky.getBoundingClientRect();
      return [r.left + x, r.top + y];
    }
    const r = this.el.ground.getBoundingClientRect(), z = this.view.zoom;
    return [r.left + x * z - this.el.ground.scrollLeft, r.top + y * z - this.el.ground.scrollTop];
  }

  events(): void {
    const omni = this.el.omni;
    omni.addEventListener("focus", () => this.el.ombox.classList.add("lit"));
    omni.addEventListener("blur", () => this.el.ombox.classList.remove("lit"));
    omni.addEventListener("input", () => this.suggest());
    document.addEventListener("keydown", (e) => this.onKey(e));
    for (const ev of ["keydown", "mousedown", "paste"])
      document.addEventListener(ev, () => { this.lastHuman = Date.now(); }, true);

    for (const host of [this.el.sky, this.el.ground]) {
      host.addEventListener("mousedown", (e) => this.onDown(e as MouseEvent));
      host.addEventListener("dblclick", (e) => this.onDbl(e as MouseEvent));
      host.addEventListener("contextmenu", (e) => this.onContext(e as MouseEvent));
    }
    window.addEventListener("mousemove", (e) => this.onMove(e as MouseEvent));
    window.addEventListener("mouseup", (e) => this.onUp(e as MouseEvent));
    let rt = 0;
    window.addEventListener("resize", () => {
      this.layout(); this.render();
      clearTimeout(rt); rt = setTimeout(() => { this.bgKey = ""; this.paintBg(); }, 220) as unknown as number;
    });

    this.el.horizon.addEventListener("mousedown", (e) => {
      if ((e.target as HTMLElement).closest("button")) return;
      this.hdrag = true; e.preventDefault();
    });
    this.el.hgrip.addEventListener("click", (e) => {
      const b = (e.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      this.view.horizon = Number(b.dataset.h); this.layout(); this.render(); this.echo("horizon");
    });

    this.el.tabs.addEventListener("click", (e) => {
      const b = (e.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      if (b.dataset.view) this.switchView(b.dataset.view);
      else if (b.dataset.newview) { omni.focus(); omni.value = "view new "; this.suggest(); }
      else if (b.dataset.up) this.ascend();
    });
    this.el.gear.addEventListener("click", () => this.toggleOptions());
    this.el.inspBtn.addEventListener("click", () => this.toggleInsp());
    this.el.libBtn.addEventListener("click", () => this.toggleLib());

    // ctrl/⌘ + wheel zooms about the cursor; shift + wheel runs sideways; plain wheel scrolls
    this.el.ground.addEventListener("wheel", (e) => {
      const ev = e as WheelEvent;
      if (ev.ctrlKey || ev.metaKey) {
        ev.preventDefault();
        const r = this.el.ground.getBoundingClientRect();
        this.setZoom(this.view.zoom * (ev.deltaY < 0 ? 1.12 : 1 / 1.12),
          { x: ev.clientX - r.left, y: ev.clientY - r.top });
      } else if (ev.shiftKey && ev.deltaX === 0) {
        ev.preventDefault(); this.el.ground.scrollLeft += ev.deltaY;
      }
    }, { passive: false });
    this.el.help.addEventListener("click", () => this.el.help.classList.remove("on"));
    this.el.empty.addEventListener("click", (e) => {
      if ((e.target as HTMLElement).closest("[data-tour]")) this.tour();
    });
    this.el.sugg.addEventListener("mousedown", (e) => {
      const s = (e.target as HTMLElement).closest(".sg") as HTMLElement | null; if (!s) return;
      e.preventDefault(); this.applySugg(s.dataset.v!);
    });
    document.addEventListener("paste", (e) => this.onPaste(e as ClipboardEvent));
    document.addEventListener("mousedown", (e) => {
      if (this.menuEl && !(e.target as HTMLElement).closest(".menu")) this.closeMenu();
    }, true);
  }

  onKey(e: KeyboardEvent): void {
    const omni = this.el.omni, ae = document.activeElement as HTMLElement | null;
    if (this.el.help.classList.contains("on")) {
      if (e.key === "Escape" || e.key === "?") { e.preventDefault(); this.el.help.classList.remove("on"); }
      return;
    }
    if (ae && ae.classList.contains("ed")) return;
    // Any other field the user is typing in owns its keys. Without this, a letter typed into
    // (say) a port name in the author panel was stolen by the omnibar, Backspace deleted the
    // focused pane, and arrows moved focus across the room. Escape still closes the panel.
    if (ae && ae !== omni && (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA"
        || ae.tagName === "SELECT" || ae.isContentEditable)) {
      if (e.key === "Escape") { e.preventDefault(); ae.blur(); this.escape(); }
      return;
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
      e.preventDefault(); return e.shiftKey ? this.redo() : this.undo();
    }
    const suggOpen = this.el.sugg.classList.contains("on");
    if (ae === omni) {
      if (suggOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
        e.preventDefault(); this.suggIdx = Math.max(0, Math.min(this.suggItems.length - 1, this.suggIdx + (e.key === "ArrowDown" ? 1 : -1)));
        return this.paintSugg();
      }
      if (e.key === "Enter") {
        e.preventDefault();
        // Enter RUNS. It only completes when the last word is genuinely unfinished, so a
        // whole command (`clock`, `mul`) never turns into a space instead of an action.
        if (suggOpen && this.partialPick()) return this.applySugg(this.partialPick()!);
        const v = omni.value; omni.value = ""; this.hideSugg(); this.run(v); return;
      }
      if (e.key === "Tab") {
        e.preventDefault();
        if (suggOpen && this.suggItems[this.suggIdx]) return this.applySugg(this.suggItems[this.suggIdx]);
        if (omni.value === "") this.descend();
        return;
      }
      if (e.key === "Escape") { e.preventDefault(); if (omni.value) { omni.value = ""; this.hideSugg(); } else this.escape(); return; }
      if (omni.value === "" && this.navKey(e.key)) { e.preventDefault(); return; }
      return;
    }
    if (this.navKey(e.key)) { e.preventDefault(); return; }
    if ((e.key === "Backspace" || e.key === "Delete")) { e.preventDefault(); return this.del([]); }
    if (e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
      omni.focus(); omni.value = e.key; this.suggest(); e.preventDefault();
    }
  }
  navKey(k: string): boolean {
    switch (k) {
      case "ArrowUp": this.moveFocus("up"); return true;
      case "ArrowDown": this.moveFocus("down"); return true;
      case "ArrowLeft": this.moveFocus("left"); return true;
      case "ArrowRight": this.moveFocus("right"); return true;
      case "Tab": this.descend(); return true;
      case "Escape": this.escape(); return true;
      case "?": this.el.help.classList.add("on"); return true;
    }
    return false;
  }
  escape(): void {
    this.closeMenu();
    if (this.el.author.classList.contains("on")) return this.closeAuthor();
    if (this.el.lib.classList.contains("on")) return this.toggleLib(false);
    if (this.el.options.classList.contains("on")) return this.toggleOptions(false);
    if (this.el.insp.classList.contains("on")) return this.toggleInsp(false);
    if (this.routeFrom) { this.routeFrom = null; this.render(); return this.echo("cancelled"); }
    if (this.editing) { this.editing = null; this.render(); return; }
    if (this.marked.size) { this.marked.clear(); this.render(); return; }
    if (this.isLiminal) return this.ascend();
    if (this.focus) { this.focus = null; this.render(); }
  }

  onDown(e: MouseEvent): void {
    if (e.button !== 0) return;
    const t = e.target as HTMLElement;
    if (t.closest(".menu") || t.closest("#options") || t.closest("#horizon")) return;
    this.closeMenu();
    if (t.classList.contains("sdot")) {
      this.dotDrag = { host: t.dataset.in!, sub: t.dataset.sub!, port: t.dataset.dot!,
                       dir: t.dataset.dir as "in" | "out", x: e.clientX, y: e.clientY };
      e.preventDefault(); e.stopPropagation(); return;
    }
    if (t.dataset.declare) { this.declareChip([t.dataset.declare]); e.preventDefault(); e.stopPropagation(); return; }
    if (t.classList.contains("bport")) {
      this.unexpose(t.dataset.in!, t.dataset.bport!); e.preventDefault(); e.stopPropagation(); return;
    }
    const sub = t.closest(".sub") as HTMLElement | null;
    if (sub) {                                   // rearranging inside a window is gauge
      const cp = `${this.pathOf(sub.dataset.in!)}/${sub.dataset.sub}`;
      const st = this.present.inner[cp] ?? [0, 0];
      this.subDrag = { path: cp, el: sub, ox: e.clientX - st[0], oy: e.clientY - st[1] };
      e.preventDefault(); e.stopPropagation(); return;
    }
    if (t.classList.contains("editable")) {
      // preventDefault, or the browser's own mousedown focus lands after the re-render and
      // blurs the editor it just made — the click commits immediately and nothing is editable
      e.preventDefault();
      this.startEdit((t.closest(".pane") as HTMLElement).dataset.occ!); return;
    }
    if (t.closest(".ed")) return;
    const z = this.zoneOf(e); if (!z) return;
    const pe = t.closest(".pane") as HTMLElement | null;

    if (t.dataset.rz && pe) {
      const m = this.pv(pe.dataset.occ!)!;
      this.rz = { occ: pe.dataset.occ!, x: e.clientX, y: e.clientY, w: m.w, h: m.h };
      e.preventDefault(); return;
    }
    if (!pe) {                       // marquee on empty space
      if (!e.shiftKey) { this.marked.clear(); this.focus = null; this.paintFocus(); }
      this.marq = { x: z.x, y: z.y, zone: z.zone };
      e.preventDefault(); return;
    }
    const occ = pe.dataset.occ!;
    if (this.routeFrom && this.routeFrom !== occ) {
      this.route(this.nameOf(this.routeFrom), this.nameOf(occ)); this.routeFrom = null; this.render(); return;
    }
    if (e.shiftKey) { this.marked.has(occ) ? this.marked.delete(occ) : this.marked.add(occ); this.focus = occ; this.paintFocus(); return; }
    this.focus = occ;
    if (!this.marked.has(occ)) this.marked.clear();
    this.paintFocus();
    const m = this.pv(occ)!;
    this.drag = { occ, dx: z.x - m.x, dy: z.y - m.y, moved: false, zone: z.zone };
    e.preventDefault();
  }

  onMove(e: MouseEvent): void {
    if (this.dotDrag) {
      const g = document.getElementById("dotline") as unknown as SVGLineElement | null;
      const host = document.getElementById("dotlayer") as unknown as SVGSVGElement | null;
      if (host && g) {
        host.style.display = "block";
        g.setAttribute("x1", String(this.dotDrag.x)); g.setAttribute("y1", String(this.dotDrag.y));
        g.setAttribute("x2", String(e.clientX)); g.setAttribute("y2", String(e.clientY));
      }
      const over = (e.target as HTMLElement).closest?.(".through");
      const wall = !over && (e.target as HTMLElement).closest?.(".pane");
      document.querySelectorAll(".pane").forEach((p) => p.classList.toggle("wall",
        !!wall && (p as HTMLElement).dataset.occ === this.dotDrag!.host));
      return;
    }
    if (this.subDrag) {
      const x = Math.max(0, e.clientX - this.subDrag.ox), y = Math.max(0, e.clientY - this.subDrag.oy);
      this.present.inner[this.subDrag.path] = [x, y];
      this.subDrag.el.style.left = `${x}px`; this.subDrag.el.style.top = `${y}px`;
      return;
    }
    if (this.hdrag) {
      const top = 36, dockH = 96, avail = window.innerHeight - top - dockH;
      this.view.horizon = Math.max(0, Math.min(0.72, (e.clientY - top) / avail));
      this.layout(); this.renderWires();
      return;
    }
    if (this.rz) {
      const m = this.pv(this.rz.occ); if (!m) return;
      m.w = Math.max(120, this.rz.w + (e.clientX - this.rz.x));
      m.h = Math.max(60, this.rz.h + (e.clientY - this.rz.y));
      const el = document.querySelector(`[data-occ="${this.rz.occ}"]`) as HTMLElement | null;
      if (el) { el.style.width = `${m.w}px`; el.style.height = `${m.h}px`; }
      return;
    }
    if (this.marq) {
      const z = this.zoneOf(e); if (!z) return;
      const host = this.marq.zone === "sky" ? this.el.sky : this.el.ground;
      const r = host.getBoundingClientRect();
      const x = Math.min(this.marq.x, z.x), y = Math.min(this.marq.y, z.y);
      const w = Math.abs(z.x - this.marq.x), h = Math.abs(z.y - this.marq.y);
      void host; void r;
      const [sx, sy] = this.toScreen(this.marq.zone, x, y);
      const sc = this.marq.zone === "ground" ? this.view.zoom : 1;
      const mq = this.el.marquee;
      mq.style.display = "block";
      mq.style.left = `${sx}px`; mq.style.top = `${sy}px`;
      mq.style.width = `${w * sc}px`; mq.style.height = `${h * sc}px`;
      // a box that has caught nothing is an offer to MAKE something that size
      mq.classList.toggle("make", w > 60 && h > 44 && !this.panesIn(this.marq.zone, x, y, x + w, y + h).length);
      return;
    }
    if (!this.drag) return;
    const z = this.zoneOf(e); if (!z) return;
    const el = document.querySelector(`[data-occ="${this.drag.occ}"]`) as HTMLElement | null; if (!el) return;
    const m = this.pv(this.drag.occ)!;
    const nx = z.x - this.drag.dx, ny = z.y - this.drag.dy;
    if (!this.drag.moved && Math.hypot(nx - m.x, ny - m.y) > 4) { this.drag.moved = true; el.classList.add("dragging"); }
    if (!this.drag.moved) return;
    el.style.left = `${nx}px`; el.style.top = `${ny}px`;
    // highlight a pane we could drop onto (= connect)
    const over = this.paneUnder(e, this.drag.occ);
    for (const p of Array.from(document.querySelectorAll(".pane"))) p.classList.remove("droptarget");
    if (over) (document.querySelector(`[data-occ="${over}"]`) as HTMLElement)?.classList.add("droptarget");
  }

  panesIn(zone: Zone, x0: number, y0: number, x1: number, y1: number): string[] {
    return this.visible().filter((o) => {
      const m = this.pv(o)!;
      return m.zone === zone && m.x < x1 && m.x + m.w > x0 && m.y < y1 && m.y + m.h > y0;
    });
  }
  paneUnder(e: MouseEvent, not: string): string | null {
    const els = document.elementsFromPoint(e.clientX, e.clientY);
    for (const el of els) {
      const p = (el as HTMLElement).closest?.(".pane") as HTMLElement | null;
      if (p && p.dataset.occ !== not) return p.dataset.occ!;
    }
    return null;
  }

  onUp(e: MouseEvent): void {
    if (this.dotDrag) {
      const d = this.dotDrag; this.dotDrag = null;
      const host = document.getElementById("dotlayer") as HTMLElement | null;
      if (host) host.style.display = "none";
      document.querySelectorAll(".pane").forEach((p) => p.classList.remove("wall"));
      const t = e.target as HTMLElement;
      const other = t.classList?.contains("sdot") ? t : null;
      if (other && other.dataset.in === d.host && other.dataset.sub !== d.sub
          && other.dataset.dir !== d.dir) {
        const from: [string, string] = d.dir === "out" ? [d.sub, d.port] : [other.dataset.sub!, other.dataset.dot!];
        const to: [string, string] = d.dir === "out" ? [other.dataset.sub!, other.dataset.dot!] : [d.sub, d.port];
        this.wireInside(d.host, from, to);
        return;
      }
      // released on the container's own body, away from the interior: make it a boundary port
      const pe = t.closest?.(".pane") as HTMLElement | null;
      if (pe && pe.dataset.occ === d.host && !t.closest?.(".through")) {
        this.expose(d.host, d.sub, d.port); return;
      }
      this.echo("drag a port onto another port, or out to the wall");
      return;
    }
    if (this.subDrag) { this.subDrag = null; this.render(); this.echo("moved inside"); return; }
    if (this.hdrag) { this.hdrag = false; this.render(); this.echo("horizon"); return; }
    if (this.rz) { this.rz = null; this.render(); this.echo("resize"); return; }
    if (this.marq) {
      const z = this.zoneOf(e);
      this.el.marquee.style.display = "none";
      this.el.marquee.classList.remove("make");
      if (z && z.zone === this.marq.zone) {
        const x0 = Math.min(this.marq.x, z.x), x1 = Math.max(this.marq.x, z.x);
        const y0 = Math.min(this.marq.y, z.y), y1 = Math.max(this.marq.y, z.y);
        const hit = this.panesIn(this.marq.zone, x0, y0, x1, y1);
        if (hit.length) {
          for (const o of hit) this.marked.add(o);
          this.echo(`${this.marked.size} marked — try wrap, grid, fold`);
        } else if (x1 - x0 > 60 && y1 - y0 > 44) {
          // caught nothing: the box is a SIZE. Pick what goes in it.
          const zone = this.marq.zone;
          this.marq = null; this.render();
          const [sx, sy] = this.toScreen(zone, x1, y0);
          this.openAddMenu(sx + 6, sy, { zone, x: x0, y: y0 },
            { w: Math.round(x1 - x0), h: Math.round(y1 - y0) });
          return;
        }
      }
      this.marq = null; this.render(); return;
    }
    const d = this.drag; this.drag = null;
    for (const p of Array.from(document.querySelectorAll(".pane"))) p.classList.remove("droptarget");
    if (!d) return;
    const el = document.querySelector(`[data-occ="${d.occ}"]`) as HTMLElement | null;
    el?.classList.remove("dragging");
    if (!d.moved) return;
    const onto = this.paneUnder(e, d.occ);
    if (onto) {                          // drop onto a pane = connect (content!)
      this.render();
      const src = this.endpoint(d.occ, "out");
      if (!src) return this.say(`${this.nameOf(d.occ)} has no output`, "no");
      const ins = inPorts(this.unitOf(onto));
      if (!ins.length) return this.say(`${this.nameOf(onto)} takes no input`, "no");
      const free = this.freeIns(onto);
      if (free.length === 1) return void this.connect(src, [onto, free[0].name]);
      if (!free.length) return this.chainOrPick(src, onto);
      return this.pickPort(src, onto, { x: e.clientX + 4, y: e.clientY });   // ambiguous → ask
    }
    const z = this.zoneOf(e);
    const m = this.pv(d.occ)!;
    this.pushUndo();
    if (z) {
      let nx = z.x - d.dx, ny = z.y - d.dy;
      if (this.present.opts.snap) { nx = Math.round(nx / 30) * 30; ny = Math.round(ny / 26) * 26; }
      m.x = Math.max(0, Math.round(nx)); m.y = Math.max(0, Math.round(ny));
      if (z.zone !== m.zone) { m.zone = z.zone; this.tick(); }
    }
    this.render();
    this.echo(`move ${this.nameOf(d.occ)}`);      // gauge: grey, and the hash is untouched
  }

  onDbl(e: MouseEvent): void {
    if ((e.target as HTMLElement).closest(".ed, .editable")) return;   // a double-click while editing is editing
    const pe = (e.target as HTMLElement).closest(".pane") as HTMLElement | null;
    if (pe) { this.descend(this.nameOf(pe.dataset.occ!)); return; }
    const z = this.zoneOf(e); if (!z) return;
    this.openAddMenu(e.clientX, e.clientY, z);
  }
  onContext(e: MouseEvent): void {
    e.preventDefault();
    const pe = (e.target as HTMLElement).closest(".pane") as HTMLElement | null;
    if (pe) {
      const occ = pe.dataset.occ!;
      if (!this.marked.has(occ)) { this.marked.clear(); }
      this.focus = occ; this.render();
      this.openPaneMenu(e.clientX, e.clientY, occ);
    } else {
      const z = this.zoneOf(e); if (z) this.openAddMenu(e.clientX, e.clientY, z);
    }
  }
  onPaste(e: ClipboardEvent): void {
    const ae = document.activeElement as HTMLElement | null;
    if (ae === this.el.omni || (ae && ae.classList.contains("ed"))) return;
    const txt = e.clipboardData?.getData("text")?.trim() ?? ""; if (!txt) return;
    e.preventDefault();
    if (/^https?:\/\/\S+$/i.test(txt)) void this.fetch(txt);
    else if (Number.isFinite(Number(txt)) && txt !== "") this.source("number", Number(txt));
    else this.source("text", txt);
  }

  // ------------------------------------------------------------ menus
  closeMenu(): void { this.menuEl?.remove(); this.menuEl = null; }
  placeMenu(el: HTMLDivElement, x: number, y: number): void {
    document.getElementById("app")!.appendChild(el);
    el.style.left = `${Math.min(x, window.innerWidth - el.offsetWidth - 8)}px`;
    el.style.top = `${Math.min(y, window.innerHeight - el.offsetHeight - 8)}px`;
    this.menuEl = el;
  }
  openAddMenu(x: number, y: number, z: { zone: Zone; x: number; y: number },
              size?: { w: number; h: number }): void {
    this.closeMenu();
    this.pendingSize = size ?? null;
    const el = document.createElement("div"); el.className = "menu";
    const from = this.marked.size ? [...this.marked].map((o) => this.nameOf(o)).join(", ") : "";
    el.innerHTML = `
      <div class="mh">${size ? `${size.w}×${size.h}` : z.zone}</div>
      <button data-add="empty"><span class="g">▢</span>empty pane<span style="margin-left:auto;color:var(--ink4);font-size:10px">nothing yet</span></button>
      <button data-add="author"><span class="g">✎</span>…and give it a body</button>
      <div class="sep"></div>
      <div class="mh">from the library</div>
      <button data-add="number"><span class="g">◇</span>number</button>
      <button data-add="text"><span class="g">✎</span>text</button>
      <button data-add="clock"><span class="g">◷</span>clock</button>
      <div class="grid">${["add", "sub", "mul", "gt", "eq", "pick", "join", "total", "last"].map((o) => `<button data-op="${o}">${o}</button>`).join("")}</div>
      <button data-add="library"><span class="g">▦</span>all of it…</button>`;
    el.addEventListener("click", (ev) => {
      const b = (ev.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      this.closeMenu();
      const at = { x: z.x, y: z.y, zone: z.zone };
      const add = b.dataset.add;
      if (add === "empty") this.empty(at);
      else if (add === "author") { const o = this.empty(at); if (o) this.openAuthor(o); }
      else if (add === "library") this.toggleLib(true);
      else if (add === "number") { const o = this.source("number", 0, at); if (o) this.startEdit(o); }
      else if (add === "text") { const o = this.source("text", "", at); if (o) this.startEdit(o); }
      else if (add === "clock") this.source("clock", 0, at);
      else if (b.dataset.op) this.op(b.dataset.op, [], at);
    });
    this.placeMenu(el, x, y);
  }
  openPaneMenu(x: number, y: number, occ: string): void {
    this.closeMenu();
    const u = this.unitOf(occ), kind = this.kindOf(occ), m = this.pv(occ)!;
    const many = this.marked.size > 1;
    const el = document.createElement("div"); el.className = "menu";
    const b = (a: string, g: string, t: string) => `<button data-act="${a}"><span class="g">${g}</span>${t}</button>`;
    el.innerHTML = `
      <div class="mh">${many ? `${this.marked.size} marked` : esc(this.nameOf(occ))}</div>
      ${!many && this.typedAs(occ) ? b("edit", "✎", "edit value") : ""}
      ${!many ? b("author", "✎", "give it a body…") : ""}
      ${!many ? b("inspect", "◫", "inspect / ports") : ""}
      ${!many ? b("route", "→", "route from here…") : ""}
      ${this.isDraftPane(occ) ? b("declare", "◈", many ? "declare them" : "declare it — seal into one unit") : ""}
      ${!many && u.cls === "container" && (u.graph ? Object.keys(u.graph.panes).length : 0)
        ? b("look", "◱", m.open ? "stop looking through" : "look through it") : ""}
      ${!many && u.cls === "container" ? b("descend", "▣", "go inside it") : ""}
      ${b("wrap", "▣", many ? "wrap them" : "wrap it")}
      ${many ? b("grid", "⊞", "tidy into a grid") : ""}
      ${b("fold", "–", m.folded ? "unfold" : "fold away")}
      ${b("pin", "◈", this.graph.panes[occ].pinned ? "unpin" : "pin")}
      ${b(m.zone === "sky" ? "toground" : "tosky", "↕", m.zone === "sky" ? "send to ground" : "send to sky")}
      <div class="sep"></div><div class="mh">lens</div>
      <div class="grid">${["auto", "big", "num", "text", "json", "bool", "bar"].map((L) => `<button data-lens="${L}">${L}</button>`).join("")}</div>
      <div class="sep"></div>${b("rename", "✎", "rename…")}${b("del", "⌫", many ? "delete them" : "delete")}`;
    el.addEventListener("click", (ev) => {
      const btn = (ev.target as HTMLElement).closest("button") as HTMLElement | null; if (!btn) return;
      this.closeMenu();
      const nm = this.nameOf(occ);
      if (btn.dataset.lens) return this.setLens(many ? "" : nm, btn.dataset.lens);
      switch (btn.dataset.act) {
        case "edit": return this.startEdit(occ);
        case "inspect": return this.toggleInsp(true);
        case "author": return this.openAuthor(occ);
        case "declare": return this.declareChip([]);
        case "route": this.routeFrom = occ; this.render(); return this.echo(`click a target for ${nm}`);
        case "descend": return this.descend(nm);
        case "wrap": return this.wrap([]);
        case "grid": return this.grid([]);
        case "fold": return this.fold([]);
        case "pin": return this.pin([]);
        case "tosky": return this.toZone([], "sky");
        case "toground": return this.toZone([], "ground");
        case "rename": this.el.omni.focus(); this.el.omni.value = `name ${occ} `; this.suggest(); return;
        case "del": return this.del([]);
      }
    });
    this.placeMenu(el, x, y);
  }

  // ------------------------------------------------------------ suggestions
  suggest(): void {
    if (!this.present.opts.suggest) return this.hideSugg();
    const raw = this.el.omni.value;
    if (!raw.trim()) return this.hideSugg();
    const parts = raw.split(/\s+/);
    if (parts.length > 1) {                       // suggest pane names for arguments
      const q = parts[parts.length - 1].toLowerCase();
      const names = this.visible().map((o) => this.nameOf(o)).filter((n) => n.toLowerCase().startsWith(q));
      if (!names.length || !q) return this.hideSugg();
      this.suggItems = names;
      this.suggIdx = Math.min(this.suggIdx, names.length - 1);
      this.el.sugg.innerHTML = names.map((n, i) =>
        `<div class="sg${i === this.suggIdx ? " sel" : ""}" data-v="${esc(n)}"><span class="k">${esc(n)}</span><span class="d">a pane here</span></div>`).join("");
      this.el.sugg.classList.add("on");
      return;
    }
    const q = parts[0].toLowerCase();
    const hits = VERBS.filter(([v]) => v.startsWith(q)).slice(0, 8);
    if (!hits.length) return this.hideSugg();
    this.suggItems = hits.map(([v]) => v);
    this.suggIdx = Math.min(this.suggIdx, hits.length - 1);
    this.el.sugg.innerHTML = hits.map(([v, d], i) =>
      `<div class="sg${i === this.suggIdx ? " sel" : ""}" data-v="${esc(v)}"><span class="k">${esc(v)}</span><span class="d">${esc(d)}</span></div>`).join("");
    this.el.sugg.classList.add("on");
  }
  /** the highlighted suggestion, but only when it would actually extend what you typed */
  partialPick(): string | null {
    const pick = this.suggItems[this.suggIdx]; if (!pick) return null;
    const toks = this.el.omni.value.split(/\s+/);
    const last = (toks[toks.length - 1] ?? "").toLowerCase();
    if (!last || pick.toLowerCase() === last) return null;
    // a word that is already a whole verb runs — `sum` must not complete to `sum5`
    if (toks.length === 1 && (ALIAS[last] || VERBS.some(([v]) => v === last))) return null;
    return pick.toLowerCase().startsWith(last) ? pick : null;
  }
  paintSugg(): void {
    Array.from(this.el.sugg.children).forEach((c, i) => c.classList.toggle("sel", i === this.suggIdx));
  }
  applySugg(v: string): void {
    const parts = this.el.omni.value.split(/\s+/);
    parts[parts.length - 1] = v;
    this.el.omni.value = parts.join(" ") + " ";
    this.el.omni.focus(); this.suggIdx = 0; this.suggest();
  }
  hideSugg(): void { this.el.sugg.classList.remove("on"); this.suggItems = []; this.suggIdx = 0; }

  // ------------------------------------------------------------ inline edit
  startEdit(occ: string): void { this.editing = this.pathOf(occ); this.focus = occ; this.render(); }
  attachEditor(el: HTMLInputElement | HTMLTextAreaElement): void {
    const w = el as unknown as { _w?: boolean }; if (w._w) return; w._w = true;
    const path = el.dataset.edit!, node = el as HTMLElement;
    const commit = () => { if (this.editing !== path) return; this.commitEdit(path, el.value); };
    node.addEventListener("keydown", (e: KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Enter" && !(el.tagName === "TEXTAREA" && e.shiftKey)) { e.preventDefault(); commit(); }
      else if (e.key === "Escape") { e.preventDefault(); this.editing = null; this.render(); this.el.omni.focus(); }
      else if (e.key === "Tab") { e.preventDefault(); commit(); }
    });
    node.addEventListener("blur", commit);
  }
  commitEdit(path: string, val: string): void {
    const kind = this.typedAs(path.split("/").pop()!);
    this.editing = null;
    if (kind === "text") this.srcValues[path] = val;
    else {
      const n = Number(val.trim());
      if (val.trim() === "" || !Number.isFinite(n)) {
        this.render(); this.el.omni.focus();
        return this.say(`“${val}” is not a number — kept ${short(this.srcValues[path])}`, "no");
      }
      this.srcValues[path] = n;
    }
    this.safeTick(); this.render(); this.el.omni.focus(); this.touch();
  }

  // ------------------------------------------------------------ focus movement
  moveFocus(dir: "up" | "down" | "left" | "right"): void {
    const vis = this.visible(); if (!vis.length) return;
    if (!this.focus) { this.focus = vis[0]; this.paintFocus(); return this.reveal(); }
    const a = this.pv(this.focus)!;
    const ac = [a.x + a.w / 2, a.y + a.h / 2 + (a.zone === "sky" ? -4000 : 0)];
    let best: string | null = null, score = Infinity;
    for (const o of vis) {
      if (o === this.focus) continue;
      const m = this.pv(o)!;
      const c = [m.x + m.w / 2, m.y + m.h / 2 + (m.zone === "sky" ? -4000 : 0)];
      const dx = c[0] - ac[0], dy = c[1] - ac[1];
      let ok = false, s = 0;
      if (dir === "right") { ok = dx > 8; s = dx + Math.abs(dy) * 2; }
      if (dir === "left") { ok = dx < -8; s = -dx + Math.abs(dy) * 2; }
      if (dir === "down") { ok = dy > 8; s = dy + Math.abs(dx) * 2; }
      if (dir === "up") { ok = dy < -8; s = -dy + Math.abs(dx) * 2; }
      if (ok && s < score) { score = s; best = o; }
    }
    if (best) { this.focus = best; this.marked.clear(); this.paintFocus(); this.reveal(); }
  }
  reveal(): void {
    if (!this.focus) return;
    (document.querySelector(`[data-occ="${this.focus}"]`) as HTMLElement | null)
      ?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "nearest" });
  }

  /**
   * The assembly, in one gesture: something to type in, an ask that leaves the graph, a reply
   * where the answer lands, and a context source you can point at whatever it should see.
   * Nothing is special about any of them — they are four library units and three wires.
   */
  makeAI(target?: string, at?: { x: number; y: number; zone: Zone }): void {
    const was = this.assembling;
    this.assembling = true;
    try { this.batch(() => this.makeAI_(target, at)); } finally { this.assembling = was; }   // one undo step
  }
  private makeAI_(target?: string, at?: { x: number; y: number; zone: Zone }): void {
    const get = (id: string) => STARTER.find((a) => a.id === id)!;
    const spot = at ?? this.freeSpot(260, 150);
    const P = (dx: number, dy: number) => ({ x: spot.x + dx, y: spot.y + dy, zone: spot.zone });
    const you = this.fromLibrary(get("text"), P(0, 0), "");
    const ctx = this.fromLibrary(get("context"), P(0, 172));
    const join = this.fromLibrary(get("join"), P(286, 86));
    const ask = this.fromLibrary(get("ask"), P(500, 86));
    const rep = this.fromLibrary(get("reply"), P(500, 210), "");
    const out = this.fromLibrary(get("show"), P(720, 86));
    if (!you || !ctx || !join || !ask || !rep || !out) return;
    for (const [o, w, h] of [[you, 260, 150], [out, 300, 220], [ctx, 240, 130]] as Array<[string, number, number]>) {
      const m = this.pv(o); if (m) { m.w = w; m.h = h; }
    }
    this.present.label[this.pathOf(you)] = "you";
    this.present.label[this.pathOf(out)] = "it says";
    const om = this.pv(out); if (om) om.lens = "text";
    // context first, then what you typed — so the model reads the situation before the ask
    this.connect([ctx, "out"], [join, "a"]);
    this.connect([you, "out"], [join, "b"]);
    this.connect([join, "out"], [ask, "prompt"]);
    // ask's config names where the answer lands; reply's value IS the answer
    this.edit((g) => graph({ ...g.panes, [ask]: { ...g.panes[ask], config: rep } }, g.wires), "");
    this.connect([rep, "out"], [out, "x"]);
    if (target) {
      const t = this.resolve(target);
      if (t) this.edit((g) => graph({ ...g.panes, [ctx]: { ...g.panes[ctx], config: t } }, g.wires), "");
    }
    this.present.kind[this.pathOf(ctx)] = "context";
    this.focus = you; this.marked.clear();
    this.safeTick(); this.render();
    this.say(target
      ? `talking, scoped to ${this.nameOf(this.resolve(target)!)} — type in “you”, then run`
      : `talking, scoped to this view — type in “you”, then run. Point ${this.nameOf(ctx)} at a container to narrow it.`, "ok");
  }

  // ------------------------------------------------------------ authoring a leaf
  // The base gesture the whole thing exists for: a boundary you declare, powers you ask for,
  // and a body you write. Nothing consults a table.

  openAuthor(occ?: string): void {
    const target = occ ?? this.focus;
    if (!target) { this.say("focus a pane to give it a body", "no"); return; }
    this.authoring = target;
    const u = this.unitOf(target);
    const isLeaf = !!(u.body && u.body["@"] === "host/1");
    this.draft = {
      cls: (isLeaf ? u.cls : "pure") as Exclude<Cls, "container">,
      ports: u.ports.length
        ? u.ports.map((p) => [p.name, p.dir, p.shape] as [string, "in" | "out", string])
        : ([["a", "in", "num"], ["out", "out", "num"]] as Array<[string, "in" | "out", string]>),
      powers: [...u.powers],
      src: isLeaf && u.body && u.body["@"] === "host/1" ? u.body.src
        : "return (i, ctx) => ({ out: (i.a || 0) })",
    };
    this.el.author.classList.add("on");
    if (this.view.horizon < 0.5) { this.view.horizon = 0.62; this.layout(); }
    this.renderAuthor();
  }
  closeAuthor(): void {
    this.el.author.classList.remove("on"); this.authoring = null; this.el.omni.focus();
  }
  renderAuthor(): void {
    const d = this.draft; if (!d || !this.authoring) return;
    const occ = this.authoring;
    const POWERS = ["mem:r", "mem:w", "emit", "world"];
    const CLASSES: Array<[string, string]> = [
      ["pure", "computes from its inputs"],
      ["source", "where novelty enters"],
      ["delay", "remembers across ticks"],
      ["effect", "touches the world"],
    ];
    const SHAPES = ["num", "str", "bool", "list", "any"];
    this.el.authorBody.innerHTML = `
      <div class="ah"><span>give <b>${esc(this.nameOf(occ))}</b> a body</span>
        <span><button data-run="1">declare ⌘⏎</button><button data-close="1">close ⎋</button></span></div>
      <div class="acols">
        <div class="acol">
          <h4>class <em>the one thing the core cares about</em></h4>
          <div class="seg vert">${CLASSES.map(([c, why]) =>
            `<button data-cls="${c}" class="${d.cls === c ? "on" : ""}">${c}<small>${why}</small></button>`).join("")}</div>
          <h4>powers <em>asked for, never assumed</em></h4>
          <div class="chips">${POWERS.map((p) =>
            `<button data-pow="${p}" class="${d.powers.includes(p) ? "on" : ""}">${p}</button>`).join("")}</div>
          <div class="anote">A body receives only what is declared here. Ask for nothing and <code>ctx</code> has nothing on it.</div>
          <h4>boundary <em>any number, in or out</em></h4>
          <div class="ports">${d.ports.map((p, i) => `
            <div class="pedit">
              <input data-pi="${i}" data-f="name" value="${esc(p[0])}"/>
              <select data-pi="${i}" data-f="dir">
                <option value="in"${p[1] === "in" ? " selected" : ""}>in</option>
                <option value="out"${p[1] === "out" ? " selected" : ""}>out</option>
              </select>
              <select data-pi="${i}" data-f="shape">
                ${SHAPES.map((sh) => `<option${p[2] === sh ? " selected" : ""}>${sh}</option>`).join("")}
              </select>
              <button data-rm="${i}">✕</button>
            </div>`).join("")}</div>
          <button class="addport" data-addport="1">+ a port</button>
        </div>
        <div class="acol">
          <h4>body <em>javascript — its source is its identity</em></h4>
          <textarea id="a-src" spellcheck="false">${esc(d.src)}</textarea>
          <div class="anote">Return a function <code>(in, ctx) =&gt; ({ out: … })</code>, or an object
            <code>{ cook, read, write, act }</code>. A <b>delay</b> needs <code>read</code> and <code>write</code>;
            an <b>effect</b> needs <code>act</code>.</div>
          <div class="aerr" id="a-err"></div>
        </div>
      </div>`;
    this.el.authorBody.onclick = (ev) => {
      const b = (ev.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      if (b.dataset.close) return this.closeAuthor();
      if (b.dataset.run) return this.applyAuthor();
      if (b.dataset.cls) { d.cls = b.dataset.cls as Exclude<Cls, "container">; return this.renderAuthor(); }
      if (b.dataset.pow) {
        const p = b.dataset.pow;
        d.powers = d.powers.includes(p) ? d.powers.filter((x) => x !== p) : [...d.powers, p];
        return this.renderAuthor();
      }
      if (b.dataset.addport) { d.ports.push([`p${d.ports.length + 1}`, "in", "any"]); return this.renderAuthor(); }
      if (b.dataset.rm) { d.ports.splice(Number(b.dataset.rm), 1); return this.renderAuthor(); }
    };
    const sync = (e: Event) => {
      const t = e.target as HTMLInputElement | HTMLSelectElement;
      const i = Number(t.dataset.pi); if (Number.isNaN(i) || !d.ports[i]) return;
      const f = t.dataset.f;
      if (f === "name") d.ports[i][0] = t.value.replace(/[^A-Za-z0-9_.-]/g, "") || `p${i + 1}`;
      if (f === "dir") d.ports[i][1] = t.value as "in" | "out";
      if (f === "shape") d.ports[i][2] = t.value;
    };
    this.el.authorBody.oninput = sync;
    this.el.authorBody.onchange = sync;
    const src = this.el.authorBody.querySelector("#a-src") as HTMLTextAreaElement;
    src.addEventListener("input", () => { d.src = src.value; });
    src.addEventListener("keydown", (e: KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); this.applyAuthor(); }
      else if (e.key === "Escape") { e.preventDefault(); this.closeAuthor(); }
      else if (e.key === "Tab") {
        e.preventDefault();
        const a = src.selectionStart;
        src.value = src.value.slice(0, a) + "  " + src.value.slice(src.selectionEnd);
        src.selectionStart = src.selectionEnd = a + 2; d.src = src.value;
      }
    });
  }
  /** freeze it: a new unit, hashed over exactly what you wrote */
  applyAuthor(): void {
    const d = this.draft, occ = this.authoring; if (!d || !occ) return;
    const err = this.el.authorBody.querySelector("#a-err") as HTMLElement | null;
    const fail = (m: string) => { if (err) err.textContent = m; this.say(m, "no"); };
    const names = d.ports.map((p) => p[0]);
    if (!d.ports.length) return fail("declare at least one port");
    if (new Set(names).size !== names.length) return fail("two ports share a name");
    if (d.cls !== "effect" && !d.ports.some((p) => p[1] === "out"))
      return fail(`a ${d.cls} node needs at least one out port`);
    const u = leaf(d.cls, { "@": "host/1", lang: "js", src: d.src },
      d.ports.map(([nm, dir, sh]) => port(nm, dir, sh)), d.powers);
    try { (this.levels[0] as { engine: Engine }).engine.host.resolve(u.body!, u); }
    catch (e) { return fail((e as Error).message); }
    const id = this.store.putUnit(u);
    const needsMem = d.powers.some((p) => p.startsWith("mem:"));
    const ok = this.edit((g) => graph({
      ...g.panes,
      [occ]: { ...g.panes[occ], unit: id, mem: needsMem ? (g.panes[occ].mem ?? this.memFor(occ)) : g.panes[occ].mem },
    }, g.wires), `${this.nameOf(occ)} declared · ${d.cls} · ${d.ports.length} ports`);
    if (!ok) return;
    this.present.kind[this.pathOf(occ)] = d.cls === "source" ? "number" : "authored";
    this.present.mine[id] = { name: this.nameOf(occ), note: `${d.cls} · ${names.join(" ")}` };
    this.present.unitLabel[id] = this.present.label[this.pathOf(occ)] ?? this.kindOf(occ);
    if (err) err.textContent = "";
    this.closeAuthor(); this.safeTick(); this.render(); this.touch();
  }

  // ------------------------------------------------------------ library (in the sky)
  toggleLib(force?: boolean): void {
    const on = force ?? !this.el.lib.classList.contains("on");
    this.el.lib.classList.toggle("on", on);
    this.el.libBtn.classList.toggle("on", on);
    if (on && this.view.horizon < 0.45) { this.view.horizon = 0.58; this.layout(); this.render(); }
    if (on) this.renderLib(); else this.el.omni.focus();
  }
  renderLib(): void {
    const tab = this.libTab;
    const groups = [...new Set(STARTER.map((a) => a.group))];
    const mine = Object.entries(this.present.mine);
    const body =
      tab === "guide"
        ? `<div class="gguide">${GUIDE.map(([h, t]) =>
            `<div class="gitem"><h5>${esc(h)}</h5><p>${esc(t)}</p></div>`).join("")}</div>`
        : tab === "mine"
          ? (mine.length
            ? `<div class="lgrid">${mine.map(([id, m]) =>
                `<button class="lcard" data-mine="${esc(id)}"><b>${esc(m.name)}</b><small>${esc(m.note)}</small></button>`).join("")}</div>`
            : `<div class="anote">Nothing yet. Box out a pane, press <b>author</b>, write a body — it lands here and it is yours.</div>`)
          : groups.map((g) => `<h4>${esc(g)}</h4><div class="lgrid">${
              STARTER.filter((a) => a.group === g).map((a) =>
                `<button class="lcard" data-add="${esc(a.id)}"><b>${esc(a.name)}</b><small>${esc(a.cls)} · ${a.ports.filter((p) => p[1] === "in").length} in</small><span class="lnote">${esc(a.note)}</span></button>`).join("")
            }</div>`).join("");
    this.el.libBody.innerHTML = `
      <div class="ah"><span>LIBRARY</span>
        <span>
          <button data-tab="starter" class="${tab === "starter" ? "on" : ""}">presets</button>
          <button data-tab="mine" class="${tab === "mine" ? "on" : ""}">mine</button>
          <button data-tab="guide" class="${tab === "guide" ? "on" : ""}">guide</button>
          <button data-close="1">close ⎋</button>
        </span></div>
      <div class="anote" style="margin:0 0 12px">Everything here is an ordinary authored unit — a class, a boundary, declared powers, a body. Click one to place it; open it afterwards to read or rewrite the source. None of it is in the core.</div>
      ${body}`;
    this.el.libBody.onclick = (ev) => {
      const b = (ev.target as HTMLElement).closest("button") as HTMLElement | null; if (!b) return;
      if (b.dataset.close) return this.toggleLib(false);
      if (b.dataset.tab) { this.libTab = b.dataset.tab as "starter" | "mine" | "guide"; return this.renderLib(); }
      if (b.dataset.add) {
        const a = STARTER.find((x) => x.id === b.dataset.add); if (!a) return;
        this.toggleLib(false);
        const o = this.fromLibrary(a);
        if (o && (a.id === "number" || a.id === "text")) this.startEdit(o);
        return;
      }
      if (b.dataset.mine) {
        this.toggleLib(false);
        const o = this.addPane(b.dataset.mine, "authored");
        if (o) { this.safeTick(); this.render(); }
      }
    };
  }

  // ------------------------------------------------------------ inspector — the manifest
  // Three groups, and the grouping is the lesson: what cannot change (identity is content),
  // what moves the hash, and what is only a way of looking. A prim's ports are fixed because
  // its boundary *is* its op; a prior's ports are whatever crosses it, so you change them by
  // going inside.
  toggleInsp(force?: boolean): void {
    const on = force ?? !this.el.insp.classList.contains("on");
    this.el.insp.classList.toggle("on", on);
    this.el.inspBtn.classList.toggle("on", on);
    if (on) this.renderInsp(); else this.el.omni.focus();
  }
  renderInsp(): void {
    if (!this.el.insp.classList.contains("on")) return;
    const occ = this.focus;
    if (!occ || !this.graph.panes[occ]) {
      this.el.inspBody.innerHTML = `<div class="ih"><div class="t">nothing focused</div>
        <button data-close="1">close</button></div>
        <div class="sec"><div class="note">Click a pane, or move with the arrow keys. The inspector always shows what has focus.</div></div>`;
      this.bindInsp(); return;
    }
    const u = this.unitOf(occ), p = this.graph.panes[occ], m = this.pv(occ);
    const path = this.pathOf(occ), kind = this.kindOf(occ);
    const [th, ts] = toneOf(p.unit);
    const isPrim = !!(u.body && u.body["@"] === "host/1");
    const inside = u.graph ? Object.keys(u.graph.panes).length : 0;

    const portRow = (name: string, dir: "in" | "out", shape: string) => {
      if (dir === "out") {
        const outs = this.graph.wires.filter((w) => w.from[0] === occ && w.from[1] === name);
        return `<div class="prow out" data-from="${esc(name)}"><span class="pn">${esc(name)}</span>
          <span class="ps">${esc(shape)}</span>
          <span class="pw ${outs.length ? "on" : "off"}">${outs.length ? "→ " + esc(outs.map((w) => this.nameOf(w.to[0])).join(", ")) : "—"}</span></div>`;
      }
      const w = this.wireInto(occ, name);
      return `<div class="prow" data-to="${esc(name)}" title="click to route something in"><span class="pn">${esc(name)}</span>
        <span class="ps">${esc(shape)}</span>
        <span class="pw ${w ? "on" : "off"}">${w ? esc(this.nameOf(w.from[0])) + " →" : "absent"}</span></div>`;
    };

    this.el.inspBody.innerHTML = `
      <div class="ih" style="--tone:${th};--tone-s:${ts}%">
        <div class="t"><span class="tag">${esc(occ)}</span><span>${esc(this.present.label[path] ?? kind)}</span></div>
        <button data-close="1">close ⎋</button>
      </div>

      <div class="sec fix"><h4>identity <em>fixed — content is the name</em></h4>
        <div class="kv"><span>${this.isDraftPane(occ) ? "state" : "unit"}</span><code${this.isDraftPane(occ) ? ' style="color:#a5b4fc"' : ""} title="${esc(p.unit)}">${this.isDraftPane(occ) ? "draft — no identity yet" : esc(p.unit.slice(5, 17)) + "…"}</code></div>
        <div class="kv"><span>class</span><code>${esc(u.cls)}</code></div>
        <div class="kv"><span>body</span><code>${isPrim ? `js · ${(u.body as { src: string }).src.length} chars` : (u.graph ? `graph · ${inside} inside` : "empty")}</code></div>
        <div class="kv"><span>powers</span><code>${u.powers.join(" ") || "none"}</code></div>
      </div>

      <div class="sec fix"><h4>ports <em>${isPrim ? "declared by whoever wrote it" : "whatever crosses the boundary"}</em></h4>
        ${inPorts(u).map((x) => portRow(x.name, "in", x.shape)).join("") || `<div class="note">no inputs</div>`}
        ${outPorts(u).map((x) => portRow(x.name, "out", x.shape)).join("")}
        <div class="note">${isPrim
          ? "Someone wrote this boundary — open the body and change it. There is no arity limit anywhere; a port list is just a list."
          : (inside ? "A group. Go inside and rewire: its boundary is exactly what crosses it." : "Empty. Give it a body, or go inside and build one.")}</div>
      </div>

      <div class="sec content"><h4>content <em>moves the hash</em></h4>
        ${this.typedAs(occ)
          ? `<div class="kv"><span>value</span><code>${esc(short(this.srcValues[path]))}</code></div>
             <div class="note">A source's value is journalled each tick — edit it on the pane.</div>`
          : ""}
        <label class="kv" style="display:block;border:none"><span>config</span>
          <input class="f" id="i-cfg" value="${esc(JSON.stringify(p.config ?? null))}"/></label>
        <div class="kv"><span>pinned <em style="color:var(--ink4);font-style:normal">alive though unwatched</em></span>
          <div class="sw${p.pinned ? " on" : ""}" data-pin="1"></div></div>
        ${p.mem ? `<div class="kv"><span>memory</span><code>${esc(p.mem)}</code></div>` : ""}
      </div>

      <div class="sec gauge"><h4>presentation <em>gauge — no hash change</em></h4>
        <label class="kv" style="display:block;border:none"><span>name</span>
          <input class="f" id="i-name" value="${esc(this.present.label[path] ?? "")}" placeholder="${esc(occ)}"/></label>
        <div class="kv"><span>lens</span><code>${esc(m?.lens ?? "auto")}</code></div>
        <div class="kv"><span>size</span><code>${m ? `${Math.round(m.w)} × ${Math.round(m.h)}` : "—"}</code></div>
        <div class="kv"><span>zone</span><code>${m?.zone ?? "—"}</code></div>
      </div>

      <div class="act">
        ${this.isDraftPane(occ) ? `<button data-act="declare">declare it</button>` : ""}
        <button data-act="author">${isPrim ? "edit the body" : "give it a body"}</button>
        ${u.cls === "container" && inside ? `<button data-act="look">look through</button>` : ""}
        ${u.cls === "container" ? `<button data-act="descend">go inside</button>` : ""}
        <button data-act="route">route from…</button>
        <button data-act="wrap">wrap</button>
        <button data-act="fold">${m?.folded ? "unfold" : "fold"}</button>
        <button data-act="del">delete</button>
      </div>`;
    this.bindInsp();
  }
  bindInsp(): void {
    const body = this.el.inspBody;
    body.onclick = (ev) => {
      const t = ev.target as HTMLElement;
      if (t.closest("[data-close]")) return this.toggleInsp(false);
      const occ = this.focus; if (!occ) return;
      const nm = this.nameOf(occ);
      if (t.closest("[data-pin]")) return this.pin([nm]);
      const to = (t.closest("[data-to]") as HTMLElement | null)?.dataset.to;
      if (to) {
        if (this.marked.size === 1 && !this.marked.has(occ)) {
          const src = this.endpoint([...this.marked][0], "out");
          if (src) return void this.connect(src, [occ, to]);
        }
        this.el.omni.focus(); this.el.omni.value = ` > ${nm}.${to}`;
        this.el.omni.setSelectionRange(0, 0);
        return this.say(`name a source, then enter — “… > ${nm}.${to}”`, "wait");
      }
      const act = (t.closest("[data-act]") as HTMLElement | null)?.dataset.act;
      switch (act) {
        case "author": return this.openAuthor(occ);
        case "declare": return this.declareChip([nm]);
        case "look": return this.look([nm]);
        case "descend": return this.descend(nm);
        case "route": this.routeFrom = occ; this.render(); return this.echo(`click a target for ${nm}`);
        case "wrap": return this.wrap([nm]);
        case "fold": return this.fold([nm]);
        case "del": return this.del([nm]);
      }
    };
    const cfg = body.querySelector("#i-cfg") as HTMLInputElement | null;
    cfg?.addEventListener("change", () => {
      const occ = this.focus; if (!occ) return;
      let v: Value;
      try { v = JSON.parse(cfg.value) as Value; } catch { return this.say("config must be JSON", "no"); }
      this.edit((g) => graph({ ...g.panes, [occ]: { ...g.panes[occ], config: v } }, g.wires), `${this.nameOf(occ)} config`);
    });
    const nm = body.querySelector("#i-name") as HTMLInputElement | null;
    nm?.addEventListener("change", () => {
      const occ = this.focus; if (!occ) return;
      if (nm.value.trim()) this.rename(occ, nm.value.trim());
      else { delete this.present.label[this.pathOf(occ)]; this.render(); }
    });
    for (const el of [cfg, nm]) el?.addEventListener("keydown", (e) => e.stopPropagation());
  }

  // ------------------------------------------------------------ options (in the sky)
  toggleOptions(force?: boolean): void {
    const on = force ?? !this.el.options.classList.contains("on");
    this.el.options.classList.toggle("on", on);
    this.el.gear.classList.toggle("on", on);
    if (on && this.view.horizon < 0.4) { this.view.horizon = 0.52; this.layout(); this.render(); }
    if (on) this.renderOptions(); else this.el.omni.focus();
  }
  renderOptions(): void {
    const o = this.present.opts;
    const sw = (k: string, on: boolean) => `<div class="sw${on ? " on" : ""}" data-opt="${k}"></div>`;
    const seg = (k: string, cur: string, vals: string[]) =>
      `<div class="seg">${vals.map((v) => `<button data-seg="${k}" data-v="${v}" class="${v === cur ? "on" : ""}">${v}</button>`).join("")}</div>`;
    this.el.optionsBody.innerHTML = `
      <h2>OPTIONS <button data-close="1">close ⎋</button></h2>
      <div class="grp"><h3>the omnibar</h3>
        <div class="opt"><div>suggest as I type<small>completions for verbs and pane names</small></div>${sw("suggest", o.suggest)}</div>
      </div>
      <div class="grp"><h3>talking</h3>
        <div class="opt"><div>model key<small>kept by this browser. It never enters a unit, a config, a hash or a saved workspace.</small></div>
          <input class="f" id="o-key" type="password" style="max-width:230px" value="${esc(o.apiKey)}" placeholder="sk-ant-…"/></div>
        <div class="opt"><div>model<small>which one answers</small></div>
          <input class="f" id="o-model" style="max-width:230px" value="${esc(o.model)}"/></div>
        <div class="opt"><div>endpoint<small>anything that speaks the same shape</small></div>
          <input class="f" id="o-url" style="max-width:230px" value="${esc(o.apiUrl)}"/></div>
      </div>
      <div class="grp"><h3>the environment</h3>
        <div class="opt"><div>background<small>painted, not shipped — each band fades through its complement</small></div>${seg("bg", o.bg, BGS.map((x) => x.id))}</div>
      </div>
      <div class="grp"><h3>the surface</h3>
        <div class="opt"><div>snap while dragging<small>free placement is the default</small></div>${sw("snap", o.snap)}</div>
        <div class="opt"><div>let idle panes recede<small>weight follows liveness — position never moves</small></div>${sw("recede", o.recede)}</div>
        <div class="opt"><div>motion<small>pulses when a pane recomputes</small></div>${sw("motion", o.motion)}</div>
      </div>
      <div class="grp"><h3>mechanism</h3>
        <div class="opt"><div>show the graph hash<small>the observable that stays still when you rearrange</small></div>${seg("hash", o.hash, ["never", "systems", "always"])}</div>
        <div class="opt"><div>tick rate<small>ms between ticks while running</small></div>${seg("rate", String(o.rate), ["80", "200", "500", "1000"])}</div>
      </div>
      <div class="grp"><h3>views</h3>
        <div class="opt"><div>opens by default<small>which view you land in</small></div>${seg("home", this.present.home, this.present.order)}</div>
        <div class="opt"><div>this view shows every pane<small>systems-style — nothing is hidden</small></div>${sw("showsAll", this.view.showsAll)}</div>
        <div class="opt"><div>generous lenses here<small>prefer big renderings in this view</small></div>${sw("rich", this.view.rich)}</div>
      </div>`;
    for (const [id, k] of [["o-key", "apiKey"], ["o-model", "model"], ["o-url", "apiUrl"]] as Array<[string, keyof Options]>) {
      const el = this.el.optionsBody.querySelector(`#${id}`) as HTMLInputElement | null;
      el?.addEventListener("keydown", (e) => e.stopPropagation());
      el?.addEventListener("change", () => {
        (o as unknown as Record<string, string>)[k as string] = el.value.trim();
        this.touch(); this.say(k === "apiKey" ? "key kept by this browser only" : `${String(k)} set`, "ok");
      });
    }
    this.el.optionsBody.onclick = (ev) => {
      const t = ev.target as HTMLElement;
      if (t.dataset.close) return this.toggleOptions(false);
      const s = t.closest("[data-opt]") as HTMLElement | null;
      if (s) {
        const k = s.dataset.opt!;
        if (k === "showsAll") this.view.showsAll = !this.view.showsAll;
        else if (k === "rich") this.view.rich = !this.view.rich;
        else (o as unknown as Record<string, boolean>)[k] = !(o as unknown as Record<string, boolean>)[k];
        this.tick(); this.renderOptions(); this.render(); return;
      }
      const g = t.closest("[data-seg]") as HTMLElement | null;
      if (g) {
        const k = g.dataset.seg!, v = g.dataset.v!;
        if (k === "hash") o.hash = v as Options["hash"];
        else if (k === "rate") o.rate = Number(v);
        else if (k === "home") this.present.home = v;
        else if (k === "bg") { o.bg = v; this.bgKey = ""; this.paintBg(); }
        this.renderOptions(); this.render(); this.touch();
      }
    };
  }

  // ------------------------------------------------------------ chrome
  startClock(): void {
    const t = () => {
      this.el.clock.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setTimeout(t, 1000);
    }; t();
  }
  /** Repaint the environment. With the sky folded away it paints a WALL — no horizon at all,
   *  which is the point: folding the sky should remove the feeling, not just the line. */
  private bgKey = "";
  paintBg(): void {
    const wall = this.view.horizon <= 0.02;
    const key = `${this.present.opts.bg}|${wall}|${window.innerWidth}x${window.innerHeight}`;
    if (key === this.bgKey) return;
    this.bgKey = key;
    const url = paint(bgById(this.present.opts.bg), window.innerWidth, window.innerHeight, wall);
    (document.getElementById("bg") as HTMLElement).style.backgroundImage = `url(${url})`;
    this.el.horizon.classList.toggle("gone", wall);
  }
  buildHelp(): void {
    this.el.helpCard.innerHTML = `
      <h2>EIDOLA</h2>
      <div style="color:var(--ink3);line-height:1.6;margin-bottom:4px">One graph, many views. Panes are named from what they are — <code style="color:var(--amber)">num1</code>, <code style="color:var(--amber)">clock1</code> — and you can rename them. Moving, folding, renaming and switching views change nothing real: the hash stays still. A coloured message means the world changed; grey means only the description did.</div>
      <h3>by hand</h3>
      <div class="row"><code>double-click</code>add something right there</div>
      <div class="row"><code>drag a pane</code>move it — free placement, nothing snaps</div>
      <div class="row"><code>drop onto a pane</code>connect them</div>
      <div class="row"><code>drag on empty space</code>box-select — or, over nothing, a box <em>is a size</em>: pick what fills it</div>
      <div class="row"><code>⌘/ctrl + wheel</code>zoom · <code style="color:var(--amber)">shift + wheel</code> sideways · the ground never ends</div>
      <div class="row"><code>right-click</code>everything you can do to what's marked</div>
      <div class="row"><code>click a value</code>edit a number or text in place</div>
      <div class="row"><code>drag the horizon</code>resize the sky · fold it away</div>
      <div class="row"><code>paste</code>url → fetch · number → num · else text</div>
      <h3>by typing</h3>
      <div class="row"><code>num 42 · text hi · clock</code>bring something in</div>
      <div class="row"><code>fetch example.com</code>fetch a url</div>
      <div class="row"><code>add num1 num2</code>an op, already wired</div>
      <div class="row"><code>add</code>…or wired from whatever is marked</div>
      <div class="row"><code>num1 &gt; add1</code>route into the first free port</div>
      <div class="row"><code>num1 &gt; add1.b</code>route into a named port — replaces what was there</div>
      <div class="row"><code>num1 x add1</code>break it</div>
      <div class="row"><code>ports add1</code>what it takes and gives</div>
      <div class="row"><code>inspect</code>the manifest: identity · content · presentation</div>
      <div class="row"><code>wrap</code>make the marked panes one prior</div>
      <div class="row"><code>name num1 revenue</code>rename — then use the name anywhere</div>
      <div class="row"><code>grid · sky · ground · fold · pin</code>on what's marked</div>
      <div class="row"><code>view media · view new notes</code>switch or make a view</div>
      <div class="row"><code>view home</code>make this the view that opens</div>
      <div class="row"><code>tour</code>a view that shows what this can do — <code style="color:var(--amber)">undo</code> takes it away</div>
      <div class="row"><code>note some words</code>a caption in this view — gauge, never in the graph · <code style="color:var(--amber)">note clear</code></div>
      <h3>keys</h3>
      <div class="row"><code>↑ ↓ ← →</code>move focus · <code>Tab</code> descend · <code>Esc</code> back out</div>
      <div class="row"><code>⌘Z / ⌘⇧Z</code>undo · redo</div>
      <div class="row"><code>just start typing</code>the omnibar takes it</div>
      <div style="color:var(--ink4);margin-top:18px;font-size:11px">click anywhere to close</div>`;
  }

  // ------------------------------------------------------------ persistence
  // The two halves stay separate (Law 8): content is a WORKSPACE/1 dump, presentation is its
  // own block. Throw the second away and you lose an arrangement, never a fact.
  /**
   * The root as it would be if every level you are inside came up now — drafts staying drafts.
   * Saving (and dumping) uses this, so a reload while you are inside a draft keeps what you
   * did there instead of the version from before you went in. A level you entered and did
   * not change saves as what it was.
   */
  saveTickets: string[] = [];
  rootForSave(): Graph {
    const root = (this.levels[0] as { engine: Engine }).engine.root;
    let child: { occ: string; unit: string } | null = null;
    for (let i = this.levels.length - 1; i >= 1; i--) {
      const l = this.levels[i] as { occ: string; lim: Liminal };
      let g = l.lim.graph;
      if (child) g = graph({ ...g.panes, [child.occ]: { ...g.panes[child.occ], unit: child.unit } }, g.wires);
      const u = container(l.lim.ports, g);
      const was = l.lim.meltedFrom;
      let id: string;
      if (was && unitId(u) === unitId(this.store.unit(was))) id = was;
      else {
        const t = this.saveTickets[i];
        if (t && this.store.draftIds().includes(t)) { this.store.setDraft(t, u); id = t; }
        else id = this.saveTickets[i] = this.store.putDraft(u);
      }
      child = { occ: l.occ, unit: id };
    }
    if (!child) return root;
    const c = child;
    return graph({ ...root.panes, [c.occ]: { ...root.panes[c.occ], unit: c.unit } }, root.wires);
  }

  session(): unknown {
    const l = this.levels[0] as { kind: "root"; engine: Engine };
    return {
      "@": "eidola/1",
      workspace: dumpWorkspace(this.store, this.rootForSave()),
      // the key is host state: it is stripped from anything that can leave this browser
      present: { ...this.present, opts: { ...this.present.opts, apiKey: "" } },
      secrets: { apiKey: this.present.opts.apiKey },
      inputs: Object.fromEntries(Object.entries(this.srcValues).map(([k, v]) => [k, toSpec(v)])),
      lineage: Object.fromEntries(this.store.lineage),
      // memory is history, not content — but without it a reload is not a replay: a running
      // total of 6 came back as 1. The logs travel beside the workspace, as the journal does.
      memory: Object.fromEntries(this.store.persist.memAddrs().map((a) =>
        [a, this.store.persist.readMem(a).map((id) => toSpec(this.store.blob(id)))])),
      clock: this.clockT,
      tick: l.engine.tickIndex,
    };
  }
  save(): void {
    try { localStorage.setItem("eidola/session", JSON.stringify(this.session())); }
    catch { /* private mode, or quota */ }
  }
  /** debounced — every edit saves, without writing on every keystroke */
  private saveT = 0;
  touch(): void {
    clearTimeout(this.saveT);
    this.saveT = setTimeout(() => this.save(), 400) as unknown as number;
  }
  restore(s: {
    workspace: WorkspaceSpec; present: Present;
    inputs?: Record<string, unknown>; lineage?: Record<string, string>;
  }): void {
    const store = new Store(new MemoryPersistence());
    const { root, unitIds } = loadWorkspace(s.workspace, store);
    for (const [c, p] of Object.entries(s.lineage ?? {})) store.lineage.set(c, p);
    this.store = store;
    this.levels = [{ kind: "root", engine: new Engine(store, root, undefined, ROOM_HOST) }];
    const base = emptyPresent();
    this.present = { ...base, ...s.present, opts: { ...base.opts, ...(s.present?.opts ?? {}) } };
    // A draft's id is a local ticket and loading hands out new ones. Content ids are stable;
    // ticket-keyed names follow their draft, and names of drafts that no longer exist go.
    const rekey = <T>(rec: Record<string, T> | undefined): Record<string, T> => {
      const outR: Record<string, T> = {};
      for (const [k, v] of Object.entries(rec ?? {})) {
        if (!Store.isDraft(k)) outR[k] = v;
        else if (unitIds[k]) outR[unitIds[k]] = v;
      }
      return outR;
    };
    this.present.unitLabel = rekey(this.present.unitLabel);
    this.present.mine = rekey(this.present.mine);
    // a session written before a field existed must still open
    for (const v of Object.values(this.present.views)) {
      if (typeof v.zoom !== "number" || !Number.isFinite(v.zoom)) v.zoom = 1;
      if (typeof v.horizon !== "number") v.horizon = 0.34;
    }
    this.srcValues = Object.fromEntries(
      Object.entries(s.inputs ?? {}).map(([k, v]) => [k, fromSpec(v as never)]));
    const sec = (s as unknown as { secrets?: { apiKey?: string } }).secrets;
    if (sec?.apiKey) this.present.opts.apiKey = sec.apiKey;
    const more = s as unknown as { memory?: Record<string, unknown[]>; clock?: number; tick?: number };
    for (const [addr, vs] of Object.entries(more.memory ?? {}))
      for (const v of vs) store.persist.appendMem(addr, store.putBlob(fromSpec(v as never)));
    this.clockT = typeof more.clock === "number" ? more.clock : 0;
    if (typeof more.tick === "number") (this.levels[0] as { engine: Engine }).engine.tickIndex = more.tick;
    this.focus = null; this.marked.clear();
  }
  load(): void {
    let raw: string | null = null;
    try { raw = localStorage.getItem("eidola/session"); } catch { /* ignore */ }
    if (raw) {
      try {
        const s = JSON.parse(raw);
        if (s && s["@"] === "eidola/1") {
          this.restore(s);
          // the first tick of a reloaded room only finds out where things stand: an ask whose
          // prompt was already asked before the reload must not be asked (and paid for) again
          this.assembling = true;
          try { this.tick(); } catch (e) {
            // a stored body that throws must not lock you out of your own room
            setTimeout(() => this.say(`a stored body threw: ${(e as Error).message}`, "no"), 60);
          } finally { this.assembling = false; }
          if (!this.present.views[this.present.active]) this.present.active = this.present.home;
          if (!this.present.views[this.present.active]) this.present.active = "free";
          return;
        }
        // Something else is stored under this key — the workstation used to share it and
        // writes session/1. Never let the next autosave silently overwrite it: keep a copy
        // aside, and open its content (any head loads any workspace; its layout stays behind).
        try { localStorage.setItem("eidola/session.other", raw); } catch { /* quota */ }
        if (s && s.workspace && s.workspace["@"] === "workspace/1") {
          this.restore({ workspace: s.workspace, present: emptyPresent(), inputs: s.inputs, lineage: s.lineage });
          this.present.active = "systems";
          try { this.tick(); } catch { /* shown on first render */ }
          setTimeout(() => this.say("opened a workspace saved by another head — its layout stayed with it (copy kept as eidola/session.other)", "ok"), 60);
          return;
        }
      } catch { /* fall through to a fresh room */ }
    }
    this.seed();
  }
  reset(): void {
    try { localStorage.removeItem("eidola/session"); } catch { /* */ }
    this.store = new Store(new MemoryPersistence());
    this.present = emptyPresent(); this.srcValues = {}; this.fetchStatus = {};
    this.focus = null; this.marked.clear(); this.undoStack = []; this.redoStack = [];
    this.undoBase = null; this.graveyard.clear(); this.clockT = 0;
    this.levels = [{ kind: "root", engine: new Engine(this.store, graph({}, []), undefined, ROOM_HOST) }];
    this.seed(); this.tick(); this.paintBg(); this.layout(); this.render();
  }
  /** open empty. The base state of this thing is an empty room, not a demo. */
  seed(): void {
    this.levels = [{ kind: "root", engine: new Engine(this.store, graph({}, []), undefined, ROOM_HOST) }];
  }
}

/** roughly how tall a caption draws — only used to keep new things from landing on one */
function noteHeight(n: Note): number {
  const chars = (n.title ? n.title.length + 2 : 0) + n.text.length;
  return 12 + Math.ceil((chars * 6.6) / Math.max(120, n.w)) * 18;
}

// ------------------------------------------------------------------ lenses
function renderLens(id: string, v: Value): string {
  if (id === "big") return `<div class="val-big">${esc(typeof v === "string" ? v : short(v))}</div>`;
  if (id === "num" && typeof v === "number") return `<div class="val-num">${esc(short(v))}</div>`;
  if (id === "bool") return `<div class="val-bool ${v === true ? "t" : "f"}">${v === true ? "● true" : "○ false"}</div>`;
  if (id === "text") return `<div class="val-str">${esc(typeof v === "string" ? v : short(v))}</div>`;
  if (id === "json") return `<div class="val-str">${esc(jsonish(v))}</div>`;
  if (id === "bar" && typeof v === "number") {
    const p = Math.max(0, Math.min(100, ((v % 100) + 100) % 100));
    return `<div class="val-num">${esc(short(v))}</div><div class="bar"><span style="width:${p}%"></span></div>`;
  }
  if (typeof v === "number") return `<div class="val-num">${esc(short(v))}</div>`;
  if (typeof v === "boolean") return `<div class="val-bool ${v ? "t" : "f"}">${v ? "● true" : "○ false"}</div>`;
  if (typeof v === "string") return `<div class="val-str">${esc(v)}</div>`;
  return `<div class="val-str">${esc(short(v))}</div>`;
}
function jsonish(v: Value): string {
  try { return JSON.stringify(v, (_k, x) => (x instanceof Uint8Array ? `0x${[...x].map((b) => b.toString(16)).join("")}` : x), 2); }
  catch { return short(v); }
}
function esc(s: unknown): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

declare global { interface Window { eidola: Eidola } }
window.eidola = new Eidola();
