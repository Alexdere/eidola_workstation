// Lenses — a value goes UP to pixels. Nothing goes back down this way.
//
// A lens is a fold, not a door: rendering needs no `pinned` pairing precisely because it
// cannot act. Which is why the renderer registry is suite-level and the kernel has never
// heard of it.

import { Value, isMap } from "../../core/src/index.js";

export type Lens = (v: Value) => string;

const fmtNum = (n: number): string => {
  if (Number.isNaN(n)) return "NaN";
  if (n === Infinity) return "∞";
  if (n === -Infinity) return "−∞";
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return String(n);
  return String(Number(n.toPrecision(8)));
};

export function short(v: Value | undefined, depth = 0): string {
  if (v === undefined) return "—";
  if (v === null) return "∅";
  if (typeof v === "boolean") return v ? "true" : "false";
  if (typeof v === "number") return fmtNum(v);
  if (typeof v === "string") return depth === 0 ? `“${v}”` : JSON.stringify(v);
  if (v instanceof Uint8Array)
    return `0x${[...v.slice(0, 6)].map((b) => b.toString(16).padStart(2, "0")).join("")}${v.length > 6 ? "…" : ""}`;
  if (Array.isArray(v)) {
    if (depth > 1) return `[${v.length}]`;
    const inner = v.slice(0, 4).map((x) => short(x, depth + 1)).join(", ");
    return `[${inner}${v.length > 4 ? ", …" : ""}]`;
  }
  if (isMap(v)) {
    const keys = Object.keys(v);
    if (depth > 1) return `{${keys.length}}`;
    return `{${keys.slice(0, 3).map((k) => `${k}: ${short(v[k], depth + 1)}`).join(", ")}${keys.length > 3 ? ", …" : ""}}`;
  }
  return "?";
}

/** shape -> a css class, so a port dot tells you what it carries before you drag it */
export const shapeClass: Record<string, string> = {
  num: "sh-num", bool: "sh-bool", str: "sh-str", list: "sh-list",
  any: "sh-any", trigger: "sh-trigger",
};
