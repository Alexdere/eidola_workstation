// The host this room runs bodies with: the core's default host, plus one courtesy.
//
// Bodies written before 2026-10-14 named their memory folds (`ctx.memFold('sum', 0)`). The
// kernel no longer knows any fold by name — "sum" is arithmetic, and arithmetic is library
// business. A body's source text is its identity, so old bodies are not rewritten; instead this
// host reads the three old names on their behalf. The vocabulary stays with the library
// (LEGACY_FOLDS in library.ts). The kernel sees only step functions.

import { Body, Ctx, ExecutionPort, LeafDef, Unit, defaultHost } from "../../core/src/index.js";
import { LEGACY_FOLDS } from "./library.js";

function legacyCtx(ctx: Ctx): Ctx {
  return {
    config: ctx.config,
    memFold: (step, init) => {
      if (typeof step !== "string") return ctx.memFold(step, init);
      const L = LEGACY_FOLDS[step as string];
      if (!L) throw new Error(`no fold called “${step as string}” — memFold takes a step function (acc, entry) => acc`);
      return ctx.memFold(L.step, L.init(init));
    },
    memAppend: (v) => ctx.memAppend(v),
    journal: () => ctx.journal(),
    world: (v) => ctx.world(v),
  };
}

export class RoomHost implements ExecutionPort {
  readonly kind = "room";
  private inner = defaultHost();
  private wrapped = new Map<LeafDef, LeafDef>();

  resolve(body: Body, unit: Unit): LeafDef {
    const d = this.inner.resolve(body, unit);
    const hit = this.wrapped.get(d);
    if (hit) return hit;
    const w: LeafDef = {};
    if (d.cook) w.cook = (i, ctx) => d.cook!(i, legacyCtx(ctx));
    if (d.read) w.read = (ctx) => d.read!(legacyCtx(ctx));
    if (d.write) w.write = (i, ctx) => d.write!(i, legacyCtx(ctx));
    if (d.act) w.act = (i, ctx) => d.act!(i, legacyCtx(ctx));
    this.wrapped.set(d, w);
    return w;
  }
}

/** one host for the whole room, so every level runs every body the same way */
export const ROOM_HOST = new RoomHost();
