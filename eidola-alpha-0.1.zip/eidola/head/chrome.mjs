// Where Chromium is, for every script that drives a page. On a normal machine Playwright finds
// its own browser after `npx playwright install chromium`. A sandbox with a preinstalled build
// can point at it with PW_CHROME; the usual sandbox path is tried as well.
import { existsSync } from "node:fs";

const candidates = [process.env.PW_CHROME, "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"].filter(Boolean);
const found = candidates.find((p) => existsSync(p));
export const launchOpts = found ? { executablePath: found } : {};
