import { chromium } from 'playwright';
import { launchOpts } from "./chrome.mjs";
import { pathToFileURL } from 'node:url'; import { join } from 'node:path';
const b = await chromium.launch(launchOpts);
const page = await b.newPage({viewport:{width:1440,height:920}});
const errs=[]; page.on('pageerror',e=>errs.push(e.message)); page.on('console',m=>{if(m.type()==='error')errs.push('C:'+m.text());});
const ok=(n,c)=>console.log((c?'  ok  ':'  XX  ')+n);
await page.goto(pathToFileURL(join(process.cwd(),'dist/eidola-base.html')).href);
await page.evaluate(()=>localStorage.clear()); await page.reload(); await page.waitForTimeout(450);
const omni=page.locator('#omni');
const cmd=async c=>{await omni.fill(c);await omni.press('Enter');await page.waitForTimeout(170);};
const ports=o=>page.evaluate(x=>{const u=window.eidola.unitOf(x);return u.ports.map(p=>p.name+':'+p.dir);},o);
const bd=o=>page.$eval(`[data-occ="${o}"] .bd`,e=>e.textContent.trim()).catch(()=>null);

// ---- build TWO containers
const tagsNow = async()=>page.$$eval('.pane .tag',e=>e.map(x=>x.textContent));
await cmd('num 20'); await cmd('num 22');
let t0 = await tagsNow();
await cmd(`add ${t0[0]} ${t0[1]}`);
t0 = await tagsNow();
await cmd(`wrap ${t0.join(' ')}`);
await page.waitForTimeout(250);
const g1 = (await tagsNow()).find(t=>/container/.test(t));
// second group: a number feeding a mul, wrapped together
const before = await tagsNow();
await cmd('num 3');
const numB = (await tagsNow()).find(t=>!before.includes(t));
await cmd(`mul ${numB}`);
const mulB = (await tagsNow()).find(t=>/^mul/.test(t));
await cmd(`wrap ${numB} ${mulB}`);
await page.waitForTimeout(250);
const g2 = (await tagsNow()).filter(t=>/container/.test(t)).find(t=>t!==g1);
ok('two containers built: '+g1+', '+g2, !!g1 && !!g2);
ok('a wrapped group starts with no ports (nothing crossed)', (await ports(g1)).length===0);

// ---- EXPOSE gives a container a boundary
await cmd(`expose ${g1} ${t0.find(t=>/^add/.test(t))} sum`.replace(/(add\d+)/,'$1.out'));
await page.waitForTimeout(220);
const p1 = await ports(g1);
ok(`${g1} now has a port: ${p1.join(' ')}`, p1.includes('sum:out'));
await cmd(`expose ${g2} ${mulB}.b factor`);
await cmd(`expose ${g2} ${mulB}.out product`);
await page.waitForTimeout(220);
const p2 = await ports(g2);
ok(`${g2} has in and out: ${p2.join(' ')}`, p2.includes('factor:in') && p2.includes('product:out'));

// ---- WIRE THE CONTAINERS TOGETHER
await cmd(`${g1}.sum > ${g2}.factor`);
await page.waitForTimeout(300);
const wired = await page.evaluate(([a,c])=>window.eidola.graph.wires
  .some(w=>w.from[0]===a&&w.to[0]===c), [g1,g2]);
ok('container → container wire exists', wired);
await cmd(`look ${g2}`); await page.waitForTimeout(300);
const insideVals = await page.$$eval('.sub .sval',e=>e.map(x=>x.textContent));
ok('the value flowed across the boundary: '+insideVals.join(','), insideVals.includes('126'));
await cmd(`look ${g1}`); await page.waitForTimeout(300);
const windows = await page.$$eval('.through',e=>e.length);
ok('both containers open as windows while wired ('+windows+')', windows===2);
await page.screenshot({path:'dist/z-wired.png'});

// ---- liminal must be unmistakable
await cmd('new'); await page.waitForTimeout(150);
const empt = (await page.$$eval('.pane .tag',e=>e.map(x=>x.textContent))).find(t=>/empty/.test(t));
await cmd(`into ${empt}`); await page.waitForTimeout(300);
const draftVisible = await page.$eval('#app',e=>e.classList.contains('liminal'));
const draftBar = await page.$eval('#draftbar',e=>e.textContent);
const hashTxt = await page.$eval('#hash',e=>e.textContent);
ok('liminal is unmistakable: "'+draftBar.trim().slice(0,50)+'…" / hash="'+hashTxt+'"',
   draftVisible && /draft/.test(draftBar) && /no identity/.test(hashTxt));
await page.screenshot({path:'dist/z-draft.png'});
await cmd('num 7'); await cmd('num 8'); await page.waitForTimeout(200);
await page.keyboard.press('Escape'); await page.waitForTimeout(450);
ok('declared and back out', !(await page.$eval('#app',e=>e.classList.contains('liminal'))));

// ---- work THROUGH the window
await cmd(`look ${empt}`); await page.waitForTimeout(400);
const dots = await page.$$eval(`[data-occ="${empt}"] .sdot`,e=>e.length);
ok('children expose port dots inside the window ('+dots+')', dots>=2);

// drag one child's out dot onto the other child's in port? both are sources (no in ports),
// so instead drag to the wall -> expose
const dot = await page.$(`[data-occ="${empt}"] .sdot.out`);
const db = await dot.boundingBox();
const pb = await page.$eval(`[data-occ="${empt}"]`, e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height};});
await page.mouse.move(db.x+4,db.y+4); await page.mouse.down();
await page.mouse.move(pb.x+pb.w-10, pb.y+13,{steps:12}); await page.mouse.up();
await page.waitForTimeout(400);
const pe = await ports(empt);
ok('dragging a port to the wall exposed it: '+pe.join(' '), pe.length>0);
const bports = await page.$$eval(`[data-occ="${empt}"] .bport`,e=>e.map(x=>x.textContent));
ok('the new boundary port is drawn on the window edge: '+bports.join(','), bports.length>0);
await page.screenshot({path:'dist/z-expose.png'});

console.log('\nerrors:',errs.length?errs:'none');
await b.close();
