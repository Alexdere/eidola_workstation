// alpha-0.1 claims: the fixes that came out of the formal pass (docs/5-foundations) and the
// metamorphic probe. Each one is a law the earlier build held only by accident of input order.

import { describe, expect, it } from "vitest";
import {
  Engine, FrameRegistry, MemoryPersistence, Store, WorkspaceSpec, conformanceFrames, loadWorkspace,
  serializeGraph,
} from "../src/index.js";

const ONE = { d: "3ff0000000000000" };   // 1.0
const TWO = { d: "4000000000000000" };   // 2.0

function sharedMemory(order: string[]): WorkspaceSpec {
  const panes: Record<string, any> = {
    one: { unit: "core.const", config: ONE },
    two: { unit: "core.const", config: TWO },
    wa: { unit: "core.delay", mem: "m", pinned: true },
    wb: { unit: "core.delay", mem: "m", pinned: true },
  };
  return {
    "@": "workspace/1",
    units: { "core.const": { prim: "core.const" }, "core.delay": { prim: "core.delay" } },
    root: {
      panes: Object.fromEntries(order.map((k) => [k, panes[k]])),
      wires: [[["one", "out"], ["wa", "x"]], [["two", "out"], ["wb", "x"]]],
    },
  } as WorkspaceSpec;
}

function run(ws: WorkspaceSpec, ticks: number) {
  const store = new Store(new MemoryPersistence());
  const { root } = loadWorkspace(ws, store);
  const e = new Engine(store, root);
  let last = "";
  for (let t = 0; t < ticks; t++) last = e.tick({}).sigmaHash;
  return { hash: serializeGraph(root), sigma: last };
}

describe("ADR-0003 · one hash, one sigma", () => {
  it("pane insertion order cannot change values, even through shared memory", () => {
    const a = run(sharedMemory(["one", "two", "wa", "wb"]), 3);
    const b = run(sharedMemory(["one", "two", "wb", "wa"]), 3);
    expect(a.hash).toEqual(b.hash);
    expect(a.sigma).toEqual(b.sigma);
  });
});

describe("ADR-0004 · rule 6 holds for wires alone", () => {
  it("a loop made only of container pass-throughs is refused", () => {
    const ws = {
      "@": "workspace/1",
      units: {
        pass: { container: { ports: [["i", "in", "any", null], ["o", "out", "any", null]],
                              graph: { panes: {}, wires: [[["@in", "i"], ["@out", "o"]]] } } },
      },
      root: { panes: { p: { unit: "pass" } }, wires: [[["p", "o"], ["p", "i"]]] },
    } as unknown as WorkspaceSpec;
    const store = new Store(new MemoryPersistence());
    const { root } = loadWorkspace(ws, store);
    expect(() => new Engine(store, root).tick({})).toThrow(/cycle without a delay/);
  });
});

describe("ADR-0005 · Law 7 by loop obligations", () => {
  const n = (v: unknown) => (typeof v === "number" ? v : NaN);
  const reg = (ids: string[], fixtures = [0, 100]) => {
    const r = new FrameRegistry();
    for (const id of ids) r.addFrame({ id, tol: 1e-9, fixtures });
    return r;
  };

  it("the conformance atlas passes both checks", () => {
    expect(conformanceFrames().checkLoops()).toEqual([]);
    expect(conformanceFrames().checkRouteAgreement()).toEqual([]);
  });

  it("a wrong inverse with no third route: only the loop check sees it", () => {
    const r = reg(["temp.c", "temp.f"]);
    r.addTransition({ from: "temp.c", to: "temp.f", fn: (v) => (n(v) * 9) / 5 + 32 });
    r.addTransition({ from: "temp.f", to: "temp.c", fn: (v) => ((n(v) - 30) * 5) / 9 }); // wrong
    expect(r.checkRouteAgreement()).toEqual([]);
    expect(r.checkLoops().length).toBeGreaterThan(0);
  });

  it("a ring of twelve frames with one wrong factor: only the loop check sees it", () => {
    const ids = Array.from({ length: 12 }, (_, i) => `s${i}`);
    const r = reg(ids, [1, 2]);
    const add = (a: string, b: string, k: number) => r.addTransition({ from: a, to: b, fn: (v) => n(v) * k });
    for (let i = 0; i < 11; i++) {
      const k = i === 2 ? 10.5 : 10;
      add(ids[i], ids[i + 1], k); add(ids[i + 1], ids[i], 1 / k);
    }
    add(ids[11], ids[0], 1e-11); add(ids[0], ids[11], 1e11);
    for (const id of ids) r.addFrame({ id, tol: 1e-6, fixtures: [1, 2] });
    expect(r.checkRouteAgreement()).toEqual([]);
    expect(r.checkLoops().length).toBeGreaterThan(0);
  });
});
