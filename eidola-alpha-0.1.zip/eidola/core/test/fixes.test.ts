// Claims added 2026-10-13, each pinning a defect found while reorganising the tree.
// The surrounding suites say why the laws hold; these say where they had quietly stopped.

import { describe, expect, it } from "vitest";
import {
  Engine, Liminal, MemoryPersistence, PowerDenied, ScratchPersistence, Store, collapse,
  conformanceFrames, container, graph, makeCtx, pane, port, primUnit, wire,
} from "../src/index.js";
import { defaultHost } from "../src/defaulthost.js";
import { PrimHost } from "../src/prims.js";
import { framed, ws } from "./helpers.js";

describe("the default host exists (engine.ts imported a module the tree no longer had)", () => {
  it("an Engine built with no host runs prim bodies through the default host", () => {
    const { store, u } = ws();
    const k = u("core.const");
    const e = new Engine(store, graph({ a: pane(k, { config: 7, pinned: true }) }, []));
    const r = e.tick();
    expect(store.blob(r.sigma["a#out"])).toBe(7);
  });
  it("the default host tries authored JS first, then the starter library", () => {
    expect(defaultHost().resolve({ "@": "prim/1", op: "core.add" }, {} as never)).toBeTruthy();
    expect(() => new PrimHost().resolve({ "@": "host/1", lang: "js", src: "" })).toThrow(/PrimHost cannot run/);
  });
});

describe("a scratch store READS THROUGH — the log is the parent's plus the draft's", () => {
  it("appending in the draft does not hide what the parent already remembered", () => {
    const parent = new MemoryPersistence();
    parent.appendMem("acc", "blob:1");
    parent.appendMem("acc", "blob:2");
    const scratch = new ScratchPersistence(parent);
    expect(scratch.readMem("acc")).toEqual(["blob:1", "blob:2"]);
    scratch.appendMem("acc", "blob:3");
    // was ["blob:3"]: one local append shadowed the whole parent log, so a sum or a history
    // folded inside a draft that ticks more than once forgot everything before it
    expect(scratch.readMem("acc")).toEqual(["blob:1", "blob:2", "blob:3"]);
    expect(parent.readMem("acc")).toEqual(["blob:1", "blob:2"]); // and the parent learnt nothing
  });

  it("a draft with a running sum, ticked twice over one scratch, keeps counting", () => {
    const { store, u } = ws();
    const k = u("core.const"), sum = u("core.sum");
    store.persist.appendMem("acc", store.putBlob(100));
    const scratch = new Store(new ScratchPersistence(store.persist));
    const e = new Engine(scratch, graph(
      { one: pane(k, { config: 1 }), s: pane(sum, { mem: "acc", pinned: true }) },
      [wire(["one", "out"], ["s", "x"])],
    ), undefined, undefined, { memo: false });
    const t0 = e.tick(), t1 = e.tick(), t2 = e.tick();
    expect([t0, t1, t2].map((t) => scratch.blob(t.sigma["s#out"]))).toEqual([100, 101, 102]);
    expect(store.persist.readMem("acc").length).toBe(1);
  });
});

describe("declaring a framed interior uses the same frames the engine does", () => {
  it("collapse over a temp.c → temp.f wire declares with the atlas the engine was given", () => {
    const { store, put } = ws();
    const fr = conformanceFrames();
    const c = put(framed("core.const", { out: "temp.c" }));
    const f = put(framed("core.neg", { a: "temp.f", out: "temp.f" }));
    const root = graph({ c: pane(c, { config: 100 }), n: pane(f, { pinned: true }) }, [wire(["c", "out"], ["n", "a"])]);
    expect(() => new Engine(store, root, fr)).not.toThrow();
    const out = collapse(root, ["c", "n"], store, "box", fr);
    expect(store.hasUnit(out.unit)).toBe(true);
    const e = new Engine(store, graph({ box: pane(out.unit, { pinned: true }) }, []), fr);
    const r = e.tick();
    expect(store.blob(r.sigma["box/n#out"])).toBeCloseTo(-212, 9);
  });

  it("a framed draft declares with the atlas it is handed", () => {
    const { store, put } = ws();
    const c = put(framed("core.const", { out: "temp.c" }));
    const f = put(framed("core.neg", { a: "temp.f", out: "temp.f" }));
    const lim = new Liminal([], graph({ c: pane(c, { config: 0 }), n: pane(f) }, [wire(["c", "out"], ["n", "a"])]));
    expect(lim.declare(store, conformanceFrames())).toMatch(/^unit:/);
  });
});

// 2026-10-14 — the kernel names nothing a library should name
describe("the kernel knows no vocabulary", () => {
  it("knows no frames: with no atlas given, temp.c → temp.f has no route", () => {
    const { store, put } = ws();
    const c = put(framed("core.const", { out: "temp.c" }));
    const f = put(framed("core.neg", { a: "temp.f" }));
    expect(() => new Engine(store, graph({ c: pane(c, { config: 1 }), n: pane(f) },
      [wire(["c", "out"], ["n", "a"])]))).toThrow(/no frame route/);
  });

  it("names no folds: memFold takes a step, and a name is refused", () => {
    const ctx = makeCtx({ powers: new Set(["mem:r"]), config: null, readLog: () => [1, 2, 3],
      appendLog: () => {}, journalValue: undefined, emitWorld: () => {} });
    expect(ctx.memFold((a, v) => (a as number) + (v as number), 10)).toBe(16);
    expect(() => ctx.memFold("sum" as never, 0)).toThrow(/step function/);
  });

  it("a source may name its door (emit:clock) without the kernel knowing the door", () => {
    const ctx = makeCtx({ powers: new Set(["emit:clock"]), config: null, readLog: () => [],
      appendLog: () => {}, journalValue: 7, emitWorld: () => {} });
    expect(ctx.journal()).toBe(7);
    const none = makeCtx({ powers: new Set(["world"]), config: null, readLog: () => [],
      appendLog: () => {}, journalValue: 7, emitWorld: () => {} });
    expect(() => none.journal()).toThrow(PowerDenied);
  });
});

describe("memory is scoped by the occurrence that holds it", () => {
  it("two copies of one declared counter keep separate logs", () => {
    const { store, put } = ws();
    const one = put(primUnit("core.const"));
    const sum = put(primUnit("core.sum"));
    const inner = graph({ s: pane(sum, { mem: "acc", config: 0 }) }, [wire(["@in", "x"], ["s", "x"]), wire(["s", "out"], ["@out", "y"])]);
    const box = store.putUnit(container([port("x", "in", "num"), port("y", "out", "num")], inner));
    const e = new Engine(store, graph({
      k: pane(one, { config: 1 }),
      a: pane(box, { pinned: true }), b: pane(box, { pinned: true }),
    }, [wire(["k", "out"], ["a", "x"]), wire(["k", "out"], ["b", "x"])]));
    let r = e.tick(); r = e.tick(); r = e.tick();
    expect(store.blob(r.sigma["a/s#out"])).toBe(2);   // its own two writes, not four
    expect(store.blob(r.sigma["b/s#out"])).toBe(2);
    expect(store.persist.readMem("a/acc").length).toBe(3);
  });

  it("panes inside one occurrence can still share a log on purpose; the root is unchanged", () => {
    const { store, put } = ws();
    const sum = put(primUnit("core.sum"));
    const src = put(primUnit("core.source"));
    const e = new Engine(store, graph({
      s: pane(src), a: pane(sum, { mem: "shared", config: 0, pinned: true }),
      b: pane(sum, { mem: "shared", config: 0, pinned: true }),
    }, [wire(["s", "out"], ["a", "x"]), wire(["s", "out"], ["b", "x"])]));
    e.tick({ journal: { "s#out": 1 } });
    expect(store.persist.readMem("shared").length).toBe(2);
  });

  it("a draft played on its own reads the logs of the occurrence it came from", () => {
    const { store, put } = ws();
    const sum = put(primUnit("core.sum"));
    store.persist.appendMem("box/acc", store.putBlob(5));
    const lim = new Liminal([], graph({ s: pane(sum, { mem: "acc", config: 0 }) }, []));
    const { result, scratch } = lim.play(store, {}, { observed: ["s"] }, undefined, "box");
    expect(scratch.blob(result.sigma["s#out"])).toBe(5);
  });
});

describe("hosts say what actually went wrong, and can run bodies they shipped with", () => {
  it("a JS body that fails to compile reports that, not that the starter library declined it", async () => {
    const { defaultHost: dh } = await import("../src/defaulthost.js");
    const unit = { "@": "unit/1", ports: [], powers: [], cls: "pure", body: null, graph: null } as never;
    expect(() => dh().resolve({ "@": "host/1", lang: "js", src: "return (" }, unit)).toThrow(/failed to compile/);
  });
  it("a registered body runs without being compiled — identity is still its text", async () => {
    const { JsHost, registerCompiled } = await import("../src/hosts.js");
    const src = "return (i) => ({ out: 'never compiled' })";
    registerCompiled(src, (i: unknown) => ({ out: ["precompiled", i] }));
    const unit = { "@": "unit/1", ports: [], powers: [], cls: "pure", body: null, graph: null } as never;
    const def = new JsHost().resolve({ "@": "host/1", lang: "js", src }, unit);
    expect((def.cook!({}, {} as never) as { out: unknown[] }).out[0]).toBe("precompiled");
  });
});

describe("wrapping a draft (2026-10-14)", () => {
  it("collapse as a draft may hold a draft, and declaring later seals both", () => {
    const { store, put } = ws();
    const k = put(primUnit("core.const"));
    const inner = store.putDraft(container([port("y", "out", "any")],
      graph({ c: pane(k, { config: 3 }) }, [wire(["c", "out"], ["@out", "y"])])));
    const root = graph({ d: pane(inner, { pinned: true }) }, []);
    const out = collapse(root, ["d"], store, "box", undefined, { draft: true });
    expect(Store.isDraft(out.unit)).toBe(true);
    const sealed = store.declare(out.unit);
    expect(sealed).toMatch(/^unit:/);
    expect(Object.values(store.unit(sealed).graph!.panes).every((p) => !Store.isDraft(p.unit))).toBe(true);
  });
});

describe("drafts keep their own time (2026-10-14)", () => {
  it("a counter inside a draft keeps counting across ticks, and none of it reaches the store", () => {
    const { store, put } = ws();
    const k = put(primUnit("core.const"));
    const sum = put(primUnit("core.sum"));
    const lim = new Liminal([], graph({ k: pane(k, { config: 1 }), s: pane(sum, { mem: "acc", config: 0 }) },
      [wire(["k", "out"], ["s", "x"])]));
    let last: unknown;
    for (let i = 0; i < 4; i++) {
      const { result, scratch } = lim.play(store, {}, { observed: ["s"] });
      last = scratch.blob(result.sigma["s#out"]);
    }
    expect(last).toBe(3);                          // read before write: 0,1,2,3
    expect(store.persist.readMem("acc").length).toBe(0);
  });

  it("a log can be ended with its binding", () => {
    const p = new MemoryPersistence();
    p.appendMem("a", "blob:x"); p.dropMem("a");
    expect(p.readMem("a")).toEqual([]);
    expect(p.memAddrs()).toEqual([]);
  });
});
