// Law 4, the floor. A context carries exactly the powers its boundary declares.
//
// Note what is absent: there is no `now` for anybody. Time is not a power; a clock is a
// source or it does not exist (Law 5).

import { Value } from "./canon.js";

export class PowerDenied extends Error {
  constructor(power: string) {
    super(`PowerDenied: ${power}`);
  }
}

/**
 * A step of a fold over a memory log: the accumulator so far and the next entry, giving the
 * next accumulator. The core names no folds. "Last", "sum" and "the whole list" are ordinary
 * code in whatever library uses them; the core only walks the log. A left fold with a step is
 * also exactly the shape an incremental fold needs (F5): acc(n+1) = step(acc(n), entry(n+1)).
 */
export type Step = (acc: Value, entry: Value) => Value;

export interface Ctx {
  /** mem:r — fold over this binding's log as it stood at the start of the tick. */
  memFold(step: Step, init: Value): Value;
  /** mem:w — append to this binding's log. Buffered until pass D. */
  memAppend(v: Value): void;
  /** emit — this source's journalled emission for this tick, or undefined. A source may name
   *  which door its novelty comes through (`emit:clock`, `emit:typed`…). The door is content,
   *  part of the boundary; the core does not know any door by name, only the family. */
  journal(): Value | undefined;
  /** world — perform an effect. */
  world(v: Value): void;
  /** the binding's config, always available; it is content, not a power. */
  config: Value | null;
}

export interface CtxBacking {
  powers: Set<string>;
  config: Value | null;
  readLog: () => Value[];
  appendLog: (v: Value) => void;
  journalValue: Value | undefined;
  emitWorld: (v: Value) => void;
}

export function makeCtx(b: CtxBacking): Ctx {
  const need = (p: string) => {
    if (!b.powers.has(p)) throw new PowerDenied(p);
  };
  const hasFamily = (p: string) => b.powers.has(p) || [...b.powers].some((x) => x.startsWith(p + ":"));
  return {
    config: b.config,
    memFold(step, init) {
      need("mem:r");
      if (typeof step !== "function")
        throw new Error("memFold takes a step function (acc, entry) => acc — the core names no folds");
      let acc = init;
      for (const v of b.readLog()) acc = step(acc, v);
      return acc;
    },
    memAppend(v) {
      need("mem:w");
      b.appendLog(v);
    },
    journal() {
      if (!hasFamily("emit")) throw new PowerDenied("emit");
      return b.journalValue;
    },
    world(v) {
      need("world");
      b.emitWorld(v);
    },
  };
}
