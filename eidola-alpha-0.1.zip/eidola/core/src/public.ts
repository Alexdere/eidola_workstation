// The alpha public surface of @eidola/core (docs/adr/0006). Suites, tools and third-party code
// import from here only. Everything else is reachable as "@eidola/core/internal" (the base uses
// it today) and may change between alpha releases without notice.

export { type Value, CanonError, isMap, canon, canonHex, hash, sameValue } from "./canon.js";
export {
  type Dir, type Cls, type Port, type Body, type Unit, type Pane, type Wire, type Graph, IN, OUT,
  port, leaf, container, pane, wire, graph, unitId, blobId, graphHash, serializeGraph, findPort,
  inPorts, outPorts,
} from "./model.js";
export { Store } from "./store.js";
export { type PersistencePort, MemoryPersistence, type LeafDef, type ExecutionPort } from "./ports.js";
export { type TickInput, type TickResult, type Command, type Event, Engine, replay } from "./engine.js";
export { type Frame, type Transition, FrameError, FrameRegistry, conformanceFrames } from "./frames.js";
export { type WorkspaceSpec, loadWorkspace, dumpWorkspace } from "./workspace.js";
export { type VSpec, fromSpec, toSpec } from "./vspec.js";
export { Liminal, melt, meltSelection, collapse } from "./liminal.js";
export { GraphError } from "./flatten.js";
export { PowerDenied } from "./caps.js";
export { primUnit, PrimHost } from "./prims.js";
export { JsHost } from "./hosts.js";
export { defaultHost } from "./defaulthost.js";
