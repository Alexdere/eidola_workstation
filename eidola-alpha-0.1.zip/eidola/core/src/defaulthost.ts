// The host an Engine gets when nobody hands it one: authored JS bodies first, then the
// bundled starter library. Kept in its own module so hosts.ts never has to import the
// starter library — the dependency points from the default, not from the port.

import { Hosts, JsHost } from "./hosts.js";
import { PrimHost } from "./prims.js";

export function defaultHost(): Hosts {
  return new Hosts([new JsHost(), new PrimHost()]);
}
