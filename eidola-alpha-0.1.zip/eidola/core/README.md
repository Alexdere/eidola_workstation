# @eidola/core

The Eidola kernel in TypeScript: canonical encoding and hash (CVE/1), units, panes and wires,
flatten, the five-pass tick, powers, frames, liminal space, the store. Zero runtime dependencies,
no DOM, no Web Crypto.

```ts
import { Store, MemoryPersistence, loadWorkspace, Engine } from "@eidola/core";

const store = new Store(new MemoryPersistence());
const { root } = loadWorkspace(workspaceJson, store);
const engine = new Engine(store, root);
const r = engine.tick({ observed: ["total"], journal: { "reading#out": 3 } });
```

`@eidola/core` is the alpha public API (`src/public.ts`). `@eidola/core/internal` exposes every
module and may change between alpha releases (ADR-0006). Tests: `npx vitest run` (72 claims).
